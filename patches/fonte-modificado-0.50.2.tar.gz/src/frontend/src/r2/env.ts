/** 2R Tools: o BoardRipper está rodando dentro do app 2R Tools (SDS)?
 *  O app injeta `window.__2rAcervo` antes da página carregar. */
export interface R2Acervo {
  list(q: string): Promise<{ rows: R2Row[]; boards: number; pdfs: number; ready: boolean }>;
  open(id: string): Promise<{ ok?: boolean; pdf?: boolean; error?: string }>;
  known(): Promise<{ boards: Record<string, { mac_model: string; emc: string; model_name: string; year: string }>;
                     models: Record<string, string>; credit: string; ext: string[] }>;
  upload(file: File, fields: Record<string, string>): Promise<{ ok?: boolean; error?: string; detail?: string }>;
}
export interface R2Row { id: string; kind: 'board' | 'pdf'; name: string; folder: string; pdf: boolean; by?: string }

export function r2(): R2Acervo | null {
  const w = (typeof window !== 'undefined' ? window : undefined) as unknown as { __2rAcervo?: R2Acervo } | undefined;
  return w?.__2rAcervo ?? null;
}
export const IS_2R = r2() !== null;

/** Funções Beta que o app liga/desliga em Configurações › Ferramentas › Boardview
 *  (Roger, 10/10/2026: «marcar como beta e a gente desativa no painel»).
 *  Sem o app (navegador), tudo ligado. */
export function beta(key: 'medicoes' | 'curvas' | 'teleguiado' | 'mcp'): boolean {
  const b = (typeof window !== 'undefined' ? (window as unknown as { __2rBeta?: Record<string, boolean> }).__2rBeta : undefined);
  return !b || b[key] !== false;
}
