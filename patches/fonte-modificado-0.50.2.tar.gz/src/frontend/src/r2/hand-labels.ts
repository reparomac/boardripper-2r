// @ts-nocheck
/* eslint-disable */
// 2R Tools — etiquetas da placa (cards do diodo, nome+valor dentro do componente, giro 90°). Portado VERBATIM do bundle 0.48.0
// editado à mão (20/10 a 27/10/2026). Usado por renderer/label-overlay.ts.
import { boardStore as U } from '../store/board-store';
const R2NET = { circleNet: 1, pinNet: 1, twoPinNet: 1 };
/*2R 27/10/2026 (Roger: «componentes de tamanho 0201, precisa diminuir a fonte do valor do componente, está truncado» / «tem vários componentes que estão cortados»): o valor do componente encolhe até caber na largura do corpo do componente na tela, e nome + valor ficam centralizados juntos dentro dele; window.__r2ValorFitOff=true volta ao antigo*/ /*2R 27/10/2026 (Roger: «nesses casos, pode girar o card e os textos em 90 graus, para manter o padrão» / «o card está cobrindo os textos»): componente de 2 pinos em pé (mais alto que largo na tela) → nome, valor e tensão giram 90°; o card de leitura do pino gira junto e vai para fora do corpo, ao lado do pino*/ let R2rs = 0,
  R2dv = null;
function R2vertBox(b, m) {
  try {
    if (window.__r2Gira90Off) return null;
    const P = U.activeTab?.board?.parts?.[b.partIndex],
      B = P && P.__r2box;
    if (!B || !P.pins || P.pins.length !== 2) return null;
    const c = [
        [B.x, B.y],
        [B.x + B.w, B.y],
        [B.x, B.y + B.h],
        [B.x + B.w, B.y + B.h],
      ].map((v) => [m.a * v[0] + m.c * v[1] + m.tx, m.b * v[0] + m.d * v[1] + m.ty]),
      X = c.map((v) => v[0]),
      Y = c.map((v) => v[1]),
      x0 = Math.min(...X),
      x1 = Math.max(...X),
      y0 = Math.min(...Y),
      y1 = Math.max(...Y);
    return {
      x0,
      x1,
      y0,
      y1,
      vert: x1 - x0 > (y1 - y0) * 1.25,
      alto: y1 - y0 > (x1 - x0) * 1.25,
    }; /*27/10 (Roger: «era pra ser só os componentes que estavam na horizontal, então o card teria de ser na vertical»): deitado (mais largo que alto) → card em pé*/
  } catch {
    return null;
  }
}
let R2vf = null;
function R2valFit(r, b, m, N, G) {
  try {
    if (window.__r2ValorFitOff) return null;
    const v = window.__r2Valores && window.__r2Valores[b.text],
      pz = v ? String(v).split(" ") : [],
      tx = pz[0] || "",
      /*27/10/2026 (Roger: «nos capacitores, add a tensão também»): capacitor ganha uma 3ª linha com a tensão (ex.: 12PF / 25V)*/ tv =
        /^C/i.test(b.text) && pz[1] && /V$/i.test(pz[1]) ? pz[1] : "";
    const P = U.activeTab?.board?.parts?.[b.partIndex],
      B = P && P.__r2box;
    let wS = 1 / 0,
      hS = 1 / 0;
    B &&
      B.w > 0 &&
      B.h > 0 &&
      ((wS = Math.abs(m.a) * B.w + Math.abs(m.c) * B.h), (hS = Math.abs(m.b) * B.w + Math.abs(m.d) * B.h));
    /*Roger escolheu: só o card na vertical; os textos ficam deitados (window.__r2GiraTexto=true gira os textos também)*/ /*27/10: componente deitado de 2 pinos → os cards ficam em cima dos pads; nome, valor e tensão usam só o meio do corpo (entre os pads) e encolhem para caber*/ if (
      !window.__r2Gira90Off &&
      P &&
      P.pins &&
      P.pins.length === 2 &&
      wS < 1 / 0 &&
      wS > hS * 1.25
    )
      wS *= 0.5;
    if (!window.__r2Gira90Off && P && P.pins && P.pins.length === 2 && hS < 1 / 0 && hS > wS * 1.25) hS *= 0.5;
    const rot =
      window.__r2GiraTexto === !0 && !window.__r2Gira90Off && P && P.pins && P.pins.length === 2 && hS > wS * 1.25;
    if (rot) {
      const t = wS;
      wS = hS;
      hS = t;
    }
    if (!(wS < 1 / 0)) return tx ? { tx, tv, nv: N, nn: N, dy: -(N * 0.5 + N * 0.6 + (tv ? N * 1.1 : 0)) / 2 } : null;
    let nn = N;
    G > wS * 0.92 && (nn = (N * wS * 0.92) / G);
    if (!tx) {
      nn = Math.min(nn, hS * 0.85);
      return nn < N || rot ? { tx: "", tv: "", rot, nv: 0, nn: Math.max(3, Math.round(nn * 10) / 10), dy: 0 } : null;
    }
    const f0 = r.font;
    r.font = `700 ${N}px "Source Sans 3",Arial,sans-serif`;
    const Gv = Math.max(r.measureText(tx).width, tv ? r.measureText(tv).width : 0) || 1;
    r.font = f0;
    let nv = N;
    Gv > wS * 0.9 && (nv = (N * wS * 0.9) / Gv);
    nv = Math.min(nv, nn);
    const alt = () => nn + nv * 1.2 + (tv ? nv * 1.1 : 0);
    if (alt() > hS * 1.1) {
      const k = Math.max(0.45, (hS * 1.1) / alt());
      nv *= k;
      nn *= k;
    }
    const dy = -(nn * 0.5 + nv * 0.6 + (tv ? nv * 1.1 : 0)) / 2;
    return { tx, tv, rot, nv: nv >= 3 ? Math.round(nv * 10) / 10 : 0, nn: Math.max(3, Math.round(nn * 10) / 10), dy };
  } catch {
    return null;
  }
}
function R2plaq(r, x, y, w, h, k) {
  ((r.fillStyle = "rgba(150,150,150,0.92)"),
    r.beginPath(),
    r.roundRect ? r.roundRect(x, y, w, h, k) : r.rect(x, y, w, h),
    r.fill());
}
export { R2NET, R2vertBox, R2valFit, R2plaq };
