/**
 * 2R Tools: sequência de mapeamento e ponto de medição mais próximo (Roger, 10/10/2026).
 *
 * «Quando for mapear o componente, sempre começa pelo pino 1 e a sequência é
 *  sempre anti-horário… num conector FPC, ímpares de um lado e pares do outro,
 *  então precisa configurar para seguir os pares ou os ímpares primeiro.»
 * «Muitas vezes o componente está soldado e não temos acesso ao pad, mas no BDV
 *  ele já indica o ponto mais próximo para medição.»
 */
import { boardStore } from '../store/board-store';
import { getFormat } from '../parsers/registry';
import type { BoardData, Part, Pin } from '../parsers/types';

export type SeqRule = 'ccw' | 'cw' | 'odd' | 'even' | 'num';
export const SEQ_LABEL: Record<SeqRule, string> = {
  ccw: 'Pino 1, anti-horário (padrão)',
  cw: 'Pino 1, horário',
  odd: 'Ímpares primeiro, depois pares (FPC)',
  even: 'Pares primeiro, depois ímpares (FPC)',
  num: 'Ordem dos números (1, 2, 3…)',
};

const RULE_KEY = '2r-seq-rule';
const AUTO_KEY = '2r-seq-auto';
const SKIPGND_KEY = '2r-seq-skipgnd';
const get = (k: string, d: string) => { try { return localStorage.getItem(k) ?? d; } catch { return d; } };
const put = (k: string, v: string) => { try { localStorage.setItem(k, v); } catch { /* */ } };

export const seqPrefs = {
  get rule(): SeqRule { return (get(RULE_KEY, 'ccw') as SeqRule); },
  set rule(v: SeqRule) { put(RULE_KEY, v); },
  get auto(): boolean { return get(AUTO_KEY, '1') === '1'; },
  set auto(v: boolean) { put(AUTO_KEY, v ? '1' : '0'); },
  get skipGnd(): boolean { return get(SKIPGND_KEY, '0') === '1'; },
  set skipGnd(v: boolean) { put(SKIPGND_KEY, v ? '1' : '0'); },
};

/** Regra escolhida por componente (ex.: J5 = FPC, ímpares primeiro). */
const PART_RULE_KEY = '2r-seq-rule-part';
function partRules(): Record<string, SeqRule> {
  try { return JSON.parse(localStorage.getItem(PART_RULE_KEY) || '{}'); } catch { return {}; }
}
export function ruleFor(board: string, part: string): SeqRule {
  return partRules()[board + '|' + part] ?? seqPrefs.rule;
}
export function setRuleFor(board: string, part: string, rule: SeqRule) {
  const r = partRules(); r[board + '|' + part] = rule;
  try { localStorage.setItem(PART_RULE_KEY, JSON.stringify(r)); } catch { /* */ }
}

/** Número do pino para ordenar: "12" → 12, "A3" (BGA) → linha A coluna 3. */
function pinKey(p: Pin): [number, number] {
  const s = (p.number || p.name || '').trim().toUpperCase();
  const n = /^\d+$/.exec(s);
  if (n) return [0, parseInt(s, 10)];
  const m = /^([A-Z]+)(\d+)$/.exec(s);
  if (m) {
    let row = 0; for (const c of m[1]) row = row * 26 + (c.charCodeAt(0) - 64);
    return [row, parseInt(m[2], 10)];
  }
  const d = /(\d+)/.exec(s);
  return [1e6, d ? parseInt(d[1], 10) : 0];
}
const byNumber = (a: Pin, b: Pin) => { const x = pinKey(a), y = pinKey(b); return x[0] - y[0] || x[1] - y[1]; };

/** Sentido em que a numeração de um CI corre ao redor do centro: +1, −1 ou 0 (não dá para dizer). */
function numberingWinding(part: Part): number {
  const nums = part.pins.map((p, i) => ({ k: pinKey(p), i })).filter(o => o.k[0] === 0);
  if (nums.length < 6 || nums.length > 400) return 0;
  nums.sort((a, b) => a.k[1] - b.k[1]);
  let cx = 0, cy = 0;
  for (const p of part.pins) { cx += p.position.x; cy += p.position.y; }
  cx /= part.pins.length; cy /= part.pins.length;
  const ang = nums.map(o => Math.atan2(part.pins[o.i].position.y - cy, part.pins[o.i].position.x - cx));
  let sum = 0, pos = 0, neg = 0;
  for (let k = 1; k < ang.length; k++) {
    let d = ang[k] - ang[k - 1];
    while (d > Math.PI) d -= 2 * Math.PI;
    while (d <= -Math.PI) d += 2 * Math.PI;
    sum += d;
    if (d > 1e-6) pos++; else if (d < -1e-6) neg++;
  }
  const steps = pos + neg;
  if (!steps || Math.abs(sum) < Math.PI * 1.4 || Math.max(pos, neg) / steps < 0.8) return 0;
  return sum > 0 ? 1 : -1;
}

const calib = new WeakMap<BoardData, { top: number; bottom: number }>();

/**
 * Sinal do ângulo que é «anti-horário» para quem olha o componente. Cada formato
 * guarda o eixo Y de um jeito e o lado de baixo vem espelhado, então a própria
 * placa calibra: nos CIs a numeração corre no sentido anti-horário (padrão da
 * indústria) e a maioria dos CIs de cada lado decide. Sem CIs, vale o eixo Y do formato.
 */
function screenSense(board: BoardData, part: Part): number {
  let c = calib.get(board);
  if (!c) {
    const votes = { top: 0, bottom: 0 };
    for (const p of board.parts) if (p.side === 'top' || p.side === 'bottom') votes[p.side] += numberingWinding(p);
    const flip = board.flipY !== undefined ? board.flipY : (getFormat(board.format)?.flipY ?? false);
    const guessTop = flip ? 1 : -1;
    const top = votes.top ? Math.sign(votes.top) : votes.bottom ? -Math.sign(votes.bottom) : guessTop;
    const bottom = votes.bottom ? Math.sign(votes.bottom) : -top;
    c = { top, bottom };
    calib.set(board, c);
  }
  return part.side === 'bottom' ? c.bottom : c.top;
}

/** Índices dos pinos do componente na ordem de mapeamento. */
export function pinOrder(board: BoardData, part: Part, rule: SeqRule, skipGnd = false): number[] {
  let idx = part.pins.map((_, i) => i);
  if (skipGnd) idx = idx.filter(i => !/^GND$|^VSS$|^PGND$|^AGND$/i.test(part.pins[i].net || ''));
  const pins = part.pins;
  const numeric = [...idx].sort((a, b) => byNumber(pins[a], pins[b]));
  if (rule === 'num') return numeric;
  if (rule === 'odd' || rule === 'even') {
    const isOdd = (i: number) => pinKey(pins[i])[1] % 2 === 1;
    const odd = numeric.filter(isOdd), even = numeric.filter(i => !isOdd(i));
    return rule === 'odd' ? [...odd, ...even] : [...even, ...odd];
  }
  if (idx.length < 3) return numeric;
  // Anti-horário / horário em volta do centro, começando pelo pino 1.
  let cx = 0, cy = 0;
  for (const i of idx) { cx += pins[i].position.x; cy += pins[i].position.y; }
  cx /= idx.length; cy /= idx.length;
  const sense = screenSense(board, part) * (rule === 'cw' ? -1 : 1);
  const first = numeric[0];
  const ang = (i: number) => Math.atan2((pins[i].position.y - cy) * sense, pins[i].position.x - cx);
  const a0 = ang(first);
  const rel = (i: number) => { let d = ang(i) - a0; while (d < -1e-6) d += 2 * Math.PI; return d; };
  const dist = (i: number) => Math.hypot(pins[i].position.x - cx, pins[i].position.y - cy);
  let maxR = 0; for (const i of idx) maxR = Math.max(maxR, dist(i));
  // Pad central (térmico) e pinos internos vão para o fim, na ordem dos números.
  const outer = idx.filter(i => dist(i) >= maxR * 0.35);
  const inner = numeric.filter(i => dist(i) < maxR * 0.35);
  outer.sort((a, b) => (a === first ? -1 : b === first ? 1 : rel(a) - rel(b) || dist(b) - dist(a)));
  return [...outer, ...inner];
}

/** O pino seguinte (ou anterior) na sequência do componente selecionado. */
export function stepPin(dir: 1 | -1): boolean {
  const tab = boardStore.activeTab;
  const sel = tab?.selection;
  if (!tab?.board || sel?.partIndex == null) return false;
  const part = tab.board.parts[sel.partIndex];
  if (!part) return false;
  const order = pinOrder(tab.board, part, ruleFor(tab.fileName, part.name), seqPrefs.skipGnd);
  if (!order.length) return false;
  const at = sel.pinIndex == null ? -1 : order.indexOf(sel.pinIndex);
  const next = at < 0 ? (dir > 0 ? 0 : order.length - 1) : at + dir;
  if (next < 0 || next >= order.length) {
    boardStore.addToast(dir > 0 ? `${part.name}: último pino da sequência.` : `${part.name}: primeiro pino.`, 'info');
    return false;
  }
  boardStore.selectPin(sel.partIndex, order[next]);
  return true;
}

export interface ProbePoint {
  partIndex: number; pinIndex: number; part: string; pin: string;
  mm: number; side: Part['side']; kind: 'teste' | 'passivo' | 'outro';
}

const IC_RE = /^(U|Q|J|CN|BGA|IC)\d/i;

/**
 * Pontos onde dá para medir a mesma net do pino selecionado, do mais perto ao
 * mais longe: ponto de teste (1 pino) e passivos (capacitor, resistor, bobina),
 * que ficam com o terminal exposto. Componentes com muitos pinos ficam de fora.
 */
export function probePoints(max = 4): { from: string; net: string; points: ProbePoint[] } | null {
  const tab = boardStore.activeTab;
  const sel = tab?.selection;
  const board = tab?.board;
  if (!board || sel?.partIndex == null || sel.pinIndex == null || sel.pinIndex < 0) return null;
  const part = board.parts[sel.partIndex];
  const pin = part?.pins[sel.pinIndex];
  if (!part || !pin) return null;
  const from = `${part.name}.${pin.number || pin.name}`;
  if (!pin.net || /^(NC|N\/C|NO_?CONNECT)$/i.test(pin.net)) return { from, net: pin.net || '', points: [] };
  const net = board.nets.get(pin.net);
  if (!net) return { from, net: pin.net, points: [] };
  const best = new Map<number, ProbePoint>();
  for (const { partIndex, pinIndex } of net.pinIndices) {
    if (partIndex === sel.partIndex) continue;
    const p = board.parts[partIndex];
    if (!p || p.hidden) continue;
    const n = p.pins.length;
    const kind: ProbePoint['kind'] = n === 1 ? 'teste' : n <= 3 && !IC_RE.test(p.name) ? 'passivo' : 'outro';
    if (kind === 'outro') continue;
    const q = p.pins[pinIndex];
    const mm = Math.hypot(q.position.x - pin.position.x, q.position.y - pin.position.y) * 0.0254;
    const cur = best.get(partIndex);
    if (!cur || mm < cur.mm) best.set(partIndex, { partIndex, pinIndex, part: p.name, pin: q.number || q.name, mm, side: p.side, kind });
  }
  const same = (s: Part['side']) => s === part.side || s === 'both' || part.side === 'both';
  const points = [...best.values()].sort((a, b) =>
    (same(a.side) ? 0 : 1) - (same(b.side) ? 0 : 1) || a.mm - b.mm).slice(0, max);
  return { from, net: pin.net, points };
}
