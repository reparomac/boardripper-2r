/**
 * 2R Tools: medições do multímetro (Rigol DM858E / i2C C09) ligadas ao pino
 * selecionado na placa (Roger, 10/10/2026). A leitura estável entra na lista
 * com o pino, a net, o valor esperado (OpenBoardData), o resultado, quem mediu
 * e a hora. Tolerância (Roger): diodo ±20%; tensão e resistência quase nenhuma (±2%).
 *
 * Brainstorm do Roger (10/10/2026, 21:03): «gravar automaticamente… com um
 * aviso sonoro quando está dentro da margem (agradável), ou se estiver muito
 * fora, um aviso mais tenso ou grave… configurar o tempo de captura automática
 * ou manual, com a opção de configurar quais teclas… editar e capturar
 * novamente, deletar… sempre ter os dados de quem capturou com a data e o horário».
 */
import { boardStore } from '../store/board-store';
import { obdBoardNumberFor, obdNetLookup } from '../store/obd-store';
import { IS_2R, beta } from './env';
import { seqPrefs, stepPin } from './probe-seq';
import { guideStore } from './guide-store';
import { playOk, playWarn, playBad, playTick, playSaved, playNotSaved } from './sounds';

export type Mode = 'diodo' | 'tensao' | 'resistencia';
export interface Medicao {
  t: number; board: string; part: string; pin: string; net: string;
  mode: Mode; value: number; unit: string; expected: string; status: 'ok' | 'fora' | 'sem'; source: string;
  /** Medido no ponto mais próximo da mesma net (ex.: «C12.1»), quando o pad estava inacessível. */
  via?: string;
  /** Quem mediu (nome do técnico pelo PIN, senão a conta). */
  by?: string;
  /** Valor corrigido à mão (o original fica em `orig`). */
  edited?: boolean; orig?: number;
  /** Identidade da medição entre os computadores da loja e quando mudou por último. */
  id?: string; upd?: number; del?: boolean;
}
export interface MeterStatus { state: string; text: string; idn?: string; kind?: string }

/** Como a leitura entra na lista. */
export interface CapturePrefs {
  auto: boolean;        // true: grava sozinho quando a leitura firma
  holdMs: number;       // quanto tempo a leitura precisa ficar parada
  key: string;          // tecla da captura manual (KeyboardEvent.code)
  /** Som da leitura: dentro da margem / um pouco fora / muito fora (toca quando a leitura firma). */
  sound: boolean;
  /** Som da gravação: gravou / não gravou. */
  soundSave: boolean;
}
const CAP_KEY = '2r-medicoes-captura';
// 2R 31/10/2026 (Roger): captura com a leitura firme por 2 s (antes 1 s)
const DEFAULT_CAP: CapturePrefs = { auto: true, holdMs: 2000, key: 'Enter', sound: true, soundSave: true };

const KEY = '2r-medicoes';
const TOL_KEY = '2r-medicoes-tol';
export const DEFAULT_TOL: Record<Mode, number> = { diodo: 20, tensao: 2, resistencia: 2 };

const PEND_KEY = '2r-medicoes-pend';
const newId = () => `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
let list: Medicao[] = (() => { try { return JSON.parse(localStorage.getItem(KEY) || '[]'); } catch { return []; } })();
/** Medições antigas (antes da pasta da loja) ganham identidade e vão para o envio. */
let pend: Medicao[] = (() => { try { return JSON.parse(localStorage.getItem(PEND_KEY) || '[]'); } catch { return []; } })();
list = list.map(m => { if (m.id) return m; const n = { ...m, id: newId(), upd: m.t }; pend.push(n); return n; });
/** «loja» = histórico na pasta da loja; «local» = só neste computador; '' = ainda não sabe. */
let where = '';
let live: { value: number | null; unit: string; text: string } | null = null;
let status: MeterStatus = { state: 'off', text: 'Desligado' };
/** Ponto alternativo escolhido para o pino atual («medir por aqui»). */
let via: { pin: string; at: string } | null = null;
/** «Medir de novo»: a próxima leitura desse pino substitui a linha antiga. */
let redo: { t: number; key: string } | null = null;
let who = '';
let rev = 0;
const subs = new Set<() => void>();
const emit = () => { rev++; subs.forEach(f => f()); };
const save = () => {
  try { localStorage.setItem(KEY, JSON.stringify(list.slice(0, 2000))); localStorage.setItem(PEND_KEY, JSON.stringify(pend.slice(-3000))); } catch { /* */ }
};

// ── pasta da loja: os computadores veem o mesmo histórico (core/medicoes.py) ──
function push(recs: Medicao[]) {
  if (!recs.length) return;
  const ids = new Set(recs.map(r => r.id));
  pend = [...pend.filter(p => !ids.has(p.id)), ...recs];
  save();
  void flush();
}
let flushing = false;
async function flush() {
  const api = meterApi();
  if (!api?.histSave || flushing || !pend.length) return;
  flushing = true;
  const batch = pend.slice(0, 300);
  try {
    const r = await api.histSave(batch);
    if (r?.ok) {
      const done = new Set(batch.map(b => `${b.id}|${b.upd}`));
      pend = pend.filter(p => !done.has(`${p.id}|${p.upd}`));
      if (r.where) where = r.where;
      save(); emit();
    }
  } catch { /* sem conexão: tenta de novo depois */ }
  flushing = false;
  if (pend.length && batch.length === 300) void flush();
}
let pulling = false;
/** Traz da pasta da loja as medições da placa aberta (de todos os computadores). */
async function pull(board: string) {
  const api = meterApi();
  if (!api?.histList || !board || pulling) return;
  pulling = true;
  try {
    const r = await api.histList(board);
    if (r && Array.isArray(r.rows)) {
      if (r.where) where = r.where;
      const mine = new Map(pend.filter(p => p.board === board).map(p => [p.id, p]));
      const merged = new Map<string, Medicao>();
      for (const m of r.rows as Medicao[]) if (m.id) merged.set(m.id, m);
      for (const [id, p] of mine) {                     // o que ainda não subiu manda
        const cur = merged.get(id!);
        if (!cur || (p.upd ?? 0) >= (cur.upd ?? 0)) merged.set(id!, p);
      }
      const rows = [...merged.values()].filter(m => !m.del).sort((a, b) => b.t - a.t);
      const before = JSON.stringify(list.filter(m => m.board === board).map(m => m.id + ':' + m.upd));
      const after = JSON.stringify(rows.map(m => m.id + ':' + m.upd));
      if (before !== after) {
        list = [...rows, ...list.filter(m => m.board !== board)].sort((a, b) => b.t - a.t);
        save(); emit();
      } else if (r.where) emit();
    }
  } catch { /* */ }
  pulling = false;
}
function syncTick() {
  // checkup: com a tela da placa escondida (outra página do SDS) não vai à pasta da loja
  if (document.hidden && !pend.length) return;
  void flush();
  const b = boardStore.activeTab?.fileName;
  if (b) void pull(b);
}

function loadCap(): CapturePrefs {
  try { return { ...DEFAULT_CAP, ...JSON.parse(localStorage.getItem(CAP_KEY) || '{}') }; } catch { return { ...DEFAULT_CAP }; }
}
let cap = loadCap();

export const meterStore = {
  subscribe(f: () => void) { subs.add(f); return () => { subs.delete(f); }; },
  /** Muda a cada alteração (para o useSyncExternalStore). */
  get rev() { return rev; },
  get list() { return list; },
  get live() { return live; },
  /** 2R 30/10/2026: última leitura de cada aparelho (rigol / i2c), com o modo e se ele grava nesse modo. */
  get liveBy() { return liveBy; },
  get status() { return status; },
  get via() { return via; },
  get redo() { return redo; },
  get who() { return who; },
  get where() { return where; },
  get pending() { return pend.length; },
  /** Medições da placa aberta (ou todas, sem placa aberta). */
  get shown() { const b = boardStore.activeTab?.fileName; return b ? list.filter(m => m.board === b) : list; },
  setVia(v: { pin: string; at: string } | null) { via = v; emit(); },
  /** Apaga as medições da placa aberta (em todos os computadores da loja). */
  clear() {
    const now = Date.now();
    const gone = meterStore.shown.map(m => ({ ...m, del: true, upd: now }));
    const ids = new Set(gone.map(m => m.id));
    list = list.filter(m => !ids.has(m.id)); redo = null;
    push(gone); emit();
  },
  remove(t: number) {
    const m = list.find(x => x.t === t);
    list = list.filter(x => x.t !== t); if (redo?.t === t) redo = null;
    if (m) push([{ ...m, del: true, upd: Date.now() }]);
    save(); emit();
  },
  /** Corrige o valor à mão (fica marcado como editado). */
  edit(t: number, value: number) {
    let changed: Medicao | null = null;
    list = list.map(m => m.t !== t ? m : (changed = judge({ ...m, value, edited: true, orig: m.orig ?? m.value, upd: Date.now() })));
    if (changed) push([changed]);
    save(); emit();
  },
  /** Medir de novo: seleciona o pino e a próxima leitura dele substitui esta linha. */
  remeasure(t: number) {
    const m = list.find(x => x.t === t);
    const tab = boardStore.activeTab;
    if (!m) return;
    redo = { t, key: `${m.board}|${m.part}|${m.pin}` };
    if (tab?.board && tab.fileName === m.board) {
      const pi = tab.board.parts.findIndex(p => p.name === m.part);
      const qi = pi >= 0 ? tab.board.parts[pi].pins.findIndex(p => (p.number || p.name) === m.pin) : -1;
      if (pi >= 0 && qi >= 0) boardStore.selectPin(pi, qi);
    }
    emit();
  },
  cancelRedo() { redo = null; emit(); },
  tolerance(): Record<Mode, number> {
    try { return { ...DEFAULT_TOL, ...JSON.parse(localStorage.getItem(TOL_KEY) || '{}') }; } catch { return { ...DEFAULT_TOL }; }
  },
  setTolerance(m: Mode, v: number) {
    const t = meterStore.tolerance(); t[m] = v;
    try { localStorage.setItem(TOL_KEY, JSON.stringify(t)); } catch { /* */ }
    emit();
  },
  get capture(): CapturePrefs { return cap; },
  setCapture(p: Partial<CapturePrefs>) {
    cap = { ...cap, ...p };
    try { localStorage.setItem(CAP_KEY, JSON.stringify(cap)); } catch { /* */ }
    emit();
  },
  /** Captura manual (botão ou tecla): grava a leitura que está na tela agora. */
  captureNow() {
    if (live?.value == null) { if (cap.soundSave) playNotSaved(); boardStore.addToast('Sem leitura agora (ponta aberta).', 'info'); return; }
    capture({ value: live.value, unit: live.unit, source: liveSource || sourceName(), mode: liveMode ?? undefined });
  },
  testSound(kind: 'ok' | 'warn' | 'bad' | 'saved' | 'notsaved') {
    ({ ok: playOk, warn: playWarn, bad: playBad, saved: playSaved, notsaved: playNotSaved })[kind]();
  },
};

/** 2R 30/10/2026: o modo vem do campo «mode» do aparelho quando existe (o i2C C09 manda unit «V» também no
 *  diodo — por isso as leituras de diodo dele entravam como tensão). */
export function modeFrom(unit: string, mode?: string): Mode {
  const m = (mode || '').toLowerCase();
  // 2R 31/10/2026: «outro» = o visor do Cockpit está num modo que a ficha não usa (capacitor, frequência…): não grava
  if (m === 'outro') return 'outro' as Mode;
  if (m.includes('diod')) return 'diodo';
  if (m.includes('ohm') || m.includes('res') || m.includes('Ω')) return 'resistencia';
  if (m.includes('volt') || m.includes('tens') || m.includes('dcv') || m.includes('acv')) return 'tensao';
  return modeOf(unit);
}

export function modeOf(unit: string): Mode {
  const u = (unit || '').toUpperCase();
  if (u.includes('DIOD')) return 'diodo';
  if (u.includes('OHM') || u.includes('Ω') || u.includes('RES')) return 'resistencia';
  if (u.includes('V')) return 'tensao';
  return 'diodo';
}

function num(s: string | null | undefined): number | null {
  const m = /[-+]?\d+(?:[.,]\d+)?/.exec(s || '');
  if (!m) return null;
  let v = parseFloat(m[0].replace(',', '.'));
  const rest = (s || '').slice(m.index + m[0].length).trim().toLowerCase();
  if (rest.startsWith('k')) v *= 1e3; else if (rest.startsWith('m') && !rest.startsWith('mv')) v *= 1e6;
  if (rest.startsWith('mv')) v /= 1000;
  return v;
}

/** Quanto fora da margem: 0 = dentro; 1 = até 2× a margem; 2 = muito fora. */
let lastSeverity = 0;
function judge(m: Medicao): Medicao {
  const exp = num(m.expected);
  lastSeverity = 0;
  if (exp === null) return { ...m, status: 'sem' };
  const tol = meterStore.tolerance()[m.mode] / 100;
  const lim = Math.max(Math.abs(exp) * tol, m.mode === 'diodo' ? 0.01 : 0.005);
  const off = Math.abs(m.value - exp);
  if (off <= lim) return { ...m, status: 'ok' };
  lastSeverity = off <= lim * 2 ? 1 : 2;
  return { ...m, status: 'fora' };
}

function sourceName(): string {
  if (status.idn) return status.idn;
  return status.kind === 'rigol' ? 'Rigol DM858E' : 'multímetro';
}

/** Pino selecionado e o valor esperado dele para a leitura (sem gravar). */
function current(unit: string) {
  const tab = boardStore.activeTab;
  const sel = tab?.selection;
  const part = tab?.board && sel?.partIndex != null ? tab.board.parts[sel.partIndex] : null;
  const pin = part && sel?.pinIndex != null && sel.pinIndex >= 0 ? part.pins[sel.pinIndex] : null;
  if (!tab || !part || !pin) return null;
  const mode = modeOf(unit);
  const obd = obdNetLookup(obdBoardNumberFor(tab) ?? undefined, pin.net)[0];
  const expStr = (mode === 'diodo' ? obd?.diode : mode === 'tensao' ? obd?.voltage : obd?.resistance) ?? '';
  return { tab, part, pin, mode, expStr };
}

/** Som da leitura: veredito da margem para o pino selecionado. */
function verdictSound(value: number, unit: string) {
  const c = current(unit);
  if (!c) return;
  const m = judge({ t: 0, board: '', part: '', pin: '', net: '', mode: c.mode, value, unit, expected: c.expStr, status: 'sem', source: '' });
  (m.status === 'ok' ? playOk : m.status === 'fora' ? (lastSeverity >= 2 ? playBad : playWarn) : playTick)();
}

function capture(d: { value: number; unit: string; source: string; mode?: Mode }) {
  const tab = boardStore.activeTab;
  const sel = tab?.selection;
  const part = tab?.board && sel?.partIndex != null ? tab.board.parts[sel.partIndex] : null;
  const pin = part && sel?.pinIndex != null && sel.pinIndex >= 0 ? part.pins[sel.pinIndex] : null;
  if (!tab || !part || !pin) {
    if (cap.soundSave) playNotSaved();
    // 2R 31/10/2026 (Roger): sem os cards azuis das leituras (a ficha já mostra); __2rMeterToasts liga de volta
    if ((window as unknown as Record<string, unknown>).__2rMeterToasts)
      boardStore.addToast('Leitura ' + d.value.toFixed(3) + ' recebida — selecione o pino na placa para guardar.', 'info');
    return;
  }
  const mode = d.mode ?? modeOf(d.unit);
  const obd = obdNetLookup(obdBoardNumberFor(tab) ?? undefined, pin.net)[0];
  const expStr = (mode === 'diodo' ? obd?.diode : mode === 'tensao' ? obd?.voltage : obd?.resistance) ?? '';
  let m: Medicao = judge({ t: Date.now(), board: tab.fileName, part: part.name, pin: pin.number || pin.name, net: pin.net || '',
    mode, value: d.value, unit: d.unit, expected: expStr, status: 'sem', source: d.source, ...(who ? { by: who } : {}) });
  const here = `${part.name}.${m.pin}`;
  if (via && via.pin === here) m = { ...m, via: via.at };
  via = null;
  // «medir de novo»: substitui a linha antiga do mesmo pino
  const k = `${m.board}|${m.part}|${m.pin}`;
  if (redo && redo.key === k) {
    const old = list.find(x => x.t === redo!.t);
    list = list.filter(x => x.t !== redo!.t);
    if (old) push([{ ...old, del: true, upd: Date.now() }]);
  }
  m = { ...m, id: newId(), upd: m.t };
  redo = null;
  list = [m, ...list]; push([m]); emit();
  // 1º padrão (leitura) se ainda não tocou neste toque; 2º padrão (gravou) logo depois
  let delay = 0;
  if (cap.sound && !announced) { verdictSound(d.value, d.unit); delay = 420; }
  announced = true;
  if (cap.soundSave) window.setTimeout(playSaved, delay);
  if ((window as unknown as Record<string, unknown>).__2rMeterToasts) boardStore.addToast(`${here}${m.via ? ` (medido em ${m.via})` : ''} (${m.net || 'sem net'}): ${d.value.toFixed(3)}`
    + (m.status === 'ok' ? ' — OK' : m.status === 'fora' ? ` — fora do esperado (${expStr})` : ''), m.status === 'fora' ? 'error' : 'info');
  // Sequência de start ligada: a leitura também vai para a coluna do passo atual
  if (guideStore.on && guideStore.recordValue(mode, d.value, d.unit, who, d.source)) return;
  if (seqPrefs.auto) window.setTimeout(() => stepPin(1), 250);   // próximo pino da sequência
}

// ── captura automática: leitura parada pelo tempo escolhido, uma por toque ──
// 2R 30/10/2026 (Roger: «a leitura do multímetro está errada… tensão ou resistência a captura tem que ser pelo Rigol
// DM858E; modo diodo a leitura é feita pelo i2C C09»): o SDS manda as leituras dos DOIS aparelhos pela mesma porta,
// misturadas. Agora cada aparelho tem o seu estado de estabilidade e só vale: Rigol em tensão/resistência, C09 em diodo.
interface LiveIn { value: number | null; unit: string; text: string; kind?: string; mode?: string; visor?: unknown }
interface Est { since: number; ref: number | null; armed: boolean; lastCaptured: number | null; announced: boolean; run?: unknown }
/** 2R 31/10/2026: regra de leitura estável da página do SDS (window.__2rEstavel, index.html) */
type Estavel = (e: Est, v: number, t: number, mode: Mode, hold: number) => { reinicio?: boolean; bip?: boolean; pronto?: boolean; valor?: number };
const est: Record<string, Est> = {};
const liveBy: Record<string, { value: number | null; unit: string; text: string; mode: Mode; vz: unknown; source: string; t: number; aceita: boolean }> = {};
let liveSource = '';
let liveMode: Mode | null = null;
/** O som da leitura já tocou neste toque da ponta (aparelho da última leitura aceita). */
let announced = false;
function nomeAparelho(kind: string): string {
  return kind === 'i2c' ? 'i2C C09' : kind === 'rigol' ? 'Rigol DM858E' : sourceName();
}
function aceita(kind: string, mode: Mode): boolean {
  // 2R 31/10/2026 (Roger: «desativar o instrumento que não está usando»): aparelho desativado na ficha não grava
  const off = (window as unknown as { __2rMeterOff?: Record<string, number> }).__2rMeterOff;
  if (off && off[kind || 'm']) return false;
  if (kind === 'i2c') return mode === 'diodo';
  if (kind === 'rigol') return mode === 'tensao' || mode === 'resistencia';
  return true;
}
function publicaLive() {
  const w = window as unknown as Record<string, unknown>;
  w.__2rMeterLiveAll = liveBy;
  try { window.dispatchEvent(new CustomEvent('r2-meter-live', { detail: liveBy })); } catch { /* */ }
}
function onLive(d: LiveIn) {
  const kind = d.kind || '';
  const mode = modeFrom(d.unit, d.mode);
  const ok = aceita(kind, mode);
  liveBy[kind || 'm'] = { value: d.value, unit: d.unit, text: d.text, mode, vz: d.visor || null, source: nomeAparelho(kind), t: Date.now(), aceita: ok };
  publicaLive();
  if (!ok) { emit(); return; }                     // aparelho no modo que não é dele: mostra, não grava
  live = { value: d.value, unit: d.unit, text: d.text }; liveSource = nomeAparelho(kind); liveMode = mode; emit();
  const e = est[kind] || (est[kind] = { since: 0, ref: null, armed: true, lastCaptured: null, announced: false });
  const v = d.value;
  const now = Date.now();
  if (v == null) { e.armed = true; e.ref = null; e.run = null; e.announced = false; announced = false; return; }   // ponta aberta: pronto para o próximo ponto
  // 2R 31/10/2026 (Roger: «os multímetros ficam oscilando… só levar em conta quando estabilizar»): a janela inteira
  // tem que ficar numa faixa estreita (regra em window.__2rEstavel, no index.html do SDS)
  const est2 = (window as unknown as { __2rEstavel?: Estavel }).__2rEstavel;
  const E = est2 ? est2(e, v, now, mode, cap.holdMs) : null;
  if (E) {
    if (E.reinicio) { e.announced = false; announced = false; return; }
    if (!e.announced && E.bip) { e.announced = true; if (cap.sound) verdictSound(v, d.unit); }
    announced = e.announced;
    if (cap.auto && e.armed && E.pronto) {
      e.armed = false; e.lastCaptured = E.valor ?? v; e.run = null;
      capture({ value: E.valor ?? v, unit: d.unit, source: nomeAparelho(kind), mode });
    }
    return;
  }
  if (!e.armed && e.lastCaptured !== null) {
    const moved = Math.abs(v - e.lastCaptured) > Math.max(0.01, Math.abs(e.lastCaptured) * 0.1);
    if (moved) { e.armed = true; e.announced = false; }
  }
  const band = (r: number) => Math.max(0.003, Math.abs(r) * 0.01);
  if (e.ref === null || Math.abs(v - e.ref) > band(e.ref)) { e.ref = v; e.since = now; e.announced = false; announced = false; return; }
  if (!e.announced && now - e.since >= Math.min(350, cap.holdMs / 2)) {
    e.announced = true;
    if (cap.sound) verdictSound(v, d.unit);
  }
  announced = e.announced;
  if (!cap.auto || !e.armed) return;
  if (now - e.since >= cap.holdMs) {
    e.armed = false; e.lastCaptured = v; e.ref = null;
    capture({ value: v, unit: d.unit, source: nomeAparelho(kind), mode });
  }
}
/** «Limpar e gravar de novo» (ficha no estudo): a próxima leitura firme grava outra vez, mesmo sem tirar a ponta. */
function rearmar() {
  for (const k of Object.keys(est)) { est[k].armed = true; est[k].ref = null; est[k].lastCaptured = null; est[k].announced = false; }
  announced = false;
}

function onKey(e: KeyboardEvent) {
  if (cap.auto || status.state !== 'on') return;
  const t = e.target as HTMLElement | null;
  if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable)) return;
  if (e.code !== cap.key && e.key !== cap.key) return;
  e.preventDefault(); e.stopPropagation();
  meterStore.captureNow();
}

export function installMeter(): void {
  if (!IS_2R || !beta('medicoes')) return;
  const w = window as unknown as Record<string, unknown>;
  // a leitura estável agora é decidida aqui (tempo ajustável); a do app fica só de reserva
  w.__2rMeterCapture = () => { /* captura feita por onLive() */ };
  w.__2rMeterLive = (d: LiveIn) => onLive(d);
  w.__2rMeterRearm = () => rearmar();
  w.__2rMeterStatus = (d: MeterStatus) => {
    status = d; emit();
    if (d.state === 'on') meterApi()?.who?.().then(r => { who = r?.name || ''; emit(); }).catch(() => {});
  };
  window.addEventListener('keydown', onKey, true);
  // histórico na pasta da loja: envia o que falta e traz o dos outros computadores
  window.setTimeout(syncTick, 1500);
  window.setInterval(syncTick, 8000);
  let lastBoard = '';
  boardStore.subscribe(() => {
    const b = boardStore.activeTab?.fileName || '';
    if (b && b !== lastBoard) { lastBoard = b; void pull(b); }
  });
}

export interface MeterApi {
  ports(): Promise<{ ports: { port: string; desc: string }[]; status: MeterStatus; rigol_host: string }>;
  connect(o: Record<string, string>): Promise<unknown>;
  disconnect(): Promise<unknown>;
  status(): Promise<MeterStatus>;
  learn(o: Record<string, string>): Promise<{ ok?: boolean; path?: string; error?: string }>;
  who?(): Promise<{ name: string; email: string }>;
  histList?(board: string): Promise<{ rows: unknown[]; where?: string; error?: string }>;
  histSave?(recs: unknown[]): Promise<{ ok: boolean; n?: number; where?: string; error?: string }>;
}
export function meterApi(): MeterApi | null {
  return (window as unknown as { __2rMeterApi?: MeterApi }).__2rMeterApi ?? null;
}
