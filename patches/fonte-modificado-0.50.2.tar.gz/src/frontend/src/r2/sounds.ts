/**
 * 2R Tools: avisos sonoros das medições (Roger, 10/10/2026): «agradável quando
 * está dentro da margem… muito fora, um aviso mais tenso ou grave».
 * Sons gerados na hora (WebAudio), sem arquivo de áudio.
 */
let ctx: AudioContext | null = null;
function ac(): AudioContext | null {
  try {
    if (!ctx) ctx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
    if (ctx.state === 'suspended') void ctx.resume();
    return ctx;
  } catch { return null; }
}

function tone(freq: number, start: number, dur: number, type: OscillatorType, vol: number) {
  const a = ac(); if (!a) return;
  const t0 = a.currentTime + start;
  const o = a.createOscillator(), g = a.createGain();
  o.type = type; o.frequency.setValueAtTime(freq, t0);
  g.gain.setValueAtTime(0, t0);
  g.gain.linearRampToValueAtTime(vol, t0 + 0.012);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  o.connect(g).connect(a.destination);
  o.start(t0); o.stop(t0 + dur + 0.02);
}

/** Dentro da margem: dois toques suaves subindo (agradável). */
export function playOk() { tone(880, 0, 0.16, 'sine', 0.18); tone(1318.5, 0.11, 0.24, 'sine', 0.16); }
/** Um pouco fora: um toque médio, seco. */
export function playWarn() { tone(440, 0, 0.22, 'triangle', 0.22); }
/** Muito fora: dois toques graves e ásperos. */
export function playBad() { tone(160, 0, 0.28, 'sawtooth', 0.16); tone(120, 0.3, 0.38, 'sawtooth', 0.16); }
/** Leitura sem valor de referência: um clique curto. */
export function playTick() { tone(1200, 0, 0.05, 'sine', 0.10); }

// ── segundo padrão (Roger, 21:11): «na leitura e se gravou direito ou não» ──
/** Gravou: dois tiques curtos e agudos, bem diferentes dos sons da leitura. */
export function playSaved() { tone(2093, 0, 0.045, 'sine', 0.12); tone(2093, 0.08, 0.045, 'sine', 0.12); }
/** Não gravou (sem pino selecionado ou sem leitura): três notas descendo. */
export function playNotSaved() { tone(660, 0, 0.11, 'square', 0.08); tone(494, 0.12, 0.11, 'square', 0.08); tone(330, 0.24, 0.2, 'square', 0.08); }
