/**
 * 2R Tools (Roger, 11/10/2026): «na busca, permitir busca quebrada… a linha é
 * pp_1v25_awake_nand… posso buscar por nand, por pp1v25, por awake». Também no PDF.
 * - ignora _ - . / espaço e maiúsculas: «pp_1v25» acha PP1V25_AWAKE_NAND;
 * - vários pedaços separados por espaço, em qualquer ordem: «nand 1v25» também acha.
 */
const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9+]/g, '');

export function looseTokens(q: string): string[] {
  return q.trim().split(/\s+/).map(norm).filter(Boolean);
}

/** O nome bate com a busca (cada pedaço aparece em algum lugar do nome). */
export function looseMatch(name: string, q: string | string[]): boolean {
  const toks = Array.isArray(q) ? q : looseTokens(q);
  if (!toks.length) return false;
  const n = norm(name);
  return toks.every(t => n.includes(t));
}

/** PDF: acha `q` no texto ignorando _ - . e espaços. Devolve [início, fim) no texto original. */
export function looseFind(text: string, q: string, from = 0): [number, number] | null {
  const nq = norm(q);
  if (!nq) return null;
  let ns = ''; const map: number[] = [];
  for (let i = from; i < text.length; i++) {
    const c = text[i].toLowerCase();
    if (/[a-z0-9+]/.test(c)) { ns += c; map.push(i); }
  }
  const p = ns.indexOf(nq);
  if (p < 0) return null;
  return [map[p], map[p + nq.length - 1] + 1];
}

/* 2R 26/10/2026 (Roger: «coloca uma opção para fazer a busca exata ou similares»): uma chave para a placa («bdv») e outra para o PDF («pdf») */
export function r2BuscaExata(k: 'bdv' | 'pdf'): boolean {
  try { return localStorage.getItem('2r-busca-exata-' + k) === '1'; } catch { return false; }
}
/** looseMatch, ou nome idêntico quando a busca exata da placa está ligada. */
export function r2Match(name: string, q: string | string[]): boolean {
  if (!r2BuscaExata('bdv')) return looseMatch(name, q);
  const t = String(Array.isArray(q) ? q.join(' ') : q).trim().toLowerCase();
  return !!t && String(name || '').toLowerCase() === t;
}
