/**
 * 2R Tools: BoardRipper em português (Roger, 10/10/2026: «tem como traduzir para o português?»).
 * Troca só textos exatos conhecidos (e placeholder/title) — nunca recria nós do
 * React, só muda o valor do texto, então não quebra a página. Fora do 2R não roda.
 */
import { IS_2R } from './env';

const PT: Record<string, string> = {
  "2-Pin Body Ratio": "Corpo dos componentes de 2 pinos", "2-Pin Label Background": "Fundo do nome (2 pinos)", "2-Pin Net Names": "Net nos componentes de 2 pinos", "Ambient Dim": "Escurecer o resto da placa", "BGA Label Gap": "Espaço dos nomes no BGA", "Board Fill": "Preenchimento da placa", "Board fill": "Preenchimento da placa", "Board theme": "Tema da placa", "Border Opacity": "Opacidade da borda", "Border Width": "Largura da borda", "Bottom side": "Lado inferior", "Cache control": "Cache", "Canvas": "Fundo", "Cap to 60 FPS": "Limitar a 60 quadros/s", "Component Size": "Tamanho do componente", "Dashed": "Tracejada", "Dim Overlay Strength": "Força do escurecimento", "Diode Values Only": "Só valores de diodo", "Edge smoothing (MSAA)": "Suavizar bordas (MSAA)", "Fill Opacity": "Opacidade do preenchimento", "Fit Padding": "Margem ao centralizar", "Floating Part Label": "Nome do componente flutuante", "Floating Pin Label": "Nome do pino flutuante", "Font": "Fonte", "Global Zoom Floor": "Zoom mínimo", "HDR outline (experimental)": "Contorno brilhante (experimental)", "Hide Mechanical Fills": "Esconder blindagens", "Hide Text During Zoom": "Esconder textos durante o zoom", "Hierarchy Depth": "Profundidade das ligações", "Highlight Ring Opacity": "Opacidade do anel de destaque", "Keyboard Zoom Step": "Passo do zoom no teclado", "Label Atlas Resolution": "Resolução dos nomes", "Label Cull (mils)": "Esconder nomes menores que (mils)", "Label Drop Shadow": "Sombra dos nomes", "Label Fade-In": "Nomes aparecem suavemente", "Line Opacity": "Opacidade da linha", "Line Width": "Largura da linha", "Max Radius": "Raio máximo", "Min Label Size": "Tamanho mínimo do nome", "Min Radius": "Raio mínimo", "Mouse wheel detection": "Detecção da roda do mouse", "Net Highlight Ring": "Anel nos pinos da net", "Net Names on Pins": "Nets nos pinos", "Net names": "Nomes das nets", "Other Pins of Selected Part": "Outros pinos do componente selecionado", "Outline": "Contorno", "Padding": "Margem", "Pan Boundaries": "Limites ao arrastar", "Part Labels": "Nomes dos componentes", "Part labels": "Nomes dos componentes", "Part names": "Nomes dos componentes", "Pin 1 Marker": "Marca do pino 1", "Pin Click Radius": "Área de clique do pino", "Pin Label Background": "Fundo do nome do pino", "Pin Label Shadow": "Sombra do nome do pino", "Pin Numbers": "Números dos pinos", "Pin labels": "Nomes dos pinos", "Pin numbers": "Números dos pinos", "Pulse Animation": "Animação de pulso", "Rotation snap window": "Ímã da rotação", "Rotation unlock angle": "Ângulo para soltar a rotação", "Scale Factor": "Escala", "Selected Part Labels": "Nomes do componente selecionado", "Selection Border": "Borda da seleção", "Selection Fill": "Preenchimento da seleção", "Selection Min Size": "Tamanho mínimo da seleção", "Selection Padding": "Margem da seleção", "Selection": "Seleção", "Show Perf Overlay": "Mostrar desempenho", "Smooth wheel zoom": "Zoom suave na roda", "Stroke Opacity": "Opacidade do traço", "Stroke Width": "Largura do traço", "Text fast mode (experimental)": "Texto rápido (experimental)", "Top side": "Lado superior", "Touch device performance mode": "Modo desempenho (toque)", "Two-finger rotation": "Girar com dois dedos", "Type colours": "Cores por tipo", "Use board metadata color": "Usar a cor do arquivo", "Wheel Smoothing": "Suavizar a roda", "Board Outline": "Contorno da placa", "Parts / Components": "Componentes", "Pins / Pads": "Pinos / pads", "Navigation": "Navegação", "Zoom Level of Detail": "Detalhes conforme o zoom", "Part properties": "Propriedades dos componentes", "Pin Color Rules": "Cores dos pinos", "Selection & Highlight": "Seleção e destaque", "Board overlay": "Sobreposição na placa", "Net Lines": "Linhas das nets", "Performance & Debug": "Desempenho e diagnóstico", "PDF Viewer": "Esquemático (PDF)", "Scanning & Indexing": "Leitura e índice", "Database info": "Banco de dados", "Keyboard Shortcuts": "Atalhos do teclado", "Interactive mode": "Modo interativo", "Resize board elements by clicking them — sizes update live.": "Clique num elemento da placa para ajustar o tamanho — muda na hora.", "Changes apply to all boards": "Vale para todas as placas", "Apply": "Aplicar", "Reset to Defaults": "Voltar ao padrão", "Board": "Placa", "Global": "Todas as placas",
  'Open': 'Abrir', '2-Window': '2 janelas', 'Search parts, nets, PDFs, library': 'Buscar componente, net ou PDF (Ctrl+F)',
  'Library': 'Local', 'History': 'Histórico', 'Tools': 'Ferramentas', 'Debug': 'Diagnóstico', 'Settings': 'Ajustes',
  'Board #': 'Placa', 'Folders': 'Pastas', 'Filter files...': 'Filtrar arquivos…', 'Change Folder': 'Trocar pasta',
  'Top': 'Superior', 'Bottom': 'Inferior', 'Parts': 'Componentes', 'Nets': 'Nets', 'Components': 'Componentes',
  'Retry now': 'Tentar agora', 'Retry': 'Tentar de novo', 'Load failed': 'Falhou ao carregar',
  'No board loaded': 'Nenhuma placa aberta', 'Clear': 'Limpar', 'Cancel': 'Cancelar', 'Close': 'Fechar', 'All': 'Todos',
  'Model': 'Modelo', 'Manufacturer': 'Fabricante', 'Search': 'Buscar', 'Info': 'Informações', 'Notes': 'Notas',
  'Recent': 'Recentes', 'Recently opened': 'Abertos recentemente', 'No recently opened files.': 'Nenhum arquivo aberto recentemente.',
  'Nothing visited yet.': 'Nada visitado ainda.', 'No matching nets': 'Nenhuma net encontrada',
  'No matching components': 'Nenhum componente encontrado', 'Loading...': 'Carregando…', 'Loading board...': 'Carregando a placa…',
  'Loading folder tree': 'Carregando as pastas', 'Empty directory': 'Pasta vazia', 'Details': 'Detalhes', 'Diode': 'Diodo',
  'Edit metadata': 'Editar dados', 'Edit Metadata': 'Editar dados', 'Board Number': 'Número da placa',
  'Click a component to inspect': 'Clique num componente para ver os detalhes', 'Calculators': 'Calculadoras',
  'Database': 'Banco de dados', 'Database Editor': 'Editor do banco de dados', 'Workbench': 'Bancada', 'Worklist': 'Lista de trabalho',
  'PDF search': 'Busca no PDF', 'Donor boards': 'Placas doadoras', 'This board': 'Esta placa', 'All boards': 'Todas as placas',
  'Show all': 'Mostrar tudo', 'Everything': 'Tudo', 'Revisions': 'Revisões', 'Multiple revisions': 'Várias revisões',
  'Library load incomplete': 'Biblioteca carregada pela metade', 'The library list did not finish loading.': 'A lista da biblioteca não terminou de carregar.',
  'Every layer is switched off.': 'Todas as camadas estão desligadas.', 'Boards and sides': 'Placas e lados',
  'Enter a query and press Search or Enter': 'Digite e clique em Buscar ou aperte Enter',
  'Search components or nets...': 'Buscar componentes ou nets…', 'Search PDF text (e.g. 10UF 25V)…': 'Buscar texto no PDF (ex.: 10UF 25V)…',
  'Zoom to fit board': 'Centralizar a placa', 'Clear search': 'Limpar a busca', 'Browse folders': 'Ver pastas',
  'Flip this board top ↔ bottom': 'Virar a placa (superior ↔ inferior)', 'Butterfly · both sides side by side': 'Borboleta · os dois lados lado a lado',
  'More transforms: 180°, mirror, flip axis': 'Mais: 180°, espelhar, virar eixo', 'Open in viewer': 'Abrir', 'Open this PDF': 'Abrir este PDF',
  'Double-click or press Enter to open': 'Dois cliques ou Enter para abrir', 'Drag to resize': 'Arraste para mudar o tamanho',
  'Back': 'Voltar', 'Forward': 'Avançar', 'Board side': 'Lado da placa', 'Download': 'Baixar',
  'Collapse all open folders in the current view': 'Fechar todas as pastas abertas', 'Change layer color': 'Mudar a cor da camada',
  'Interface scale': 'Tamanho da interface', 'Hover info': 'Informação ao passar o mouse', 'Net lines': 'Linhas das nets',
  'Spotlight': 'Destacar', 'Ghost parts': 'Componentes fantasma', 'Diode values': 'Valores de diodo', 'Traces': 'Trilhas',
  'Find part': 'Achar componente', 'Find net': 'Achar net', 'Minimap': 'Minimapa', 'Fit board': 'Centralizar',
  'Rotate left': 'Girar para a esquerda', 'Rotate right': 'Girar para a direita', 'Side': 'Lado',
  'Search (multi-term: 10UF 25V)': 'Buscar (vários termos: 10UF 25V)', 'Power': 'Alimentação', 'Ground': 'Terra (GND)', 'Datalines': 'Linhas de dados', 'Logical': 'Lógica', 'Misc': 'Outros', 'Follow PDF': 'Seguir o PDF', 'Scroll mode': 'Modo de rolagem', 'Slide mode': 'Modo slide',
};


// Espanhol: textos do BoardRipper (inglês) → espanhol
const ES: Record<string, string> = {
  'Open': 'Abrir', '2-Window': '2 ventanas', 'Search parts, nets, PDFs, library': 'Buscar componente, net o PDF (Ctrl+F)',
  'Library': 'Local', 'History': 'Historial', 'Tools': 'Herramientas', 'Debug': 'Diagnóstico', 'Settings': 'Ajustes',
  'Board #': 'Placa', 'Folders': 'Carpetas', 'Filter files...': 'Filtrar archivos…', 'Change Folder': 'Cambiar carpeta',
  'Top': 'Superior', 'Bottom': 'Inferior', 'Parts': 'Componentes', 'Nets': 'Nets', 'Components': 'Componentes',
  'Retry now': 'Reintentar ahora', 'Retry': 'Reintentar', 'Load failed': 'Error al cargar',
  'No board loaded': 'Ninguna placa abierta', 'Clear': 'Limpiar', 'Cancel': 'Cancelar', 'Close': 'Cerrar', 'All': 'Todos',
  'Model': 'Modelo', 'Manufacturer': 'Fabricante', 'Search': 'Buscar', 'Info': 'Información', 'Notes': 'Notas',
  'Recent': 'Recientes', 'Recently opened': 'Abiertos recientemente', 'No recently opened files.': 'Ningún archivo abierto recientemente.',
  'Nothing visited yet.': 'Nada visitado todavía.', 'No matching nets': 'Ninguna net encontrada',
  'No matching components': 'Ningún componente encontrado', 'Loading...': 'Cargando…', 'Loading board...': 'Cargando la placa…',
  'Loading folder tree': 'Cargando las carpetas', 'Empty directory': 'Carpeta vacía', 'Details': 'Detalles', 'Diode': 'Diodo',
  'Edit metadata': 'Editar datos', 'Edit Metadata': 'Editar datos', 'Board Number': 'Número de placa',
  'Click a component to inspect': 'Haga clic en un componente para ver los detalles', 'Calculators': 'Calculadoras',
  'Database': 'Base de datos', 'Database Editor': 'Editor de la base de datos', 'Workbench': 'Banco de trabajo', 'Worklist': 'Lista de trabajo',
  'PDF search': 'Búsqueda en el PDF', 'Donor boards': 'Placas donantes', 'This board': 'Esta placa', 'All boards': 'Todas las placas',
  'Show all': 'Mostrar todo', 'Everything': 'Todo', 'Revisions': 'Revisiones', 'Multiple revisions': 'Varias revisiones',
  'Library load incomplete': 'Biblioteca cargada a medias', 'The library list did not finish loading.': 'La lista de la biblioteca no terminó de cargar.',
  'Every layer is switched off.': 'Todas las capas están apagadas.', 'Boards and sides': 'Placas y lados',
  'Enter a query and press Search or Enter': 'Escriba y haga clic en Buscar o presione Enter',
  'Search components or nets...': 'Buscar componentes o nets…', 'Search PDF text (e.g. 10UF 25V)…': 'Buscar texto en el PDF (ej.: 10UF 25V)…',
  'Search (multi-term: 10UF 25V)': 'Buscar (varios términos: 10UF 25V)', 'Power': 'Alimentación', 'Ground': 'Tierra (GND)', 'Datalines': 'Líneas de datos', 'Logical': 'Lógica', 'Misc': 'Otros', 'Cores das nets': 'Colores de las nets', 'Mostrar / esconder a legenda': 'Mostrar / ocultar la leyenda',
  'Zoom to fit board': 'Centrar la placa', 'Clear search': 'Limpiar la búsqueda', 'Browse folders': 'Ver carpetas',
  'Flip this board top ↔ bottom': 'Voltear la placa (superior ↔ inferior)', 'Butterfly · both sides side by side': 'Mariposa · los dos lados lado a lado',
  'More transforms: 180°, mirror, flip axis': 'Más: 180°, espejar, voltear eje', 'Open in viewer': 'Abrir', 'Open this PDF': 'Abrir este PDF',
  'Double-click or press Enter to open': 'Doble clic o Enter para abrir', 'Drag to resize': 'Arrastre para cambiar el tamaño',
  'Back': 'Volver', 'Forward': 'Avanzar', 'Board side': 'Lado de la placa', 'Download': 'Descargar',
  'Collapse all open folders in the current view': 'Cerrar todas las carpetas abiertas', 'Change layer color': 'Cambiar el color de la capa',
  'Interface scale': 'Tamaño de la interfaz', 'Hover info': 'Información al pasar el mouse', 'Net lines': 'Líneas de las nets',
  'Spotlight': 'Destacar', 'Ghost parts': 'Componentes fantasma', 'Diode values': 'Valores de diodo', 'Traces': 'Pistas',
  'Find part': 'Buscar componente', 'Find net': 'Buscar net', 'Minimap': 'Minimapa', 'Fit board': 'Centrar',
  'Rotate left': 'Girar a la izquierda', 'Rotate right': 'Girar a la derecha', 'Side': 'Lado',
  'Follow PDF': 'Seguir el PDF', 'Scroll mode': 'Modo de desplazamiento', 'Slide mode': 'Modo diapositiva',
};

// Textos da 2R (escritos em português no código) → espanhol / inglês
const MINE_ES: Record<string, string> = {
  "Curvas": "Curvas", "Start": "Arranque", "Sequência de start": "Secuencia de arranque", "Ligar sequência": "Activar secuencia", "Curvas (RastreCurve / Smart Curve)…": "Curvas (RastreCurve / Smart Curve)…", "Sequência de start na placa…": "Secuencia de arranque en la placa…", "Converter": "Convertir", "Roteiros desta placa": "Guiones de esta placa", "Novo roteiro": "Nuevo guion", "trocar roteiro": "cambiar guion", "Capturar curva": "Capturar curva", "Foto da tela": "Foto de la pantalla", "Curva firme — pode capturar": "Curva estable — puede capturar", "Esperando a curva firmar (capacitores carregando)…": "Esperando que la curva se estabilice (capacitores cargando)…", "Capturar sozinho quando a curva firmar": "Capturar solo cuando la curva se estabilice", "Igual à oficial": "Igual a la oficial", "Parecida": "Parecida", "Diferente da oficial": "Diferente de la oficial", "Aprovar": "Aprobar", "Recusar": "Rechazar", "Perfil": "Perfil", "Ponta preta (referência)": "Punta negra (referencia)", "Bateria e carregador desligados": "Batería y cargador desconectados", "Placa descansada (capacitores descarregados)": "Placa en reposo (capacitores descargados)",
  "Apagar as desta placa?": "¿Borrar las de esta placa?", "Salvo na pasta da loja: todos os computadores veem estas medições.": "Guardado en la carpeta del taller: todas las computadoras ven estas mediciones.", "Salvo só neste computador (a pasta da loja não está ligada).": "Guardado solo en esta computadora (la carpeta del taller no está activa).",
  "Captura automática": "Captura automática", "Captura manual": "Captura manual", "Grava quando a leitura fica parada por": "Graba cuando la lectura queda quieta por", "Tecla para gravar:": "Tecla para grabar:", "Aperte a tecla…": "Presione la tecla…", "Gravar agora": "Grabar ahora", "Som da leitura (quando a leitura firma)": "Sonido de la lectura (cuando la lectura se estabiliza)", "♪ dentro da margem": "♪ dentro del margen", "♪ um pouco fora": "♪ un poco fuera", "♪ muito fora": "♪ muy fuera", "Som da gravação": "Sonido de la grabación", "♪ gravou": "♪ grabó", "♪ não gravou": "♪ no grabó", "Medições gravadas em nome de": "Mediciones grabadas a nombre de", "Apagar tudo?": "¿Borrar todo?", "Corrigir o valor": "Corregir el valor", "Apagar esta medição": "Borrar esta medición", "Sem leitura agora (ponta aberta).": "Sin lectura ahora (punta abierta).", "Clique e aperte a tecla que você quer usar": "Haga clic y presione la tecla que quiere usar", "Ouvir": "Escuchar",
  "Mapear componente": "Mapear componente", "Clique num componente na placa para ver a sequência dos pinos e o ponto de medição mais próximo.": "Haga clic en un componente de la placa para ver la secuencia de los pines y el punto de medición más cercano.", "Mapear": "Mapear", "medidos": "medidos", "Sequência dos pinos": "Secuencia de los pines", "Pino 1, anti-horário (padrão)": "Pin 1, antihorario (estándar)", "Pino 1, horário": "Pin 1, horario", "Ímpares primeiro, depois pares (FPC)": "Impares primero, después pares (FPC)", "Pares primeiro, depois ímpares (FPC)": "Pares primero, después impares (FPC)", "Ordem dos números (1, 2, 3…)": "Orden de los números (1, 2, 3…)", "Ir sozinho para o próximo pino depois de medir": "Pasar solo al siguiente pin después de medir", "Pular pinos de GND": "Saltar pines de GND", "◀ Anterior": "◀ Anterior", "Próximo ▶": "Siguiente ▶", "Sem acesso ao pad de": "¿Sin acceso al pad de", "? Meça a mesma net (": "? Mida la misma net (", ") em:": ") en:", "Nenhum ponto de teste ou passivo nessa net.": "Ningún punto de prueba o pasivo en esa net.", "Mostrar na placa": "Mostrar en la placa", "Medir aqui": "Medir aquí", "Medindo aqui ✓": "Midiendo aquí ✓", "ponto de teste": "punto de prueba", "passivo": "pasivo", "· outro lado": "· otro lado", "Mapear componente (sequência dos pinos)…": "Mapear componente (secuencia de los pines)…", "Próximo pino da sequência": "Siguiente pin de la secuencia", "Pino anterior da sequência": "Pin anterior de la secuencia", "· em": "· en",
  "Medições": "Mediciones", "ligado": "conectado", "desligado": "desconectado", "Rigol DM858E (rede)": "Rigol DM858E (red)", "IP do Rigol (Utility › I/O › LAN)": "IP del Rigol (Utility › I/O › LAN)", "Porta USB": "Puerto USB", "Velocidade": "Velocidad", "Ligar": "Conectar", "Desligar": "Desconectar", "Aprender (10 s)": "Aprender (10 s)", "Procurar portas": "Buscar puertos", "Desligado": "Desconectado", "Clique no pino na placa e encoste a ponta: quando a leitura firma, ela entra sozinha na lista abaixo.": "Haga clic en el pin en la placa y apoye la punta: cuando la lectura se estabiliza, entra sola en la lista de abajo.", "Tolerância:": "Tolerancia:", "Diodo": "Diodo", "Tensão": "Tensión", "Resistência": "Resistencia", "Pino": "Pin", "Net": "Net", "Medido": "Medido", "Esperado": "Esperado", "Salvar em planilha (CSV)": "Guardar en planilla (CSV)", "Limpar o histórico": "Limpiar el historial", "Multímetro e medições (Rigol / i2C)…": "Multímetro y mediciones (Rigol / i2C)…",
  "Tudo": "Todo", "No componente": "En el componente", "Onde buscar: tudo ou só nos pinos do componente selecionado": "Dónde buscar: todo o solo en los pines del componente seleccionado", "Selecione um componente na placa": "Seleccione un componente en la placa", "Nenhum pino encontrado": "Ningún pin encontrado", "Microscópio: câmera ao lado, mesclar com a placa e transparência": "Microscopio: cámara al lado, mezclar con la placa y transparencia", "Microscópio (câmera, mesclar, transparência)": "Microscopio (cámara, mezclar, transparencia)", "Câmera ao lado da placa": "Cámara al lado de la placa", "Mesclar: ligado": "Mezclar: encendido", "Mesclar com a placa": "Mezclar con la placa",
  "Arquivo": "Archivo", "Exibir": "Ver", "Preferências": "Preferencias", "Ajuda": "Ayuda", "Abrir boardview ou PDF…": "Abrir boardview o PDF…", "Acervo 2R (nuvem)": "Acervo 2R (nube)", "Enviar arquivo novo ao acervo…": "Enviar archivo nuevo al acervo…", "Abertos recentemente": "Abiertos recientemente", "Centralizar a placa": "Centrar la placa", "2 janelas (PDF numa segunda janela)": "2 ventanas (PDF en una segunda ventana)", "Painel lateral (mostrar / esconder)": "Panel lateral (mostrar / ocultar)", "Legenda das cores das nets": "Leyenda de colores de las nets", "Barra de status": "Barra de estado", "Virar a placa (superior ↔ inferior)": "Voltear la placa (superior ↔ inferior)", "Girar para a esquerda": "Girar a la izquierda", "Girar para a direita": "Girar a la derecha", "Linhas das nets (desligado → estrela → corrente)": "Líneas de las nets (apagado → estrella → cadena)", "Buscar componente ou net": "Buscar componente o net", "Microscópio (câmera USB)": "Microscopio (cámara USB)", "Mesclar imagem real com a placa": "Mezclar imagen real con la placa", "Ajustes do Boardview…": "Ajustes del Boardview…", "Letra maior": "Letra más grande", "Letra menor": "Letra más chica", "Letra no tamanho padrão": "Letra en tamaño estándar", "Voltar a barra de ícones ao padrão": "Volver la barra de íconos al estándar", "Atalhos do teclado": "Atajos del teclado", "Espaço": "Espacio",
  'Local': 'Local', 'Histórico': 'Historial', 'Ferramentas': 'Herramientas', 'Diagnóstico': 'Diagnóstico', 'Ajustes': 'Ajustes',
  'Centralizar': 'Centrar', 'Centralizar: a placa inteira na tela': 'Centrar: la placa entera en la pantalla',
  'Aproximar (zoom +)': 'Acercar (zoom +)', 'Afastar (zoom −)': 'Alejar (zoom −)',
  'Girar para a esquerda (placa ou PDF ativo)': 'Girar a la izquierda (placa o PDF activo)',
  'Girar para a direita (placa ou PDF ativo)': 'Girar a la derecha (placa o PDF activo)',
  'Girar a placa 180°': 'Girar la placa 180°', 'Girar 180°': 'Girar 180°',
  'Espelhar': 'Espejar', 'Espelhar (mirror) — placa ou PDF ativo (tecla M)': 'Espejar (mirror) — placa o PDF activo (tecla M)',
  'Espelhar na vertical': 'Espejar en vertical', 'Espelhar a placa na vertical': 'Espejar la placa en vertical',
  'Virar': 'Voltear', 'Virar a placa': 'Voltear la placa', 'Virar a placa: lado superior ↔ inferior (Espaço)': 'Voltear la placa: lado superior ↔ inferior (Espacio)',
  'Borboleta (os dois lados)': 'Mariposa (los dos lados)', 'Borboleta: os dois lados lado a lado': 'Mariposa: los dos lados lado a lado',
  'Linhas das nets': 'Líneas de las nets', 'Linhas das nets: desligado → estrela → corrente': 'Líneas de las nets: apagado → estrella → cadena',
  'Voltar': 'Volver', 'Voltar para a visão anterior': 'Volver a la vista anterior', 'Avançar': 'Avanzar', 'Avançar para a próxima visão': 'Avanzar a la próxima vista',
  'Microscópio': 'Microscopio', 'Microscópio — câmera USB ao lado da placa': 'Microscopio — cámara USB al lado de la placa',
  'Mesclar': 'Mezclar', 'Mesclar a imagem real (câmera ou foto) com a placa': 'Mezclar la imagen real (cámara o foto) con la placa',
  'Transparência': 'Transparencia', 'Transparência da imagem mesclada e dos pinos': 'Transparencia de la imagen mezclada y de los pines',
  'Busca local': 'Búsqueda local', 'Busca local: componente, net ou arquivo deste computador': 'Búsqueda local: componente, net o archivo de esta computadora',
  'Biblioteca': 'Biblioteca', 'Biblioteca local': 'Biblioteca local', 'Biblioteca local (pasta deste computador)': 'Biblioteca local (carpeta de esta computadora)',
  'Abrir': 'Abrir', 'Abrir arquivo': 'Abrir archivo', 'Abrir boardview ou PDF deste computador': 'Abrir boardview o PDF de esta computadora',
  '2 janelas': '2 ventanas', 'PDF numa segunda janela': 'PDF en una segunda ventana',
  'Dividir tela': 'Dividir pantalla', 'Dividir a tela: escolha o que fica lado a lado': 'Dividir la pantalla: elija qué queda lado a lado',
  'Só a placa': 'Solo la placa', 'Placa | PDF': 'Placa | PDF', 'Placa | Microscópio': 'Placa | Microscopio',
  'PDF | Microscópio': 'PDF | Microscopio', 'Placa | PDF | Microscópio': 'Placa | PDF | Microscopio',
  'Adicionar função à barra': 'Agregar función a la barra', 'Adicionar à barra (depois é só arrastar para o lugar):': 'Agregar a la barra (después solo arrástrelo a su lugar):',
  '│ Separador': '│ Separador', 'Separador (arraste ou botão direito para tirar)': 'Separador (arrastre o clic derecho para quitar)',
  'Voltar a barra ao padrão': 'Volver la barra al estándar', 'Tirar da barra': 'Quitar de la barra', 'Pôr um separador depois': 'Poner un separador después',
  'A transparência vale com o Mesclar ligado.': 'La transparencia vale con Mezclar encendido.', 'Ligar o Mesclar': 'Encender Mezclar',
  'Imagem': 'Imagen', 'Pinos': 'Pines',
  'Nenhum PDF aberto com esta placa.': 'Ningún PDF abierto con esta placa.', 'Abra uma placa primeiro.': 'Abra una placa primero.',
  'Nenhuma placa aberta': 'Ninguna placa abierta', 'Busque a placa na aba': 'Busque la placa en la pestaña',
  '(nuvem) ao lado, ou abra um arquivo deste computador em': '(nube) al lado, o abra un archivo de esta computadora en', 'ou no botão': 'o en el botón',
  'online': 'en línea', 'Placa (820-01700), modelo (A2141) ou ano': 'Placa (820-01700), modelo (A2141) o año',
  'boardviews e': 'boardviews y', 'esquemáticos no acervo. Digite para buscar.': 'esquemáticos en el acervo. Escriba para buscar.',
  'Nada encontrado no Acervo 2R.': 'Nada encontrado en el Acervo 2R.', '+ PDF': '+ PDF',
  'Enviar arquivo novo ao acervo': 'Enviar archivo nuevo al acervo',
  'O arquivo entra no acervo de todos os técnicos, com o seu nome como quem enviou. Informe o modelo EXATO da placa.':
    'El archivo entra en el acervo de todos los técnicos, con su nombre como remitente. Indique el modelo EXACTO de la placa.',
  'Arquivo (boardview ou esquemático PDF)': 'Archivo (boardview o esquemático PDF)', 'Placa *': 'Placa *', 'Número A do Mac *': 'Número A del Mac *',
  'EMC': 'EMC', 'Ano': 'Año', 'Modelo': 'Modelo', 'Observação': 'Observación',
  'ex.: 820-01700': 'ej.: 820-01700', 'ex.: A2141 (gravado embaixo do Mac)': 'ej.: A2141 (grabado debajo del Mac)', 'ex.: 3347': 'ej.: 3347',
  'ex.: 2019': 'ej.: 2019', 'ex.: MACBOOK PRO 16 - T2': 'ej.: MACBOOK PRO 16 - T2', 'ex.: testada OK': 'ej.: probada OK',
  'Declaro que posso compartilhar este arquivo e autorizo a 2R Tools a incluí-lo no Acervo 2R.':
    'Declaro que puedo compartir este archivo y autorizo a 2R Tools a incluirlo en el Acervo 2R.',
  'Enviar': 'Enviar', 'Enviando…': 'Enviando…', 'Escolha o arquivo.': 'Elija el archivo.',
  'Informe o número A (ex.: A2141).': 'Indique el número A (ej.: A2141).', 'Informe a placa (ex.: 820-01700).': 'Indique la placa (ej.: 820-01700).',
  'Marque a autorização para enviar.': 'Marque la autorización para enviar.',
  'Enviado! Em alguns minutos o arquivo aparece no Acervo 2R. Obrigado pela ajuda.': '¡Enviado! En unos minutos el archivo aparece en el Acervo 2R. Gracias por la ayuda.',
  'Placa já conhecida no acervo: dados preenchidos.': 'Placa ya conocida en el acervo: datos completados.',
  'Sem conexão com o servidor da 2R Tools.': 'Sin conexión con el servidor de 2R Tools.', 'O envio é liberado só para licença ativa.': 'El envío está disponible solo con licencia activa.',
  'Limite de envios por hoje. Amanhã libera de novo.': 'Límite de envíos por hoy. Mañana se libera de nuevo.',
  'O servidor não aceitou o arquivo agora. Tente de novo em instantes.': 'El servidor no aceptó el archivo ahora. Intente de nuevo en instantes.',
  'Arquivo vazio ou maior que 300 MB.': 'Archivo vacío o mayor de 300 MB.', 'Esse tipo de arquivo não é boardview nem PDF.': 'Este tipo de archivo no es boardview ni PDF.',
  'Placa': 'Placa', 'PDF': 'PDF', 'só PDF': 'solo PDF', 'Superior': 'Superior', 'Inferior': 'Inferior',
};

const MINE_EN: Record<string, string> = {
  "Curvas": "Curves", "Start": "Power-on", "Sequência de start": "Power-on sequence", "Ligar sequência": "Start sequence", "Curvas (RastreCurve / Smart Curve)…": "Curves (RastreCurve / Smart Curve)…", "Sequência de start na placa…": "Power-on sequence on the board…", "Converter": "Convert", "Roteiros desta placa": "Scripts for this board", "Novo roteiro": "New script", "trocar roteiro": "change script", "Capturar curva": "Capture curve", "Foto da tela": "Screen photo", "Curva firme — pode capturar": "Curve settled — ready to capture", "Esperando a curva firmar (capacitores carregando)…": "Waiting for the curve to settle (capacitors charging)…", "Capturar sozinho quando a curva firmar": "Capture automatically when the curve settles", "Igual à oficial": "Same as official", "Parecida": "Similar", "Diferente da oficial": "Different from official", "Aprovar": "Approve", "Recusar": "Reject", "Perfil": "Profile", "Ponta preta (referência)": "Black probe (reference)", "Bateria e carregador desligados": "Battery and charger disconnected", "Placa descansada (capacitores descarregados)": "Board rested (capacitors discharged)",
  "Apagar as desta placa?": "Delete this board's?", "Salvo na pasta da loja: todos os computadores veem estas medições.": "Saved in the shop folder: every computer sees these measurements.", "Salvo só neste computador (a pasta da loja não está ligada).": "Saved on this computer only (the shop folder is not set up).",
  "Captura automática": "Automatic capture", "Captura manual": "Manual capture", "Grava quando a leitura fica parada por": "Saves when the reading holds still for", "Tecla para gravar:": "Key to save:", "Aperte a tecla…": "Press the key…", "Gravar agora": "Save now", "Som da leitura (quando a leitura firma)": "Reading sound (when the reading settles)", "♪ dentro da margem": "♪ within margin", "♪ um pouco fora": "♪ slightly off", "♪ muito fora": "♪ far off", "Som da gravação": "Save sound", "♪ gravou": "♪ saved", "♪ não gravou": "♪ not saved", "Medições gravadas em nome de": "Measurements saved as", "Apagar tudo?": "Delete all?", "Corrigir o valor": "Correct the value", "Apagar esta medição": "Delete this measurement", "Sem leitura agora (ponta aberta).": "No reading now (probe open).", "Clique e aperte a tecla que você quer usar": "Click and press the key you want to use", "Ouvir": "Listen",
  "Mapear componente": "Map component", "Clique num componente na placa para ver a sequência dos pinos e o ponto de medição mais próximo.": "Click a part on the board to see its pin sequence and the nearest measuring point.", "Mapear": "Map", "medidos": "measured", "Sequência dos pinos": "Pin sequence", "Pino 1, anti-horário (padrão)": "Pin 1, counter-clockwise (default)", "Pino 1, horário": "Pin 1, clockwise", "Ímpares primeiro, depois pares (FPC)": "Odd first, then even (FPC)", "Pares primeiro, depois ímpares (FPC)": "Even first, then odd (FPC)", "Ordem dos números (1, 2, 3…)": "Number order (1, 2, 3…)", "Ir sozinho para o próximo pino depois de medir": "Go to the next pin after measuring", "Pular pinos de GND": "Skip GND pins", "◀ Anterior": "◀ Previous", "Próximo ▶": "Next ▶", "Sem acesso ao pad de": "No access to the pad of", "? Meça a mesma net (": "? Measure the same net (", ") em:": ") at:", "Nenhum ponto de teste ou passivo nessa net.": "No test point or passive on this net.", "Mostrar na placa": "Show on the board", "Medir aqui": "Measure here", "Medindo aqui ✓": "Measuring here ✓", "ponto de teste": "test point", "passivo": "passive", "· outro lado": "· other side", "Mapear componente (sequência dos pinos)…": "Map component (pin sequence)…", "Próximo pino da sequência": "Next pin in sequence", "Pino anterior da sequência": "Previous pin in sequence", "· em": "· at",
  "Medições": "Measurements", "ligado": "connected", "desligado": "disconnected", "Rigol DM858E (rede)": "Rigol DM858E (LAN)", "IP do Rigol (Utility › I/O › LAN)": "Rigol IP (Utility › I/O › LAN)", "Porta USB": "USB port", "Velocidade": "Baud rate", "Ligar": "Connect", "Desligar": "Disconnect", "Aprender (10 s)": "Learn (10 s)", "Procurar portas": "Find ports", "Desligado": "Disconnected", "Clique no pino na placa e encoste a ponta: quando a leitura firma, ela entra sozinha na lista abaixo.": "Click the pin on the board and touch the probe: when the reading settles it goes into the list below.", "Tolerância:": "Tolerance:", "Diodo": "Diode", "Tensão": "Voltage", "Resistência": "Resistance", "Pino": "Pin", "Medido": "Measured", "Esperado": "Expected", "Salvar em planilha (CSV)": "Save as spreadsheet (CSV)", "Limpar o histórico": "Clear history", "Multímetro e medições (Rigol / i2C)…": "Multimeter and measurements (Rigol / i2C)…",
  "Tudo": "All", "No componente": "In the part", "Onde buscar: tudo ou só nos pinos do componente selecionado": "Where to search: everything or only the selected part pins", "Selecione um componente na placa": "Select a part on the board", "Nenhum pino encontrado": "No pin found", "Microscópio: câmera ao lado, mesclar com a placa e transparência": "Microscope: camera beside, blend with the board and transparency", "Microscópio (câmera, mesclar, transparência)": "Microscope (camera, blend, transparency)", "Câmera ao lado da placa": "Camera beside the board", "Mesclar: ligado": "Blend: on", "Mesclar com a placa": "Blend with the board",
  "Arquivo": "File", "Exibir": "View", "Preferências": "Preferences", "Ajuda": "Help", "Abrir boardview ou PDF…": "Open boardview or PDF…", "Acervo 2R (nuvem)": "2R Library (cloud)", "Enviar arquivo novo ao acervo…": "Send a new file to the library…", "Abertos recentemente": "Recently opened", "Centralizar a placa": "Center the board", "2 janelas (PDF numa segunda janela)": "2 windows (PDF in a second window)", "Painel lateral (mostrar / esconder)": "Side panel (show / hide)", "Legenda das cores das nets": "Net color legend", "Barra de status": "Status bar", "Virar a placa (superior ↔ inferior)": "Flip the board (top ↔ bottom)", "Girar para a esquerda": "Rotate left", "Girar para a direita": "Rotate right", "Linhas das nets (desligado → estrela → corrente)": "Net lines (off → star → chain)", "Buscar componente ou net": "Find part or net", "Microscópio (câmera USB)": "Microscope (USB camera)", "Mesclar imagem real com a placa": "Blend real image with the board", "Ajustes do Boardview…": "Boardview settings…", "Letra maior": "Larger text", "Letra menor": "Smaller text", "Letra no tamanho padrão": "Default text size", "Voltar a barra de ícones ao padrão": "Reset the icon bar", "Atalhos do teclado": "Keyboard shortcuts", "Espaço": "Space",
  'Local': 'Local', 'Histórico': 'History', 'Ferramentas': 'Tools', 'Diagnóstico': 'Debug', 'Ajustes': 'Settings',
  'Centralizar': 'Center', 'Centralizar: a placa inteira na tela': 'Center: the whole board on screen',
  'Aproximar (zoom +)': 'Zoom in', 'Afastar (zoom −)': 'Zoom out',
  'Girar para a esquerda (placa ou PDF ativo)': 'Rotate left (active board or PDF)', 'Girar para a direita (placa ou PDF ativo)': 'Rotate right (active board or PDF)',
  'Girar a placa 180°': 'Rotate the board 180°', 'Girar 180°': 'Rotate 180°',
  'Espelhar': 'Mirror', 'Espelhar (mirror) — placa ou PDF ativo (tecla M)': 'Mirror — active board or PDF (M key)',
  'Espelhar na vertical': 'Mirror vertically', 'Espelhar a placa na vertical': 'Mirror the board vertically',
  'Virar': 'Flip', 'Virar a placa': 'Flip the board', 'Virar a placa: lado superior ↔ inferior (Espaço)': 'Flip the board: top ↔ bottom (Space)',
  'Borboleta (os dois lados)': 'Butterfly (both sides)', 'Borboleta: os dois lados lado a lado': 'Butterfly: both sides side by side',
  'Linhas das nets': 'Net lines', 'Linhas das nets: desligado → estrela → corrente': 'Net lines: off → star → chain',
  'Voltar': 'Back', 'Voltar para a visão anterior': 'Back to the previous view', 'Avançar': 'Forward', 'Avançar para a próxima visão': 'Forward to the next view',
  'Microscópio': 'Microscope', 'Microscópio — câmera USB ao lado da placa': 'Microscope — USB camera next to the board',
  'Mesclar': 'Blend', 'Mesclar a imagem real (câmera ou foto) com a placa': 'Blend the real image (camera or photo) with the board',
  'Transparência': 'Transparency', 'Transparência da imagem mesclada e dos pinos': 'Transparency of the blended image and pins',
  'Busca local': 'Local search', 'Busca local: componente, net ou arquivo deste computador': 'Local search: part, net or file on this computer',
  'Biblioteca': 'Library', 'Biblioteca local': 'Local library', 'Biblioteca local (pasta deste computador)': 'Local library (folder on this computer)',
  'Abrir': 'Open', 'Abrir arquivo': 'Open file', 'Abrir boardview ou PDF deste computador': 'Open a boardview or PDF from this computer',
  '2 janelas': '2 windows', 'PDF numa segunda janela': 'PDF in a second window',
  'Dividir tela': 'Split screen', 'Dividir a tela: escolha o que fica lado a lado': 'Split screen: choose what goes side by side',
  'Só a placa': 'Board only', 'Placa | PDF': 'Board | PDF', 'Placa | Microscópio': 'Board | Microscope',
  'PDF | Microscópio': 'PDF | Microscope', 'Placa | PDF | Microscópio': 'Board | PDF | Microscope',
  'Adicionar função à barra': 'Add a function to the bar', 'Adicionar à barra (depois é só arrastar para o lugar):': 'Add to the bar (then drag it into place):',
  '│ Separador': '│ Separator', 'Separador (arraste ou botão direito para tirar)': 'Separator (drag, or right-click to remove)',
  'Voltar a barra ao padrão': 'Reset the bar', 'Tirar da barra': 'Remove from the bar', 'Pôr um separador depois': 'Add a separator after',
  'A transparência vale com o Mesclar ligado.': 'Transparency works with Blend on.', 'Ligar o Mesclar': 'Turn Blend on',
  'Imagem': 'Image', 'Pinos': 'Pins',
  'Nenhum PDF aberto com esta placa.': 'No PDF open with this board.', 'Abra uma placa primeiro.': 'Open a board first.',
  'Nenhuma placa aberta': 'No board open', 'Busque a placa na aba': 'Search the board in the',
  '(nuvem) ao lado, ou abra um arquivo deste computador em': '(cloud) tab, or open a file from this computer in', 'ou no botão': 'or with the button',
  'online': 'online', 'Placa (820-01700), modelo (A2141) ou ano': 'Board (820-01700), model (A2141) or year',
  'boardviews e': 'boardviews and', 'esquemáticos no acervo. Digite para buscar.': 'schematics in the library. Type to search.',
  'Nada encontrado no Acervo 2R.': 'Nothing found in the 2R Library.', 'Acervo 2R': '2R Library',
  'Enviar arquivo novo ao acervo': 'Send a new file to the library',
  'O arquivo entra no acervo de todos os técnicos, com o seu nome como quem enviou. Informe o modelo EXATO da placa.':
    'The file goes into every technician\'s library, credited to you. Enter the EXACT board model.',
  'Arquivo (boardview ou esquemático PDF)': 'File (boardview or PDF schematic)', 'Placa *': 'Board *', 'Número A do Mac *': 'Mac A number *',
  'Ano': 'Year', 'Modelo': 'Model', 'Observação': 'Note',
  'ex.: 820-01700': 'e.g. 820-01700', 'ex.: A2141 (gravado embaixo do Mac)': 'e.g. A2141 (printed under the Mac)', 'ex.: 3347': 'e.g. 3347',
  'ex.: 2019': 'e.g. 2019', 'ex.: MACBOOK PRO 16 - T2': 'e.g. MACBOOK PRO 16 - T2', 'ex.: testada OK': 'e.g. tested OK',
  'Declaro que posso compartilhar este arquivo e autorizo a 2R Tools a incluí-lo no Acervo 2R.':
    'I declare I may share this file and authorize 2R Tools to include it in the 2R Library.',
  'Enviar': 'Send', 'Enviando…': 'Sending…', 'Escolha o arquivo.': 'Choose the file.',
  'Informe o número A (ex.: A2141).': 'Enter the A number (e.g. A2141).', 'Informe a placa (ex.: 820-01700).': 'Enter the board (e.g. 820-01700).',
  'Marque a autorização para enviar.': 'Tick the authorization to send.',
  'Enviado! Em alguns minutos o arquivo aparece no Acervo 2R. Obrigado pela ajuda.': 'Sent! In a few minutes the file shows up in the 2R Library. Thanks for helping.',
  'Placa já conhecida no acervo: dados preenchidos.': 'Board already in the library: details filled in.',
  'Sem conexão com o servidor da 2R Tools.': 'No connection to the 2R Tools server.', 'O envio é liberado só para licença ativa.': 'Sending requires an active license.',
  'Limite de envios por hoje. Amanhã libera de novo.': 'Daily sending limit reached. Try again tomorrow.',
  'O servidor não aceitou o arquivo agora. Tente de novo em instantes.': 'The server did not accept the file now. Try again shortly.',
  'Arquivo vazio ou maior que 300 MB.': 'File empty or larger than 300 MB.', 'Esse tipo de arquivo não é boardview nem PDF.': 'This file type is not a boardview or PDF.',
  'Placa': 'Board', 'só PDF': 'PDF only', 'Cores das nets': 'Net colors', 'Mostrar / esconder a legenda': 'Show / hide the legend',
};

// Idioma (Roger, 11/10/2026: «no win aparece em inglês e o app tá em português»):
// 1) o que o app injeta (__2rLang); 2) ?lang= no endereço (o app também manda);
// 3) o último idioma visto (localStorage); 4) português.
function pickLang(): string {
  const w = window as unknown as { __2rLang?: string };
  let l = w.__2rLang || '';
  try { if (!l) l = new URLSearchParams(location.search).get('lang') || ''; } catch { /* sem URL */ }
  try { if (!l) l = localStorage.getItem('2r-lang') || ''; } catch { /* sem storage */ }
  l = (l || 'pt').slice(0, 2).toLowerCase();
  try { localStorage.setItem('2r-lang', l); } catch { /* sem storage */ }
  return l;
}
function lang(): 'pt' | 'es' | 'en' {
  const l = pickLang();
  return l === 'es' ? 'es' : l === 'en' ? 'en' : 'pt';
}
// 2R 22/10/2026: traduções extras injetadas pelo app (data/ui/boardripper_tr.json → window.__2rTrEn / __2rTrEs)
const R2W = window as unknown as { __2rTrEs?: Record<string, string>; __2rTrEn?: Record<string, string> };
const DICT: Record<string, string> = lang() === 'es' ? { ...ES, ...MINE_ES, ...(R2W.__2rTrEs || {}) } : lang() === 'en' ? { ...MINE_EN, ...(R2W.__2rTrEn || {}) } : PT;

const ATTRS = ['placeholder', 'title', 'aria-label', 'data-tooltip'];

function tr(s: string | null): string | null {
  if (!s) return null;
  const k = s.trim();
  const v = DICT[k];
  return v && v !== k ? s.replace(k, v) : null;
}

function walk(root: Node) {
  if (root.nodeType === Node.TEXT_NODE) {
    const v = tr(root.nodeValue);
    if (v !== null) root.nodeValue = v;
    return;
  }
  if (!(root instanceof Element)) return;
  if (root.closest('.pdf-viewer canvas, .textLayer')) return;     // conteúdo do PDF não se mexe
  for (const a of ATTRS) {
    const v = tr(root.getAttribute(a));
    if (v !== null) root.setAttribute(a, v);
  }
  const it = document.createTreeWalker(root, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT);
  let n: Node | null = it.nextNode();
  while (n) {
    if (n.nodeType === Node.TEXT_NODE) {
      const v = tr(n.nodeValue);
      if (v !== null) n.nodeValue = v;
    } else if (n instanceof Element) {
      if (n.classList.contains('textLayer')) { n = it.nextSibling() ?? it.nextNode(); continue; }
      for (const a of ATTRS) {
        const v = tr(n.getAttribute(a));
        if (v !== null) n.setAttribute(a, v);
      }
    }
    n = it.nextNode();
  }
}

export function installPortuguese(): void {
  let in2r = IS_2R;
  try { in2r = in2r || new URLSearchParams(location.search).get('r2') === '1'; } catch { /* sem URL */ }
  if (!in2r || typeof MutationObserver === 'undefined') return;
  const start = () => {
    walk(document.body);
    new MutationObserver(muts => {
      for (const m of muts) {
        if (m.type === 'characterData') walk(m.target);
        else if (m.type === 'attributes') walk(m.target);
        else m.addedNodes.forEach(walk);
      }
    }).observe(document.body, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ATTRS });
  };
  if (document.body) start(); else document.addEventListener('DOMContentLoaded', start);
}
