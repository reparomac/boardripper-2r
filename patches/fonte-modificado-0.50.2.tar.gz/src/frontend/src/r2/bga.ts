/**
 * 2R Tools (Roger, 11/10/2026): «quando aparecer o componente que é BGA, identificar
 * o pad desse componente… pra ficar mais fácil».
 * Diz qual é a BOLA do BGA (ex.: «G7» = linha G, coluna 7). Quando o boardview já
 * traz o nome da bola, usa ele; senão calcula pela grade, a partir do canto do pino 1
 * (letras no padrão JEDEC: sem I, O, Q, S, X, Z) e marca como aproximado.
 */
import type { Part } from '../parsers/types';

const ROWS = 'ABCDEFGHJKLMNPRTUVWY';      // JEDEC
const BALL_RE = /^([A-HJ-NPR-Y]{1,2})(\d{1,2})$/i;

export interface Ball { ball: string; row: string; col: number; approx: boolean; rows: number; cols: number }

function rowName(i: number): string {
  if (i < ROWS.length) return ROWS[i];
  return ROWS[Math.floor(i / ROWS.length) - 1] + ROWS[i % ROWS.length];   // AA, AB…
}

/** Agrupa coordenadas próximas (mesma linha/coluna da grade). */
function clusters(vals: number[], tol: number): number[] {
  const s = [...vals].sort((a, b) => a - b);
  const out: number[] = [];
  for (const v of s) if (!out.length || v - out[out.length - 1] > tol) out.push(v);
  return out;
}
const idx = (cl: number[], v: number) => {
  let best = 0, d = Infinity;
  cl.forEach((c, i) => { const e = Math.abs(c - v); if (e < d) { d = e; best = i; } });
  return best;
};

const cache = new WeakMap<Part, { rows: number[]; cols: number[]; flipR: boolean; flipC: boolean; named: boolean } | null>();

function grid(part: Part) {
  if (cache.has(part)) return cache.get(part)!;
  let g: { rows: number[]; cols: number[]; flipR: boolean; flipC: boolean; named: boolean } | null = null;
  const pins = part.pins;
  if (pins.length >= 16) {
    const r = Math.max(0.5, ...pins.slice(0, 8).map(p => p.radius || 0)) * 0.9;
    const xs = clusters(pins.map(p => p.position.x), r);
    const ys = clusters(pins.map(p => p.position.y), r);
    // grade cheia (ou quase) com pelo menos 4×4: BGA (um QFN/conector fica só na borda)
    // BGA é CI (U…): conector (J…) com fileiras não conta. Precisa ter bolas no MEIO
    // da grade, não só na borda (QFN/LGA de borda não é BGA).
    const isIC = /^U/i.test(part.name || '');
    const inner = pins.filter(p => {
      const ri = idx(ys, p.position.y), ci = idx(xs, p.position.x);
      return ri > 0 && ri < ys.length - 1 && ci > 0 && ci < xs.length - 1;
    }).length;
    if (isIC && xs.length >= 5 && ys.length >= 5 && pins.length >= 0.35 * xs.length * ys.length
        && inner >= 0.25 * pins.length) {
      const named = pins.filter(p => BALL_RE.test(p.name || '') || BALL_RE.test(p.number || '')).length > pins.length * 0.8;
      // canto do pino 1 / A1 vira a origem (linha A, coluna 1)
      const p1 = pins.find(p => /^(a1|1)$/i.test(p.name || '') || /^(a1|1)$/i.test(p.number || '')) ?? pins[0];
      const flipR = idx(ys, p1.position.y) > (ys.length - 1) / 2;
      const flipC = idx(xs, p1.position.x) > (xs.length - 1) / 2;
      g = { rows: ys, cols: xs, flipR, flipC, named };
    }
  }
  cache.set(part, g);
  return g;
}

/** A bola do pino num BGA, ou null se o componente não é BGA. */
export function bgaBall(part: Part | undefined, pinIndex: number): Ball | null {
  const pin = part?.pins[pinIndex];
  if (!part || !pin) return null;
  const g = grid(part);
  if (!g) return null;
  for (const t of [pin.name, pin.number]) {
    const m = BALL_RE.exec(t || '');
    if (m) return { ball: (m[1] + m[2]).toUpperCase(), row: m[1].toUpperCase(), col: +m[2], approx: false, rows: g.rows.length, cols: g.cols.length };
  }
  let ri = idx(g.rows, pin.position.y), ci = idx(g.cols, pin.position.x);
  if (g.flipR) ri = g.rows.length - 1 - ri;
  if (g.flipC) ci = g.cols.length - 1 - ci;
  const row = rowName(ri);
  return { ball: `${row}${ci + 1}`, row, col: ci + 1, approx: true, rows: g.rows.length, cols: g.cols.length };
}
