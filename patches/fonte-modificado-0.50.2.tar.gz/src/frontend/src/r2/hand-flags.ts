// 2R Tools — chaves e utilidades pequenas das edições à mão do bundle 0.48.0 (portadas para o fonte).
/* 2R 20/10/2026: pads em cinza discreto (só a net escolhida acende). localStorage «2r-pads-coloridos»="1" volta às cores */
let R2PC: boolean | null = null;
export function r2PadsColoridos(): boolean {
  if (R2PC === null) {
    try { R2PC = localStorage.getItem('2r-pads-coloridos') === '1'; } catch { R2PC = false; }
  }
  return R2PC;
}
export const R2_PAD_CINZA_BOTTOM = 6974058; // 0x6a6a6a
export const R2_PAD_CINZA_TOP = 7960953; // 0x797979

/* 2R 20/10/2026: XW (pontes de solda/shunt) não mostram leitura; window.__r2MostrarXW=true mostra */
export function r2XwOculto(p: { name?: string; refdes?: string } | null | undefined): boolean {
  return (window as unknown as { __r2MostrarXW?: boolean }).__r2MostrarXW !== true && /^XW/i.test((p && (p.name || p.refdes)) || '');
}
/* 2R 27/10/2026 09h13 (Roger: «igual o FlexBV, mas só no fundo de mesa… todo o resto mantém»): a área em volta da placa
   fica cinza-claro como no FlexBV. Cor em localStorage «2r-mesa-cor»; window.__r2MesaOff=true volta ao fundo do tema */
export function r2Mesa(c: string): string {
  if ((window as unknown as { __r2MesaOff?: boolean }).__r2MesaOff === true) return c;
  try { const v = localStorage.getItem('2r-mesa-cor'); if (v && /^#[0-9a-f]{6}$/i.test(v)) return v; } catch { /* */ }
  return '#d4d4d4';
}
