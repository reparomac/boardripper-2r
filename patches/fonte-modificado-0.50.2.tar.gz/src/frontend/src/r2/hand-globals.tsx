// 2R Tools — globais que estavam no topo do bundle editado à mão (0.48.0), portados para o fonte.
/* eslint-disable @typescript-eslint/no-explicit-any */
import { jsx, jsxs } from 'react/jsx-runtime';

/* 2R 24/10/2026: última posição do mouse (zoom na direção do mouse) */
try {
  window.addEventListener('pointermove', (e: PointerEvent) => {
    (window as any).__r2MouseXY = { x: e.clientX, y: e.clientY, t: Date.now() };
  }, { passive: true, capture: true });
} catch { /* */ }

/* 2R-postits (16/10/2026): separa a observação por « | » e pinta AÇÃO / ATENÇÃO / ESPERADO / EXPLICA / RESOLVIDO.
   O 1º parâmetro (runtime JSX) é mantido por compatibilidade com quem chama de fora; aqui usa o runtime próprio. */
(window as any).__r2Notes = function (_d: unknown, note: string, cls: string, hud?: boolean) {
  const d = { jsx, jsxs } as any;
  const T: Record<string, string> = { 'AÇÃO': 'acao', 'ATENÇÃO': 'atencao', 'ESPERADO': 'esperado', 'EXPLICA': 'explica', 'RESOLVIDO': 'resolvido' };
  const out: { k: string; t: string }[] = [];
  const plain: string[] = [];
  String(note).split(' | ').forEach((p) => {
    const m = /^(AÇÃO|ATENÇÃO|ESPERADO|EXPLICA|RESOLVIDO):\s*([\s\S]*)$/.exec(p);
    if (m) out.push({ k: T[m[1]], t: m[2] }); else plain.push(p);
  });
  if (cls === 'r2hist-sub' && out.length) return null;
  if (!out.length) return hud ? d.jsxs('span', { className: cls, children: [' · ', note] }) : d.jsx('span', { className: cls, children: note });
  return d.jsxs('span', {
    className: 'r2pi-wrap ' + cls,
    children: [
      plain.length ? d.jsx('span', { className: 'r2pi-plain', children: plain.join(' · ') }) : null,
      out.map((o, i) => d.jsx('span', {
        className: 'r2pi r2pi-' + o.k,
        title: o.k === 'acao' ? 'Ação deste passo' : o.k === 'atencao' ? 'Atenção' : o.k === 'esperado' ? 'Valor esperado' : o.k === 'resolvido' ? 'Resolução confirmada' : 'Explicação',
        children: o.t,
      }, i)),
    ],
  });
};
export {};
