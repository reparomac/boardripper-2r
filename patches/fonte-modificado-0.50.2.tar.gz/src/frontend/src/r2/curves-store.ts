/**
 * 2R Tools: curvas dos traçadores (RastreCurve 2Plus / Smart Curve) por pino — Beta.
 * Pedidos do Roger (10/10/2026):
 *  • «setor de mapeamento… baseado no boardview, com banco de dados colaborativo,
 *     que passam por um crivo da 2R tools»;
 *  • «qualquer um pode gravar, mas pra ter as curvas oficiais… aprovação;
 *     se o técnico for capacitado, não precisa de supervisão»;
 *  • «às vezes demora mais tempo para carregar os capacitores e a curva muda
 *     bastante… o programa tem que saber qual momento é o ideal para capturar…
 *     editar e capturar novamente, deletar… sempre quem capturou com data e horário».
 *
 * Cada curva guarda as CONDIÇÕES (aparelho, perfil, referência, estado da placa):
 * só compara curvas tiradas nas mesmas condições.
 * Pontos = [tensão V, corrente mA]. Os quadros ao vivo chegam por
 * window.__2rCurveFrame (leitura direta do aparelho, depois da escuta da USB).
 */
import { boardStore } from '../store/board-store';
import { IS_2R, beta } from './env';

export type Device = 'rastre' | 'smart';
export type Profile = 'baixa' | 'normal' | 'auto' | 'maxima';
export const DEVICE_LABEL: Record<Device, string> = { rastre: 'RastreCurve 2Plus', smart: 'Smart Curve (Telecélula)' };
export const PROFILE_LABEL: Record<Profile, string> = { baixa: 'Potência baixa', normal: 'Normal', auto: 'Automática', maxima: 'Máxima' };
/** Faixa de cada aparelho (manual «Dicas 2Plus»: 2,4 Vp e 10 mA). */
export const RANGE: Record<Device, { v: number; ma: number }> = { rastre: { v: 2.4, ma: 10 }, smart: { v: 2.4, ma: 10 } };

export interface Conditions { device: Device; profile: Profile; ref: string; battery: 'desligada' | 'ligada'; caps: 'descarregados' | 'carregando' }
export interface Curve {
  id: string; board: string; part: string; pin: string; net: string;
  points: [number, number][];           // [V, mA]
  image?: string;                        // foto da tela do aparelho (quando não há pontos)
  cond: Conditions;
  status: 'pendente' | 'oficial' | 'recusada' | 'minha';
  by: string; created: number; upd?: number;
  reviewer?: string; reviewed?: number; notes?: string;
}

export interface CurveApi {
  list(board: string, part: string): Promise<{ rows: Curve[]; capacitado?: boolean; who?: string }>;
  save(c: Curve): Promise<{ ok: boolean; status?: Curve['status']; error?: string }>;
  remove(id: string): Promise<{ ok: boolean }>;
  pending?(): Promise<{ rows: Curve[] }>;
  review?(id: string, action: 'aprovar' | 'recusar'): Promise<{ ok: boolean }>;
}
export function curveApi(): CurveApi | null {
  return (window as unknown as { __2rCurveApi?: CurveApi }).__2rCurveApi ?? null;
}

const COND_KEY = '2r-curvas-cond';
const DEFAULT_COND: Conditions = { device: 'rastre', profile: 'normal', ref: 'GND', battery: 'desligada', caps: 'descarregados' };

let rows: Curve[] = [];
let pending: Curve[] = [];
let capacitado = false;
let who = '';
let cond: Conditions = (() => { try { return { ...DEFAULT_COND, ...JSON.parse(localStorage.getItem(COND_KEY) || '{}') }; } catch { return { ...DEFAULT_COND }; } })();
/** Quadro ao vivo do aparelho e o quanto ele está parado (0–1). */
let live: [number, number][] | null = null;
let stable = 0;
let stableSince = 0;
let lastFrames: [number, number][][] = [];
let rev = 0;
let loadedKey = '';
const subs = new Set<() => void>();
const emit = () => { rev++; subs.forEach(f => f()); };
const newId = () => `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;

// ── comparação ──────────────────────────────────────────────────────────
/** Reamostra a curva em N pontos ao longo do caminho (para comparar formatos). */
function resample(pts: [number, number][], n = 64, r = RANGE.rastre): [number, number][] {
  if (pts.length < 2) return pts;
  const P = pts.map(([v, i]) => [v / r.v, i / r.ma] as [number, number]);
  const seg: number[] = [0];
  for (let k = 1; k < P.length; k++) seg.push(seg[k - 1] + Math.hypot(P[k][0] - P[k - 1][0], P[k][1] - P[k - 1][1]));
  const L = seg[seg.length - 1] || 1;
  const out: [number, number][] = [];
  let j = 1;
  for (let s = 0; s < n; s++) {
    const d = (L * s) / (n - 1);
    while (j < seg.length - 1 && seg[j] < d) j++;
    const t = (d - seg[j - 1]) / ((seg[j] - seg[j - 1]) || 1);
    out.push([P[j - 1][0] + (P[j][0] - P[j - 1][0]) * t, P[j - 1][1] + (P[j][1] - P[j - 1][1]) * t]);
  }
  return out;
}
/** Parecença 0–100% entre duas curvas (formato, nas mesmas condições). */
export function similarity(a: [number, number][], b: [number, number][], dev: Device = 'rastre'): number {
  if (a.length < 2 || b.length < 2) return 0;
  const A = resample(a, 64, RANGE[dev]), B = resample(b, 64, RANGE[dev]);
  // distância média de cada ponto de A ao ponto mais perto de B (e vice-versa)
  const near = (X: [number, number][], Y: [number, number][]) =>
    X.reduce((s, p) => s + Math.min(...Y.map(q => Math.hypot(p[0] - q[0], p[1] - q[1]))), 0) / X.length;
  const d = (near(A, B) + near(B, A)) / 2;            // 0 = igual; 0,25 já é bem diferente
  return Math.max(0, Math.round(100 * (1 - d / 0.25)));
}
export const sameCond = (a: Conditions, b: Conditions) =>
  a.device === b.device && a.profile === b.profile && a.ref === b.ref;

// ── estado ──────────────────────────────────────────────────────────────
function selected() {
  const tab = boardStore.activeTab;
  const sel = tab?.selection;
  const part = tab?.board && sel?.partIndex != null ? tab.board.parts[sel.partIndex] : null;
  const pin = part && sel?.pinIndex != null && sel.pinIndex >= 0 ? part.pins[sel.pinIndex] : null;
  return { tab, part, pin };
}

async function load(force = false) {
  const api = curveApi();
  const { tab, part } = selected();
  if (!api || !tab || !part) return;
  const key = `${tab.fileName}|${part.name}`;
  if (!force && key === loadedKey) return;
  loadedKey = key;
  try {
    const r = await api.list(tab.fileName, part.name);
    rows = r.rows || []; capacitado = !!r.capacitado; who = r.who || who;
    if (capacitado && api.pending) pending = (await api.pending()).rows || [];
    emit();
  } catch { /* sem conexão */ }
}

export const curvesStore = {
  subscribe(f: () => void) { subs.add(f); return () => { subs.delete(f); }; },
  get rev() { return rev; },
  get cond() { return cond; },
  get live() { return live; },
  get stable() { return stable; },
  get capacitado() { return capacitado; },
  get who() { return who; },
  get pending() { return pending; },
  setCond(p: Partial<Conditions>) {
    cond = { ...cond, ...p };
    try { localStorage.setItem(COND_KEY, JSON.stringify(cond)); } catch { /* */ }
    emit();
  },
  /** Curvas do pino selecionado (todas as condições; a tela separa). */
  forPin(pinNo: string) { return rows.filter(c => c.pin === pinNo); },
  reload() { void load(true); },
  /** Grava a curva do quadro atual (ou dos pontos dados) no pino selecionado. */
  async capture(points?: [number, number][], image?: string, notes = '', replaceId?: string): Promise<string> {
    const api = curveApi();
    const { tab, part, pin } = selected();
    if (!tab || !part || !pin) return 'Selecione o pino na placa.';
    const pts = points ?? live ?? [];
    if (!pts.length && !image) return 'Sem curva para gravar.';
    const c: Curve = { id: replaceId || newId(), board: tab.fileName, part: part.name, pin: pin.number || pin.name, net: pin.net || '',
      points: pts, ...(image ? { image } : {}), cond: { ...cond }, status: capacitado ? 'oficial' : 'pendente', by: who, created: Date.now(), upd: Date.now(), notes };
    if (!api) return 'Sem ligação com o app.';
    const r = await api.save(c);
    if (!r.ok) return r.error || 'O servidor não aceitou a curva.';
    c.status = r.status || c.status;
    rows = [c, ...rows.filter(x => x.id !== c.id)];
    emit();
    return c.status === 'oficial' ? 'Gravada como curva OFICIAL (técnico capacitado).' : 'Gravada. Fica pendente até a aprovação da 2R.';
  },
  async remove(id: string) {
    const api = curveApi();
    if (api) await api.remove(id).catch(() => null);
    rows = rows.filter(c => c.id !== id); emit();
  },
  async review(id: string, action: 'aprovar' | 'recusar') {
    const api = curveApi();
    if (!api?.review) return;
    await api.review(id, action).catch(() => null);
    pending = pending.filter(c => c.id !== id);
    rows = rows.map(c => c.id !== id ? c : { ...c, status: action === 'aprovar' ? 'oficial' : 'recusada', reviewer: who, reviewed: Date.now() });
    emit();
  },
};

/** Quadro novo do aparelho: mede o quanto a curva mudou para saber quando ela firmou
 *  (capacitores carregando mudam a curva; quando para de mudar, é a hora de capturar). */
function onFrame(pts: [number, number][]) {
  live = pts;
  lastFrames = [...lastFrames.slice(-5), pts];
  if (lastFrames.length >= 3) {
    const s = Math.min(similarity(lastFrames[lastFrames.length - 1], lastFrames[lastFrames.length - 2], cond.device),
      similarity(lastFrames[lastFrames.length - 1], lastFrames[lastFrames.length - 3], cond.device));
    const now = Date.now();
    if (s >= 97) { if (!stableSince) stableSince = now; } else stableSince = 0;
    stable = stableSince ? Math.min(1, (now - stableSince) / 1500) : Math.max(0, (s - 70) / 30) * 0.6;
  }
  emit();
}

export function installCurves(): void {
  if (!IS_2R || !beta('curvas')) return;
  (window as unknown as Record<string, unknown>).__2rCurveFrame = (pts: [number, number][]) => onFrame(pts);
  boardStore.subscribe(() => { void load(); });
}
