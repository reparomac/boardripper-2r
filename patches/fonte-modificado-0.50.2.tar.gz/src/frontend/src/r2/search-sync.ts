/** 2R Tools (Roger, 11/10/2026): «temos 3 buscas — geral, do PDF e do BDV — melhorar».
 *  Busca junto: o que se procura na placa vai também para o PDF aberto, e vice-versa.
 *  Liga/desliga em localStorage «2r-search-sync» (padrão ligado). */
import { boardStore } from '../store/board-store';
import { pdfStore } from '../store/pdf-store';
import { fileInputRefs } from '../store/file-inputs';
import { IS_2R } from './env';
import { r2BuscaExata, r2Match } from './loose-match';

/* 2R 26/10/2026: busca Exata | Geral — window.__r2BuscaExata.get('bdv'|'pdf') / .set(k, v) (index.html usa) */
(window as unknown as Record<string, unknown>).__r2BuscaExata = {
  get: r2BuscaExata,
  set(k: 'bdv' | 'pdf', v: boolean) {
    try { localStorage.setItem('2r-busca-exata-' + k, v ? '1' : '0'); } catch { /* */ }
    if (k === 'bdv') {
      try { (boardStore as unknown as { _cachedSearchQuery: string | null })._cachedSearchQuery = null; boardStore.r2Notify(); } catch { /* */ }
    } else {
      try {
        const d = (pdfStore as unknown as { _active?: { searchQuery?: string } })._active;
        if (d && d.searchQuery) pdfStore.searchText(d.searchQuery, 'lookup');
      } catch { /* */ }
    }
    window.dispatchEvent(new Event('2r-busca-exata'));
  },
};
(window as unknown as Record<string, unknown>).__r2sd = (i: string, e: string | string[]) => r2Match(i, e);

let busy = false;      // evita ida e volta infinita (placa → PDF → placa…)

/* 2R 26/10/2026 (Roger: «quero um search no BDV e outro para o PDF… para não misturar»): buscar junto começa
   DESLIGADO (chave nova «2r-search-sync2»); liga em Configurações */
export function searchSyncOn(): boolean {
  try { return IS_2R && localStorage.getItem('2r-search-sync2') === '1'; } catch { return false; }
}
export function setSearchSync(on: boolean) {
  try { localStorage.setItem('2r-search-sync2', on ? '1' : '0'); } catch { /* */ }
  window.dispatchEvent(new Event('2r-search-sync'));
}

/** PDF que acompanha a placa: o ativo, senão o primeiro aberto. */
function pdfTarget(): string | null {
  return pdfStore.activeFileName2R ?? pdfStore.loadedFileNames[0] ?? null;
}

/** Placa → PDF. */
export function mirrorToPdf(term: string) {
  if (busy || !searchSyncOn()) return;
  const t = term.trim();
  const fn = pdfTarget();
  if (!fn || t.length < 2) return;
  busy = true;
  try {
    pdfStore.switchTo(fn);
    pdfStore.searchText(t);
    if (fileInputRefs.pdfSearch) fileInputRefs.pdfSearch.value = t;
  } finally { busy = false; }
}

/** PDF → placa (preenche a busca da placa e acende o que achar). */
export function mirrorToBoard(term: string) {
  if (busy || !searchSyncOn()) return;
  const t = term.trim();
  if (!boardStore.activeTab?.board || t.length < 2) return;
  busy = true;
  try { boardStore.setSearch(t); } finally { busy = false; }
}
