/**
 * 2R Tools: Teleguiado — sequência de start indicada na placa (Roger, 10/10/2026):
 * «deixar o boardripper com a função teleguiado… uma sequência de start e já
 *  indicar os pontos na placa-mãe… em cima de um texto, converter… com a função
 *  ativada, as setas do teclado vão alternando os pontos na sequência».
 *
 * Texto aceito (exemplo do Roger, M1 820-02020):
 *   M1 820-02020
 *   01 USBC0_CC1
 *   14 MPMU_XOUT,MPMU-XIN (32.768KHz) (ELE MANDA O MESMO CLOCK PARA U7700)
 * 1ª linha sem número = título (o 820-xxxxx liga o roteiro à placa aberta).
 * Cada linha numerada = um passo; nomes separados por vírgula; o que está entre
 * parênteses vira observação.
 */
import { boardStore } from '../store/board-store';
import { pdfStore } from '../store/pdf-store';
import type { BoardData } from '../parsers/types';
import { IS_2R, beta } from './env';

export interface Step { n: number; nets: string[]; note: string; raw: string; /** ponto escolhido à mão (ex.: «C7033.1») */ point?: string;
  /** valores do passo (Roger: «add mais 3 colunas, como tensão, modo diodo e resistência… editável durante a
   *  leitura dos pontos, pelos instrumentos ou manualmente») — texto como o técnico escreve */
  v?: string; d?: string; r?: string; /** quem/quando preencheu pelo instrumento */ valBy?: string; valAt?: number;
  /** Ponto a ponto (Roger, 11/10/2026): nome do teste (renomeável), valor certo (ideal) e a estrela
   *  do «valor certo depois do reparo» (vira referência). */
  name?: string; iv?: string; id?: string; ir?: string; star?: boolean;
  /** 2R 16/10/2026: 1 linha por passo — sub-passos de um grupo (id do grupo, posição k de m, nº do passo original) */
  gid?: string | number; gk?: number; gm?: number; gn?: number;
  /** 2R 26/10/2026: tipo da medida do valor esperado (v | d | r) */
  tipo?: 'v' | 'd' | 'r' }
export interface Roteiro { id: string; title: string; board: string; steps: Step[]; created: number; by?: string; models?: string[]; builtin?: boolean;
  /** créditos: quem montou a sequência (Roger: «colocar os créditos para o dono da sequência de start») */
  credit?: string; upd?: number;
  /** start = sequência de start; analise = sequência de análise montada pelo técnico */
  kind?: 'start' | 'analise' }
export interface Point { partIndex: number; pinIndex: number; label: string; kind: 'capacitor' | 'resistor' | 'bobina' | 'teste' | 'outro'; fixed?: boolean }
export interface Resolved { step: Step; nets: string[]; missing: string[]; points: Point[] }

// Sequência de start do M1 enviada pelo Roger (10/10/2026), que pediu para deixar
// no A2337 (MacBook Air M1, 820-02016) e no A2338 (MacBook Pro 13 M1, 820-02020).
// Conferida contra os boardviews reais do servidor (/Volumes/acervo2r/Boardview):
// onde o nome do texto não existe na placa, o passo usa o nome da placa e a
// observação guarda o nome original.
const M1_02020 = `01 USBC0_CC1
02 PPVBUS_USBC0
03 PP3V3_UPC0_LDO
04 PP1V5_UPC0_LDO_CORE
05 PPDCIN_USBC_AON (no texto: PPDCIN_AONSW — na 820-02020 o nome é PPDCIN_USBC_AON)
06 PPDCIN_AON_CHGR_R
07 PPCHGR_VDDA
08 PPCHGR_VDDP
09 PPBUS_AON
10 CHGR_EN_MVR (no texto: CHGR_MVR_EN)
11 P3V8AON_PWR_EN
12 PP5V_AON
13 PP3V8_AON (no texto: PP3V8_AON_VDDMAIN)
14 MPMU_XOUT,MPMU_XIN (32.768KHz) (ELE MANDA O MESMO CLOCK PARA U7700)
15 PP5V_BSTLQ_SPMU
16 PP5V_BSTLQ_MPMU
17 PP1V8_AON_MPMU
18 P3V3_S2_PWR_EN_R (no texto: P3V3_S2_PWR_EN)
19 PP1V8_AWAKE
20 PP2V5_AWAKE_NAND
21 P5V_S2_PWR_EN_R (no texto: P5V_S2_PWR_EN)
22 PP1V06_S2SW_DRAM
23 PP0V88_S1
24 PP0V764_S1_SRAM (no texto: PP0V7764_S1_SRAM)
25 PPVDD_DISP_S1
26 PPVDD_SOC_S1
27 PPVDD_DCS_S1
28 PP0V6_S1_VDDQL
29 PP3V3_S2
30 PP1V25_S2
31 PP1V8_S2
32 PP3V3_S2_UPC
33 PP0V855_S2SW_CIO
34 PP0V805_S1_VDD_FIXED
35 PP1V2_S2_CIO
36 PP1V25_AWAKE_NAND (não existe na 820-02020 — só na 820-02016)
37 PP1V2_AWAKE_PLL
38 PP0V88_AWAKESW_NAND (no texto: PP0V88_AWAKE_NAND)
39 PP5V_S2
40 PPVDD_CPU_SRAM_AWAKE
41 PPVDD_ECPU_AWAKE
42 PPVDD_PCPU_AWAKE
43 PPVDD_GPU_AWAKE
44 PPVOUT_LCDBKLT (no texto: PPVOUT_LCD_BACKLT)`;
const M1_02016 = M1_02020
  .replace(/^05 .*$/m, '05 PPDCIN_AONSW')
  .replace(/^13 .*$/m, '13 PP3V8_AON_VDDMAIN')
  .replace(/^36 .*$/m, '36 PP1V25_AWAKE_NAND')
  .replace(/^38 .*$/m, '38 PP0V88_AWAKE_NAND');
const CREDIT = 'Wellington — Welltech (sequência usada nos testes do 2R Tools)';
const BUILTIN: Roteiro[] = [
  { ...parseRoteiro('A2338 · MacBook Pro 13 M1 · 820-02020 — sequência de start\n' + M1_02020), id: 'm1-a2338', models: ['A2338'], builtin: true, by: 'Roger (2R Tools)', credit: CREDIT, created: 0 },
  { ...parseRoteiro('A2337 · MacBook Air M1 · 820-02016 — sequência de start\n' + M1_02016), id: 'm1-a2337', models: ['A2337'], builtin: true, by: 'Roger (2R Tools)', credit: CREDIT, created: 0 },
];

const KEY = '2r-teleguiado';
const ON_KEY = '2r-teleguiado-on';
const HIDE_KEY = '2r-teleguiado-ocultos';
let hidden: string[] = (() => { try { return JSON.parse(localStorage.getItem(HIDE_KEY) || '[]'); } catch { return []; } })();
let own: Roteiro[] = (() => { try { return JSON.parse(localStorage.getItem(KEY) || '[]'); } catch { return []; } })();
const EDIT_KEY = '2r-teleguiado-edicoes';     // passos editados dos roteiros de fábrica
const edits: Record<string, Step[]> = (() => { try { return JSON.parse(localStorage.getItem(EDIT_KEY) || '{}'); } catch { return {}; } })();
const CRED_KEY = '2r-teleguiado-creditos';
const credits: Record<string, string> = (() => { try { return JSON.parse(localStorage.getItem(CRED_KEY) || '{}'); } catch { return {}; } })();
let list: Roteiro[] = [...own, ...BUILTIN.filter(b => !hidden.includes(b.id))
  .map(b => ({ ...b, ...(edits[b.id] ? { steps: edits[b.id] } : {}), ...(credits[b.id] != null ? { credit: credits[b.id] } : {}) }))];
let active: Roteiro | null = null;
let pos = 0;
let on = false;
let pointIdx = 0;              // qual ponto da net está indicado (Tab troca)
let programming = false;      // montando a lista de pontos a medir (Roger, 11/10/2026)
let rev = 0;
const subs = new Set<() => void>();
const emit = () => { rev++; subs.forEach(f => f()); };
const save = () => {
  own = list.filter(r => !r.builtin);
  for (const r of list) if (r.builtin) edits[r.id] = r.steps;
  try {
    localStorage.setItem(KEY, JSON.stringify(own)); localStorage.setItem(HIDE_KEY, JSON.stringify(hidden));
    localStorage.setItem(EDIT_KEY, JSON.stringify(edits)); localStorage.setItem(CRED_KEY, JSON.stringify(credits));
  } catch { /* */ }
};
const norm = (s: string) => s.trim().toUpperCase().replace(/-/g, '_').replace(/\s+/g, '');

/** Converte o texto colado num roteiro. */
export function parseRoteiro(text: string): Roteiro {
  const lines = text.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
  let title = '';
  const steps: Step[] = [];
  for (const line of lines) {
    const m = /^(\d{1,3})[\s.)\-–:]+(.+)$/.exec(line);
    if (!m) { if (!steps.length && !title) title = line; else if (steps.length) steps[steps.length - 1].note += (steps[steps.length - 1].note ? ' ' : '') + line; continue; }
    let body = m[2];
    const notes: string[] = [];
    body = body.replace(/\(([^)]*)\)/g, (_s, g) => { notes.push(String(g).trim()); return ' '; });
    const nets = body.split(/[,;/]+|\s+e\s+/i).map(s => s.trim()).filter(Boolean)
      .map(s => s.split(/\s+/)[0]).filter(s => /[A-Z0-9_]{2,}/i.test(s));
    steps.push({ n: parseInt(m[1], 10), nets, note: notes.join(' · '), raw: line });
  }
  const board = (/(820-\d{4,5}(?:-[A-Z0-9]+)?)/i.exec(title)?.[1] || '').toUpperCase();
  return { id: `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`, title: title || 'Roteiro', board, steps, created: Date.now(), kind: 'start' };
}

/** Acha as nets do passo na placa e os pontos bons para medir (capacitor primeiro). */
export function resolve(board: BoardData, step: Step): Resolved {
  const byNorm = new Map<string, string>();
  for (const name of board.nets.keys()) byNorm.set(norm(name), name);
  const nets: string[] = [], missing: string[] = [];
  for (const want of step.nets) {
    const k = norm(want);
    let hit = byNorm.get(k);
    if (!hit) {                                  // nome parecido: sem sufixo/prefixo
      const cands = [...byNorm.keys()].filter(n => n.startsWith(k) || k.startsWith(n) || n.endsWith('_' + k));
      if (cands.length === 1) hit = byNorm.get(cands[0]);
    }
    if (hit) nets.push(hit); else missing.push(want);
  }
  const points: (Point & { score: number })[] = [];
  for (const net of nets) {
    for (const { partIndex, pinIndex } of board.nets.get(net)?.pinIndices ?? []) {
      const p = board.parts[partIndex];
      if (!p || p.hidden) continue;
      const nm = p.name.toUpperCase();
      const kind: Point['kind'] = p.pins.length === 1 ? 'teste'
        : p.pins.length <= 3 && /^C\d/.test(nm) ? 'capacitor'
        : p.pins.length <= 3 && /^(R|RP)\d/.test(nm) ? 'resistor'
        : p.pins.length <= 3 && /^(L|FB)\d/.test(nm) ? 'bobina' : 'outro';
      const score = { capacitor: 0, teste: 1, resistor: 2, bobina: 3, outro: 9 }[kind];
      const q = p.pins[pinIndex];
      points.push({ partIndex, pinIndex, label: `${p.name}.${q.number || q.name}`, kind, score });
    }
  }
  // ponto escolhido à mão vem primeiro (mesmo que seja de outra net — o técnico sabe)
  if (step.point) {
    const [pn, qn] = step.point.toUpperCase().split('.');
    const pi = board.parts.findIndex(p => p.name.toUpperCase() === pn);
    const qi = pi >= 0 ? board.parts[pi].pins.findIndex(q => (q.number || q.name).toUpperCase() === qn) : -1;
    if (qi >= 0) {
      const ex = points.find(p => p.partIndex === pi && p.pinIndex === qi);
      if (ex) { ex.score = -1; ex.fixed = true; }
      else points.push({ partIndex: pi, pinIndex: qi, label: step.point.toUpperCase(), kind: 'outro', fixed: true, score: -1 });
    }
  }
  points.sort((a, b) => a.score - b.score || a.label.localeCompare(b.label, undefined, { numeric: true }));
  return { step, nets, missing, points: points.map(({ score: _s, ...r }) => r) };
}

function current(): Resolved | null {
  // 2R: com o ponto a ponto ligado, vale a placa aberta mesmo que a aba ativa seja outra (PDF)
  const b = boardStore.activeTab?.board || (active && on ? (boardStore.tabs.find(t => t.board) || { board: null }).board : null);
  if (!active || !b || !active.steps[pos]) return null;
  return resolve(b, active.steps[pos]);
}

/** Zoom da Sequência de start (Roger, 11/10/2026): passando de um passo para o outro
 *  o zoom NÃO muda — só centraliza o ponto. O último zoom fica guardado e volta ao
 *  ligar a sequência de novo. */
let applySavedZoom = false;
function savedZoom(): number | undefined {
  try { const v = parseFloat(localStorage.getItem('2r-seq-zoom') || ''); return v > 0 ? v : undefined; } catch { return undefined; }
}

type R2W = Window & {
  __2rRend?: { containerEl?: HTMLElement };
  __r2rc?: ReturnType<typeof setTimeout>;
  __r2PertoOff?: boolean;
  __r2pp?: { x: number; y: number; side?: string } | null;
  __r2rp?: { on: boolean };
  __r2GrpMudou?: (a: Roteiro, p: number) => void;
  __r2Anot?: (a: Roteiro, i: number, patch: Partial<Step>) => void;
  __r2Num?: (k: string, v: string) => string | null;
  __r2PlacaExtra?: string;
  __2rVP?: { scale: { x: number } };
  __2rBoardGet?: () => typeof boardStore;
  __r2LadoPeca?: (w: string) => void;
  __r2seq?: unknown;
};
const r2w = window as R2W;

/* 2R 21/10/2026 (Roger): a cada passo, mesmo zoom do usuário e o pad no centro — se a área da placa mudar de
   tamanho logo depois (coluna/esquemático abrindo), centraliza de novo */
function r2Recentra(t: Point) {
  const R = r2w.__2rRend;
  if (!R || !R.containerEl) return;
  const w0 = R.containerEl.clientWidth, h0 = R.containerEl.clientHeight;
  clearTimeout(r2w.__r2rc);
  r2w.__r2rc = setTimeout(() => {
    const R2 = r2w.__2rRend;
    if (!R2 || !R2.containerEl || !on) return;
    if (R2.containerEl.clientWidth !== w0 || R2.containerEl.clientHeight !== h0) {
      const s = boardStore.activeTab?.selection;
      if (s && s.partIndex === t.partIndex && s.pinIndex === t.pinIndex) boardStore.focusPinKeepZoom(t.partIndex, t.pinIndex);
    }
  }, 650);
}
/* 2R 26/10/2026 (Roger): «durante os estudos, quando mudar de ponto, ir para o ponto mais próximo em relação ao ponto
   anterior» — entre os pontos medíveis da net, vai para o mais perto do ponto do passo anterior; ponto fixado à mão vale */
function r2PtAtual(): { x: number; y: number; side?: string } | null {
  try {
    const c = current(), b = boardStore.activeTab?.board;
    const t = c && c.points[pointIdx % Math.max(1, c.points.length)];
    const p = t && b && b.parts[t.partIndex]?.pins[t.pinIndex];
    return p && b ? { x: p.position.x, y: p.position.y, side: b.parts[t!.partIndex].side } : null;
  } catch { return null; }
}
function r2Perto(p: { x: number; y: number; side?: string } | null | undefined): number {
  try {
    if (!p || r2w.__r2PertoOff) return 0;
    const c = current(), b = boardStore.activeTab?.board;
    if (!c || !b || !c.points.length || c.points[0].fixed) return 0;
    let a = c.points.map((t, k) => ({ t, k })).filter(o => o.t.kind !== 'outro');
    if (!a.length) a = c.points.map((t, k) => ({ t, k }));
    let m = 0, d = Infinity;
    for (const o of a) {
      const pt = b.parts[o.t.partIndex], q = pt?.pins[o.t.pinIndex];
      if (!q) continue;
      const e = (q.position.x - p.x) ** 2 + (q.position.y - p.y) ** 2 + (p.side != null && pt.side != null && pt.side !== p.side ? 1e-9 : 0);
      if (e < d) { d = e; m = o.k; }
    }
    return m;
  } catch { return 0; }
}
/* 2R 26/10/2026 (Roger: «quando fizer uma busca no PDF, clicar duas vezes, mostrar já o componente exato no BDV, se
   possível inverter o lado bottom e top»): peça no lado escondido → vira a placa para o lado dela; com os dois lados ou
   borboleta, não mexe */
export function r2LadoPeca(w: string): void {
  try {
    const t = boardStore.activeTab, b = t?.board;
    if (!t || !b || t.butterfly) return;
    const W = String(w).toUpperCase(), P = b.parts.find(p => p.name.toUpperCase() === W);
    if (!P || (P.side !== 'top' && P.side !== 'bottom')) return;
    const vis = P.side === 'top' ? t.showTop : t.showBottom;
    if (!vis) boardStore.r2Patch({ showTop: P.side === 'top', showBottom: P.side === 'bottom', butterfly: false });
  } catch { /* */ }
}
r2w.__r2LadoPeca = (w: string) => r2LadoPeca(w);

/** Mostra o passo na placa: acende a net e leva a câmera ao ponto indicado. */
function show() {
  const r = current();
  if (!r) { emit(); return; }
  const tab = boardStore.activeTab;
  const pt = r.points[pointIdx % Math.max(1, r.points.length)];
  if (pt && tab?.board) {
    const z = applySavedZoom ? savedZoom() : undefined;
    applySavedZoom = false;
    // 2R 27/10/2026 (Roger: «nos estudos, tem ponto que fica do outro lado da placa, tem que virar automaticamente…
    // sempre deixar o ponto no centro da cruz»)
    const vt = (() => {
      try {
        const P = tab.board!.parts[pt.partIndex];
        if (!P || tab.butterfly || (P.side !== 'top' && P.side !== 'bottom')) return false;
        const vis = P.side === 'top' ? tab.showTop : tab.showBottom;
        if (vis) return false;
        r2LadoPeca(P.name);
        return true;
      } catch { return false; }
    })();
    boardStore.focusPinKeepZoom(pt.partIndex, pt.pinIndex, z);
    r2Recentra(pt);
    if (vt) [90, 300].forEach(ms => setTimeout(() => { try { boardStore.focusPinKeepZoom(pt.partIndex, pt.pinIndex); } catch { /* */ } }, ms));
  } else if (r.nets[0]) {
    boardStore.highlightNet(r.nets[0]);
  }
  followSchematic(r);
  emit();
}

/** Esquemático junto (Roger: «deixar linkado com o esquemático, cada ponto que pular,
 *  alterar no esquemático também»): procura a net do passo no PDF da placa. */
const PDF_KEY = '2r-seq-pdf';
let pdfFollow = (() => { try { return localStorage.getItem(PDF_KEY) !== '0'; } catch { return true; } })();
let pdfTimer: number | undefined;
function followSchematic(r: Resolved) {
  if (!pdfFollow || !r.nets[0]) return;
  const pdfs = boardStore.activeTab?.pdfFileNames ?? [];
  if (!pdfs.length) return;
  window.clearTimeout(pdfTimer);
  // depois do «seguir PDF» do próprio BoardRipper (que procura pelo componente), para a net valer
  pdfTimer = window.setTimeout(() => {
    try {
      pdfStore.switchTo(pdfs[0]);
      pdfStore.lookupEntity(pdfs[0], r.nets[0], r.nets.slice(1).map(text => ({ text, kind: 'net' as const })), 'lookup');
    } catch { /* PDF ainda carregando */ }
  }, 180);
}

r2w.__2rBoardGet = () => boardStore;
export const guideStore = {
  subscribe(f: () => void) { subs.add(f); return () => { subs.delete(f); }; },
  get rev() { return rev; },
  get list() { return list; },
  get active() { return active; },
  get pos() { return pos; },
  get on() { return on; },
  get pointIdx() { return pointIdx; },
  get pdfFollow() { return pdfFollow; },
  setPdfFollow(v: boolean) { pdfFollow = v; try { localStorage.setItem(PDF_KEY, v ? '1' : '0'); } catch { /* */ } const r = current(); if (v && r && on) followSchematic(r); emit(); },
  current,
  add(text: string): Roteiro | null {
    const r = parseRoteiro(text);
    if (!r.steps.length) return null;
    list = [r, ...list.filter(x => !(x.title === r.title && x.board === r.board))];
    save(); push(r); emit();
    return r;
  },
  remove(id: string) { const old = list.find(x => x.id === id); if (old && !old.builtin) push(old, true); if (BUILTIN.some(b => b.id === id)) hidden = [...hidden, id]; list = list.filter(x => x.id !== id); if (active?.id === id) { active = null; on = false; } save(); emit(); },
  /** Roteiros que combinam com a placa aberta (pelo 820-xxxxx no nome do arquivo). */
  forOpenBoard(): Roteiro[] {
    const f = (boardStore.activeTab?.fileName || '').toUpperCase();
    return list.filter(r => matchesBoard(r, f));
  },
  open(id: string) { active = list.find(x => x.id === id) ?? null; pos = 0; pointIdx = 0; emit(); },
  start() { if (!active) return; on = true; applySavedZoom = true; try { localStorage.setItem(ON_KEY, '1'); } catch { /* */ } show(); },
  stop() {
    try { const v = r2w.__2rVP, z = v && Math.abs(v.scale.x); if (z && z > 0) localStorage.setItem('2r-seq-zoom', String(z)); } catch { /* */ }
    on = false;
    r2w.__r2rp = { on: false };
    try { localStorage.setItem(ON_KEY, '0'); } catch { /* */ } emit();
  },
  go(i: number) {
    if (!active) return;
    r2w.__r2pp = r2PtAtual();
    pos = Math.max(0, Math.min(active.steps.length - 1, i));
    pointIdx = r2Perto(r2w.__r2pp);
    if (r2w.__r2GrpMudou) r2w.__r2GrpMudou(active, pos);
    show();
  },
  next() { guideStore.go(r2w.__r2rp && r2w.__r2rp.on ? guideStore.nextMeasured(1) : pos + 1); },
  prev() { guideStore.go(r2w.__r2rp && r2w.__r2rp.on ? guideStore.nextMeasured(-1) : pos - 1); },
  /* 2R 16/10/2026: REPLAY — rever só os passos já medidos (somente leitura) */
  nextMeasured(d: number): number {
    if (!active) return pos;
    for (let e = pos + d; e >= 0 && e < active.steps.length; e += d) {
      const t = active.steps[e];
      if (t.v || t.d || t.r) return e;
    }
    return pos;
  },
  replay(v: boolean): boolean {
    r2w.__r2rp = { on: !!v };
    if (v && active) {
      const e = active.steps.findIndex(t => t.v || t.d || t.r);
      if (e < 0) { r2w.__r2rp = { on: false }; emit(); return false; }
      if (!on) guideStore.start();
      guideStore.go(e);
    } else emit();
    return true;
  },
  get replaying() { return !!(r2w.__r2rp && r2w.__r2rp.on); },
  /** Outro ponto da mesma net (Tab). */
  nextPoint(d = 1) { const r = current(); if (!r?.points.length) return; pointIdx = (pointIdx + d + r.points.length) % r.points.length; show(); },
  usePoint(i: number) { pointIdx = i; show(); },

  // ── edição dos passos (Roger: «add a opção de editar o ponto teleguiado») ──
  /** Muda nets / observação / ponto do passo i do roteiro aberto. */
  editStep(i: number, patch: Partial<Step>) {
    if (!active || !active.steps[i]) return;
    const steps = active.steps.map((st, k) => (k === i ? { ...st, ...patch } : st));
    replaceActive(steps);
    if (r2w.__r2Anot) r2w.__r2Anot(active, i, patch);
    const onlyValues = Object.keys(patch).every(k => ['v', 'd', 'r', 'valBy', 'valAt', 'note'].includes(k));
    if (i === pos && !onlyValues) { pointIdx = 0; if (on) show(); }
  },
  /** Fixa o pino selecionado na placa como o ponto do passo atual. */
  pinSelectedAsPoint(i = pos): string {
    const tab = boardStore.activeTab;
    const sel = tab?.selection;
    const part = tab?.board && sel?.partIndex != null ? tab.board.parts[sel.partIndex] : null;
    const pin = part && sel?.pinIndex != null && sel.pinIndex >= 0 ? part.pins[sel.pinIndex] : null;
    if (!part || !pin) return '';
    const label = `${part.name}.${pin.number || pin.name}`;
    guideStore.editStep(i, { point: label });
    return label;
  },
  clearPoint(i = pos) { guideStore.editStep(i, { point: undefined }); },
  insertStep(after: number) {
    if (!active) return;
    const steps = [...active.steps];
    steps.splice(after + 1, 0, { n: 0, nets: [], note: '', raw: '' });
    replaceActive(renumber(steps));
    pos = after + 1; emit();
  },
  deleteStep(i: number) {
    if (!active || active.steps.length <= 1) return;
    const steps = active.steps.filter((_s, k) => k !== i);
    replaceActive(renumber(steps));
    pos = Math.min(pos, steps.length - 1); if (on) show(); else emit();
  },
  moveStep(i: number, d: -1 | 1) {
    if (!active) return;
    const j = i + d;
    if (j < 0 || j >= active.steps.length) return;
    const steps = [...active.steps];
    [steps[i], steps[j]] = [steps[j], steps[i]];
    replaceActive(renumber(steps));
    if (pos === i) pos = j; emit();
  },
  /** Sequência nova do zero para a placa aberta (Roger: «criar sua própria sequência de análise»). */
  createBlank(title: string, kind: 'start' | 'analise', credit: string): Roteiro | null {
    const f = boardStore.activeTab?.fileName || '';
    const num = /(820-\d{4,5})/i.exec(f)?.[1]?.toUpperCase() || '';
    const r: Roteiro = { id: `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`,
      title: title.trim() || `${num || f} — ${kind === 'start' ? 'sequência de start' : 'sequência de análise'}`,
      board: num, steps: [], created: Date.now(), kind, credit: credit.trim(), by: credit.trim() };
    list = [r, ...list]; active = r; pos = 0; pointIdx = 0;
    save(); push(r); emit();
    return r;
  },
  /** Acrescenta um passo com a net do pino selecionado (e fixa esse pino como ponto). */
  addSelectedPin(): string {
    if (!active) return '';
    const tab = boardStore.activeTab, sel = tab?.selection;
    const part = tab?.board && sel?.partIndex != null ? tab.board.parts[sel.partIndex] : null;
    const pin = part && sel?.pinIndex != null && sel.pinIndex >= 0 ? part.pins[sel.pinIndex] : null;
    if (!part || !pin) return '';
    const label = `${part.name}.${pin.number || pin.name}`;
    const steps = [...active.steps];
    const at = active.steps.length ? pos + 1 : 0;
    steps.splice(at, 0, { n: 0, nets: pin.net ? [pin.net] : [], note: '', raw: '', point: label });
    replaceActive(renumber(steps));
    pos = at; emit();
    return label;
  },
  /** Leitura do instrumento com a sequência ligada: preenche a coluna do modo no passo atual. */
  recordValue(mode: 'tensao' | 'diodo' | 'resistencia', value: number, unit: string, by = ''): boolean {
    if (!on || !active || !active.steps[pos] || (r2w.__r2rp && r2w.__r2rp.on)) return false;
    const key = mode === 'tensao' ? 'v' : mode === 'diodo' ? 'd' : 'r';
    // 2R 26/10/2026: valores no padrão do SDS (vírgula, V com 2 casas) — window.__r2Num vem do index.html
    const txt = r2w.__r2Num ? r2w.__r2Num(key, String(value)) : mode === 'resistencia' ? fmtOhm(value) : value.toFixed(3);
    void unit;
    guideStore.editStep(pos, { [key]: txt as string, valBy: by, valAt: Date.now() } as Partial<Step>);
    return true;
  },
  // ── programar os pontos a medir (Roger, 11/10/2026): clicar/buscar na placa e no PDF,
  //    ou pegar o CI inteiro; depois «Finalizar e medir». ──
  get programming() { return programming; },
  setProgramming(v: boolean) { programming = v; emit(); },
  /** Começa uma lista nova (análise) para programar os pontos; entra no modo programar. */
  startProgramming(ciName?: string): void {
    const f = boardStore.activeTab?.fileName || '';
    const num = /(820-\d{4,5})/i.exec(f)?.[1]?.toUpperCase() || '';
    const title = (ciName ? `${ciName} — pontos` : `${num || 'Placa'} — pontos a medir`);
    guideStore.createBlank(title, 'analise', '');
    programming = true; on = false; emit();
  },
  /** Adiciona a net pelo nome (busca). Põe o melhor ponto (capacitor primeiro) como ponto. */
  addNetByName(name: string): string {
    const b = boardStore.activeTab?.board;
    if (!active || !b) return '';
    const want = norm(name);
    let net = '';
    for (const nm of b.nets.keys()) { if (norm(nm) === want) { net = nm; break; } }
    if (!net) for (const nm of b.nets.keys()) { if (norm(nm).includes(want)) { net = nm; break; } }
    if (!net) return '';
    const steps = [...active.steps];
    if (steps.some(st => st.nets.includes(net) && !st.point)) { /* já tem */ }
    const tmp: Step = { n: 0, nets: [net], note: '', raw: '' };
    const r = resolve(b, tmp);
    const pt = r.points[0]?.label;
    steps.push({ n: 0, nets: [net], note: '', raw: '', ...(pt ? { point: pt } : {}) });
    replaceActive(renumber(steps));
    pos = steps.length - 1; if (pt) show(); else emit();
    return net;
  },
  /** Mapeia todos os pontos do CI selecionado (ou pelo índice) e add como passos. */
  addComponentPins(partIndex?: number, skipGnd = false): number {
    const b = boardStore.activeTab?.board;
    const sel = boardStore.activeTab?.selection;
    const pi = partIndex != null ? partIndex : sel?.partIndex;
    const part = b && pi != null ? b.parts[pi] : null;
    if (!b || !part) return 0;
    if (!active) guideStore.startProgramming(part.name);
    const steps = active ? [...active.steps] : [];
    let added = 0;
    part.pins.forEach((pin) => {
      const label = `${part.name}.${pin.number || pin.name}`;
      if (steps.some(st => st.point === label)) return;
      const net = (pin.net || '').trim();
      if (skipGnd && /^(GND|AGND|VSS|PGND)/i.test(net)) return;
      steps.push({ n: 0, nets: net ? [net] : [], note: '', raw: '', point: label });
      added++;
    });
    if (added) replaceActive(renumber(steps));
    return added;
  },
  /** Finaliza a programação e começa a medir (liga a sequência). */
  finishProgramming(): void {
    programming = false;
    if (active && active.steps.length) { pos = 0; pointIdx = 0; guideStore.start(); }
    else emit();
  },

  /** Renomeia o teste do passo (não muda a net). */
  renameStep(i: number, name: string) { guideStore.editStep(i, { name: name.trim() || undefined } as Partial<Step>); },
  /** Valor certo (ideal) do passo, por modo. */
  setIdeal(i: number, k: 'iv' | 'id' | 'ir', val: string) { guideStore.editStep(i, { [k]: val.trim() || undefined } as Partial<Step>); },
  /** Marca/desmarca a estrela («valor certo depois do reparo»). */
  toggleStar(i: number) { const st = active?.steps[i]; if (st) guideStore.editStep(i, { star: !st.star } as Partial<Step>); },
  /** Copia o medido (v/d/r) para o valor certo (iv/id/ir) e marca a estrela — «valores certos depois do reparo». */
  markCorrect(onlyIndex?: number) {
    if (!active) return;
    const steps = active.steps.map((st, k) => {
      if (onlyIndex != null && k !== onlyIndex) return st;
      const has = st.v || st.d || st.r;
      if (!has) return st;
      return { ...st, iv: st.v ?? st.iv, id: st.d ?? st.id, ir: st.r ?? st.ir, star: true };
    });
    replaceActive(steps);
  },

  setCredit(credit: string) {
    if (!active) return;
    const upd = { ...active, credit: credit.trim() };
    list = list.map(r => (r.id === upd.id ? upd : r)); active = upd;
    if (upd.builtin) credits[upd.id] = upd.credit || '';
    save(); push(upd); emit();
  },
  /** Volta o roteiro de fábrica ao original. */
  resetBuiltin() {
    if (!active?.builtin) return;
    const b = BUILTIN.find(x => x.id === active!.id);
    if (!b) return;
    delete edits[b.id];
    replaceActive(b.steps.map(s => ({ ...s })));
  },
};
r2w.__r2seq = guideStore; // 2R: o index.html (painéis do ponto a ponto, tecla N) usa window.__r2seq

// ── junto do boardview (core/medicoes.py: <arquivo>.2r/sequencias.json) ──
interface SeqApi { seqList?(b: string): Promise<{ rows: Roteiro[]; where?: string }>; seqSave?(b: string, r: unknown): Promise<{ ok: boolean }> }
const api = () => (window as unknown as { __2rMeterApi?: SeqApi }).__2rMeterApi ?? null;
let seqWhere = '';
export const seqWhereNow = () => seqWhere;
function push(r: Roteiro, del = false) {
  const f = boardStore.activeTab?.fileName;
  const a = api();
  if (!f || !a?.seqSave) return;
  void a.seqSave(f, { ...r, upd: Date.now(), ...(del ? { del: true } : {}) }).catch(() => {});
}
let lastBoard = '';
async function pullSeq() {
  const f = boardStore.activeTab?.fileName || '';
  const a = api();
  if (!f || f === lastBoard || !a?.seqList) return;
  lastBoard = f;
  try {
    const r = await a.seqList(f);
    seqWhere = r.where || '';
    for (const rot of r.rows || []) {
      const b = BUILTIN.find(x => x.id === rot.id);
      const merged: Roteiro = b ? { ...b, steps: rot.steps, credit: rot.credit ?? b.credit } : { ...rot, builtin: false };
      list = [merged, ...list.filter(x => x.id !== rot.id)];
      if (active?.id === rot.id) active = merged;
    }
    emit();
  } catch { /* */ }
}

/** O roteiro é desta placa? (820-xxxxx no nome do arquivo, sem a revisão, ou o A-number). */
export function matchesBoard(r: Roteiro, fileName: string): boolean {
  const f = ((fileName || '') + ' ' + ((window as unknown as { __r2PlacaExtra?: string }).__r2PlacaExtra || '')).toUpperCase();
  const num = /^(820-\d{4,5})/.exec(r.board || '')?.[1];
  return (!!num && f.includes(num)) || (r.models ?? []).some(m => f.includes(m));
}

function fmtOhm(v: number): string {
  const a = Math.abs(v);
  return a >= 1e6 ? (v / 1e6).toFixed(2) + 'M' : a >= 1e3 ? (v / 1e3).toFixed(2) + 'k' : v.toFixed(1);
}

function renumber(steps: Step[]): Step[] { return steps.map((s, k) => ({ ...s, n: k + 1 })); }
function replaceActive(steps: Step[]) {
  if (!active) return;
  const upd = { ...active, steps };
  list = list.map(r => (r.id === upd.id ? upd : r));
  active = upd;
  save(); push(upd); emit();
}

function onKey(e: KeyboardEvent) {
  if (!on || !active) return;
  const t = e.target as HTMLElement | null;
  if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable)) return;
  if (e.metaKey || e.ctrlKey || e.altKey) return;
  const k = e.key;
  if (k === 'ArrowRight' || k === 'ArrowDown') guideStore.next();
  else if (k === 'ArrowLeft' || k === 'ArrowUp') guideStore.prev();
  else if (k === 'Tab') guideStore.nextPoint(e.shiftKey ? -1 : 1);
  else if (k === 'Escape') guideStore.stop();
  else return;
  e.preventDefault(); e.stopImmediatePropagation();
}

export function installGuide(): void {
  if (!IS_2R || !beta('teleguiado')) return;
  window.addEventListener('keydown', onKey, true);
  boardStore.subscribe(() => { void pullSeq(); });
}
