/**
 * 2R Tools: ponte para o app abrir arquivos do Acervo 2R direto no BoardRipper
 * (sem depender do campo de arquivo escondido da barra) e mostrar avisos.
 * Roger 10/10/2026: «acha os arquivos nas nuvens, baixa, mas não abre».
 */
import { boardStore } from '../store/board-store';
import { openPdfFiles } from '../store/file-actions';
import { getFileExtension } from '../parsers/registry';
import { IS_2R } from './env';
import { getDockviewApi } from '../store/dockview-api';
import { pdfStore } from '../store/pdf-store';
import { guideStore } from './guide-store';

export function installBridge(): void {
  if (!IS_2R) return;
  const w = window as unknown as Record<string, unknown>;
  w.__2rLoadFiles = async (files: File[]): Promise<string> => {
    const pdfs = files.filter(f => getFileExtension(f.name).toLowerCase() === '.pdf');
    const boards = files.filter(f => getFileExtension(f.name).toLowerCase() !== '.pdf');
    try {
      if (boards.length) {
        const dt = new DataTransfer();
        boards.forEach(f => dt.items.add(f));
        await boardStore.loadFiles(dt.files);
      }
      if (pdfs.length) await openPdfFiles(pdfs, { activeTabId: boardStore.activeTabId });
      return 'ok';
    } catch (err) {
      boardStore.addToast('Não consegui abrir o arquivo do Acervo 2R: ' + String((err as Error)?.message ?? err), 'error');
      return 'erro';
    }
  };
  w.__2rToast = (msg: string, kind: 'error' | 'info' = 'info') => boardStore.addToast(msg, kind);
  // 2R: abrir outra placa fecha a anterior (placas, PDFs e painéis)
  w.__2rFecharTudo = (nm: string[]) => {
    try {
      try {
        // 26/10/2026: a mesma placa abrindo de novo (outro arquivo/cache) não derruba o ponto a ponto — o card sumia
        const B = String(guideStore.active?.board || '').toUpperCase();
        const mesma = !!B && Array.isArray(nm) && nm.some(x => String(x).toUpperCase().includes(B));
        if (guideStore.on && !mesma) guideStore.stop();
      } catch { /* */ }
      const v = getDockviewApi();
      if (v) for (const p of [...v.panels]) if (p.id.startsWith('board-') || p.id.startsWith('pdf-')) v.removePanel(p);
      for (const t of [...boardStore.tabs]) boardStore.closeTab(t.id);
      for (const n of [...boardStore.pdfFileNames]) {
        try { pdfStore.closeFile(n); } catch { /* */ }
        boardStore.removePdf(n);
      }
    } catch { /* */ }
  };
}
