/** Canvas2D board-text overlay — draws only on-screen, LoD-passing labels
 *  each redraw instead of keeping ~100k BitmapText nodes in the Pixi scene.
 *  Pure selection logic is exported for unit tests; the class owns the
 *  canvas. Text draws upright in screen space (counter-flip machinery not
 *  needed); positions transform through the per-side label-layer world
 *  matrices so rotate/mirror/butterfly work unchanged. */
import { haloFor, type LabelModel, type LabelRecord } from './label-model';
import { log } from '../store/log-store';
import { resizeModeStore } from '../store/resize-mode-store';
import { R2tam, R2lado } from '../r2/hand-geom';
import { R2NET, R2vertBox, R2valFit, R2plaq } from '../r2/hand-labels';
/* eslint-disable @typescript-eslint/no-explicit-any */
// 2R 20/10/2026: letra igual à do FlexBV
const R2FONT = '"Source Sans 3","Source Sans Pro","Segoe UI",-apple-system,"Helvetica Neue",Arial,sans-serif';
const R2NETK = R2NET as Record<string, number>;

export interface OverlayViewState {
  topMatrix: { a: number; b: number; c: number; d: number; tx: number; ty: number };
  bottomMatrix: { a: number; b: number; c: number; d: number; tx: number; ty: number };
  scale: number;
  width: number; height: number;
  showTop: boolean; showBottom: boolean;
  selectedPartIndex: number | null;
  /** Selected pin within the selected part (board-store selection.pinIndex). */
  selectedPinIndex?: number | null;
  /** Pin under the pointer, on any part — its labels get the full floor too. */
  hoverPartIndex?: number | null;
  hoverPinIndex?: number | null;
  dimActive: boolean;
  litParts: ReadonlySet<number> | null;
  /** Light schemes, 'ink' styles: the pins renderSelection fills with ink,
   *  part index → pin indices. Their labels take `LabelRecord.inkColor`. */
  inkedPins?: ReadonlyMap<number, ReadonlySet<number>> | null;
}
export interface OverlayThresholds {
  labelMinScreenPx: number;
  /** Net names on IC/BGA pins appear at this many screen px. */
  circleLabelMinScreenPx: number;
  /** Pin numbers appear at this many screen px — lower than the net names:
   *  a number sits inside its pin and cannot overlap, so it can stay through
   *  more of the unzoom. Falls back to circleLabelMinScreenPx when unset. */
  pinNumberMinScreenPx?: number;
  twoPinLabelMinScreenPx: number;
  labelZoomHide: number;
  /** Floor (screen px) for the selected part's labels — they stay readable
   *  while unzooming ("grow" relative to the shrinking part, which users
   *  liked). 0 = no floor, scale naturally. User-adjustable: Settings ▸
   *  Zoom Level of Detail ▸ Selected Part Labels. */
  selectedLabelMinPx: number;
  /** LoD relax multiplier for the selected part's labels (see render-settings
   *  `selectedLabelLodRelax`). Lower = selected labels appear at lower zoom. */
  selectedLabelLodRelax: number;
  /** Fraction of `selectedLabelMinPx` the selected part's OTHER pin labels get
   *  (default 0.8). Only the selected pin and the hovered pin — and the part
   *  name — get the full floor; every pin of a dense part at 11 px overlapped
   *  its neighbours. */
  selectedLabelOtherScale?: number;
  /** Cap every pin label of a multi-pin part at the size that fits between
   *  its pin centres (`labelFitToPitch`, default on). Labels that would have
   *  to shrink below their appear-floor to fit are hidden instead. */
  fitToPitch?: boolean;
  /** Fade-in width as a fraction of the appear-floor: a label is faint at its
   *  floor and fully opaque at `floor × (1 + fadeRange)`. 0 = hard pop, the
   *  old behaviour. Default 0.5. The pointed-at pin and the selected part's
   *  name are exempt — they are the things being looked at. */
  fadeRange?: number;
}

const OFFSCREEN_MARGIN = 40;      // px — keep labels whose center is just off-edge
const DIM_ALPHA = 0.22;           // parity-tuned vs netDimGfx look in Task 9
/** Selected-part pin/net labels get a RELAXED LoD (default 0.75× the normal
 *  min-px, via `selectedLabelLodRelax`) rather than a full bypass: slightly
 *  sticky through unzoom, but they disappear close to the normal cutoff (user
 *  feedback 2026-07-19 — net names must not survive unzooming, and 0.5 kept
 *  them too long). The part NAME label alone keeps the full bypass as the
 *  selection identity marker (parity with the Pixi elevated badge). */
/** Component (part) names fade out as they grow oversized on screen — i.e. as
 *  you zoom into a big part — so the net names underneath (drawn earlier) and
 *  the pins below the overlay show through, instead of the huge designator
 *  blanketing a BGA. Purely a draw-time alpha; net names are unaffected. */
const PART_FADE_START = 80;    // px on-screen — name begins to recede (earlier)
const PART_FADE_END = 240;     // px — name reaches PART_FADE_MIN (a faint ghost)
const PART_FADE_MIN = 0.14;
function smoothstep(a: number, b: number, x: number): number {
  const t = Math.max(0, Math.min(1, (x - a) / (b - a)));
  return t * t * (3 - 2 * t);
}
function partNameFade(onScreenPx: number): number {
  return 1 - smoothstep(PART_FADE_START, PART_FADE_END, onScreenPx) * (1 - PART_FADE_MIN);
}

/** Alpha for a label emerging past its appear-floor: FADE_IN_MIN at the floor,
 *  1 at `floor × (1 + range)`, smoothstepped — the small-end counterpart of
 *  partNameFade, so labels swell into view while zooming instead of popping
 *  in at full strength on one zoom step. range 0 (or no floor) = 1. */
const FADE_IN_MIN = 0.18;
export function labelFadeAlpha(px: number, floorPx: number, range: number): number {
  if (range <= 0 || floorPx <= 0) return 1;
  return FADE_IN_MIN + (1 - FADE_IN_MIN) * smoothstep(floorPx, floorPx * (1 + range), px);
}

function minPxFor(kind: LabelRecord['kind'], th: OverlayThresholds): number {
  switch (kind) {
    case 'circleNum': return th.pinNumberMinScreenPx ?? th.circleLabelMinScreenPx;
    case 'circleNet': return th.circleLabelMinScreenPx;
    case 'twoPinNet': return th.twoPinLabelMinScreenPx;
    default: return th.labelMinScreenPx;
  }
}

/** Screen-px floor for a label drawn in the selected pass. The part name and
 *  the focused pin (selected or hovered) get the full `selectedLabelMinPx`;
 *  every other label of the selected part gets `selectedLabelOtherScale` of
 *  it, so a dense part's pin names stop overlapping while the one you point
 *  at is still the big one. 0 when the floor is off. */
export function selectedFloorPx(kind: LabelRecord['kind'], isFocusPin: boolean, th: OverlayThresholds): number {
  if (th.selectedLabelMinPx <= 0) return 0;
  const full = isFocusPin || kind === 'part';
  return th.selectedLabelMinPx * (full ? 1 : (th.selectedLabelOtherScale ?? 0.8));
}

/** The largest screen-px font at which this label still fits between its
 *  part's pin centres: width `chars × 0.6 × px ≤ 0.9 × pitch`, height
 *  `px ≤ 0.9 × pitch` (0.45 × pitch when a number and a name are stacked on
 *  the pin — two labels share the pitch). Infinity when the record carries no pitch. This is the whole
 *  overlap test — per label, one multiply, no pairwise comparison: on a grid
 *  of pins, "fits between centres" is exactly "cannot overlap a neighbour". */
export function pitchCapPx(r: LabelRecord, scale: number): number {
  if (!r.pitch) return Infinity;
  const pitchPx = r.pitch * scale;
  const width = (pitchPx * 0.9) / (Math.max(r.text.length, 3) * 0.6);
  const height = pitchPx * (r.stacked ? 0.45 : 0.9);
  return Math.min(width, height);
}

/** Where a pin number sits at this zoom: centred in its pin while the pin's
 *  net name is below its appear-floor (nothing to make room for), shifted
 *  above/below once the name shows. Mirrors the net label's own visibility
 *  rule so the two never disagree. */
export function pinNumberPlacement(
  r: LabelRecord, view: OverlayViewState, th: OverlayThresholds, selected: boolean,
): { x: number; y: number; anchorY: number } {
  if (r.alt && r.pairFontSize) {
    const zoomHidden = th.labelZoomHide > 0 && view.scale < th.labelZoomHide;
    const min = th.circleLabelMinScreenPx * (selected ? th.selectedLabelLodRelax : 1);
    const netVisible = !zoomHidden && r.pairFontSize * view.scale >= min;
    if (!netVisible) return r.alt;
  }
  return { x: r.x, y: r.y, anchorY: r.anchorY };
}

export function selectVisibleLabels(
  records: readonly LabelRecord[],
  m: OverlayViewState['topMatrix'],
  view: OverlayViewState,
  th: OverlayThresholds,
): LabelRecord[] {
  const out: LabelRecord[] = [];
  const zoomHidden = th.labelZoomHide > 0 && view.scale < th.labelZoomHide;
  for (const r of records) {
    const selected = view.selectedPartIndex !== null && r.partIndex === view.selectedPartIndex;
    const keepAlways = selected && r.kind === 'part';   // selection identity marker
    if (!keepAlways) {
      if (zoomHidden) continue;
      const min = minPxFor(r.kind, th) * (selected ? th.selectedLabelLodRelax : 1);
      if (r.fontSize * view.scale < min) continue;
    }
    const sx = m.a * r.x + m.c * r.y + m.tx;
    const sy = m.b * r.x + m.d * r.y + m.ty;
    if (sx < -OFFSCREEN_MARGIN || sx > view.width + OFFSCREEN_MARGIN ||
        sy < -OFFSCREEN_MARGIN || sy > view.height + OFFSCREEN_MARGIN) continue;
    out.push(r);
  }
  return out;
}

export class LabelOverlay {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private container: HTMLElement;
  private colorCache = new Map<number, string>();
  lastDrawMs = 0;
  lastCounts = { visible: 0, total: 0 };
  private lastSlowDrawLogAt = 0;
  /** Screen-space bounding boxes of every label painted in the last draw,
   *  in CSS px (same space as the renderer canvas). Consumed by hitTest()
   *  for Resize Mode's "did the click land on text?" classification. */
  private lastBoxes: Array<{ x0: number; y0: number; x1: number; y1: number; kind: LabelRecord['kind']; partIndex: number }> = [];

  constructor(container: HTMLElement) {
    this.container = container;
    this.canvas = document.createElement('canvas');
    const s = this.canvas.style;
    s.position = 'absolute';
    s.inset = '0';
    s.pointerEvents = 'none';
    s.zIndex = '2';
    s.transformOrigin = '0 0';
    container.appendChild(this.canvas);
    // NOT alpha:false — persistent canvas, per the PDF-canvas rules in CLAUDE.md.
    this.ctx = this.canvas.getContext('2d')!;
    this.resize();
  }

  resize(): void {
    const dpr = Math.max(1, window.devicePixelRatio || 1);
    const w = this.container.clientWidth, h = this.container.clientHeight;
    const bw = Math.max(1, Math.floor(w * dpr)), bh = Math.max(1, Math.floor(h * dpr));
    if (this.canvas.width !== bw || this.canvas.height !== bh) {
      this.canvas.width = bw; this.canvas.height = bh;
      this.canvas.style.width = w + 'px'; this.canvas.style.height = h + 'px';
    }
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  private css(color: number): string {
    let s = this.colorCache.get(color);
    if (!s) { s = '#' + color.toString(16).padStart(6, '0'); this.colorCache.set(color, s); }
    return s;
  }

  clear(): void {
    this.ctx.clearRect(0, 0, this.container.clientWidth, this.container.clientHeight);
    this.lastCounts = { visible: 0, total: 0 };
  }

  setCssTransform(t: string): void { this.canvas.style.transform = t; }

  /** The backing canvas — read by BoardRenderer.captureView for PNG export. */
  get element(): HTMLCanvasElement { return this.canvas; }

  draw(model: LabelModel, view: OverlayViewState, th: OverlayThresholds): void {
    const t0 = performance.now();
    this.setCssTransform('');
    const ctx = this.ctx;
    ctx.clearRect(0, 0, view.width, view.height);
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    // Only record hit-test boxes while Resize Mode is on — otherwise this is a
    // per-visible-label allocation on the (normally allocation-free) draw hot
    // path that no one reads (boxes are consumed only on a Resize Mode click).
    const recordBoxes = resizeModeStore.enabled;
    this.lastBoxes.length = 0;

    // Cull ONCE per side, then iterate the three paint passes over the
    // pre-culled arrays (painter's order: dimmed → lit → selected-on-top).
    const sides: Array<[LabelRecord[], OverlayViewState['topMatrix']]> = [];
    if (view.showTop) sides.push([selectVisibleLabels(model.top, view.topMatrix, view, th), view.topMatrix]);
    if (view.showBottom) sides.push([selectVisibleLabels(model.bottom, view.bottomMatrix, view, th), view.bottomMatrix]);
    let visible = 0;
    for (const pass of ['dim', 'lit', 'selected'] as const) {
      for (const [vis, m] of sides) {
        let lastFontPx = -1;
        for (const r of vis) {
          const isSel = view.selectedPartIndex !== null && r.partIndex === view.selectedPartIndex;
          // The pin being pointed at: the selected pin, or the hovered pin on
          // any part. Its labels take the full floor and paint on top.
          const isFocusPin = r.pinIndex !== undefined && r.pinIndex >= 0 && (
            (isSel && r.pinIndex === view.selectedPinIndex) ||
            (r.partIndex === view.hoverPartIndex && r.pinIndex === view.hoverPinIndex));
          const onTop = isSel || isFocusPin;
          const isLit = !view.dimActive || onTop || (view.litParts?.has(r.partIndex) ?? false);
          const want = pass === 'selected' ? onTop : pass === 'lit' ? (isLit && !onTop) : !isLit;
          if (!want) continue;
          visible += 1;
          let px = r.fontSize * view.scale;
          if (onTop) px = Math.max(px, selectedFloorPx(r.kind, isFocusPin, th));
          const floorPx = minPxFor(r.kind, th) * (isSel ? th.selectedLabelLodRelax : 1);
          // Fit to pitch — every pin label except the one being pointed at,
          // which is one label drawn on top and may cover its neighbours.
          if (th.fitToPitch !== false && !isFocusPin && r.pitch) {
            const cap = pitchCapPx(r, view.scale);
            if (px > cap) {
              px = cap;
              // Below the appear-floor it is noise, not a label: hide, don't shrink.
              if (px < floorPx) continue;
            }
          }
          // 2R 20/10/2026: etiquetas de net menores, nome do componente 80%, card do diodo dentro/ao lado do pad
          if (R2NETK[r.kind]) px = Math.min(px * 0.6, 11.5);
          if (r.kind === 'part') px *= 0.8;
          if (r.kind === 'diode') { px = R2tam(r, m, view, px * 1.05); if (px <= 0) continue; }
          const fontPx = Math.round(px * 4) / 4;          // quantize to limit ctx.font churn
          if (r.kind === 'diode') { ctx.font = `700 ${fontPx}px -apple-system,system-ui,"Segoe UI","Helvetica Neue",Arial,sans-serif`; lastFontPx = -1; }
          else if (r.kind === 'part') { ctx.font = `700 ${fontPx}px ${R2FONT}`; lastFontPx = -1; }
          else if (fontPx !== lastFontPx) { ctx.font = `${fontPx}px ${R2FONT}`; lastFontPx = fontPx; }
          const pl = r.kind === 'circleNum' ? pinNumberPlacement(r, view, th, isSel) : r;
          const sx0 = m.a * pl.x + m.c * pl.y + m.tx;
          const sy0 = m.b * pl.x + m.d * pl.y + m.ty;
          // Anchor compensation: ctx draws centered (textAlign/baseline middle),
          // records carry BitmapText anchors — shift so the anchored point of
          // the text box lands on (sx0, sy0). Width via measureText; height ≈ fontPx.
          const textW = ctx.measureText(r.text).width;   // measured once — reused for bg rect
          const aw = (0.5 - r.anchorX) * textW;
          const ah = (0.5 - pl.anchorY) * fontPx;
          const R2p = r.kind === 'diode' ? R2lado(r, m, view, textW, fontPx) : null;
          const sx = R2p ? R2p[0] : sx0 + aw;
          const sy = R2p ? R2p[1] : sy0 + ah;
          // Diode readings are exempt from ambient dimming: a measurement
          // you are comparing against the meter must not be translucent.
          let alpha = pass === 'dim' && r.kind !== 'diode' ? DIM_ALPHA : 1;
          if (r.kind === 'part') alpha *= partNameFade(r.fontSize * view.scale);
          // Fade in past the appear-floor; the focus pin and the selected
          // part's name are what the user is looking at and stay solid.
          if (!isFocusPin && !(isSel && r.kind === 'part')) alpha *= labelFadeAlpha(px, floorPx, th.fadeRange ?? 0.5);
          ctx.globalAlpha = alpha;
          // 2R 27/10/2026: componente de 2 pinos deitado/em pé → card do diodo girado e centrado no pad
          let rs = 0;
          const dv: any = r.kind === 'diode' ? R2vertBox(r, m) : null;
          if (dv && dv.alto && r.px != null) {
            ctx.save(); ctx.translate(m.a * r.px + m.c * r.py! + m.tx - sx, m.b * r.px + m.d * r.py! + m.ty - sy); rs = 1;
          }
          if (dv && dv.vert && !rs) {
            ctx.save();
            ctx.translate(
              r.px != null ? m.a * r.px + m.c * r.py! + m.tx : sx < (dv.x0 + dv.x1) / 2 ? dv.x0 : dv.x1,
              r.px != null ? m.b * r.px + m.d * r.py! + m.ty : sy);
            ctx.rotate(-Math.PI / 2);
            ctx.translate(-sx, -sy);
            rs = 1;
          }
          const r2Card = r.kind === 'diode' || !!R2NETK[r.kind];
          if (r2Card) {
            // 2R 20/10/2026: valor de diodo em card claro com texto preto (Roger: mesmo card das etiquetas, negrito e com folga)
            const tw = textW + fontPx * (r.kind === 'diode' ? 1.1 : 0.6);
            if (r.kind === 'diode') {
              ctx.shadowColor = 'rgba(0,0,0,.55)'; ctx.shadowBlur = 4; ctx.shadowOffsetY = 1;
              R2plaq(ctx, sx - tw / 2, sy - fontPx * 0.8, tw, fontPx * 1.6, Math.min(4, fontPx * 0.28));
              ctx.fillStyle = '#F2F2F2'; ctx.fill();
              ctx.shadowColor = 'transparent'; ctx.shadowBlur = 0; ctx.shadowOffsetY = 0;
            } else R2plaq(ctx, sx - tw / 2, sy - fontPx * 0.62, tw, fontPx * 1.24, Math.min(3, fontPx * 0.25));
          } else if (r.bg) {                              // backing rect (replaces the Graphics wrappers — two-pin AND circle-net)
            const tw = textW + fontPx * 0.6;
            if (r.bgColor !== undefined) {
              ctx.fillStyle = this.css(r.bgColor);
              ctx.globalAlpha = alpha * (r.bgAlpha ?? 0.55);
            } else {
              ctx.fillStyle = 'rgba(0,0,0,0.55)';
            }
            ctx.fillRect(sx - tw / 2, sy - fontPx * 0.65, tw, fontPx * 1.3);
            ctx.globalAlpha = alpha;
          }
          // A pin filled with a light scheme's ink: the colour chosen against
          // the pin at build would be ink on ink, so take the one chosen against
          // the ink, haloed — the stacked BGA number may sit beside the pin.
          let color = r.color, halo = r.halo;
          if (r.inkColor !== undefined && r.pinIndex !== undefined && view.inkedPins?.get(r.partIndex)?.has(r.pinIndex)) {
            color = r.inkColor;
            halo = haloFor(color);
          }
          // 2R: cards com texto preto; nome do componente selecionado em branco; números dos pinos claros
          const r2Fixa = r2Card || (r.kind === 'part' && onTop) || r.kind === 'circleNum' || r.kind === 'pinNum';
          if (halo !== undefined && !r2Fixa) {             // palette schemes: legible over any pad
            ctx.lineJoin = 'round';
            ctx.lineWidth = Math.min(5, Math.max(1.5, fontPx * 0.22));
            ctx.strokeStyle = this.css(halo);
            ctx.strokeText(r.text, sx, sy);
          }
          ctx.fillStyle = r2Card ? '#111111'
            : r.kind === 'part' ? (onTop ? '#FFFFFF' : this.css(color))
            : r.kind === 'circleNum' || r.kind === 'pinNum' ? '#EDEDED'
            : this.css(color);
          // 2R 24/10/2026 (Roger): componente NOSTUFF no esquema = ofuscado
          const nsf = (window as any).__r2NoStuff;
          if (r.kind === 'part' && nsf && nsf[r.text]) ctx.globalAlpha = alpha * 0.3;
          // 2R 27/10/2026: nome + valor (+ tensão do capacitor) dentro do corpo, encolhendo para caber
          const vf: any = r.kind === 'part' ? R2valFit(ctx, r, m, fontPx, textW) : null;
          if (vf && vf.rot && !rs) { ctx.save(); ctx.translate(sx, sy); ctx.rotate(-Math.PI / 2); ctx.translate(-sx, -sy); rs = 1; }
          if (vf && vf.nn < fontPx) { ctx.font = `700 ${vf.nn}px ${R2FONT}`; lastFontPx = -1; }
          ctx.fillText(r.text, sx, sy + (vf ? vf.dy : 0));
          if (vf && vf.nv > 0) {
            ctx.font = `700 ${vf.nv}px ${R2FONT}`; lastFontPx = -1;
            ctx.fillStyle = '#D5D9DF';
            ctx.fillText(vf.tx, sx, sy + vf.dy + vf.nn * 0.5 + vf.nv * 0.6);
            if (vf.tv) ctx.fillText(vf.tv, sx, sy + vf.dy + vf.nn * 0.5 + vf.nv * 1.7);
          }
          if (rs) { ctx.restore(); lastFontPx = -1; rs = 0; }
          // Record the painted box (centered draw) for Resize Mode hit-testing.
          // A few px of slop makes small labels easier to click.
          if (recordBoxes) {
            const hw = textW / 2 + 3;
            const hh = fontPx / 2 + 3;
            this.lastBoxes.push({ x0: sx - hw, y0: sy - hh, x1: sx + hw, y1: sy + hh, kind: r.kind, partIndex: r.partIndex });
          }
        }
      }
    }
    ctx.globalAlpha = 1;
    this.lastCounts = { visible, total: model.top.length + model.bottom.length };
    const ms = performance.now() - t0;
    this.lastDrawMs = this.lastDrawMs === 0 ? ms : this.lastDrawMs * 0.8 + ms * 0.2;
    if (ms > 12 && t0 - this.lastSlowDrawLogAt > 1000) {   // ≤1 emit/s — content-dirty motion can hit this per frame
      this.lastSlowDrawLogAt = t0;
      log.perf.log(`label overlay draw ${ms.toFixed(1)}ms visible=${visible}`);
    }
  }

  /** Resize Mode: return the topmost label box containing the given
   *  canvas-space (CSS px) point, or null. Iterates last-painted-first so the
   *  visually-on-top label (selected pass drawn last) wins. */
  hitTest(sx: number, sy: number): { kind: LabelRecord['kind']; partIndex: number } | null {
    for (let i = this.lastBoxes.length - 1; i >= 0; i--) {
      const b = this.lastBoxes[i];
      if (sx >= b.x0 && sx <= b.x1 && sy >= b.y0 && sy <= b.y1) return { kind: b.kind, partIndex: b.partIndex };
    }
    return null;
  }

  destroy(): void { this.canvas.remove(); }
}
