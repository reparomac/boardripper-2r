/**
 * Main PixiJS renderer — owns the Application, Viewport, and scene lifecycle.
 *
 * Responsibilities:
 *  - Creates and manages the PixiJS Application + pixi-viewport
 *  - Delegates scene graph construction to buildBoardScene() (renderer/board-scene.ts)
 *  - Handles multi-board tabs: builds one BoardScene per tab, switches between them
 *  - Manages selection state: hover, click, net highlight, selection rect
 *  - Butterfly mode: renders a mirrored side-by-side copy of the bottom layer
 *  - Net lines: draws connection lines between components sharing a net
 *  - Reacts to renderSettingsStore changes and rebuilds the scene as needed
 *
 */
import { Application, Graphics, Container, BitmapText, Text, RenderLayer, extensions, CullerPlugin, Sprite, Texture } from 'pixi.js';
import { Viewport } from 'pixi-viewport';
import type { BoardData, Point, Part } from '../parsers';
import { pinDisplayId } from '../parsers/types';
import { boardStore } from '../store/board-store';
import type { SelectionState, NetLineMode } from '../store/board-store';
import { databankStore } from '../store/databank-store';
import { pdfStore, type LookupContextTerm } from '../store/pdf-store';
import { renderSettingsStore, computePinRadius, resolvePinColor, computePartRenderBounds, computePartRenderPoly, isOutlineOnlyNet, resolvePartType, selectionOutlineWorld } from '../store/render-settings';
import { themeStore, hexToInt } from '../store/themes';
import { looksLikeMouseWheel } from '../store/scroll-mode';
import { contextMenuStore } from '../store/context-menu-store';
import { resizeModeStore } from '../store/resize-mode-store';
import { boardAntialias, boardMaxFps, boardPixelRatio } from '../device-profile';
import { rotationLockStore } from '../store/rotation-lock-store';
import { viewCommands, type PanDirection, type ZoomDirection } from '../store/view-commands';
import { selectionSetStore } from '../store/selection-set-store';
import { slideStore } from '../store/slide-store';
import { partCompareStore } from '../store/part-compare-store';
import type { PinDiffStatus } from '../store/part-compare';
import { worklistStore, MARK_COLOR_HEX, MEAS_KINDS, type NetMeasurement } from '../store/worklist-store';
import { PART_MARK_SVG, NET_MARK_SVG, WATER_SVG, SURGE_SVG, MEAS_SVG, MEAS_LETTER, escapeHtml } from './worklist-tooltip-icons';
import { openBoardSidebarTab } from '../panels/board-viewer-bridge';
import { buildBoardScene, drawOutline, drawOutlineDebug, updateBorderWidths, BOARD_COLORS, drawPadShape, drawPinShape, pinLabelInk } from './board-scene';
import { LabelOverlay } from './label-overlay';
import { focusHaloGeometry } from './focus-halo';
import { isOblongRoundPad, capsuleGrowForRadius, capsulePolygon } from './pad-capsule';
import { HdrSelectionOutline, isHdrCapable, rungForIntensity, type ScreenPoint } from './hdr-selection-outline';
import { applyRotationLayout, rotLayoutKey, type LabelModel } from './label-model';
import { compareStackHits, type StackHit } from './hit-test-ranking';
import { buildTraceGrid, queryTraceGrid, type TraceGrid } from './trace-grid';
import type { BorderBatch, PadGeometry } from './board-scene';
import { registerRenderer, unregisterRenderer } from './renderer-registry';
import { navHistoryStore, type BoardCameraProvider } from '../store/nav-history-store';
import type { BoardCamera } from '../store/nav-history';

/** The world rectangle a viewport pose shows on a `sw`×`sh` screen. */
function viewRect(c: BoardCamera, sw: number, sh: number) {
  const x0 = -c.x / c.scaleX, x1 = (sw - c.x) / c.scaleX;
  const y0 = -c.y / c.scaleY, y1 = (sh - c.y) / c.scaleY;
  return { minX: Math.min(x0, x1), maxX: Math.max(x0, x1), minY: Math.min(y0, y1), maxY: Math.max(y0, y1) };
}

/** Does pose `b` still show the view pose `a` showed? Zoom within 2× and at
 *  least 30 % of the new view was inside the old one (design §3.5). */
export function viewsOverlap(a: BoardCamera, b: BoardCamera, sw: number, sh: number): boolean {
  if (!sw || !sh || !a.scaleX || !b.scaleX) return true;
  const ratio = Math.abs(a.scaleX) / Math.abs(b.scaleX);
  if (ratio > 2 || ratio < 0.5) return false;
  const ra = viewRect(a, sw, sh), rb = viewRect(b, sw, sh);
  const ix = Math.max(0, Math.min(ra.maxX, rb.maxX) - Math.max(ra.minX, rb.minX));
  const iy = Math.max(0, Math.min(ra.maxY, rb.maxY) - Math.max(ra.minY, rb.minY));
  const areaB = (rb.maxX - rb.minX) * (rb.maxY - rb.minY);
  return areaB > 0 && (ix * iy) / areaB >= 0.3;
}
import { getFormat } from '../parsers/registry';
import { log } from '../store/log-store';
import { ensurePdfPanel } from '../store/dockview-api';
import { fileInputRefs } from '../store/file-inputs';
import { obdNetIndex, obdBoardNumberFor, obdStore } from '../store/obd-store';
import { primaryDiodeReading, boardHasDiodeData, formatDiode, diodeReadingColor } from '../store/diode-readings';
import { stepExpApproach, ZOOM_TWEEN_RATE } from './smooth-zoom';
import { isPinsOnTop, subscribeCameraOverlay } from '../store/camera-overlay';
import { r2PadsColoridos, r2Mesa } from '../r2/hand-flags';
import { R2mira } from '../r2/hand-geom';

// Alias for local use — all colour references go through board-scene.ts
const COLORS = BOARD_COLORS;

/** How long a board tab may stay hidden before its GPU context + scene graph
 *  are released (deep-pause). Long enough that flipping between a couple of
 *  boards doesn't thrash rebuilds; short enough to reclaim within a minute of
 *  leaving a board. resume() rebuilds via the tested reinitApp() path. */
const DEEP_PAUSE_DELAY_MS = 45_000;

/** Compare highlight: the standing outline around the part under comparison,
 *  and the two pin marks — red where the boards disagree, amber where the net
 *  is the same one named differently. */
const COMPARE_OUTLINE_COLOR = 0xffffff;
const COMPARE_DIFFER_COLOR = 0xff3b30;
const COMPARE_PARTIAL_COLOR = 0xffcc00;

/** Notes for the statuses topology settled, where the two names alone say
 *  nothing about why. Everything else carries its own reason or needs none. */
const STATUS_NOTE: Partial<Record<PinDiffStatus, string>> = {
  renamed: 'renamed, same connections',
  similar: 'mostly the same connections',
  bulk: 'both a rail',
};

/** Glow colour for "highlight connections" — nets shared between ≥2 parts in
 *  the cyan selection set. Cyan to tie the glow to the cyan selection outline. */
const SHARED_NET_GLOW = 0x00e5ff;

/** Container alpha applied to non-emphasized trace layers when one layer is
 *  bumped/pinned to the top, so the emphasized layer visually stands out. */
const LAYER_DIM_ALPHA = 0.25;

/** Divisor for the smooth-zoom plain-wheel branch's exponential factor
 *  (`factor = 2^(1.3 · -deltaY/divisor)`). Calibrated 2026-07-19 with a
 *  headless Playwright probe (samples/820-02016/820-02016.bvr): with
 *  smoothZoom:false + twoFingerPan:false (routes the bare wheel event to
 *  pixi-viewport's own legacy Wheel plugin instead of our tween or its
 *  drag-to-pan path), one `page.mouse.wheel(0, -100)` notch at rest moved
 *  viewport.scale.x from 0.12794882 to 0.15321599 — ratio ≈ 1.19748.
 *  divisor = (1.3·ln2·100) / ln(ratio) ≈ 500.0000000000007, rounds to 500.
 *  That is exactly the constant pixi-viewport's own Wheel plugin and this
 *  file's zoomAtScreen already hardcode (`factor = 2^(1.3·-deltaY/500)`), so
 *  the tween reproduces the legacy per-notch zoom magnitude exactly instead
 *  of only approximating it. */
const WHEEL_DIVISOR = 500;

// Spatial culling: scene-build tags per-grid-cell + per-part containers with
// `cullable + cullArea` in board-mil coords, but PixiJS v8 culling is opt-in.
// Without CullerPlugin the culler never runs and every BitmapText is walked
// each frame at deep zoom. Disable via `localStorage.boardripper.renderer.disableCulling = '1'` + reload.
if (typeof window !== 'undefined' && window.localStorage?.getItem('boardripper.renderer.disableCulling') !== '1') {
  extensions.add(CullerPlugin);
}

// WebGPU backend (opt-in). PixiJS auto-falls back to WebGL if unavailable.
// Enable via `localStorage.boardripper.renderer.webgpu = '1'` + reload.
const RENDERER_PREFERENCE: 'webgpu' | 'webgl' | undefined =
  typeof window !== 'undefined' && window.localStorage?.getItem('boardripper.renderer.webgpu') === '1'
    ? 'webgpu'
    : undefined;

/** Unique non-empty values pulled from a list via a getter. Used by the
 *  OBD tooltip formatter, which collapses readings across variants. */
function uniqOf<T>(items: T[], get: (x: T) => string | null | undefined): string[] {
  const seen = new Set<string>();
  for (const it of items) {
    const v = get(it);
    if (v && !seen.has(v)) seen.add(v);
  }
  return Array.from(seen);
}

// Selected-part name currently uses a simple alpha fade when pin numbers come
// into view (see updateElevatedLabels). A read-under-text invert effect was
// prototyped via `blendMode: 'difference'` but it doesn't take effect for
// labels living inside a RenderLayer — see
// `docs/research/threejs-webgpu-vs-pixi.md` § "Label blending options" for
// the long-term plan.

/** Shape of the event object emitted by pixi-viewport's `clicked` event. */
interface ViewportClickEvent {
  world: Point;
  screen: { x: number; y: number };
  event: unknown;
}

/** Point-in-convex-polygon test using cross-product winding. */
/** Squared distance from point (px,py) to the segment (ax,ay)-(bx,by). */
function pointSegDist2(px: number, py: number, ax: number, ay: number, bx: number, by: number): number {
  const dx = bx - ax, dy = by - ay;
  const len2 = dx * dx + dy * dy;
  let t = len2 > 0 ? ((px - ax) * dx + (py - ay) * dy) / len2 : 0;
  t = Math.max(0, Math.min(1, t));
  const cx = ax + t * dx, cy = ay + t * dy;
  const ex = px - cx, ey = py - cy;
  return ex * ex + ey * ey;
}

function pointInConvexPoly(px: number, py: number, poly: [number, number][]): boolean {
  const n = poly.length;
  if (n < 3) return false;
  let sign = 0;
  for (let i = 0; i < n; i++) {
    const [ax, ay] = poly[i];
    const [bx, by] = poly[(i + 1) % n];
    const cross = (bx - ax) * (py - ay) - (by - ay) * (px - ax);
    if (cross === 0) continue;
    if (sign === 0) sign = cross > 0 ? 1 : -1;
    else if ((cross > 0 ? 1 : -1) !== sign) return false;
  }
  return true;
}



/** Pre-built scene graph for a single board */
interface BoardScene {
  root: Container;
  outlineGfx: Graphics;
  topLayer: Container;
  bottomLayer: Container;
  topFillLayer: Container;
  bottomFillLayer: Container;
  topPinLayer: Container;
  bottomPinLayer: Container;
  topOutlineLayer: Container;
  bottomOutlineLayer: Container;
  topLabelLayer: Container;
  bottomLabelLayer: Container;
  labels: import('pixi.js').BitmapText[];
  topLabels: import('pixi.js').BitmapText[];
  bottomLabels: import('pixi.js').BitmapText[];
  topDiodeLabels: import('pixi.js').BitmapText[];
  bottomDiodeLabels: import('pixi.js').BitmapText[];
  topPinLabels: Container[];
  bottomPinLabels: Container[];
  /** Pin labels per part index — used by selection highlight to brighten only
   *  the labels of the selected part. */
  pinLabelsByPartIndex: Map<number, Container[]>;
  borderBatches: BorderBatch[];
  fontSizeGroups: import('./board-scene').FontSizeGroup[];
  /** Group A: pin numbers + net names on circle/1-pin parts */
  topCircleLabelLayer: Container;
  bottomCircleLabelLayer: Container;
  circleFontSizeGroups: import('./board-scene').PinFontSizeGroup[];
  /** Group B: net names on 2-pin parts */
  topTwoPinNetLayer: Container;
  bottomTwoPinNetLayer: Container;
  twoPinFontSizeGroups: import('./board-scene').PinFontSizeGroup[];
  /** Part label by index — for brightening selected part name */
  partLabelByIndex: Map<number, import('pixi.js').BitmapText>;
  /** Top/bottom pin circle graphics by part index */
  topPinGfx: Map<number, import('pixi.js').Graphics>;
  bottomPinGfx: Map<number, import('pixi.js').Graphics>;
  /** Per-part max pin radius to prevent overlap (BGA etc). partIndex → maxRadius. */
  pinRadiusClamp: Map<number, number>;
  /** Per 2-pin part: per-pin pad polygons (4 corners each). Used for exact selection highlights. */
  twoPinPadPolys: Map<number, [number, number][][]>;
  /** PCB trace lines container — toggled by showTraces */
  traceLayer: Container | null;
  /** Per-layer trace containers for multi-layer boards (indexed by layer). Empty for single-layer. */
  traceLayerContainers: Container[];
  /** Copper-fill polygons (ground planes, power pours) — toggled by `showSurfaces`. */
  surfacesLayer: Container | null;
  /** Per-layer surface containers, indexed by layer. Mirrors traceLayerContainers. */
  surfacesLayerContainers: Container[];
  /** Silkscreen / assembly outlines — toggled by showSilkscreen */
  silkscreenLayer: Container | null;
  silkscreenTop: Container | null;
  silkscreenBottom: Container | null;
  /** Copper pad rectangles — sit inside topLayer/bottomLayer between pin and
   *  outline so the copper-color overlay substitutes the pin sprite when
   *  visible. Toggled by `showPads` AND the corresponding side toggle. */
  padsTop: Container | null;
  padsBottom: Container | null;
  /** Standalone copper drops — same parenting as pads but render BELOW the
   *  pin layer (they're noise). Toggled by `showCopperDrops` AND side. */
  copperDropsTop: Container | null;
  copperDropsBottom: Container | null;
  /** Via/drill hole overlay container */
  viaLayer: Container | null;
  /** Via labels — tracked for counter-rotation on board flip */
  viaLabels: import('pixi.js').BitmapText[];
  /** Per-via connected layer indices (parallel to board.vias). Empty for single-layer boards. */
  viaConnectedLayers: number[][];
  /** Butterfly mode: a mirrored copy of the board for the bottom side */
  butterflyRoot: Container | null;
  butterflyOutline: Graphics | null;
  /** Canvas2D-overlay label records — non-null only when the scene was built
   *  with Text fast mode on (buildBoardScene emits it behind textFastMode).
   *  Consumed by the LabelOverlay draw path; the BitmapText layers stay empty
   *  for those label sites in that mode. */
  labelModel: LabelModel | null;
}

/** Saved viewport transform for restoring on tab switch */
interface ViewportState {
  x: number;
  y: number;
  scaleX: number;
  scaleY: number;
}

/** Expand a convex polygon outward by `sp` mils along edge normals from the
 *  polygon centroid. Used by selection, cross-side ghost, and disco halo to
 *  draw an outline ring around (rather than on top of) a part's actual edge. */
function expandPoly(poly: ReadonlyArray<readonly [number, number]>, sp: number): [number, number][] {
  const cx = poly.reduce((s, p) => s + p[0], 0) / poly.length;
  const cy = poly.reduce((s, p) => s + p[1], 0) / poly.length;
  return poly.map(([px, py]) => {
    const dx = px - cx, dy = py - cy;
    const len = Math.hypot(dx, dy);
    if (len < 1e-6) return [px, py] as [number, number];
    return [px + dx / len * sp, py + dy / len * sp] as [number, number];
  });
}

/** Emit a closed polygon path into `gfx` (does not stroke or fill). */
function drawPoly(gfx: Graphics, poly: ReadonlyArray<readonly [number, number]>): void {
  gfx.moveTo(poly[0][0], poly[0][1]);
  for (let i = 1; i < poly.length; i++) gfx.lineTo(poly[i][0], poly[i][1]);
  gfx.closePath();
}

/** Emit a part's outline path into `gfx` — OBB polygon when available, AABB
 *  rect fallback otherwise — padded outward by `sp`. The caller decides
 *  whether to fill, stroke, or both. */
function drawPartOutline(
  gfx: Graphics,
  part: Part,
  s: import('../store/render-settings').RenderSettings,
  sp: number,
): void {
  const poly = computePartRenderPoly(part, s);
  if (poly) {
    drawPoly(gfx, sp === 0 ? poly : expandPoly(poly, sp));
  } else {
    const rb = computePartRenderBounds(part, s);
    gfx.rect(rb.px - sp, rb.py - sp, rb.pw + sp * 2, rb.ph + sp * 2);
  }
}

/** The outline a PART is highlighted with: its polygon/AABB outline, or — for
 *  a single-pin part, which has no meaningful outline — the pin's own shape.
 *
 *  Proposed by Sean Johnson (@sjohnson1021) in issue #32, which found the four
 *  drifted copies this replaces.
 *  Four highlight paths (search results, primary selection, net members,
 *  disco halo) carried drifted copies of this decision, all of them
 *  hardcoding a circle for the single-pin case, which is wrong for a testpoint
 *  or a mounting leg whose pad is a capsule. */
function emitPartOutlineShape(
  gfx: Graphics,
  part: Part,
  s: import('../store/render-settings').RenderSettings,
  pad: number,
): void {
  if (part.pins.length === 1) {
    drawPinShape(gfx, part.pins[0], computePinRadius(s, part.pins[0].radius), pad);
    return;
  }
  drawPartOutline(gfx, part, s, pad);
}

/** 0 when board and screen axes line up (0°/180°), 1 when they're transposed
 *  (90°/270°). Pin-label layout in `buildBoardScene` depends on this. */
function rot90Parity(rotationDeg: number): number {
  return ((Math.round(rotationDeg / 90) % 4) + 4) % 4 % 2;
}


const IS_MAC = typeof navigator !== 'undefined' && /Mac|iPhone|iPad/.test(navigator.platform || navigator.userAgent);

/** What `BoardRenderer.onViewChange` listeners receive. */
export interface ViewChange { userPan: boolean; dx: number; dy: number }

/** 2R: velocidade do trackpad (Roger: «deixar um pouco mais rápido, ou ter a opção de
 *  regular a velocidade») — padrão 1,4× ao arrastar e 1,4× na pinça. */
function trackpadSpeed(): { pan: number; zoom: number } {
  try {
    const pan = parseFloat(localStorage.getItem('2r-trackpad-pan') || '1.4');
    const zoom = parseFloat(localStorage.getItem('2r-trackpad-zoom') || '1.4');
    return { pan: isFinite(pan) ? pan : 1.4, zoom: isFinite(zoom) ? zoom : 1.4 };
  } catch { return { pan: 1.4, zoom: 1.4 }; }
}

/** 2R: aparelho de apontar (Roger, 11/10/2026: «adequar para mouse e trackpad no Windows»).
 *  'auto' = descobre pelo jeito do giro (roda de mouse dá saltos; trackpad desliza),
 *  'mouse' = roda sempre amplia/reduz, 'trackpad' = dois dedos sempre arrastam. */
/* 2R 20/10/2026: 'flexbv' (padrão) — dois dedos para baixo aumenta e para cima diminui; roda do mouse para cima aumenta */
export function pointerMode(): 'auto' | 'mouse' | 'trackpad' | 'flexbv' {
  try {
    const v = localStorage.getItem('2r-pointer-mode');
    return v === 'mouse' || v === 'trackpad' || v === 'auto' ? v : 'flexbv';
  } catch { return 'auto'; }
}
/** 2R: inverter a roda do mouse / os dois dedos (Roger: «padrão Win / padrão Mac»). */
function invertFlag(k: '2r-mouse-invert' | '2r-pan-invert'): number {
  try { return localStorage.getItem(k) === '1' ? -1 : 1; } catch { return 1; }
}
/* 2R 27/10/2026 (Roger: «consegue aumentar a velocidade do scroll? ainda sinto que dá uma garrada»): roda do mouse 1,6×
   por padrão (chave nova «2r-mouse-zoom2») e até 5× */
export function mouseZoomSpeed(): number {
  try { const n = parseFloat(localStorage.getItem('2r-mouse-zoom2') || '1.6'); return isFinite(n) && n > 0 ? n : 1.6; }
  catch { return 1.6; }
}
/* eslint-disable @typescript-eslint/no-explicit-any */
const r2w = window as any;
const R2_SEM_FANTASMAS = false; // 2R 30/10/2026: ghost do upstream 0.50 de volta, na íntegra
/** 2R 22/10/2026: roda do MOUSE (wheelDeltaY múltiplo de 120, sem giro lateral, sem trackpad nos últimos 400 ms) */
function r2RodaDoMouse(e: WheelEvent): boolean {
  const w = (e as any).wheelDeltaY as number | undefined, ag = performance.now();
  const tp = e.deltaX !== 0 || (w !== undefined && w !== 0 ? w % 120 !== 0 && (e.deltaY % 1 !== 0 || w === -3 * e.deltaY) : e.deltaY % 1 !== 0);
  if (tp) r2w.__r2tpT = ag;
  return !tp && ag - (r2w.__r2tpT || 0) >= 400 && w !== undefined && w !== 0 && w % 120 === 0;
}
function r2RodaK(e: WheelEvent): number { return r2w.__r2RodaK ? r2w.__r2RodaK(e) : 1; }

/** 2R: trackpad direto (padrão ligado; Preferências › Uso › Trackpad). */
export function trackpadDirect(): boolean {
  try {
    if (!(window as unknown as { __2rAcervo?: unknown }).__2rAcervo) return false;
    return localStorage.getItem('2r-trackpad-direto') !== '0';
  } catch { return false; }
}

export class BoardRenderer {
  /** Whether top layer should be visible (accounts for butterfly mode) */
  private get isTopVisible() { return boardStore.showTop || boardStore.butterfly; }
  /** Whether bottom layer should be visible (accounts for butterfly mode) */
  private get isBottomVisible() { return boardStore.showBottom || boardStore.butterfly; }
  /** Butterfly hides everything that is not one side's own (traces, vias,
   *  pours); see applyLayerVisibility. Read by every trace consumer so a
   *  hidden trace can neither be hovered nor lit. */
  private get copperHidden() { return boardStore.butterfly; }
  /** Per-name memo of "is this refdes's resolved part-type hidden?". Cleared
   *  whenever render settings change (the part-type list / hidden flags live
   *  there). Keyed by refdes so the prefix scan in resolvePartType runs once
   *  per distinct name, not per frame. */
  private _typeHiddenMemo = new Map<string, boolean>();

  /** True when the part's resolved part-type is flagged hidden in settings.
   *  A type-hidden part is fully gone: not built into the scene, not
   *  hit-tested, not highlighted on net select, and not drawn as a
   *  cross-side ghost. Empty name → never type-hidden. */
  private isTypeHidden(name: string | undefined): boolean {
    if (!name) return false;
    let v = this._typeHiddenMemo.get(name);
    if (v === undefined) {
      v = resolvePartType(name, renderSettingsStore.settings)?.hidden ?? false;
      this._typeHiddenMemo.set(name, v);
    }
    return v;
  }

  /** Whether a part should be visible given its side and current view mode.
   *  'both' parts live in topLayer, so they follow top-side visibility.
   *  Parts flagged `hidden: true` by `deriveBoardView` (outside the selected
   *  board) are never visible. Parts whose resolved part-type is hidden in
   *  settings are never visible either — and (unlike cross-side parts) never
   *  fall back to a ghost: see the ghost branch in renderSelection. */
  private isPartVisible(part: { name?: string; side: string; hidden?: boolean }): boolean {
    if (part.hidden) return false;
    if (this.isTypeHidden(part.name)) return false;
    if (part.side === 'bottom') return this.isBottomVisible;
    return this.isTopVisible; // 'top' and 'both'
  }

  private app: Application;
  private viewport!: Viewport;
  private selectionGfx!: Graphics;
  /** The primary (clicked) part's outline lives in a CHILD of selectionGfx /
   *  butterflySelectionGfx, so the per-frame zoom redraw touches just this
   *  one shape. Repainting the parent — which on a lit GND holds ~7 000
   *  member rings — makes PixiJS re-triangulate all of it on the next frame:
   *  ~1 s per zoom notch under SwiftShader, a visible hitch on real hardware
   *  (reported 2026-09-05). A child inherits every attach/detach/zIndex move
   *  the parent gets, and survives parent.clear(). */
  private primarySelGfx!: Graphics;
  private butterflyPrimarySelGfx!: Graphics;
  private netDimGfx!: Graphics;
  /** Container for part-name labels drawn above the net-dim overlay */
  private netLabelLayer!: Container;
  private butterflySelectionGfx!: Graphics;
  /** Bottom-half dim layer in butterfly mode. Mirrors netDimGfx but lives
   *  inside butterflyRoot so the bottom half's parts (which sit in
   *  butterflyRoot, NOT scene.root) are also dimmed when chain-adjacent /
   *  search-dim / spotlight is active. Without this, the bottom half stays
   *  bright while the top half dims. */
  private butterflyDimGfx!: Graphics;
  private netLinesGfx!: Graphics;
  /** Render layer that lifts selection-related labels above netLinesGfx in render order.
   *  Labels keep scene.root as logical parent (for transform inheritance) but render
   *  after the net lines via this layer. */
  private selectionLabelLayer!: RenderLayer;
  /** Ghost outlines for cross-side net components (hidden side, semi-transparent + pulsing) */
  private crossSideGhostGfx!: Graphics;
  /** Ghost outlines, baked separately from the fills because the pulse gives
   *  the two different alphas. Sibling of crossSideGhostGfx in scene.root. */
  private crossSideGhostOutlineGfx!: Graphics;
  /** Signature of what crossSideGhostGfx currently holds — the ghost set plus
   *  the settings the shapes depend on. The pulse never redraws; only a
   *  changed signature does. */
  private crossSideGhostBakeSig = '';
  /** Part indices currently drawn as cross-side ghosts (for ticker-driven pulse redraw) */
  // Set, not array — `.has()` is O(1) and the field is hot inside the per-pin
  // chain-mode net-line builder (R-4 in 2026-05-07-renderer.md). Ordering is
  // not required; iteration in renderCrossSideGhosts is fine on a Set.
  private crossSideGhostParts: Set<number> = new Set();
  /** Disco mode — same-net parts heartbeat red on both sides. Single
   *  Graphics, two-pass build (fill + outline) when the pulse is active;
   *  short-circuited entirely during the silent ~70% of each cycle. */
  private discoHaloGfx!: Graphics;
  /** Part indices on the currently highlighted net (cached so the ticker
   *  doesn't re-traverse board.nets each frame). */
  private discoHaloParts: Set<number> = new Set();
  /** Whether the disco gfx layer currently holds non-empty geometry. Used
   *  by the silent-phase fast-path to know when a `clear()` is still owed. */
  private discoHaloDirty = false;
  private debugVertexLabels: Text[] = [];
  private debugVertexPositions: Array<{x: number; y: number}> = [];
  private board: BoardData | null = null;
  private unsubscribeBoard: (() => void) | null = null;
  private unsubscribeSettings: (() => void) | null = null;
  private unsubscribeResizeMode: (() => void) | null = null;
  private unsubscribeTheme: (() => void) | null = null;
  /** 2R Tools: modo "Pinos por cima" da função Mesclar */
  private unsubscribeCamOverlay: (() => void) | null = null;
  private pinsOnTop = false;
  private unsubscribeViewCommands: (() => void) | null = null;
  private unsubscribeSelectionSet: (() => void) | null = null;
  private unsubscribePartCompare: (() => void) | null = null;
  /** DEV-only record of the last compare highlight drawn — see the probe in
   *  `drawCompareHighlight`. Never read by production code. */
  lastCompareMarks: { part: string; differ: number; partial: number } | null = null;
  private unsubscribeWorklist: (() => void) | null = null;
  private unsubscribeObd: (() => void) | null = null;
  /** Outline-only highlight overlay for the ephemeral multi-select set AND the
   *  active worklist. Single Graphics object — re-cleared and redrawn on store
   *  notify. Sits above standard selection at zIndex 28 (just below the rich
   *  selectionGfx at 30, so single-select keeps visual primacy). */
  private multiHighlightGfx!: Graphics;
  /** Shift-key state captured at the most recent pointerdown — read by
   *  handleClick (pixi-viewport's "clicked" event fires on pointerup but
   *  doesn't carry the down-time modifier reliably across browsers). */
  private lastPointerShift = false;
  /** ⌘ (macOS) / Ctrl (elsewhere) held at pointerdown: slide mode's
   *  add-to-selection modifier. Not Shift — that adds to the worklist. */
  private lastPointerAddMod = false;
  /** Client (CSS) coords of the last primary pointerdown — used to place the
   *  Resize Mode popup at the real cursor (viewport.toScreen is in DPR-scaled
   *  device px, wrong for a position:fixed DOM popup). */
  private lastPointerClient = { x: 0, y: 0 };
  /** Click-cycle state for stacked/overlapping component selection (#23).
   *  `key` is the ordered set of part indices under the anchor; `index` is the
   *  current position in the smallest-first stack. Reset to null on pointer
   *  move so the next click starts fresh at the smallest part. */
  private clickCycle: {
    x: number; y: number; key: string; index: number;
    /** What the cycle last put in the store. The cycle is a claim about the
     *  *current* selection — "you are looking at stack[index], click again for
     *  the next one" — so it only means anything while that claim still holds.
     *  Anything else that changes the selection (a part picked in the Net List,
     *  an MCP `select_part`, a programmatic clear) makes the next click at the
     *  same spot a fresh one, not a step through a stack the user has left. */
    selectedPartIndex: number | null;
  } | null = null;
  /** Pending deferred cycle advance — a same-spot repeat click schedules the
   *  advance so a following double-click (PDF lookup) can cancel it. */
  private pendingCycleAdvance: ReturnType<typeof setTimeout> | null = null;
  /** Same-spot tolerance for cycling, in screen pixels (converted to world). */
  /** Pointer travel past which a gesture is a drag, not a click. Matches
   *  pixi-viewport's own `threshold` so the two agree about what a click is. */
  private static readonly CLICK_DRAG_TOLERANCE_PX = 5;
  /** Same test for a finger. A contact patch wanders as it settles and lifts:
   *  a tap a user would swear was stationary routinely travels 8-10 CSS px, so
   *  the mouse threshold would reject ordinary taps. pixi-viewport's own 5 px
   *  threshold still gates every gesture whose moves it actually saw, and this
   *  one only ever decides the cases it did not — so relaxing it cannot make
   *  the board *more* click-happy during a pan. */
  private static readonly TOUCH_CLICK_DRAG_TOLERANCE_PX = 12;
  private static readonly CYCLE_TOLERANCE_PX = 6;
  /** Guard window: a same-spot repeat click's advance waits this long so a
   *  double-click can cancel it. Longer than the browser's dblclick dispatch,
   *  shorter than a deliberate re-click cadence. */
  private static readonly CYCLE_DBL_GUARD_MS = 250;
  /** Bound pointerdown handler that captures shift state. */
  private boundShiftCapture: ((e: PointerEvent) => void) | null = null;
  /** Bound window-capture pointermove tracker — see `pointerTravelPx`. */
  private boundPointerTravel: ((e: PointerEvent) => void) | null = null;
  /** How far the pointer has moved from where the current gesture started, in
   *  CSS px (straight-line distance). Reset on every pointerdown.
   *
   *  pixi-viewport suppresses its own `clicked` after 5 px of movement, but
   *  only when its InputManager actually *sees* the pointermoves — and the
   *  drag-to-zoom loop stops them at window capture so the board does not pan
   *  while it zooms. So the viewport believes a shift-drag was a click and
   *  emits one. This is the renderer's own record of the gesture, taken from
   *  a listener installed at init and therefore ahead of any per-gesture
   *  handler that might swallow the events. */
  private pointerTravelPx = 0;
  /** Touch pointers currently on the glass, with their last position. The
   *  renderer keeps its own record for the same reason it keeps
   *  `pointerTravelPx`: what a gesture *was* cannot be recovered from what
   *  pixi-viewport believes it saw. The positions are what `installTouchPinch`
   *  runs on. */
  private activeTouchIds = new Map<number, { x: number; y: number }>();
  /** The two pointers a pinch is running on, and the state it started from.
   *  `startDist` and `startScale` describe that *pair*: if either pointer
   *  changes the gesture is re-seeded, never continued against a stale
   *  baseline. */
  private pinch: {
    a: number; b: number; startDist: number; startScale: number;
    lastMidX: number; lastMidY: number;
    /** Angle of the pair at seed time, and the rotation the roots already
     *  carried then — so a re-seed (third finger, a replaced pointer) keeps
     *  turning from where the picture is, not from zero. */
    startAngle: number; rotBaseRad: number;
  } | null = null;
  /** Two-finger rotation in progress, from either stream (pointer pair or
   *  WebKit gesture). `appliedRad` is what the scene roots carry beyond the
   *  store's rotation; it is committed to the store when the fingers lift
   *  (`commitLiveRotation`). Mid-gesture the roots are turned directly, like
   *  the pinch writes the viewport: a store commit per move would run the
   *  whole onBoardUpdate — net-line re-projection, ghosts, a full
   *  renderSelection — for every finger movement. */
  private liveRotate: {
    engaged: boolean; appliedRad: number; baseRad: number; midX: number; midY: number;
    /** Which stream drives it, and the last raw angle that stream reported —
     *  for the one summary line per gesture in the Debug log, which is how a
     *  sign or ownership question gets settled on the device itself. */
    stream: 'pointer' | 'gesture'; rawDeg: number;
  } | null = null;
  /** Locked (the starting state, `rotationLockStore`): the fingers must turn
   *  `renderSettings.rotateUnlockDeg` before rotation unlocks — and then the
   *  board turns on from where it is, no catch-up jump (`baseRad`).
   *  Unlocked: this small dead zone, so a pinch-zoom's wobble does not
   *  drift a free angle by a degree or two per pinch. */
  private static readonly ROTATE_DEAD_ZONE_DEG = 2;
  /** A two-finger double-tap toggles the lock: two taps of ≤ TAP_MS with the
   *  fingers travelling no further than a tap may, within DOUBLE_MS. */
  /** The right angle the Butterfly spread is laid out at; a free angle is
   *  that layout turned rigidly by the residual (see applyFlips). Kept
   *  across gesture commits so a turn never re-lays the halves out
   *  mid-way — only a button rotation (right angle from a right angle) or
   *  turning Butterfly on picks a new base. */
  private butterflyBaseDeg: number | null = null;
  private butterflyLastDeg = 0;
  private static readonly TWO_FINGER_TAP_MS = 350;
  private static readonly TWO_FINGER_DOUBLE_MS = 450;
  private twoFingerDownAt = 0;
  private twoFingerMaxTravel = 0;
  private lastTwoFingerTapAt = 0;
  /** Touch "right click" (2026-10-02): hold a finger on a part and tap a
   *  second finger — the trackpad's two-finger click, done on glass. The long
   *  press stays as the other way in; this one needs no waiting. A hold is a
   *  first finger down at least HOLD_TAP_MIN_HOLD_MS before the second lands
   *  (a two-finger tap lands both together and toggles the rotation lock —
   *  that is how the two are told apart), the second finger is up within
   *  TWO_FINGER_TAP_MS while the first stays down, and neither travels past a
   *  tap. Any zoom the pinch path applied in between is undone. */
  private static readonly HOLD_TAP_MIN_HOLD_MS = 200;
  private holdDownAt = 0;
  private holdTap: {
    secondId: number; holdId: number; at: number; x: number; y: number;
    cam: { x: number; y: number; sx: number; sy: number };
  } | null = null;
  private gestureHoldTap: {
    at: number; x: number; y: number;
    cam: { x: number; y: number; sx: number; sy: number };
  } | null = null;
  private touchDownPos = new Map<number, { x: number; y: number }>();
  /** True once two or more fingers have been down during the gesture in
   *  progress, and until the next gesture begins.
   *
   *  pixi-viewport does clear its own `clickedAvailable` when a second pointer
   *  arrives — but its InputManager routes `pointercancel` straight into
   *  `up()`, indistinguishably from a release. iPadOS hands a two-finger
   *  gesture to its own recogniser freely and cancels the pointers it took, so
   *  the first finger's cancel arrives as "a release, with no other pointer
   *  registered, that never moved" and the viewport emits `clicked` in the
   *  middle of a pinch. No distance test can catch that one: at cancel time
   *  the finger has barely travelled. Only the fact that the gesture was
   *  multi-touch identifies it. */
  private gestureWasMultiTouch = false;
  /** True when a `pointercancel` landed during the gesture in progress — the
   *  browser took the gesture over, which is never a tap. */
  private gestureWasCancelled = false;
  /** Pointer type of the gesture in progress, for the click/drag threshold. */
  private gestureIsTouch = false;
  /** The gesture in progress began while the board was still gliding after
   *  a flick. pixi-viewport then never emits `clicked` for it — a touch during
   *  deceleration is "stop the glide" to it, by design — so if it ends as a
   *  tap, the renderer has to raise the click itself. */
  private tapDuringGlide = false;
  /** Bound capture-phase pointerup/pointercancel tracker. */
  private boundPointerRelease: ((e: PointerEvent) => void) | null = null;
  /** Bound capture-phase pointermove that drives the two-finger pinch. */
  private boundTouchPinchMove: ((e: PointerEvent) => void) | null = null;
  /** Which stream owns the gesture in progress — see `boundGestureStart`. */
  private gestureOwner: 'none' | 'pointer' | 'gesture' = 'none';
  private gestureReleaseTimer: ReturnType<typeof setTimeout> | null = null;
  private boundGestureEnd: ((e: Event) => void) | null = null;
  /** Ends a gesture whoever owned it — see the body for why that matters. */
  private endGestureOwnership: (() => void) | null = null;
  private resizeObserver: ResizeObserver | null = null;
  private containerEl: HTMLDivElement;
  /** Canvas2D "Text fast mode" label overlay — lazily created by
   *  ensureLabelOverlay() when the setting is on, torn down when it goes off.
   *  Decoupled from the Pixi Application: survives context-loss reinit (its
   *  canvas is a containerEl sibling, not a Pixi object). Task 8 extends the
   *  sync path; do not rename (referenced by name in the plan). */
  private textFastMode: LabelOverlay | null = null;
  /** HDR selection outline — mounted lazily by ensureHdrOverlay() when the
   *  setting is on AND the display can actually show HDR; torn down otherwise.
   *  Like textFastMode it is a containerEl sibling, so it survives Pixi
   *  context-loss reinit. */
  private hdrOverlay: HdrSelectionOutline | null = null;
  /** Set whenever the view, selection, dim state, or scene changed so the next
   *  tick redraws the overlay. Reset in onTick after a successful draw. */
  private overlayDirty = false;
  /** Set alongside overlayDirty at every site EXCEPT the two viewport 'moved'
   *  handlers — i.e. whenever the label CONTENT (not just the view transform)
   *  changed: selection/dim, settings, scene switches, flips, resize. The
   *  adaptive motion mode's CSS-transform branch (Task 8) only re-projects the
   *  last-drawn bitmap when this is false — a content change mid-pan must
   *  force a full redraw instead of cheaply transforming a stale/blank bitmap.
   *  Reset alongside overlayDirty in onTick after a successful full draw. */
  private overlayContentDirty = false;
  /** View state (viewport x/y/scale) at the last full overlay draw — lets the
   *  adaptive motion mode (Task 8) cheaply re-project the last-drawn bitmap via
   *  a CSS transform while panning instead of redrawing every frame. Null until
   *  the first full draw. */
  private overlayDrawnView: { x: number; y: number; scale: number } | null = null;
  /** Part indices left lit by the ambient-dim overlay for the current frame
   *  (the net-member "punch-through" set built in renderSelection). Null until
   *  the first renderSelection; the selected part is lit unconditionally by the
   *  overlay so it need not appear here. */
  private litPartIndices: Set<number> | null = null;
  private initialized = false;
  private boundContextMenu: ((e: MouseEvent) => void) | null = null;
  private boundDblClick: ((e: MouseEvent) => void) | null = null;
  /** Touch long-press → context menu. iOS Safari never fires `contextmenu`
   *  for a canvas long-press, and Chromium suppresses it once the viewport's
   *  drag plugin has claimed the pointer, so on a tablet the whole quick-action
   *  menu was unreachable (measured 2026-09-04: 0 menu elements after a 700 ms
   *  press). Synthesised here from pointer events instead. */
  private boundLongPressDown: ((e: PointerEvent) => void) | null = null;
  private boundLongPressMove: ((e: PointerEvent) => void) | null = null;
  private boundLongPressEnd: ((e: PointerEvent) => void) | null = null;
  private longPressTimer: ReturnType<typeof setTimeout> | null = null;
  private longPressStart: { id: number; x: number; y: number } | null = null;
  private tooltipEl: HTMLDivElement | null = null;
  private tooltipNetSpan: HTMLSpanElement | null = null;
  private tooltipDetailSpan: HTMLSpanElement | null = null;
  private tooltipCompareSpan: HTMLSpanElement | null = null;  // cross-board compare line
  private tooltipMetaSpan: HTMLSpanElement | null = null;   // value / package (TVW + parsers that fill PartMeta)
  private tooltipObdSpan: HTMLSpanElement | null = null;  // OBD diode/V/Ω line (separate pipeline)
  private tooltipWorklistSpan: HTMLSpanElement | null = null;  // worklist mark/note for the hovered part
  private tooltipWorklistNetSpan: HTMLSpanElement | null = null;  // worklist mark/reading for the hovered net
  private tooltipCanvas: HTMLCanvasElement | null = null;  // canvas ref for listener cleanup
  private boundHover: ((e: PointerEvent) => void) | null = null;
  private boundHideTooltip: (() => void) | null = null;
  // rAF-coalesced hover (audit A1): pointermove events arrive far faster than
  // the display refreshes, so boundHover only records the latest event and
  // schedules a single handleHover() per animation frame.
  private hoverRafId: number | null = null;
  private lastHoverEvent: PointerEvent | null = null;
  /** Identity of the currently-hovered pin/trace ("p{part}:{pin}" / "t{traceIndex}") —
   *  lets handleHover skip tooltip content rewrites when the target hasn't changed. */
  private hoverKey: string | null = null;
  /** Cached tooltip DOM size from the last content rewrite — avoids a forced
   *  reflow (offsetWidth/Height read) on every pointer move. */
  private tooltipSize: { w: number; h: number } | null = null;
  /** Net name currently under the pointer (for ambient dim hover highlight) */
  private hoverNet: string | null = null;
  /** Pin under the pointer, for the label overlay's hover size bump. */
  private hoverPartIndex: number | null = null;
  private hoverPinIndex: number | null = null;
  /** Bound wheel wake-up handler for cleanup */
  private boundWheelWake: ((e: WheelEvent) => void) | null = null;
  private boundPointerCapture: ((e: PointerEvent) => void) | null = null;
  /** Bound shift+wheel handler — intercepts before pixi-viewport to implement scroll bindings */
  private boundShiftWheel: ((e: WheelEvent) => void) | null = null;
  private boundDragZoomDown: ((e: PointerEvent) => void) | null = null;
  /** Set to true when a drag-to-zoom gesture actually moved (committed past the
   *  threshold). Consumed by the next `handleClick` to prevent a stale selection:
   *  pixi-viewport's InputManager never sees the pointermoves (drag-zoom
   *  stopPropagation's them), so it still emits 'clicked' on pointerup. */
  private dragZoomConsumedClick = false;
  /** True from the moment a drag-to-zoom gesture passes its movement threshold
   *  until the pointer is released.
   *
   *  The latch above is not enough on its own, because the stray click does not
   *  arrive at pointerup: committing the gesture calls `setPointerCapture` on
   *  `containerEl`, which retargets every later pointer event from the canvas
   *  to its parent div. PixiJS listens on the canvas, so it stops seeing the
   *  pointer, decides it left, and emits `pointerupoutside` — pixi-viewport's
   *  InputManager takes that as the end of a gesture it believes never moved
   *  and fires `clicked` **in the middle of the drag**, after one move. At that
   *  instant almost no travel has accumulated, so no distance test can catch
   *  it; the only reliable signal is that a zoom gesture is under way. */
  private dragZoomActive = false;
  /** If a drag-zoom gesture is active, holds its cleanup function so dispose()
   *  can force-remove the per-gesture window listeners. */
  private activeDragZoomCleanup: (() => void) | null = null;
  /** Timer to re-pause ticker after wheel activity on an unfocused panel */
  private wheelIdleTimer: ReturnType<typeof setTimeout> | null = null;
  private hudEl: HTMLDivElement | null = null;
  private selectionOverlayEl: HTMLDivElement | null = null;
  private perfOverlayEl: HTMLDivElement | null = null;
  private perfToggleBtn: HTMLButtonElement | null = null;
  private perfToggleBtnHandler: (() => void) | null = null;
  // Synced from RenderSettings.showPerfOverlay via onSettingsUpdate. Initial
  // value comes from the persisted setting so an overlay enabled in a prior
  // session shows up immediately on next launch.
  private perfVisible = renderSettingsStore.settings.showPerfOverlay;

  // Perf overlay accumulators (reset every ~500ms)
  private perfSamples = 0;
  private perfAccum = { lod: 0, selection: 0, netLines: 0, gpuRender: 0, frame: 0 };
  /** Wall time of the most recent app.render(), always measured (the perf
   *  overlay's accumulators only run while it is showing). Read by the
   *  selection blink to decide how many full renders it may afford. */
  private lastRenderMs = 0;
  private perfDisplay = { lod: 0, selection: 0, netLines: 0, gpuRender: 0, frame: 0 };
  /** Frames that actually drew, for the perf overlay's "what limits the
   *  frame rate" line: JS time per drawn frame vs the interval between two
   *  drawn frames. When the interval is much longer than the JS, the time
   *  goes to the GPU or the compositor — something no JS timer can see, and
   *  the question an iPad report needs answered first. */
  private perfDrawn = { n: 0, js: 0, interval: 0, intervalN: 0, lastDrewAt: 0 };
  private renderedThisTick = false;
  private perfThrottle = 0;

  // Elevated labels — persistent BitmapText + background Graphics for selected part/pin
  private elevatedPartLabel: BitmapText | null = null;
  private elevatedPartBg: Graphics | null = null;
  private elevatedPinLabel: BitmapText | null = null;
  private elevatedPinBg: Graphics | null = null;
  // Pin labels raised above the ambient dim overlay for the selected part.
  // Each entry remembers where to put the child back on the next update.
  private raisedPinLabels: { child: Container; parent: Container; index: number }[] = [];
  /** Light schemes, 'ink' styles: pins the last renderSelection filled with
   *  ink (part index → pin indices), read by the label overlay so their labels
   *  read against the ink. Null when nothing is inked. */
  private inkedPins: Map<number, Set<number>> | null = null;
  /** BitmapText path: raised pin labels recoloured for an inked pin, with the
   *  fill to give back when the selection is redrawn. */
  private inkRecoloured: { label: BitmapText; fill: BitmapText['style']['fill'] }[] = [];
  // The bright-white clone of the selected part's name label (lives in
  // netLabelLayer). Tracked so the per-tick loop can fade its alpha when the
  // part grows large enough on screen that the label would cover pins.
  private selectedPartLabelClone: BitmapText | null = null;

  // On-demand rendering: only render when something changed
  private needsRender = true;

  /** Extra render frames to force after a scene (re)activation so the global
   *  CullerPlugin re-culls with UP-TO-DATE world transforms. The plugin culls
   *  with `skipUpdateTransform=true` (reads `container.worldTransform` as-is),
   *  so the FIRST render after building a fresh scene culls every part container
   *  against its still-identity transform → their board-mil `cullArea` maps far
   *  off-screen → `culled=true`. That render then updates the transforms, but on
   *  an on-demand (needsRender-gated) static board no further frame re-runs the
   *  culler, so the wrongly-culled part-name/pin labels never reappear (BUG-A:
   *  toggling Text-fast-mode ON→OFF, or any settings rebuild, drops labels until
   *  reload). Draining a couple of extra frames lets the culler re-evaluate with
   *  correct transforms. Cheap: a static board renders identical pixels, and on
   *  first load the fit/zoom sequence already renders many frames. */
  private cullRefreshFrames = 0;

  // LoD zoom tracking — updated by ticker
  private lastLodScale = -1;

  // Hide-text-during-zoom: detect actual zooming via per-frame scale comparison
  private zoomSettleTimer: ReturnType<typeof setTimeout> | null = null;
  private textHiddenForZoom = false;
  /** Net lines are drawn at a stale stroke width (or, mid-rotation, cleared)
   *  until the zoom settles — see onZoomFrame. */
  private netLinesHiddenForZoom = false;
  /** Viewport scale the net lines were last stroked at during a zoom. */
  private netLinesStrokeScale = 0;
  private prevTickScale = -1;
  // Pulse animations (net lines + cross-side ghosts) freeze for a short window
  // after viewport motion so pan/zoom don't pay the per-frame Graphics rebuild.
  // Bumped on every viewport 'moved' event; pulse resumes once it expires.
  private viewportMovingUntil = 0;

  // Selection blink state (triggered by focusPart / PDF reverse search)
  private selectionBlinkPhase = 0;
  private selectionBlinkTimer: ReturnType<typeof setTimeout> | null = null;
  // Halo sprite — soft glow drawn under the selected part
  private _haloTexture: Texture | null = null;
  /** The dim colour `_haloTexture` was painted in (see buildHaloTexture). */
  private _haloTextureColor = -1;
  private _haloSprite: Sprite | null = null;
  // Last-rendered selection — used to skip redundant renderSelection() on tab switch
  private lastRenderedSel = { partIndex: null as number | null, pinIndex: null as number | null, highlightedNet: null as string | null, adjacentNetsSize: 0, searchLen: 0, board: null as BoardData | null, dimMode: 'dim' as 'off' | 'dim' | 'darklight', butterfly: false, showTop: true, showBottom: true, showGhosts: true, discoHighlight: false, searchSelectionActive: false, connectionHighlight: false, rotation: 0, mirrorX: false, mirrorY: false, flipAxis: 'x' as 'x' | 'y', netLineMode: 'off' as NetLineMode };
  // Track previous top/bottom state for flip-to-center
  private prevShowTop = true;
  private prevShowBottom = false;
  // Track the worklist Highlight toggle so a change repaints the worklist
  // outline overlay (multiHighlightGfx) — boardStore notifies don't otherwise
  // reach redrawMultiHighlight, so the marks appeared/disappeared only on the
  // next pan/zoom.
  private prevConnectionHighlight = false;
  // Track previous rotation so we can keep the viewport-center world point
  // anchored across rotation changes (rotation pivot at board center would
  // otherwise drag the user's focus off-screen on non-centered views).
  private prevRotation = 0;
  // Track previous mirror / flip-axis so a change force-recomputes the
  // world-space net-line cache (see onBoardUpdate flip branch) — like rotation,
  // a flip re-signs scene.root's scale and leaves the cached segments stale.
  private prevMirrorX = false;
  private prevMirrorY = false;
  private prevFlipAxis: 'x' | 'y' = 'x';

  // Net line pulse animation phase (0–1, driven by ticker)
  private netLinePulsePhase = 0;
  // Pool index for reusing BitmapText children in netLabelLayer
  private netLabelPoolIdx = 0;

  /** Navigation-history camera provider: the departure rule reads the pose
   *  through `get`, a restore writes one through `set` (`animateToViewport`).
   *  Registered wherever `registerRenderer` is, released wherever it is. */
  private navCamera: BoardCameraProvider = {
    get: () => ({ x: this.viewport.x, y: this.viewport.y, scaleX: this.viewport.scale.x, scaleY: this.viewport.scale.y }),
    set: (cam) => this.animateToViewport(cam),
  };

  /** Navigation history, layer 4: a user move that has settled becomes a
   *  viewpoint when it left the previous view; a smaller one only refreshes
   *  the current entry's pose. `programmaticMove` marks a fit / restore so
   *  the next transform change is not read as the user's. */
  private viewSettleTimer: ReturnType<typeof setTimeout> | null = null;
  private lastViewSig = '';
  private programmaticMove = false;

  // Animated zoom state
  private zoomAnim: {
    fromX: number; fromY: number; fromScaleX: number; fromScaleY: number;
    toX: number; toY: number; toScaleX: number; toScaleY: number;
    elapsed: number; duration: number;
  } | null = null;

  /** Active wheel-zoom tween — exponential approach toward targetScale with
   *  the world point under the cursor pinned to its screen position. */
  private zoomTween: {
    targetScale: number;
    anchorScreenX: number; anchorScreenY: number;
    anchorWorldX: number; anchorWorldY: number;
  } | null = null;

  // Net line geometry cache — avoid O(N) recomputation every frame for pulse/dash animation.
  // Only recomputed when selection, viewport, or visibility changes.
  private netLineSegments: Array<{ start: Point; end: Point; color: number }> = [];
  // Same data colour-keyed for the batched-stroke fast path. Populated alongside
  // `netLineSegments` in recomputeNetLineSegments so the per-frame draw path
  // can iterate without allocating a fresh Map / wrapper objects every tick
  // (G-3 zero-allocation property).
  private netLineSegmentsByColor: Map<number, Array<{ start: Point; end: Point }>> = new Map();
  private netLinesDirty = true;
  /** Extra state tracked for fade logic */
  private netLineFadeDist = 0;
  private netLineSettleTimer: ReturnType<typeof setTimeout> | null = null;

  // Scene cache: avoid rebuilding PixiJS objects on tab switch
  private sceneCache = new Map<string, BoardScene>();
  private boardRefs = new WeakMap<BoardData, number>();
  private boardRefCounter = 0;
  private sceneCacheKey(_board: BoardData): string {
    // Key on the raw board ref + filter state. Derived boards come and go on
    // each filter toggle, so keying on them would leak cache entries. Keying
    // on rawBoard lets repeated toggles reuse the same scene slots.
    const raw = boardStore.rawBoard ?? _board;
    let ref = this.boardRefs.get(raw);
    if (ref == null) { ref = ++this.boardRefCounter; this.boardRefs.set(raw, ref); }
    const swaps = [...boardStore.swappedBoards].sort((a, b) => a - b).join(',');
    return `${ref}|${boardStore.foldMode}|${boardStore.selectedBoardIndex ?? 'all'}|${swaps}`;
  }
  private activeScene: BoardScene | null = null;
  /** Snapshot of settings at the last onSettingsUpdate — enables a cheap diff
   *  to skip full scene rebuilds when only interaction-only fields changed. */
  private lastSettingsSnapshot: import('../store/render-settings').RenderSettings | null = null;
  /** JSON of the active theme's board palette at the last theme-driven rebuild.
   *  Lets onThemeUpdate rebuild only when board-side colours actually change,
   *  not on every accent / background / chrome knob tweak. */
  private _lastBoardColorKey = '';
  /** Debounce timer for scheduleRebuild — coalesces rapid colour-edit rebuilds. */
  private _rebuildTimer: ReturnType<typeof setTimeout> | null = null;
  /** Screen-axis parity (0 = board axes, 1 = transposed) the active scene's
   *  pin labels were built for. Compared against the live rotation so a
   *  90°/270° change rebuilds the label stagger on the right axis. */
  private sceneRot90Parity = 0;
  /** Which rotation layout each label model's staggered labels are in (see
   *  `RotLayout`). A 90° turn moves those labels in place instead of
   *  rebuilding the scene, which on a dense board froze the app for 1–2 s. */
  private labelRotKeys = new WeakMap<LabelModel, 0 | 1 | 3>();
  /** Reference snapshot of `boardStore.partOverrides`. The store replaces the
   *  Map on every change, so an identity-equality compare in `onBoardUpdate`
   *  detects right-click hide/send-to-back actions without a deep diff. */
  private lastPartOverrides: ReadonlyMap<string, { hidden?: boolean; sendToBack?: boolean }> | null = null;

  // Spatial hash for O(1) hit-testing — maps grid cell keys to part indices.
  // Cached per (raw board, foldMode, selectedBoardIndex) via `sceneCacheKey`
  // so filter toggles reuse the same grid entry instead of leaking a new
  // one per derived-board reference.
  private hitGrid: Map<string, number[]> = new Map();
  private hitGridCellSize = 0;
  private hitGridCache = new Map<string, { grid: Map<string, number[]>; cellSize: number }>();

  /** Lazy per-board trace spatial hash (audit A2). WeakMap so derived boards
   *  (fold/filter toggles) don't pin — see finding C1 for why not Map. */
  private traceGridCache = new WeakMap<BoardData, TraceGrid>();

  // WebGL context loss recovery
  private contextLost = false;
  private destroyed = false;
  private reinitializing = false;
  /** Deep-pause timer: after a tab has been hidden this long, release its GPU
   *  context + scene graph so K open tabs don't hold K live WebGL contexts. */
  private _deepPauseTimer: ReturnType<typeof setTimeout> | null = null;

  // Cached label counts for perf overlay — updated by applyLabelVisibility, not by iterating every 500ms
  private labelCounts = { partVis: 0, partTotal: 0, pinVis: 0, pinTotal: 0 };

  // HUD update throttle — shared across init/reinit ticker
  private hudThrottle = 0;

  // WebGL context loss handler refs (for cleanup in destroy)
  private boundContextLost: ((e: Event) => void) | null = null;
  private boundContextRestored: (() => void) | null = null;

  // Trackpad rotation gesture state
  private boundGestureStart: ((e: Event) => void) | null = null;
  private boundGestureChange: ((e: Event) => void) | null = null;

  // Pending fit-to-board: when set, the ResizeObserver will re-fit after layout stabilises.
  // This covers the case where fitToBoard() is called before a PDF panel opens and
  // shrinks the board panel — the resize triggers a deferred re-fit.
  private _pendingFit = false;
  private _pendingFitTimer: ReturnType<typeof setTimeout> | null = null;

  // PDF follow mode: debounce viewport movement before searching PDF
  private followDebounceTimer: ReturnType<typeof setTimeout> | null = null;
  private lastFollowQuery = '';

  // applyFlips cache — skip O(N) label loop when transform params are unchanged
  private lastFlipParams: {
    butterfly: boolean;
    topRot: number; topSx: number; topSy: number;
    botRot: number; botSx: number; botSy: number;
  } | null = null;

  // Viewport state per board: restore pan/zoom on tab switch. WeakMap —
  // keys are DERIVED boards that get a fresh object on every fold/filter
  // toggle; a strong Map pinned each abandoned derivation (tens of MB) for
  // the renderer's lifetime (rendering-review-2026-07-12 finding C1).
  private viewportStates = new WeakMap<BoardData, ViewportState>();

  /** A3 (rendering-review-2026-07-12): renderSelection repaints fire for
   *  hover-dim changes too — only mark net-line geometry dirty when the
   *  net-line-relevant selection (net/part/pin) or board actually changed,
   *  so pulse frames don't re-run the O(K² log K) chain recompute. */
  private lastNetLinesSelKey: string | null = null;
  private lastNetLinesSelBoard: BoardData | null = null;

  /** D1 (rendering-review-2026-07-12): settings/theme changes on an INACTIVE
   *  tab defer their scene rebuild until the tab is next resumed, instead of
   *  every open renderer rebuilding back-to-back (~140 ms each) on one theme
   *  flip. Coalesces naturally — N deferred changes = one rebuild on resume. */
  private pendingDeferredRebuild = false;

  /** A5: pulse crossfade layer. Base net-line geometry is baked once per
   *  (geometry, width, alpha) signature and the pulse animates THIS layer's
   *  alpha, instead of re-issuing every path 60x/s. It is attached as a
   *  SIBLING directly above netLinesGfx — never as its child, because pixi v8
   *  Graphics is a leaf ViewContainer and giving one children renders through
   *  a deprecated, undefined path. Null until the first bake and after any
   *  renderer reinit. */
  private netLinesPulseGfx: Graphics | null = null;
  private netLineBakeSig = '';

  /** A4 (rendering-review-2026-07-12): skip multi-highlight redraws on pan/zoom
   *  frames when neither the highlight state nor the screen-space stroke width
   *  changed. Store-notify/board-change call sites force a redraw. */
  private multiHighlightDirty = true;
  private lastMultiHighlightWidth = -1;
  /** Per-board refdes→partIndex cache for worklist resolution (A4). */
  private refdesIndexBoard: BoardData | null = null;
  private refdesIndexCache: Map<string, number> | null = null;

  /** The board tab ID this renderer is bound to (null = legacy single-renderer mode) */
  private tabId: number | null = null;
  /** See the deferral at the top of onBoardUpdate. */
  private sceneBuildDeferral: 'idle' | 'pending' | 'running' = 'idle';

  constructor(container: HTMLDivElement, tabId?: number) {
    this.containerEl = container;
    this.tabId = tabId ?? null;
    this.app = new Application();
    // Leak probe (WeakRefs retain nothing): after a tab closes + GC, this
    // renderer must deref() to undefined — asserted by memory-release.spec.ts.
    const dbg = globalThis as unknown as { __brRendererRefs?: WeakRef<BoardRenderer>[] };
    (dbg.__brRendererRefs ??= []).push(new WeakRef(this));
    if (import.meta.env.DEV) {
      const w = window as unknown as { __boardRenderer?: BoardRenderer; __computePartRenderBounds?: typeof computePartRenderBounds };
      w.__boardRenderer = this;
      w.__computePartRenderBounds = computePartRenderBounds;
    }
  }

  /** Safely stop the ticker — app or ticker may be null/destroyed. */
  /** True between pause() and resume(): the panel is not the active one.
   *  The ticker may still run for a while — a store change, a camera
   *  animation or a wheel wake — and the tick stops it again once nothing is
   *  pending (see the end of onTick). */
  private panelPaused = false;

  /** A store change arrived while the panel is paused: start the ticker so
   *  it is drawn. Before this, a mode button pressed while a PDF panel was
   *  active updated the geometry and nobody drew a frame — "nothing happens
   *  until the next net is clicked" (field report 2026-10-14). */
  private wakeWhilePaused() {
    if (!this.panelPaused || this.app.ticker.started || this.destroyed || this.contextLost || !this.initialized) return;
    this.app.ticker.start();
    this.needsRender = true;
  }

  private stopTicker() {
    try { this.app?.ticker?.stop(); } catch { /* context may be lost */ }
  }

  /** Shared ticker callback — used by both init() and reinitApp(). */
  private __r2pv: unknown; private __r2vv: unknown;
  private onTick = (ticker: import('pixi.js').Ticker) => {
    // 2R 27/10/2026: valores/encapsulamentos lidos do esquema chegaram → redesenha (cards de valor, tamanho físico)
    if (r2w.__r2PacoteVer !== this.__r2pv || r2w.__r2Valores !== this.__r2vv) {
      this.__r2pv = r2w.__r2PacoteVer; this.__r2vv = r2w.__r2Valores;
      if (this.board) this.scheduleRebuild();
    }
    const perf = this.perfVisible;
    const frameStart = perf ? performance.now() : 0;

    // Wheel-zoom tween (exponential, cursor-anchored) — see smooth-zoom.ts.
    if (this.zoomTween) {
      const t = this.zoomTween;
      const cur = Math.abs(this.viewport.scale.x);
      const next = stepExpApproach(cur, t.targetScale, ticker.deltaMS, ZOOM_TWEEN_RATE);
      this.viewport.scale.set(next, next);
      // Re-pin the anchored world point to its captured screen position.
      const sp = this.viewport.toScreen(t.anchorWorldX, t.anchorWorldY);
      this.viewport.x += t.anchorScreenX - sp.x;
      this.viewport.y += t.anchorScreenY - sp.y;
      this.needsRender = true;
      // No netLinesDirty: a pan or zoom never moves the world-space segments (a live turn carries them rigidly, rotateLive), and a dirty flag holds off the in-zoom re-stroke (onZoomFrame).
      this.viewport.emit('moved', { viewport: this.viewport, type: 'animate' });
      if (next === t.targetScale) this.zoomTween = null;
    }

    // Drive animated zoom
    let animMoved = false;
    let animDone = false;
    if (this.zoomAnim) {
      animMoved = true;
      const a = this.zoomAnim;
      a.elapsed += ticker.deltaMS;
      const t = Math.min(a.elapsed / a.duration, 1);
      const e = this.easeOutCubic(t);
      this.viewport.scale.set(
        a.fromScaleX + (a.toScaleX - a.fromScaleX) * e,
        a.fromScaleY + (a.toScaleY - a.fromScaleY) * e,
      );
      this.viewport.position.set(
        a.fromX + (a.toX - a.fromX) * e,
        a.fromY + (a.toY - a.fromY) * e,
      );
      this.needsRender = true;
      // No netLinesDirty here: net-line segments are world-space, so an animated
      // zoom never changes their geometry. onZoomFrame hides them during the
      // anim and the settle timer redraws from the cached segments at the new
      // scale (renderNetLines re-derives the zoom-dependent draw params).
      if (t >= 1) { this.zoomAnim = null; animDone = true; }
    }

    // Navigation history: classify every transform change as the user's or
    // ours. Ours (animated jump, fit, restore) re-baselines; the user's
    // starts the settle timer. Cheap: four numbers into a string per frame.
    if (this.viewport) {
      const vp = this.viewport;
      const sig = `${vp.x.toFixed(1)},${vp.y.toFixed(1)},${vp.scale.x.toFixed(4)},${vp.scale.y.toFixed(4)}`;
      if (sig !== this.lastViewSig) {
        this.lastViewSig = sig;
        // A user move at an unchanged scale is a pan — the minimap's trigger.
        if (!animMoved && !this.programmaticMove && !this.zoomTween &&
            Math.abs(vp.scale.x) === this.viewPoseScale) {
          this.viewUserPanned = true;
          this.viewPanDx += vp.x - this.viewPanX;
          this.viewPanDy += vp.y - this.viewPanY;
        }
        this.viewPanX = vp.x;
        this.viewPanY = vp.y;
        // 2R (Roger, 11/10/2026): «conforme eu der zoom no BDV, dar zoom no esquemático»
        // — só o zoom do técnico (não os pulos animados); desliga em Preferências.
        const newScale = Math.abs(vp.scale.x);
        if (!animMoved && !this.programmaticMove && this.viewPoseScale > 0 && newScale !== this.viewPoseScale) {
          // 2R 13/10/2026: zoom da placa e do PDF independentes (Roger) — liga com «2r-sync-zoom»="1"
          let on = false;
          try { on = localStorage.getItem('2r-sync-zoom') === '1'; } catch { on = false; }
          if (on) window.dispatchEvent(new CustomEvent('2r-bv-zoom', { detail: { ratio: newScale / this.viewPoseScale } }));
        }
        this.viewPoseScale = newScale;
        if (animMoved || this.programmaticMove) {
          this.programmaticMove = false;
          if (this.viewSettleTimer) { clearTimeout(this.viewSettleTimer); this.viewSettleTimer = null; }
        } else {
          this.scheduleViewSettle();
        }
      }
      if (animDone) this.noteArrivalPose();
    }

    // Detect active zooming by comparing scale between frames
    const curScale = Math.abs(this.viewport.scale.x);
    if (this.prevTickScale >= 0 && curScale !== this.prevTickScale) {
      this.onZoomFrame();
    }
    this.prevTickScale = curScale;

    let t0 = perf ? performance.now() : 0;
    if (this.updateLoD()) this.needsRender = true;
    if (perf) this.perfAccum.lod += performance.now() - t0;

    // Net line pulse animation — only when there's an active selection with net lines.
    // Skip during active zoom (net lines are hidden, no point redrawing).
    // Skip while the viewport is being panned/zoomed: the per-frame Graphics
    // rebuild for net lines + ghosts is expensive and competes with viewport
    // updates. Phase doesn't advance during the pause, so resume is jump-free.
    // Also skip when the page is hidden or the window has lost focus: nobody can
    // see the pulse, so advancing the phase + forcing a GPU render is pure waste.
    // Selection changes still draw ghosts via renderSelection(), so the static
    // frame stays correct; on refocus, the pulse resumes from the saved phase.
    const hasGhosts = this.crossSideGhostParts.size > 0;
    // The disco layer also carries the preview marker, so it must keep
    // animating for a preview even when disco mode itself is off — and must
    // get one more pass after everything goes quiet to clear its geometry.
    const hasDisco =
      (boardStore.discoHighlight && this.discoHaloParts.size > 0) ||
      boardStore.previewPulse !== null ||
      this.discoHaloDirty;
    const hasNetLines = boardStore.netLineMode !== 'off' && boardStore.selection.highlightedNet !== null;
    const pageVisible = !document.hidden && document.hasFocus();
    const viewportIdle = performance.now() >= this.viewportMovingUntil;
    if (pageVisible && viewportIdle && !this.netLinesHiddenForZoom && (hasNetLines || hasGhosts || hasDisco)) {
      const s = renderSettingsStore.settings;
      const needsPulse = s.netLineDashed || s.netLinePulse || hasGhosts || hasDisco;
      if (needsPulse) {
        this.netLinePulsePhase = (this.netLinePulsePhase + ticker.deltaMS / 1000) % 1;
        t0 = perf ? performance.now() : 0;
        if (hasNetLines) this.renderNetLines();
        if (hasGhosts) this.renderCrossSideGhosts();
        if (hasDisco) this.renderDiscoHalo();
        if (perf) this.perfAccum.netLines += performance.now() - t0;
        // `needsRender` is now flipped by each renderer that actually drew.
      }
    }

    this.updateDebugVertexLabels();

    // On-demand GPU render — skip when nothing changed (e.g. idle at high zoom)
    // Also skip if WebGL context was lost — PixiJS internals are corrupted
    if (this.needsRender && !this.contextLost) {
      this.needsRender = false;
      // The primary selection outline is zoom-dependent (screen-constant
      // stroke, minimum on-screen size). It is ONE polygon in its own child
      // Graphics, so it is simply redrawn on any frame whose zoom differs from
      // the last paint — no settle timer, no threshold, no lag where a
      // world-unit stroke thickens until a debounce catches up. The rest of
      // the scene is static world geometry and never rebuilds on zoom; this
      // is the one shape whose world geometry legitimately follows the zoom.
      if (boardStore.selection.partIndex !== null) {
        const k = this.viewScale();
        if (Math.abs(k - this.lastSelectionPaintScale) > this.lastSelectionPaintScale * 0.005) {
          this.renderSelectionPrimary();
        }
      }
      t0 = perf ? performance.now() : 0;
      const renderStart = performance.now();
      try {
        this.app.render();
      } catch (err) {
        this.handleRenderCrash(err);
        return;
      }
      this.lastRenderMs = performance.now() - renderStart;
      this.renderedThisTick = true;
      if (perf) this.perfAccum.gpuRender += performance.now() - t0;
      // After rendering a freshly-activated scene, keep rendering for a few more
      // frames so the CullerPlugin re-culls with the now-updated world transforms
      // (the first post-rebuild cull ran against stale/identity transforms). See
      // cullRefreshFrames — this is what makes labels reappear after ON→OFF.
      if (this.cullRefreshFrames > 0) {
        this.cullRefreshFrames--;
        this.needsRender = true;
      }
    }

    // Canvas2D label overlay — drawn AFTER app.render() so the per-side label
    // layers' worldTransforms are current for this frame. When needsRender was
    // false (e.g. a selection change without a scene/viewport change) the
    // transforms are unchanged from the last render — also correct.
    const overlay = this.ensureLabelOverlay();
    if (overlay && this.activeScene?.labelModel) {
      // Adaptive motion mode: while the viewport is actively panning/zooming
      // (viewportMovingUntil window) AND the last full draw was heavy (>6ms),
      // re-project the last-drawn bitmap via a cheap CSS transform instead of
      // redrawing every frame. Redraw resumes once motion settles (next tick
      // with moving=false takes the full-draw branch). Butterfly is excluded —
      // its two sides move under different transforms, so a single CSS
      // transform can't represent it; it always full-draws. A light board
      // (draw < 6ms) always full-draws too, since redrawing is cheap enough
      // to stay crisp every frame.
      const moving = performance.now() < this.viewportMovingUntil;
      const heavy = overlay.lastDrawMs > 6;
      const butterfly = !!(boardStore.butterfly && this.activeScene.butterflyRoot);
      // Some transform mutations bypass the viewport 'moved' event entirely
      // (zoomAnim jump-to-part, fitToBoard's viewport.fit/moveCenter, keyboard
      // pan). Catch them by comparing against the last-drawn view so overlay
      // text never freezes at a stale transform (whole-branch review finding).
      // Three number compares per tick when idle — effectively free.
      if (!this.overlayDirty && this.overlayDrawnView) {
        const d = this.overlayDrawnView;
        if (d.x !== this.viewport.x || d.y !== this.viewport.y || d.scale !== curScale) {
          this.overlayDirty = true;
        }
      }
      if (this.overlayDirty && (!moving || !heavy || butterfly || !this.overlayDrawnView || this.overlayContentDirty)) {
        this.overlayDirty = false;
        this.overlayContentDirty = false;
        this.syncLabelOverlay(overlay, this.activeScene);
        this.overlayDrawnView = { x: this.viewport.x, y: this.viewport.y, scale: curScale };
      } else if (this.overlayDirty && this.overlayDrawnView) {
        // Heavy + moving + content-clean: transform the last-drawn bitmap
        // instead of redrawing. A content change (selection/settings/scene/
        // flip/resize — overlayContentDirty) forces the full-draw branch
        // above instead, so this never re-projects a stale/blank bitmap.
        // Redraw happens when movement settles (viewportMovingUntil expires —
        // the next tick with moving=false takes the full-draw branch).
        //
        // Derivation of dx/dy: a scene point p maps to screen
        // `viewport.pos + p·scale`; the drawn bitmap has it at
        // `d.pos + p·d.scale`. Composite CSS `translate(t)·scale(k)` maps
        // bitmap pixel q → `t + q·k`, so requiring
        // `t + (d.pos + p·d.scale)·k = viewport.pos + p·scale` gives
        // `k = scale/d.scale`, `t = viewport.pos − d.pos·k`. `draw()` already
        // resets the CSS transform to `''` at entry, so the full-draw branch
        // above needs no explicit reset.
        const d = this.overlayDrawnView;
        const k = curScale / d.scale;
        const dx = this.viewport.x - d.x * k;
        const dy = this.viewport.y - d.y * k;
        overlay.setCssTransform(`translate(${dx}px, ${dy}px) scale(${k})`);
        // overlayDirty (and overlayContentDirty, if set later this tick) stay true → settle redraw
      }
    } else if (overlay) {
      overlay.clear();   // setting on, but scene built pre-toggle → rebuild pending
    }

    // HDR focus glow — deliberately OUTSIDE the label-overlay branch above: it
    // works with either label mode, and has no dependency on labelModel. Also
    // after app.render(), for the same worldTransform-freshness reason.
    const hdr = this.ensureHdrOverlay();
    if (hdr && this.activeScene) this.syncHdrOverlay(hdr, this.activeScene);

    if (perf) {
      const now = performance.now();
      this.perfAccum.frame += now - frameStart;
      this.perfSamples++;
      if (this.renderedThisTick) {
        const d = this.perfDrawn;
        d.n++; d.js += now - frameStart;
        // Only back-to-back draws measure the frame rate; a draw after an
        // idle stretch would read as a long frame.
        if (d.lastDrewAt && frameStart - d.lastDrewAt < 250) { d.interval += frameStart - d.lastDrewAt; d.intervalN++; }
        d.lastDrewAt = frameStart;
      }
    }
    this.renderedThisTick = false;

    this.emitViewChange();

    // HUD update (DOM only, no GPU cost) — throttle to ~4 updates/sec
    this.hudThrottle += ticker.deltaMS;
    if (this.hudThrottle >= 250) {
      this.hudThrottle = 0;
      this.updateHud(ticker.FPS);
    }

    // Perf overlay update — flush accumulators every ~500ms
    if (this.perfVisible) {
      this.perfThrottle += ticker.deltaMS;
      if (this.perfThrottle >= 500) {
        this.flushPerfOverlay();
        this.perfThrottle = 0;
      }
    }

    // A paused panel's ticker runs only for what is pending — a store wake,
    // a camera animation, a glide, a blink — and stops when that is drawn.
    // A PDF word lookup used to leave it running until the panel was next
    // activated; the wheel wake re-pauses on its own 300 ms timer.
    if (this.panelPaused && !this.needsRender && !this.zoomTween && !this.zoomAnim
      && this.selectionBlinkPhase === 0 && !this.selectionBlinkTimer && this.cullRefreshFrames === 0
      && !this.wheelIdleTimer
      && !(this.viewport?.plugins.get('decelerate') as { isActive?(): boolean } | null)?.isActive?.()) {
      this.stopTicker();
    }
  };

  /** Pause the renderer (stop ticker, zero CPU cost). Call when panel is hidden. */
  pause() {
    log.render.log('pause', 'tab=' + this.tabId);
    this.panelPaused = true;
    if (boardStore.activeTabId === this.tabId) {
      log.render.warn(`pausing the store-active renderer tab=${this.tabId} — possible spurious isActive=false`);
    } else {
      log.render.log(`pause tab=${this.tabId} storeActive=${boardStore.activeTabId}`);
    }
    // Cancel pending follow-PDF debounce
    if (this.followDebounceTimer) { clearTimeout(this.followDebounceTimer); this.followDebounceTimer = null; }
    // Cancel any pending rAF-coalesced hover — harmless if it fires after
    // pause() (handleHover no-ops without an active scene), but wasteful.
    if (this.hoverRafId !== null) { cancelAnimationFrame(this.hoverRafId); this.hoverRafId = null; }
    // Drop any in-flight wheel-zoom tween — the ticker that drives it is
    // about to stop, and resuming much later with a stale target would glide
    // unexpectedly on refocus.
    this.zoomTween = null;
    // Just stop the ticker — do NOT destroy the Application.
    // PixiJS v8 uses module-level batch pools that get permanently corrupted
    // by app.destroy(), making all future Applications crash with
    // "_DefaultBatcher2.break: Cannot read properties of null (reading 'clear')".
    this.stopTicker();
  }

  /** Re-pause the ticker after wheel activity if this panel isn't the active Dockview panel. */
  private scheduleWheelIdlePause() {
    if (this.wheelIdleTimer) clearTimeout(this.wheelIdleTimer);
    this.wheelIdleTimer = setTimeout(() => {
      this.wheelIdleTimer = null;
      // A zoom tween or glide still running is part of the gesture: let it land.
      if (this.zoomTween || this.zoomAnim || (this.viewport?.plugins.get('decelerate') as { isActive?(): boolean } | null)?.isActive?.()) {
        this.scheduleWheelIdlePause();
        return;
      }
      // Only auto-pause if this renderer's panel is NOT the active board tab
      if (boardStore.activeTabId !== this.tabId && this.app.ticker.started) {
        this.stopTicker();
      }
    }, 300);
  }

  /**
   * Tear down the scene and canvas without calling app.destroy().
   *
   * PixiJS v8's app.destroy() triggers GlobalResourceRegistry.clear() which
   * destroys the module-level batchPool shared by ALL Application instances.
   * This permanently corrupts rendering for every other renderer on the page.
   * Instead, we just remove the canvas from the DOM, clear scenes, and let GC
   * reclaim GPU resources when the Application becomes unreferenced.
   */
  private teardownForReinit() {
    log.render.log('teardownForReinit', 'tab=' + this.tabId);
    if (this.tabId !== null) { unregisterRenderer(this.tabId); navHistoryStore.unregisterBoardCamera(this.tabId, this.navCamera); }
    if (this._rebuildTimer) { clearTimeout(this._rebuildTimer); this._rebuildTimer = null; }
    this.clickCycle = null;
    this.clearPendingCycleAdvance();

    // Save viewport state
    if (this.board && this.viewport) {
      try {
        this.viewportStates.set(this.board, {
          x: this.viewport.x,
          y: this.viewport.y,
          scaleX: this.viewport.scale.x,
          scaleY: this.viewport.scale.y,
        });
      } catch { /* viewport may be in bad state */ }
    }

    // Stop the ticker first so no more callbacks fire during teardown
    this.stopTicker();

    // Evict scene cache (GPU objects will be invalid after new app)
    try { this.invalidateAllScenes(); } catch (e) { log.render.warn('teardown invalidateAllScenes error:', e); }
    this.activeScene = null;
    this.sceneCache.clear();
    this.hitGridCache.clear();

    // Remove canvas event listeners and canvas from DOM
    try {
      const canvas = this.app?.renderer?.canvas as HTMLCanvasElement | undefined;
      if (canvas && this.boundHover) {
        canvas.removeEventListener('pointermove', this.boundHover);
        canvas.removeEventListener('pointerleave', this.boundHideTooltip!);
        if (this.boundWheelWake) canvas.removeEventListener('wheel', this.boundWheelWake);
        if (this.boundPointerCapture) canvas.removeEventListener('pointerdown', this.boundPointerCapture);
      }
      // Symmetry with destroy(): drop webglcontextlost/restored listeners off the
      // old canvas (reinitApp reinstalls them on the fresh canvas). Otherwise the
      // dead canvas keeps a listener referencing `this` until GC.
      this.removeContextLossHandlers();
      canvas?.parentElement?.removeChild(canvas);
    } catch (e) { log.render.warn('teardown canvas cleanup error:', e); }

    // Do NOT call app.destroy() (global-pool corruption) — but
    // renderer.destroy(false) is safe and required: it removes
    // GlContextSystem's webglcontextlost/restored listeners (which pin the
    // abandoned WebGLRenderer from a GC root), loses the GL context, and
    // returns GraphicsContext batches to the pool. Without it every
    // deep-pause/reinit cycle leaked the whole render graph. Mirrors destroy().
    try {
      this.viewport?.removeAllListeners();
    } catch { /* ignore */ }
    try {
      this.app?.ticker?.remove(this.onTick);
      this.app?.renderer?.destroy(false);
    } catch {
      try {
        const gl = (this.app?.renderer as unknown as { gl?: WebGL2RenderingContext })?.gl;
        gl?.getExtension('WEBGL_lose_context')?.loseContext();
      } catch { /* ignore — renderer may already be gone */ }
    }
    log.render.log(`teardownForReinit tab=${this.tabId} — old app released (renderer destroyed, app GC-able)`);
  }

  /** Resume the renderer (restart ticker). Call when panel becomes visible. */
  resume() {
    if (this.destroyed) return;
    this.panelPaused = false;
    // Panel is visible again — cancel any pending deep-pause release.
    this.cancelDeepPause();
    // GPU was released (pause/context loss) — need full re-init
    if (this.contextLost) {
      log.render.log(`resume → reinitApp tab=${this.tabId}`);
      this.reinitApp();
      return;
    }
    // init() failed (e.g. its WebGL chunk could not be fetched): there is no
    // ticker to restart, and touching it would turn one error into another.
    if (!this.initialized) return;

    const w = this.containerEl.clientWidth;
    const h = this.containerEl.clientHeight;
    log.render.log(`resume tab=${this.tabId} size=${w}x${h} scene=${this.activeScene ? 'yes' : 'null'} ticker=${this.app.ticker.started} storeActive=${boardStore.activeTabId}`);
    this.app.ticker.start();
    this.needsRender = true;
    // Re-sync with container size (may have been 0 while hidden)
    if (w > 0 && h > 0 && this.viewport) {
      this.viewport.resize(w, h);
      this.app.renderer.resize(w, h);
    }
    // Sync with current store state
    this.onBoardUpdate();

    // D1: a settings/theme change arrived while this tab was inactive — run
    // the single deferred rebuild now that the tab is visible again.
    if (this.pendingDeferredRebuild) {
      this.pendingDeferredRebuild = false;
      this.scheduleRebuild();
    }

    // If the container had 0 dimensions (dockview hasn't shown it yet), schedule
    // a deferred sync so the first render uses correct viewport size.
    if ((w === 0 || h === 0) && this.viewport) {
      requestAnimationFrame(() => {
        if (!this.app.ticker.started) return; // paused again before callback
        const dw = this.containerEl.clientWidth;
        const dh = this.containerEl.clientHeight;
        if (dw > 0 && dh > 0) {
          log.render.log('resume deferred resize', dw, 'x', dh);
          this.viewport.resize(dw, dh);
          this.app.renderer.resize(dw, dh);
          this.needsRender = true;
          this.onBoardUpdate();
        }
      });
    }
  }

  /**
   * Arm the deep-pause timer. Call when this panel becomes hidden (dockview
   * onDidVisibilityChange → not visible). After DEEP_PAUSE_DELAY_MS the tab's
   * GPU context + scene graph are released. Only hidden panels arm this — a
   * board still visible in a split/floating group keeps its live renderer.
   */
  scheduleDeepPause() {
    if (this.destroyed || this.contextLost) return;
    let delay = DEEP_PAUSE_DELAY_MS;
    // DEV/test seam: Playwright lowers this to exercise the deep-pause→reinit
    // cycle without a 45s wait. Never read in production builds.
    if (import.meta.env.DEV) {
      const ov = (window as unknown as { __deepPauseDelayMs?: number }).__deepPauseDelayMs;
      if (typeof ov === 'number' && ov >= 0) delay = ov;
    }
    if (this._deepPauseTimer) clearTimeout(this._deepPauseTimer);
    this._deepPauseTimer = setTimeout(() => {
      this._deepPauseTimer = null;
      this.deepPause();
    }, delay);
  }

  /** Cancel a pending deep-pause (panel became visible again before it fired). */
  cancelDeepPause() {
    if (this._deepPauseTimer) { clearTimeout(this._deepPauseTimer); this._deepPauseTimer = null; }
  }

  /**
   * Release GPU + scene memory for a tab that has been hidden long enough.
   * Reuses the tested context-loss recovery path: teardownForReinit() stops the
   * ticker, evicts the scene/hit-grid caches, loses the WebGL context and removes
   * the canvas; setting contextLost makes the next resume() rebuild the whole
   * Application from this.board via reinitApp(). Guarded so it never fires on the
   * store-active tab or an already-released/uninitialised renderer.
   */
  private deepPause() {
    if (this.destroyed || this.contextLost || this.reinitializing || !this.initialized) return;
    // Never release the board the user is actually looking at.
    if (boardStore.activeTabId === this.tabId) return;
    log.render.log(`deepPause tab=${this.tabId} — releasing GPU context + scene graph`);
    // Release the label-overlay canvas too (up to ~33 MB backing store at
    // retina) — ensureLabelOverlay() recreates it lazily on the next tick
    // after resume. (v0.31.40 review follow-up)
    this.textFastMode?.destroy();
    this.textFastMode = null;
    this.hdrOverlay?.destroy();
    this.hdrOverlay = null;
    this.teardownForReinit();
    // teardownForReinit() releases the context but leaves contextLost=false;
    // set it so resume() routes through reinitApp() instead of touching the
    // now-dead Application.
    this.contextLost = true;
  }

  /** Force a full scene re-activation — use the restart button to recover a broken render. */
  restartRender() {
    log.render.log(`restartRender tab=${this.tabId} initialized=${this.initialized} contextLost=${this.contextLost} board=${this.board ? this.board.format : 'null'}`);
    if (!this.initialized) return;
    // Clear the contextLost flag so rendering can resume
    this.contextLost = false;
    // Use renderer's own board reference (works even if boardStore active tab is wrong)
    const board = this.board ?? boardStore.tabs.find(t => t.id === this.tabId)?.board ?? null;
    if (!board) {
      log.render.log(`restartRender: no board — nothing to rebuild`);
      return;
    }
    // Evict cached scene so buildBoardScene runs fresh, then re-activate directly
    const key = this.sceneCacheKey(board);
    this.sceneCache.delete(key);
    this.hitGridCache.delete(key);
    this.activateScene(board);
    this.board = board;
    // Resync board store so onBoardUpdate won't skip future notifications
    if (this.tabId != null) boardStore.switchTab(this.tabId);
    if (!this.app.ticker.started) {
      log.render.log(`restartRender: restarting stopped ticker`);
      this.app.ticker.start();
    }
    this.needsRender = true;
  }

  /**
   * Handle a crash during app.render() — typically caused by WebGL context loss
   * or PixiJS v8 batch pool corruption.
   *
   * We do NOT call app.destroy() here because that corrupts the global batch pool
   * and makes ALL renderers crash. Instead we just stop the ticker and let the user
   * use the "Restart Render" button (restartRender) which rebuilds the scene without
   * destroying the Application.
   */
  private handleRenderCrash(err: unknown) {
    if (this.contextLost) return; // already handled
    this.contextLost = true;
    log.render.error(`render crash tab=${this.tabId} — ticker stopped, use Restart Render to recover:`, err);
    this.stopTicker();
  }

  /** Install WebGL context loss/restore handlers on a canvas element. */
  private installContextLossHandlers(canvas: HTMLCanvasElement) {
    // Remove previous handlers if any (reinitApp creates a new canvas)
    this.removeContextLossHandlers();

    this.boundContextLost = (e: Event) => {
      e.preventDefault();
      if (this.destroyed) return;
      this.contextLost = true;
      log.render.warn(`WebGL context lost tab=${this.tabId} — will recover on resume`);
      this.stopTicker();
    };
    this.boundContextRestored = () => {
      log.render.log(`WebGL context restored event tab=${this.tabId} — deferring recovery to resume()`);
      this.r2RecoverIfVisible();
    };
    canvas.addEventListener('webglcontextlost', this.boundContextLost);
    canvas.addEventListener('webglcontextrestored', this.boundContextRestored);
    /* 2R 29/10/2026 (Roger: «quando fui preencher a ficha de reparo e voltei para o ripper, tava em nada... só a tela de
       fundo»): no SDS a página inteira some quando se troca de ferramenta — o contexto WebGL pode ser perdido enquanto ela
       está escondida, mas o painel do Dockview nunca deixou de estar «visível», então ninguém chamava resume() e a placa
       ficava em branco. Ao a página voltar a aparecer (ou ganhar foco), recupera. */
    if (!this.r2BoundVis) {
      this.r2BoundVis = () => this.r2RecoverIfVisible();
      document.addEventListener('visibilitychange', this.r2BoundVis);
      window.addEventListener('focus', this.r2BoundVis);
      window.addEventListener('pageshow', this.r2BoundVis);
    }
  }

  private r2BoundVis: (() => void) | null = null;
  private r2RecoverIfVisible() {
    try {
      if (this.destroyed || this.panelPaused || document.visibilityState !== 'visible') return;
      if (this.contextLost && !this.reinitializing) {
        log.render.log(`page visible again with a lost context tab=${this.tabId} — recovering`);
        setTimeout(() => { if (!this.destroyed && !this.panelPaused && this.contextLost) this.resume(); }, 60);
      } else if (this.initialized && this.app?.ticker && !this.app.ticker.started) {
        this.app.ticker.start();
        this.needsRender = true;
      } else {
        this.needsRender = true;
      }
    } catch { /* */ }
  }

  /** Remove context loss handlers from the current canvas. */
  private removeContextLossHandlers() {
    const canvas = this.app?.renderer?.canvas as HTMLCanvasElement | undefined;
    if (canvas && this.boundContextLost) {
      canvas.removeEventListener('webglcontextlost', this.boundContextLost);
      canvas.removeEventListener('webglcontextrestored', this.boundContextRestored!);
    }
    this.boundContextLost = null;
    this.boundContextRestored = null;
  }

  /**
   * Full re-initialization after GPU release or WebGL context loss.
   * Creates a fresh PixiJS Application, preserving subscriptions, DOM overlays,
   * and board data. Called by resume() when contextLost is true.
   */
  private async reinitApp() {
    log.render.log('reinitApp ENTER', 'tab=' + this.tabId, 'contextLost=' + this.contextLost, 'board=' + (this.board ? this.board.format : 'null'));
    if (this.destroyed) return;
    if (this.reinitializing) {
      log.render.log('reinitApp SKIPPED (already reinitializing)', 'tab=' + this.tabId);
      return;
    }
    this.reinitializing = true;
    log.render.log(`reinitApp START tab=${this.tabId} board=${this.board ? this.board.format + '/' + this.board.parts.length + 'parts' : 'null'}`);

    const savedBoard = this.board;

    // Tear down old app's scene/canvas without calling app.destroy()
    this.teardownForReinit();
    this.contextLost = false;

    // --- Create fresh Application ---
    log.render.log(`reinitApp: creating new Application tab=${this.tabId}`);
    this.app = new Application();
    try {
      await this.app.init({
        background: COLORS.background,
      // 2R Tools: contexto com canal alpha p/ o modo "Pinos por cima" (o fundo
      // volta a 1 logo após o init em applyBackgroundAlpha)
      backgroundAlpha: 0.99,
        width: this.containerEl.clientWidth || 1,
        height: this.containerEl.clientHeight || 1,
        antialias: boardAntialias(renderSettingsStore.settings.touchPerformanceMode, renderSettingsStore.settings.boardAntialiasing),
        resolution: boardPixelRatio(renderSettingsStore.settings.touchPerformanceMode, renderSettingsStore.settings.boardResolutionCap),
        autoDensity: true,
        powerPreference: 'high-performance',
        ...(RENDERER_PREFERENCE ? { preference: RENDERER_PREFERENCE } : {}),
      });
      log.render.log(`reinitApp: app.init succeeded tab=${this.tabId} size=${this.containerEl.clientWidth}x${this.containerEl.clientHeight}`);
      if (this.tabId !== null) { registerRenderer(this.tabId, this.app); navHistoryStore.registerBoardCamera(this.tabId, this.navCamera); }
    } catch (err) {
      log.render.error(`reinitApp: app.init FAILED tab=${this.tabId}:`, err);
      this.reinitializing = false;
      return;
    }

    this.containerEl.appendChild(this.app.canvas as HTMLCanvasElement);
    this.app.ticker.maxFPS = boardMaxFps(renderSettingsStore.settings.cap60Fps,
      renderSettingsStore.settings.touchPerformanceMode);
    this.app.ticker.remove(this.app.render, this.app);

    // --- Recreate Viewport ---
    this.viewport = new Viewport({
      screenWidth: this.containerEl.clientWidth || 1,
      screenHeight: this.containerEl.clientHeight || 1,
      events: this.app.renderer.events,
      // A drag follows the pointer until the button is released, wherever it
      // goes — pixi-viewport otherwise takes `pointermove` only while the
      // pointer hit-tests inside the screen rect and ends the drag on
      // `pointerleave` (2026-10-22, "click and drag stops when the pointer
      // leaves the board view").
      allowPreserveDragOutside: true,
    });
    this.applyViewportPlugins();
    this.installShiftWheelHandler();
    this.installTouchPinch();
    this.installDragZoomHandler();
    this.viewport.on('moved', () => {
      this.needsRender = true;
      // Do NOT mark netLinesDirty here. Net-line segments are world-space and
      // the viewport transforms netLinesGfx on the GPU, so pan/zoom never
      // invalidates the geometry. Genuine changes (selection/flip/rotation)
      // set netLinesDirty at their own sites; the idle-settle path re-derives
      // the zoom-dependent draw params. Firing a full O(K^2 log K) recompute on
      // every 'moved' frame produced byte-identical segments — pure waste.
      this.viewportMovingUntil = performance.now() + 100;
      this.scheduleFollowDebounce();
      // Keep multi-select / worklist outline thickness ~constant in screen
      // pixels across zoom changes — unforced: skips entirely unless the
      // stroke width bucket or highlight state changed (A4).
      this.redrawMultiHighlight(false);
      this.overlayDirty = true;   // pan/zoom moved the label-layer transforms
    });
    this.viewport.on('clicked', (e: ViewportClickEvent) => { this.handleClick(e.world); });
    this.app.stage.addChild(this.viewport);

    // --- Recreate overlay Graphics (old ones were destroyed with the old app) ---
    // zIndex values must match init() — see comments there for the full layering map.
    // eventMode='none' on every decoration layer so pointer events fall through
    // to the underlying parts/pins. Without this, the netDimGfx full-screen
    // darkening drawn in chain-adjacent / spotlight modes captures clicks
    // before they can reach pin sprites — small pins become unselectable while
    // the dim is active. Same risk applies to net-lines, ghosts, selection
    // highlights, and label layers (any Graphics with painted content under
    // the cursor counts as a hit otherwise).
    // selectionGfx zIndex 30 — sits below netLabelLayer (35) so pin numbers
    // and net names stay readable on top of the highlight. It is attached to
    // selectionLabelLayer in activateScene/setupButterfly so it still renders
    // after netLinesGfx. The glow ring stroke painted in renderSelection is
    // wide enough to remain visible at the pad perimeter regardless of label
    // coverage at the pad center. Scene-graph parent stays scene.root so
    // flip/rotation transforms still apply.
    this.selectionGfx = new Graphics();
    this.selectionGfx.zIndex = 30;
    this.selectionGfx.eventMode = 'none';
    this.primarySelGfx = new Graphics();
    this.primarySelGfx.eventMode = 'none';
    this.selectionGfx.addChild(this.primarySelGfx);
    this.netDimGfx = new Graphics();
    this.netDimGfx.zIndex = 10;
    this.netDimGfx.eventMode = 'none';
    this.netLabelLayer = new Container();
    this.netLabelLayer.zIndex = 35;
    this.netLabelLayer.eventMode = 'none';
    this.butterflySelectionGfx = new Graphics();
    this.butterflySelectionGfx.eventMode = 'none';
    this.butterflyPrimarySelGfx = new Graphics();
    this.butterflyPrimarySelGfx.eventMode = 'none';
    this.butterflySelectionGfx.addChild(this.butterflyPrimarySelGfx);
    this.butterflyDimGfx = new Graphics();
    this.butterflyDimGfx.eventMode = 'none';
    this.netLinesGfx = new Graphics();
    this.netLinesPulseGfx = null;  // orphaned by the reinit; rebuilt on next bake
    this.netLineBakeSig = '';
    this.netLinesGfx.eventMode = 'none';
    this.crossSideGhostGfx = new Graphics();
    this.crossSideGhostGfx.zIndex = 15;
    this.crossSideGhostGfx.eventMode = 'none';
    this.crossSideGhostOutlineGfx = new Graphics();
    this.crossSideGhostOutlineGfx.zIndex = 15;
    this.crossSideGhostOutlineGfx.eventMode = 'none';
    this.crossSideGhostBakeSig = '';
    this.discoHaloGfx = new Graphics();
    this.discoHaloGfx.zIndex = 31; // just above selectionGfx (30), below netLabelLayer (35)
    this.discoHaloGfx.eventMode = 'none';
    this.selectionLabelLayer = new RenderLayer({ sortableChildren: true });
    // multiHighlightGfx is attached to scene.root in activateScene() so the
    // board's rotation/flip/butterfly transforms apply to the outlines too —
    // attaching to viewport would draw them at raw mil coords, which lands
    // in the wrong place once the board is rotated or mirrored.
    this.multiHighlightGfx = new Graphics();
    this.multiHighlightGfx.zIndex = 28;
    this.multiHighlightGfx.eventMode = 'none';
    this.viewport.addChild(this.netLinesGfx);
    this.viewport.addChild(this.selectionLabelLayer);

    // Recreate elevated labels (see init() for detailed comments)
    const labelStyle = { fontSize: 12, fill: BOARD_COLORS.labelPin, fontFamily: 'monospace' };
    this.elevatedPartBg = new Graphics();
    this.elevatedPartBg.zIndex = 100;
    this.elevatedPartBg.eventMode = 'none';
    this.elevatedPartLabel = new BitmapText({ text: '', style: labelStyle });
    this.elevatedPartLabel.anchor.set(0.5, 0.5);
    this.elevatedPartLabel.zIndex = 101;
    this.elevatedPartLabel.visible = false;
    this.elevatedPartLabel.eventMode = 'none';
    this.elevatedPartBg.visible = false;
    this.elevatedPinBg = new Graphics();
    this.elevatedPinBg.zIndex = 102;
    this.elevatedPinBg.eventMode = 'none';
    this.elevatedPinLabel = new BitmapText({ text: '', style: labelStyle });
    this.elevatedPinLabel.anchor.set(0.5, 0.5);
    this.elevatedPinLabel.zIndex = 103;
    this.elevatedPinLabel.visible = false;
    this.elevatedPinLabel.eventMode = 'none';
    this.elevatedPinBg.visible = false;

    // --- Reinstall canvas event listeners ---
    const newCanvas = this.app.renderer.canvas as HTMLCanvasElement;
    this.tooltipCanvas = newCanvas;
    if (this.boundHover) {
      newCanvas.addEventListener('pointermove', this.boundHover);
      newCanvas.addEventListener('pointerleave', this.boundHideTooltip!);
      if (this.boundWheelWake) newCanvas.addEventListener('wheel', this.boundWheelWake, { passive: true });
      if (this.boundPointerCapture) newCanvas.addEventListener('pointerdown', this.boundPointerCapture);
    }
    this.installContextLossHandlers(newCanvas);

    // Reinstall shared ticker callback
    this.hudThrottle = 0;
    this.app.ticker.add(this.onTick);

    // --- Reset state and rebuild scene ---
    log.render.log(`reinitApp: resetting state & rebuilding scene tab=${this.tabId}`);
    this.lastLodScale = -1;
    this.prevTickScale = -1;
    this.lastFlipParams = null;
    this.netLinesDirty = true;
    this.needsRender = true;

    if (savedBoard) {
      log.render.log(`reinitApp: activateScene for ${savedBoard.format}/${savedBoard.parts.length}parts tab=${this.tabId}`);
      // skipSaveViewport: don't let activateScene overwrite the viewport state
      // teardownForReinit saved with the fresh default viewport (would render blank).
      this.activateScene(savedBoard, true);
      this.board = savedBoard;
    } else {
      log.render.warn(`reinitApp: no saved board — nothing to rebuild tab=${this.tabId}`);
    }

    this.initialized = true;
    this.app.ticker.start();
    this.reinitializing = false;

    // Sync with current store state (applies layer visibility, selection, etc.)
    this.onBoardUpdate();

    this.applyBackgroundAlpha();
    log.render.log(`reinitApp COMPLETE tab=${this.tabId} board=${savedBoard ? savedBoard.format : 'null'} tickerStarted=${this.app.ticker.started} scene=${this.activeScene ? 'yes' : 'null'}`);
  }

  async init() {
    log.render.log('init', this.containerEl.clientWidth, 'x', this.containerEl.clientHeight);
    try {
    await this.app.init({
      background: COLORS.background,
      // 2R Tools: contexto com canal alpha p/ o modo "Pinos por cima" (o fundo
      // volta a 1 logo após o init em applyBackgroundAlpha)
      backgroundAlpha: 0.99,
      width: this.containerEl.clientWidth,
      height: this.containerEl.clientHeight,
      antialias: boardAntialias(renderSettingsStore.settings.touchPerformanceMode, renderSettingsStore.settings.boardAntialiasing),
      resolution: boardPixelRatio(renderSettingsStore.settings.touchPerformanceMode, renderSettingsStore.settings.boardResolutionCap),
      autoDensity: true,
      powerPreference: 'high-performance',
      ...(RENDERER_PREFERENCE ? { preference: RENDERER_PREFERENCE } : {}),
    });
    // React StrictMode (and fast HMR) can run mount → unmount → remount while
    // `app.init()` is mid-await. The cleanup path calls destroy() synchronously,
    // which nulls `this.app` (see the bottom of destroy()). When the awaited
    // promise finally resolves we'd continue executing here with this.app ===
    // null, crashing at .canvas access. Bail out quietly in that case — the
    // remount will create a fresh BoardRenderer.
    if (this.destroyed || !this.app) {
      log.render.log(`init: aborted — renderer destroyed during app.init (tab=${this.tabId})`);
      return;
    }
    if (this.tabId !== null) { registerRenderer(this.tabId, this.app); navHistoryStore.registerBoardCamera(this.tabId, this.navCamera); }
    this.pinsOnTop = isPinsOnTop();
    this.applyBackgroundAlpha();
    this.containerEl.appendChild(this.app.canvas as HTMLCanvasElement);
    this.initialized = true;

    this.app.ticker.maxFPS = boardMaxFps(renderSettingsStore.settings.cap60Fps,
      renderSettingsStore.settings.touchPerformanceMode);

    // Remove the TickerPlugin's auto-render so we control when GPU work happens.
    // The ticker still fires our callbacks; we call app.render() only when needsRender is set.
    this.app.ticker.remove(this.app.render, this.app);

    this.viewport = new Viewport({
      screenWidth: this.containerEl.clientWidth,
      screenHeight: this.containerEl.clientHeight,
      events: this.app.renderer.events,
      allowPreserveDragOutside: true, // see the init site above
    });

    this.applyViewportPlugins();
    this.installShiftWheelHandler();
    this.installTouchPinch();
    this.installDragZoomHandler();

    // Viewport pan/zoom/decelerate → mark dirty so we render
    this.viewport.on('moved', () => {
      this.needsRender = true;
      // Do NOT mark netLinesDirty here. Net-line segments are world-space and
      // the viewport transforms netLinesGfx on the GPU, so pan/zoom never
      // invalidates the geometry. Genuine changes (selection/flip/rotation)
      // set netLinesDirty at their own sites; the idle-settle path re-derives
      // the zoom-dependent draw params. Firing a full O(K^2 log K) recompute on
      // every 'moved' frame produced byte-identical segments — pure waste.
      this.viewportMovingUntil = performance.now() + 100;
      this.scheduleFollowDebounce();
      // Keep multi-select / worklist outline thickness ~constant in screen
      // pixels across zoom changes — unforced: skips entirely unless the
      // stroke width bucket or highlight state changed (A4).
      this.redrawMultiHighlight(false);
      this.overlayDirty = true;   // pan/zoom moved the label-layer transforms
    });
    this.app.stage.addChild(this.viewport);

    // Overlay objects live inside scene.root (sortableChildren=true).
    // zIndex values define the render order — higher = rendered later = on top.
    //   0        board content (outline, layers, pins, labels) — default zIndex
    //   10       netDimGfx          — dim/fade non-selected nets
    //   15       crossSideGhostGfx  — ghost outlines for hidden-side net components
    //   30       selectionGfx       — highlight fills/strokes/glow (rendered via
    //                                  selectionLabelLayer so it lands above netLinesGfx
    //                                  but below pin/net labels at z=35)
    //   35       netLabelLayer      — net/pin labels (rendered via selectionLabelLayer)
    //   100-103  elevated labels    — part/pin name badges, always topmost
    //
    // selectionGfx (and netLabelLayer + elevated badges) are attached to
    // selectionLabelLayer in activateScene/setupButterfly. Render order inside
    // that layer is by zIndex; the values above are the canonical map. Pin labels
    // sit ABOVE highlights so pin numbers and net names stay readable; the glow
    // ring stroke painted in renderSelection at the pad perimeter is what carries
    // the "popping out" cue past the label.
    //
    // eventMode='none' on every decoration layer so pointer events fall through
    // to the underlying parts/pins. Without this, the netDimGfx full-screen
    // darkening drawn in chain-adjacent / spotlight modes captures clicks
    // before they can reach pin sprites — small pins become unselectable while
    // the dim is active. Same risk applies to net-lines, ghosts, selection
    // highlights, and label layers (any Graphics with painted content under
    // the cursor counts as a hit otherwise).
    this.selectionGfx = new Graphics();
    this.selectionGfx.zIndex = 30;
    this.selectionGfx.eventMode = 'none';
    this.primarySelGfx = new Graphics();
    this.primarySelGfx.eventMode = 'none';
    this.selectionGfx.addChild(this.primarySelGfx);
    this.netDimGfx = new Graphics();
    this.netDimGfx.zIndex = 10;
    this.netDimGfx.eventMode = 'none';
    this.netLabelLayer = new Container();
    this.netLabelLayer.zIndex = 35;
    this.netLabelLayer.eventMode = 'none';
    this.butterflySelectionGfx = new Graphics();
    this.butterflySelectionGfx.eventMode = 'none';
    this.butterflyPrimarySelGfx = new Graphics();
    this.butterflyPrimarySelGfx.eventMode = 'none';
    this.butterflySelectionGfx.addChild(this.butterflyPrimarySelGfx);
    this.butterflyDimGfx = new Graphics();
    this.butterflyDimGfx.eventMode = 'none';
    this.netLinesGfx = new Graphics();
    this.netLinesPulseGfx = null;  // orphaned by the reinit; rebuilt on next bake
    this.netLineBakeSig = '';
    this.netLinesGfx.eventMode = 'none';
    this.crossSideGhostGfx = new Graphics();
    this.crossSideGhostGfx.zIndex = 15; // above dim (10), below selection (30) and labels (35)
    this.crossSideGhostGfx.eventMode = 'none';
    this.crossSideGhostOutlineGfx = new Graphics();
    this.crossSideGhostOutlineGfx.zIndex = 15;
    this.crossSideGhostOutlineGfx.eventMode = 'none';
    this.crossSideGhostBakeSig = '';
    this.discoHaloGfx = new Graphics();
    this.discoHaloGfx.zIndex = 31; // just above selectionGfx (30), below netLabelLayer (35)
    this.discoHaloGfx.eventMode = 'none';
    this.selectionLabelLayer = new RenderLayer({ sortableChildren: true });

    // Elevated labels for selected part/pin — persistent objects reused across
    // scene switches. Visibility is toggled in updateElevatedLabels() each frame.
    // High zIndex ensures they render above all board content (pins, borders,
    // selection highlight) regardless of child insertion order.
    const labelStyle = { fontSize: 12, fill: BOARD_COLORS.labelPin, fontFamily: 'monospace' };
    this.elevatedPartBg = new Graphics();
    this.elevatedPartBg.zIndex = 100;
    this.elevatedPartBg.eventMode = 'none';
    this.elevatedPartLabel = new BitmapText({ text: '', style: labelStyle });
    this.elevatedPartLabel.anchor.set(0.5, 0.5);
    this.elevatedPartLabel.zIndex = 101;
    this.elevatedPartLabel.visible = false;
    this.elevatedPartLabel.eventMode = 'none';
    this.elevatedPartBg.visible = false;
    this.elevatedPinBg = new Graphics();
    this.elevatedPinBg.zIndex = 102;
    this.elevatedPinBg.eventMode = 'none';
    this.elevatedPinLabel = new BitmapText({ text: '', style: labelStyle });
    this.elevatedPinLabel.anchor.set(0.5, 0.5);
    this.elevatedPinLabel.zIndex = 103;
    this.elevatedPinLabel.visible = false;
    this.elevatedPinLabel.eventMode = 'none';
    this.elevatedPinBg.visible = false;
    // multiHighlightGfx is created here but parented to scene.root in
    // activateScene so board rotation/flip transforms apply.
    this.multiHighlightGfx = new Graphics();
    this.multiHighlightGfx.zIndex = 28;
    this.multiHighlightGfx.eventMode = 'none';
    this.viewport.addChild(this.netLinesGfx);
    this.viewport.addChild(this.selectionLabelLayer);

    // Capture shift state at pointerdown — pixi-viewport's "clicked" event
    // fires on pointerup but the underlying event reaches handlers via
    // multiple stop-propagation paths; reading the down-time modifier from
    // a capture-phase listener is the most reliable signal.
    this.boundShiftCapture = (e: PointerEvent) => {
      if (e.button !== 0) return;
      if (e.pointerType === 'touch') {
        // `isPrimary` marks the first finger of a multi-touch sequence, so it
        // is also the point at which any id left behind by a cancel the
        // renderer never saw can be dropped. Without this self-heal one lost
        // pointerup would make every later tap look like a second finger.
        if (e.isPrimary) this.activeTouchIds.clear();
        this.activeTouchIds.set(e.pointerId, { x: e.clientX, y: e.clientY });
        if (e.isPrimary) this.touchDownPos.clear();
        this.touchDownPos.set(e.pointerId, { x: e.clientX, y: e.clientY });
        if (e.isPrimary) { this.holdDownAt = performance.now(); this.holdTap = null; }
      }
      if (this.activeTouchIds.size > 1) {
        if (this.activeTouchIds.size === 2) {
          const now = performance.now();
          this.twoFingerDownAt = now;
          this.twoFingerMaxTravel = 0;
          // A first finger already resting on the board: the second may be a
          // tap that asks for the menu under the first.
          const holdId = [...this.activeTouchIds.keys()].find(id => id !== e.pointerId);
          const holdPos = holdId != null ? this.touchDownPos.get(holdId) : undefined;
          this.holdTap = (holdId != null && holdPos && now - this.holdDownAt >= BoardRenderer.HOLD_TAP_MIN_HOLD_MS)
            ? { secondId: e.pointerId, holdId, at: now, x: holdPos.x, y: holdPos.y, cam: this.camSnapshot() }
            : null;
        } else {
          this.holdTap = null;   // a third finger: not a tap any more
        }
        // Second finger of a pinch. The gesture is no longer a tap, and its
        // travel must keep being measured from where the FIRST finger landed
        // — re-anchoring here would reset the drag test mid-pinch and hand
        // handleClick a gesture that looks stationary.
        this.gestureWasMultiTouch = true;
        this.clearHoverState();
        this.seedPinch();
        // One line per pinch, not per move. This is the only record of what a
        // tablet gesture actually was — Chromium headless does not reproduce
        // iPadOS's pointer-cancel behaviour, so the Debug panel is where that
        // gets read back off the real device.
        log.ui.log(`touch: ${this.activeTouchIds.size} fingers — gesture is a pinch, not a tap`);
        return;
      }
      this.gestureWasMultiTouch = false;
      this.gestureWasCancelled = false;
      this.gestureIsTouch = e.pointerType === 'touch';
      // Read this here, in capture phase on the container: pixi's own
      // pointerdown on the canvas runs after us and both stops the glide and
      // decides, from the same `isActive()`, that no click may come of this
      // touch. On a desktop nobody clicks mid-glide; on a tablet, flick then
      // tap is the everyday way to select — measured with inertia on, a tap
      // right after a pan selected nothing, and one 1.5 s later hit the
      // wrong part because the board was still moving.
      const decel = this.viewport.plugins.get('decelerate') as { isActive(): boolean } | null;
      this.tapDuringGlide = this.gestureIsTouch && !!decel?.isActive();
      // pixi-viewport decides click-vs-drag on its own `threshold` (a plain
      // public field, default 5 px) and suppresses `clicked` past it — so the
      // renderer's matching tolerance in handleClick is never even consulted
      // unless this agrees. Measured before this line: a tap that wandered
      // 8 px selected nothing, 0 times out of 5, which is an ordinary tap on
      // a tablet. The two thresholds must be the same number or they disagree
      // about what a click is.
      this.viewport.threshold = this.gestureIsTouch
        ? BoardRenderer.TOUCH_CLICK_DRAG_TOLERANCE_PX
        : BoardRenderer.CLICK_DRAG_TOLERANCE_PX;
      this.lastPointerShift = e.shiftKey;
      this.lastPointerAddMod = IS_MAC ? e.metaKey : e.ctrlKey;
      this.lastPointerClient = { x: e.clientX, y: e.clientY };
      this.pointerTravelPx = 0;
      // A new gesture starts clean. The drag-zoom latch is set from a
      // pointerup handler that can run *after* pixi emits 'clicked', in
      // which case it would otherwise sit armed and swallow the next real
      // click instead of the drag it was meant for.
      this.dragZoomConsumedClick = false;
    };
    this.containerEl.addEventListener('pointerdown', this.boundShiftCapture, { capture: true });

    // Window + capture so it stays ahead of PixiJS (which listens on the
    // canvas) and of anything that took pointer capture — the latch has to be
    // set before `clicked` is emitted, and `clicked` comes out of the very
    // same release.
    this.boundPointerRelease = (e: PointerEvent) => {
      if (e.type === 'pointercancel') {
        this.gestureWasCancelled = true;
        log.ui.log(`touch: pointercancel id=${e.pointerId} type=${e.pointerType} ` +
          `— browser took the gesture over; any click it produces is stale`);
      }
      this.activeTouchIds.delete(e.pointerId);
      // Lifting one of three fingers leaves a pinch running on a different
      // pair; dropping to one ends it.
      if (this.pinch && (e.pointerId === this.pinch.a || e.pointerId === this.pinch.b)) {
        if (this.activeTouchIds.size < 2) this.commitLiveRotation();
        this.seedPinch();
      }
      if (this.activeTouchIds.size === 0 && this.gestureOwner !== 'none') {
        this.endGestureOwnership?.();
      }
      // Hold + tap: the second finger came up quickly, the first is still down.
      const ht = this.holdTap;
      if (ht) {
        this.holdTap = null;
        const quick = performance.now() - ht.at <= BoardRenderer.TWO_FINGER_TAP_MS;
        if (e.type === 'pointerup' && e.pointerId === ht.secondId && this.activeTouchIds.has(ht.holdId)
            && this.activeTouchIds.size === 1 && quick
            && this.twoFingerMaxTravel <= BoardRenderer.TOUCH_CLICK_DRAG_TOLERANCE_PX) {
          log.ui.log('touch: hold + second-finger tap — opening the context menu (stream=pointer)');
          this.twoFingerDownAt = 0;
          this.lastTwoFingerTapAt = 0;
          this.restoreCam(ht.cam);
          this.openTouchMenu(ht.x, ht.y);
        }
      }
      // A two-finger tap: both fingers down and up within TAP_MS, neither
      // travelling further than a tap may, no rotation engaged. Two of them
      // within DOUBLE_MS toggle the rotation lock.
      if (this.activeTouchIds.size === 0 && this.gestureWasMultiTouch && e.type === 'pointerup'
          && !this.gestureWasCancelled && this.twoFingerDownAt > 0) {
        const now = performance.now();
        const isTap = now - this.twoFingerDownAt <= BoardRenderer.TWO_FINGER_TAP_MS
          && this.twoFingerMaxTravel <= BoardRenderer.TOUCH_CLICK_DRAG_TOLERANCE_PX;
        this.twoFingerDownAt = 0;
        if (isTap) {
          if (now - this.lastTwoFingerTapAt <= BoardRenderer.TWO_FINGER_DOUBLE_MS) {
            this.lastTwoFingerTapAt = 0;
            if (renderSettingsStore.settings.twoFingerRotate) this.toggleRotationLock();
          } else {
            this.lastTwoFingerTapAt = now;
          }
        } else {
          this.lastTwoFingerTapAt = 0;
        }
      }
      // A tap that began mid-glide: pixi-viewport withheld `clicked`, so raise
      // it here — with every guard handleClick would have applied, because
      // handleClick applies them again anyway.
      if (this.tapDuringGlide && e.type === 'pointerup' && this.activeTouchIds.size === 0) {
        this.tapDuringGlide = false;
        const isTap = !this.gestureWasMultiTouch && !this.gestureWasCancelled
          && this.pointerTravelPx <= BoardRenderer.TOUCH_CLICK_DRAG_TOLERANCE_PX;
        if (isTap && this.board) {
          const rect = this.containerEl.getBoundingClientRect();
          const world = this.viewport.toWorld(e.clientX - rect.left, e.clientY - rect.top);
          log.ui.log('touch: tap during glide — raising the click pixi-viewport withheld');
          this.handleClick(world);
        }
      } else if (this.activeTouchIds.size === 0) {
        this.tapDuringGlide = false;
      }
    };
    window.addEventListener('pointerup', this.boundPointerRelease, { capture: true });
    window.addEventListener('pointercancel', this.boundPointerRelease, { capture: true });

    // Window + capture, installed once here: per-gesture move handlers (the
    // drag-to-zoom loop) are added on pointerdown and therefore always later
    // in the list, so this sees every move even when they stop propagation.
    this.boundPointerTravel = (e: PointerEvent) => {
      const down = this.lastPointerClient;
      if (!down) return;
      // Euclidean, not a Manhattan sum: the tolerance is a distance in CSS px
      // and pixi-viewport's own threshold is per-axis, so summing the axes
      // made a diagonal tap count as ~1.4x its real travel and rejected taps
      // both thresholds considered stationary.
      const d = Math.hypot(e.clientX - down.x, e.clientY - down.y);
      if (d > this.pointerTravelPx) this.pointerTravelPx = d;
    };
    window.addEventListener('pointermove', this.boundPointerTravel, { capture: true });

    this.viewport.on('clicked', (e: ViewportClickEvent) => {
      this.handleClick(e.world);
    });

    this.boundContextMenu = (e: MouseEvent) => {
      e.preventDefault();
      // 2R 24/10/2026 21h55 (Roger: «quando clicar com o botão direito no componente, linkar no PDF e vice-versa»):
      // botão direito (ou dois dedos) no componente = mostra no PDF; Shift + botão direito abre o menu de antes
      if (!e.shiftKey && this.board && r2w.__r2DireitoMenu !== true) {
        const R = this.containerEl.getBoundingClientRect();
        const W = this.viewport.toWorld(e.clientX - R.left, e.clientY - R.top);
        const H = this.hitTest(W);
        if (H && H.partIndex != null) {
          const P = this.board.parts[H.partIndex];
          if (P) {
            try { boardStore.selectPart(H.partIndex); } catch { /* */ }
            this.triggerFollowPdf(P, true);
            /* 2R 29/10/2026 (Roger: «ao clicar com o botão direito em cima de um pad, copiar o nome da linha ou alguma
               outra informação»): além de mostrar no PDF, abre ao lado do cursor um cartãozinho para copiar a net, o
               pino, a peça (desenhado pelo index.html: window.__r2CopiaChip) */
            try {
              const pin = H.pinIndex != null && H.pinIndex >= 0 ? P.pins[H.pinIndex] : undefined;
              const chip = (r2w as unknown as { __r2CopiaChip?: (o: Record<string, string>, x: number, y: number) => void }).__r2CopiaChip;
              if (chip) chip({ peca: P.name, pino: pin ? String(pin.number || pin.name || '') : '', net: pin ? String(pin.net || '') : '',
                               lado: String(P.side || '') }, e.clientX, e.clientY);
            } catch { /* */ }
            return;
          }
        }
      }
      this.handleRightClick(e);
    };
    this.containerEl.addEventListener('contextmenu', this.boundContextMenu);

    this.boundDblClick = (e: MouseEvent) => { this.handleDblClick(e); };
    this.containerEl.addEventListener('dblclick', this.boundDblClick);

    // Touch long-press → the same menu right-click opens. 500 ms held within
    // 10 px, primary touch only; a second finger (pinch) or any movement
    // cancels it. When it fires, the pointerup that follows would still
    // produce (a) pixi-viewport's 'clicked' → handleClick, changing the
    // selection under the menu, and (b) the browser's compatibility `click`,
    // which ContextMenu's document listener treats as "click outside → hide"
    // — so the menu would close in the same gesture that opened it. Both are
    // swallowed: the first through the existing dragZoomConsumedClick latch,
    // the second by a one-shot capture-phase click listener.
    const LONG_PRESS_MS = 500;
    const LONG_PRESS_SLOP_PX = BoardRenderer.TOUCH_CLICK_DRAG_TOLERANCE_PX;   // a hold may wander as far as a tap
    const cancelLongPress = () => {
      if (this.longPressTimer) { clearTimeout(this.longPressTimer); this.longPressTimer = null; }
      this.longPressStart = null;
    };
    this.boundLongPressDown = (e: PointerEvent) => {
      if (e.pointerType !== 'touch' || !e.isPrimary) { cancelLongPress(); return; }
      cancelLongPress();
      this.longPressStart = { id: e.pointerId, x: e.clientX, y: e.clientY };
      this.longPressTimer = setTimeout(() => {
        const start = this.longPressStart;
        this.longPressTimer = null;
        this.longPressStart = null;
        if (!start) return;
        this.openTouchMenu(start.x, start.y);
      }, LONG_PRESS_MS);
    };
    this.boundLongPressMove = (e: PointerEvent) => {
      const st = this.longPressStart;
      if (!st || e.pointerId !== st.id) return;
      if (Math.hypot(e.clientX - st.x, e.clientY - st.y) > LONG_PRESS_SLOP_PX) cancelLongPress();
    };
    this.boundLongPressEnd = () => cancelLongPress();
    this.containerEl.addEventListener('pointerdown', this.boundLongPressDown, { capture: true });
    this.containerEl.addEventListener('pointermove', this.boundLongPressMove, { capture: true });
    this.containerEl.addEventListener('pointerup', this.boundLongPressEnd, { capture: true });
    this.containerEl.addEventListener('pointercancel', this.boundLongPressEnd, { capture: true });

    // Hover tooltip — listens directly on the PixiJS canvas (the actual event target)
    this.tooltipEl = document.createElement('div');
    this.tooltipEl.className = 'pin-net-tooltip';
    this.tooltipNetSpan = document.createElement('span');
    this.tooltipNetSpan.className = 'pnt-net';
    this.tooltipDetailSpan = document.createElement('span');
    this.tooltipDetailSpan.className = 'pnt-detail';
    // Compare line — only ever filled while "Highlight on board" is on, so the
    // tooltip is unchanged for everyone not running a comparison.
    this.tooltipCompareSpan = document.createElement('span');
    this.tooltipCompareSpan.className = 'pnt-compare';
    this.tooltipCompareSpan.style.display = 'none';
    this.tooltipMetaSpan = document.createElement('span');
    this.tooltipMetaSpan.className = 'pnt-meta';
    this.tooltipMetaSpan.style.display = 'none';
    this.tooltipObdSpan = document.createElement('span');
    this.tooltipObdSpan.className = 'pnt-obd';
    this.tooltipObdSpan.style.display = 'none';
    this.tooltipObdSpan.style.fontFamily = 'monospace';
    this.tooltipObdSpan.style.fontSize = '11px';
    this.tooltipObdSpan.style.color = '#9f9';
    this.tooltipObdSpan.style.marginTop = '2px';
    // Worklist line: if the hovered part is pinned in the active worklist, show
    // its mark + note (coloured to match the mark, like the panel).
    // Worklist lines (part + net). Plain text, styled like the other tooltip
    // lines via the .pnt-worklist* CSS — no colour/weight/emoji.
    this.tooltipWorklistSpan = document.createElement('span');
    this.tooltipWorklistSpan.className = 'pnt-worklist';
    this.tooltipWorklistSpan.style.display = 'none';
    // Net-level line sits directly above the OBD line and is fully independent
    // of it — OBD is a separate pipeline that may be removed later.
    this.tooltipWorklistNetSpan = document.createElement('span');
    this.tooltipWorklistNetSpan.className = 'pnt-worklist-net';
    this.tooltipWorklistNetSpan.style.display = 'none';
    // 2R: a leitura OBD logo abaixo do nome (antes vinha por último)
    this.tooltipEl.append(this.tooltipNetSpan, this.tooltipDetailSpan, this.tooltipObdSpan, this.tooltipCompareSpan, this.tooltipWorklistSpan, this.tooltipMetaSpan, this.tooltipWorklistNetSpan);
    this.containerEl.appendChild(this.tooltipEl);
    this.tooltipCanvas = this.app.renderer.canvas as HTMLCanvasElement;
    // Coalesce to one handleHover() per animation frame — pointermove can fire
    // far faster than the display refreshes; only the latest event per frame
    // is processed (audit A1).
    this.boundHover = (e: PointerEvent) => {
      // A finger that is gesturing is not hovering. Every hover runs a
      // hitTest plus a traceHitTest, and both pointers of a pinch deliver
      // moves — measured on a 3369-part / 39319-trace Allegro board: 90 hover
      // hit-tests during one pinch, and the gesture ran at a median of 30 fps
      // instead of 60. There is no cursor to follow: the tooltip would be
      // under the fingers and the lit net changes every frame.
      //
      // A single *resting* finger is still a hover — tapping a pin to read its
      // net and diode value is the main reason to touch a pin at all — so the
      // test is the same one handleClick uses for a tap: one pointer, and
      // travel within the touch tolerance. `pointerTravelPx` is a running
      // maximum, so once a gesture has moved, hover stays off for the rest of
      // it rather than flickering back on when the finger pauses.
      if (e.pointerType === 'touch' && !this.touchIsResting()) {
        this.clearHoverState();
        return;
      }
      this.lastHoverEvent = e;
      if (this.hoverRafId !== null) return;           // already scheduled this frame
      this.hoverRafId = requestAnimationFrame(() => {
        this.hoverRafId = null;
        if (this.lastHoverEvent) this.handleHover(this.lastHoverEvent);
      });
    };
    this.boundHideTooltip = () => {
      // Cancel any hover scheduled by the rAF coalescer — otherwise a stale
      // in-canvas pointermove event fires after this leave and re-shows the
      // tooltip / re-lights the hover net with the cursor outside the canvas.
      if (this.hoverRafId !== null) { cancelAnimationFrame(this.hoverRafId); this.hoverRafId = null; }
      this.lastHoverEvent = null;
      this.hideTooltip();
      this.setHoverNet(null);
    };
    this.tooltipCanvas.addEventListener('pointermove', this.boundHover);
    this.tooltipCanvas.addEventListener('pointerleave', this.boundHideTooltip);

    // Wheel wake-up: if the ticker is stopped (panel not focused), restart it
    // so zoom/scroll gestures render immediately without needing a click first.
    // The ticker auto-pauses after 300ms of idle when the panel isn't active.
    this.boundWheelWake = () => {
      if (!this.app.ticker.started && !this.destroyed && !this.contextLost) {
        this.app.ticker.start();
        this.needsRender = true;
      }
      this.scheduleWheelIdlePause();
    };
    this.tooltipCanvas.addEventListener('wheel', this.boundWheelWake, { passive: true });

    // A mouse drag keeps the board: PixiJS listens for pointermove on the
    // canvas only, so the moment the pointer crossed onto the ribbon, the
    // minimap or out of the panel the pan froze until it came back —
    // "scrolling stops when the mouse goes beyond the rendering area"
    // (2026-10-22). Capturing the pointer on the canvas keeps every move on
    // it until release, as any other app's drag does. Touch has implicit
    // capture already; drag-to-zoom later moves the capture to the container
    // on purpose (see dragZoomActive).
    this.boundPointerCapture = (e: PointerEvent) => {
      if (e.pointerType === 'touch' || e.button === 2) return;
      try { (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId); } catch { /* pointer already gone */ }
    };
    this.tooltipCanvas.addEventListener('pointerdown', this.boundPointerCapture);

    // WebGL context loss recovery — browser may reclaim context when canvas is hidden
    this.installContextLossHandlers(this.app.renderer.canvas as HTMLCanvasElement);

    // Safari trackpad pinch — fires gesture* events instead of (or in addition
    // to) wheel+ctrlKey. Read event.scale to drive zoom; preventDefault stops
    // browser page-zoom AND board rotation in one shot. stopPropagation keeps
    // the global gesture-block in browser-zoom-block.ts as a fallback for
    // gestures over non-canvas UI (toolbar, sidebar) without it stomping ours.
    let gestureStartScale = 1;
    // Tracked, not frozen: on iPadOS `GestureEvent.clientX/Y` is the midpoint
    // between two moving fingers and travels with them, so an anchor fixed at
    // gesturestart is stale from the second event on. Same rule as the pointer
    // pinch — scale about the previous anchor, then translate by its travel.
    let gestureAnchor = { x: 0, y: 0 };

    /** Give the gesture back. A finger still on the glass resumes whichever
     *  path owns it: two go back to `installTouchPinch`, one back to drag. */
    const releaseGesture = () => {
      if (this.gestureReleaseTimer) { clearTimeout(this.gestureReleaseTimer); this.gestureReleaseTimer = null; }
      if (this.gestureOwner !== 'gesture') return;
      this.gestureOwner = 'none';
      this.commitLiveRotation();
      this.viewport.plugins.resume('drag');
      if (this.activeTouchIds.size >= 2) this.seedPinch();
    };
    this.endGestureOwnership = () => {
      // Whoever owned it. The drag plugin is paused when WebKit's stream
      // claims a gesture and was resumed only by releaseGesture, which bails
      // unless the owner is still 'gesture' — so when the second finger's
      // pointerdown arrived after the claim and seedPinch took the owner over,
      // the plugin stayed paused for good. From then on one finger could not
      // pan at all; two still could, because installTouchPinch pans by itself.
      // That was the "after a few zooms, pan only works with two fingers"
      // report. Resuming here, unconditionally, on the last finger leaving, is
      // the invariant: no fingers ⇒ drag is live.
      if (this.gestureReleaseTimer) { clearTimeout(this.gestureReleaseTimer); this.gestureReleaseTimer = null; }
      this.gestureOwner = 'none';
      this.viewport.plugins.resume('drag');
    };
    /** WebKit fires no gesturecancel, so a claim that stops arriving lapses. */
    const armGestureRelease = () => {
      if (this.gestureReleaseTimer) clearTimeout(this.gestureReleaseTimer);
      this.gestureReleaseTimer = setTimeout(releaseGesture, 400);
    };
    this.boundGestureEnd = (ev: Event) => {
      // Hold + tap through WebKit's stream: the engine may claim the gesture
      // before the second finger's pointerdown is dispatched, so the pointer
      // path above never sees a second finger. A gesture that began over a
      // resting finger and ends quickly, barely scaled or turned, is the tap.
      const gh = this.gestureHoldTap;
      this.gestureHoldTap = null;
      const g = ev as GestureEvent;
      if (gh && performance.now() - gh.at <= BoardRenderer.TWO_FINGER_TAP_MS
          && Math.abs((g.scale ?? 1) - 1) < 0.08 && Math.abs(g.rotation ?? 0) < 8
          && this.activeTouchIds.size <= 1) {
        releaseGesture();
        log.ui.log('touch: hold + second-finger tap — opening the context menu (stream=gesture)');
        this.restoreCam(gh.cam);
        this.openTouchMenu(gh.x, gh.y);
        return;
      }
      releaseGesture();
    };

    this.boundGestureStart = (ev: Event) => {
      const e = ev as GestureEvent;
      // iPadOS fires the WebKit gesture* events for a two-finger TOUCH pinch
      // as well as for a trackpad one, so both streams describe one gesture
      // and exactly one may own it. A complete pointer pair is the better
      // stream — it knows both finger positions — so it wins; but with only
      // one finger registered (the engine can claim the gesture before the
      // second `pointerdown` is ever dispatched) this path takes over, and
      // then pixi-viewport's drag plugin must not pan along that one finger
      // while this zooms. That half was missing: the stand-down ran in one
      // direction only.
      if (this.activeTouchIds.size >= 2) {
        log.ui.log(`touch: ignoring ${ev.type} — ${this.activeTouchIds.size} fingers down, ` +
          `the pointer pinch owns this gesture`);
        return;
      }
      ev.preventDefault();
      ev.stopPropagation();
      {
        const only = [...this.activeTouchIds.keys()][0];
        const pos = only != null ? this.touchDownPos.get(only) : undefined;
        this.gestureHoldTap = (pos && this.activeTouchIds.size === 1
          && performance.now() - this.holdDownAt >= BoardRenderer.HOLD_TAP_MIN_HOLD_MS)
          ? { at: performance.now(), x: pos.x, y: pos.y, cam: this.camSnapshot() }
          : null;
      }
      this.gestureOwner = 'gesture';
      this.pinch = null;
      this.commitLiveRotation();   // a pointer-pair rotation this claim interrupts
      this.viewport.plugins.pause('drag');
      gestureStartScale = this.viewport.scale.x;
      const rect = this.containerEl.getBoundingClientRect();
      gestureAnchor = { x: e.clientX - rect.left, y: e.clientY - rect.top };
      armGestureRelease();
    };
    this.boundGestureChange = (ev: Event) => {
      const e = ev as GestureEvent;
      if (this.gestureOwner !== 'gesture') return;
      ev.preventDefault();
      ev.stopPropagation();
      armGestureRelease();
      const rect = this.containerEl.getBoundingClientRect();
      const anchor = { x: e.clientX - rect.left, y: e.clientY - rect.top };
      this.setScaleAtScreen(gestureAnchor.x, gestureAnchor.y,
        Math.max(0.001, Math.min(10, gestureStartScale * e.scale)));
      this.viewport.x += anchor.x - gestureAnchor.x;
      this.viewport.y += anchor.y - gestureAnchor.y;
      gestureAnchor = anchor;
      // GestureEvent.rotation is cumulative degrees since gesturestart,
      // CLOCKWISE positive: Apple's own sample (Safari Web Content Guide,
      // "Handling Events") applies `rotate(event.rotation + "deg")` and the
      // element follows the fingers, and CSS rotate() is CW-positive. The
      // first cut negated it on the strength of a doc sentence, and since
      // which stream owns a pinch on iPadOS depends on whether the engine
      // claims it before the second pointerdown arrives, the board turned
      // the wrong way on exactly the gestures that came with movement
      // (2026-09-28). The pointer path's screen angle is CW-positive too,
      // so the two streams now agree; the per-gesture Debug line records
      // raw vs applied in case a device disagrees.
      if (typeof e.rotation === 'number' && Number.isFinite(e.rotation)) {
        this.rotateLive(e.rotation * Math.PI / 180, anchor.x, anchor.y, 'gesture', e.rotation);
      }
      this.viewport.emit('moved', { viewport: this.viewport, type: 'pinch' });
      this.needsRender = true;
      // No netLinesDirty: a pan or zoom never moves the world-space segments (a live turn carries them rigidly, rotateLive), and a dirty flag holds off the in-zoom re-stroke (onZoomFrame).
    };
    this.containerEl.addEventListener('gesturestart', this.boundGestureStart, { passive: false });
    this.containerEl.addEventListener('gesturechange', this.boundGestureChange, { passive: false });
    this.containerEl.addEventListener('gestureend', this.boundGestureEnd, { passive: false });

    this.unsubscribeBoard = boardStore.subscribe(() => this.onBoardUpdate());
    this.unsubscribeSettings = renderSettingsStore.subscribe(() => this.onSettingsUpdate());
    // Toggling Resize Mode changes whether the label overlay records hit-test
    // boxes; force one overlay redraw so boxes are ready on the first click.
    this.unsubscribeResizeMode = resizeModeStore.subscribe(() => {
      this.overlayDirty = true;
      this.overlayContentDirty = true;
      if (this.app && !this.contextLost && !this.reinitializing) this.app.render();
    });
    this.unsubscribeTheme = themeStore.subscribe(() => this.onThemeUpdate());
    this.unsubscribeCamOverlay = subscribeCameraOverlay(() => this.onCamOverlayUpdate());
    this.pinsOnTop = isPinsOnTop();
    this.applyBackgroundAlpha();
    this.unsubscribeObd = obdStore.subscribe(() => this.onObdUpdate());
    this.unsubscribeSelectionSet = selectionSetStore.subscribe(() => {
      this.redrawMultiHighlight();
      this.needsRender = true;
    });
    this.unsubscribePartCompare = partCompareStore.subscribe(() => {
      this.redrawMultiHighlight();
      this.needsRender = true;
    });
    this.unsubscribeWorklist = worklistStore.subscribe(() => {
      this.redrawMultiHighlight();
      // When "highlight connections" is on, the shared-net glow is now derived
      // from the active worklist (not the selection set), so a worklist change
      // must re-run the net highlight. Guard on active tab.
      if (boardStore.connectionHighlight && (this.tabId === null || boardStore.activeTabId === this.tabId)) {
        this.renderSelection();
      }
      this.needsRender = true;
    });
    this.unsubscribeViewCommands = viewCommands.subscribe((cmd, payload) => {
      if (this.tabId !== boardStore.activeTabId) return;
      if (cmd === 'pan') {
        this.panView(payload as PanDirection);
      } else if (cmd === 'zoom') {
        this.zoomKeyboard(payload as ZoomDirection);
      } else if (cmd === 'fit') {
        this.fitToBoard();
        this.noteFitViewpoint();
      }
    });

    this.resizeObserver = new ResizeObserver(() => {
      const w = this.containerEl.clientWidth;
      const h = this.containerEl.clientHeight;
      // Skip 0-size resizes (panel hidden by dockview tab switch)
      if (w === 0 || h === 0) return;
      // Skip while the renderer is torn down or rebuilding. Returning to a
      // deep-paused (or context-lost) tab resizes the container, which fires
      // this observer DURING the async reinitApp(): there `this.app` is a fresh
      // Application whose `.renderer` isn't initialised yet (pre await app.init)
      // and `this.viewport` is momentarily stale — resizing then throws
      // "Cannot read properties of undefined (reading 'resize')" and leaves the
      // rebuilt board blank. reinitApp() sizes the new viewport/renderer itself.
      // (reinitApp clears contextLost early but holds reinitializing across the
      // await, so both flags plus the renderer/viewport null-checks are needed.)
      if (this.destroyed || this.contextLost || this.reinitializing || !this.app?.renderer || !this.viewport) return;
      this.viewport.resize(w, h);
      this.app.renderer.resize(w, h);
      this.needsRender = true;
      // Resize the label overlay's backing store to match and force a redraw.
      this.textFastMode?.resize();
      this.overlayDirty = true;
      this.overlayContentDirty = true;   // resize() wipes the canvas backing store
      // If ticker is stopped (panel inactive), do a one-shot render so the
      // resized canvas isn't left black until the user clicks.
      if (!this.app.ticker.started && !this.contextLost) {
        try { this.app.render(); } catch { /* ignore if context lost */ }
        this.needsRender = false;
      }

      // When a fit-to-board is pending (e.g. initial load), re-fit after each
      // resize. Debounce so we only fit once the layout has stabilised (e.g.
      // after a PDF panel finishes opening and the board panel stops resizing).
      if (this._pendingFit) {
        if (this._pendingFitTimer) clearTimeout(this._pendingFitTimer);
        this._pendingFitTimer = setTimeout(() => {
          this._pendingFitTimer = null;
          if (this._pendingFit && !this.destroyed) {
            this._pendingFit = false;
            this.fitToBoard();
          }
        }, 150);
      }
    });
    this.resizeObserver.observe(this.containerEl);

    // HUD overlay (zoom + FPS)
    this.hudEl = document.createElement('div');
    this.hudEl.className = 'board-hud';
    this.hudEl.style.zIndex = '3';   // above the Text-fast-mode overlay canvas (z 2)
    this.containerEl.style.position = 'relative';
    this.containerEl.appendChild(this.hudEl);

    // Selection overlay (big centered text showing component/net name)
    this.selectionOverlayEl = document.createElement('div');
    this.selectionOverlayEl.className = 'board-selection-overlay';
    this.containerEl.appendChild(this.selectionOverlayEl);

    // Perf overlay (per-phase CPU timings) + toggle button
    this.perfOverlayEl = document.createElement('div');
    this.perfOverlayEl.style.zIndex = '3';   // above the Text-fast-mode overlay canvas (z 2)
    this.perfOverlayEl.className = 'board-perf-overlay';
    this.perfOverlayEl.style.display = 'none';
    this.containerEl.appendChild(this.perfOverlayEl);

    this.perfToggleBtn = document.createElement('button');
    this.perfToggleBtn.className = 'board-perf-toggle';
    this.perfToggleBtn.textContent = 'i';
    this.perfToggleBtn.title = 'Toggle performance overlay';
    this.perfToggleBtnHandler = () => {
      // Write to the shared setting — settings subscriber syncs perfVisible on
      // every BoardRenderer so the canvas "i" button and the
      // Performance & Debug → Show Perf Overlay checkbox stay in lockstep.
      const cur = renderSettingsStore.globalSnapshot();
      renderSettingsStore.applyGlobal({ ...cur, showPerfOverlay: !cur.showPerfOverlay });
    };
    this.perfToggleBtn.addEventListener('click', this.perfToggleBtnHandler);
    this.containerEl.appendChild(this.perfToggleBtn);

    // Combined ticker: LoD updates + net line animation + HUD + on-demand render
    this.hudThrottle = 0;
    this.app.ticker.add(this.onTick);
    this.app.ticker.start();

    // Pick up any board data that loaded during async init
    this.onBoardUpdate();
    const tabLabel = this.tabId !== null ? ` (tab ${this.tabId})` : '';
    log.render.log(`Initialized${tabLabel}: ${this.containerEl.clientWidth}×${this.containerEl.clientHeight}`);
    } catch (err) {
      log.render.error('init failed:', err);
      throw err;
    }
  }

  /** Update the HUD overlay with rendering stats */
  private updateHud(tickerFps: number) {
    if (!this.hudEl) return;

    const zoom = Math.round(Math.abs(this.viewport.scale.x) * 100);
    const fps = Math.round(tickerFps);

    let sceneText = '';
    const scene = this.activeScene;
    if (scene) {
      // Text fast mode: the BitmapText caches are empty, so source the count
      // from the overlay's last draw instead — same fallback flushPerfOverlay
      // uses for its label line.
      const overlayActive = this.textFastMode && !!scene.labelModel;
      const labelCount = overlayActive
        ? this.textFastMode!.lastCounts.total
        : scene.topLabels.length + scene.bottomLabels.length
          + scene.topPinLabels.length + scene.bottomPinLabels.length;
      sceneText = ` · ${labelCount} labels`;
    }

    // ("gpu idle" used to trail this; it read needsRender, which the dirty-flag
    // loop clears every frame, so it never said anything a user could use.)
    this.hudEl.textContent = `${zoom}% · ${fps} fps${sceneText}`;
  }

  /** Flush perf accumulators and update the perf overlay DOM */
  private flushPerfOverlay() {
    if (!this.perfOverlayEl || !this.perfVisible) return;

    const n = Math.max(this.perfSamples, 1);
    this.perfDisplay.lod = this.perfAccum.lod / n;
    this.perfDisplay.selection = this.perfAccum.selection / n;
    this.perfDisplay.netLines = this.perfAccum.netLines / n;
    this.perfDisplay.gpuRender = this.perfAccum.gpuRender / n;
    this.perfDisplay.frame = this.perfAccum.frame / n;

    // Reset accumulators
    this.perfAccum = { lod: 0, selection: 0, netLines: 0, gpuRender: 0, frame: 0 };
    this.perfSamples = 0;

    // Label sub-counts from cache — maintained by applyLabelVisibility(), zero per-label work here
    const { partVis, partTotal, pinVis, pinTotal } = this.labelCounts;

    // Text fast mode: the BitmapText caches are empty, so source the counts from
    // the overlay's last draw (visible/total across both sides) instead.
    const overlayActive = this.textFastMode && !!this.activeScene?.labelModel;
    const labelLine = overlayActive
      ? `\noverlay labels: ${this.textFastMode!.lastCounts.visible}/${this.textFastMode!.lastCounts.total}`
      : `\npart labels: ${partVis}/${partTotal}` + ` | pin labels: ${pinVis}/${pinTotal}`;

    const f = (ms: number) => ms < 0.01 ? '0' : ms.toFixed(2);
    const d = this.perfDisplay;
    // What limits the frame rate while the board is moving.
    const dr = this.perfDrawn;
    let boundLine = '';
    if (dr.intervalN >= 5) {
      const js = dr.js / dr.n, iv = dr.interval / dr.intervalN;
      const verdict = iv < 20 ? 'keeping up'
        : js > iv * 0.6 ? 'CPU-bound (JS)'
        : 'GPU/compositor-bound';
      boundLine = `\nmoving: ${Math.round(1000 / iv)} fps · js ${js.toFixed(1)} of ${iv.toFixed(1)} ms → ${verdict}`;
    }
    this.perfDrawn = { n: 0, js: 0, interval: 0, intervalN: 0, lastDrewAt: dr.lastDrewAt };
    const rr = this.app.renderer as unknown as { name?: string; resolution: number };
    const s = renderSettingsStore.settings;
    const setupLine = `\n${rr.name ?? '?'} · ${rr.resolution}× · ${s.boardAntialiasing ? 'MSAA' : 'no MSAA'} · ` +
      `cap ${this.app.ticker.maxFPS || 'none'} · corners ${s.traceCorners}`;
    this.perfOverlayEl.textContent =
      `frame: ${f(d.frame)}ms` +
      ` | lod: ${f(d.lod)}ms` +
      ` | sel: ${f(d.selection)}ms` +
      ` | net: ${f(d.netLines)}ms` +
      ` | render (CPU): ${f(d.gpuRender)}ms` +
      labelLine + boundLine + setupLine;
    this.perfOverlayEl.style.display = '';
  }

  /** Lazily create (or tear down) the Canvas2D label overlay to match the
   *  textFastMode setting. Called every tick from onTick so both the init and
   *  the context-loss reinit paths are covered without touching either — the
   *  overlay canvas is a containerEl sibling, independent of the Pixi app. */
  private ensureLabelOverlay(): LabelOverlay | null {
    if (!renderSettingsStore.settings.textFastMode) {
      if (this.textFastMode) { this.textFastMode.destroy(); this.textFastMode = null; }
      return null;
    }
    if (!this.textFastMode) {
      // containerEl is set position:relative in init() (the tooltip already
      // positions inside it), so the overlay's position:absolute anchors here.
      this.textFastMode = new LabelOverlay(this.containerEl);
      this.overlayDirty = true;
      this.overlayContentDirty = true;   // brand-new blank canvas
    }
    return this.textFastMode;
  }

  /** Mirror of ensureLabelOverlay for the HDR glow layer. Gated on BOTH the
   *  opt-in setting and live display capability, so undocking to an SDR monitor
   *  tears it down on the next frame without any explicit listener. */
  private ensureHdrOverlay(): HdrSelectionOutline | null {
    if (!renderSettingsStore.settings.hdrFocusGlow || !isHdrCapable()) {
      if (this.hdrOverlay) { this.hdrOverlay.destroy(); this.hdrOverlay = null; }
      return null;
    }
    if (!this.hdrOverlay) {
      this.hdrOverlay = new HdrSelectionOutline(this.containerEl);
      log.render.log('HDR selection outline mounted');
    }
    return this.hdrOverlay;
  }

  /** Light the current selection's outline in HDR — the SAME shape the SDR
   *  selection draws (see drawPartOutline), just above SDR white. Called from
   *  onTick AFTER app.render(), so worldTransform is current — same ordering
   *  requirement as syncLabelOverlay.
   *
   *  Steady, not animated: this only re-projects the outline to track pan/zoom,
   *  so it adds nothing to frames that were already going to run. Reads
   *  boardStore.selection directly rather than carrying a parallel "focus
   *  target" field — selection is already set and cleared at exactly the right
   *  moments, and a second copy would be one more thing to keep in sync. */
  /** World→screen magnification of the board right now. */
  private viewScale(): number {
    const k = Math.abs(this.viewport?.scale.x ?? 1);
    return k > 0 ? k : 1;
  }

  /** Outline geometry for THE selected part at the current zoom — see
   *  selectionOutlineWorld. Primary selection only (SDR child Graphics and
   *  the HDR mirror). Net-member boxes, highlight rings, search outlines,
   *  ghosts and the disco halo keep their fixed world-unit padding and
   *  stroke: they are context, not the thing being pointed at, and padding
   *  every member of a lit net out to 24 px turned a highlighted rail into a
   *  field of boxes (reported 2026-09-07). */
  private selOutline(part: Part): { pad: number; stroke: number } {
    const s = renderSettingsStore.settings;
    let minWorld: number;
    if (part.pins.length === 1) {
      minWorld = computePinRadius(s, part.pins[0].radius) * 2;
    } else {
      const rb = computePartRenderBounds(part, s);
      minWorld = Math.min(rb.pw, rb.ph);
    }
    const { padWorld, strokeWorld } = selectionOutlineWorld(s, this.viewScale(), minWorld);
    return { pad: padWorld, stroke: strokeWorld };
  }

  /** Zoom at which the primary outline was last painted; onTick redraws it
   *  on any frame whose zoom differs (see the needsRender block). */
  private lastSelectionPaintScale = 0;

  private syncHdrOverlay(overlay: HdrSelectionOutline, scene: BoardScene): void {
    const sel = boardStore.selection;
    if (sel.partIndex === null || !this.board) { overlay.hide(); return; }

    const part = this.board.parts[sel.partIndex];
    if (!part || !this.isPartVisible(part)) { overlay.hide(); return; }

    const s = renderSettingsStore.settings;
    const sp = this.selOutline(part).pad;

    // Mirror emitPartOutlineShape's shape choice exactly, so the HDR outline
    // sits on the SDR one instead of beside it: OBB polygon when the part has
    // one, AABB rect otherwise — and for a single-pin part the pin's own
    // shape, a circle as a 24-gon or a sampled capsule when the pad is an
    // oblong stroke, which is what renderSelection draws for them.
    let world: Array<readonly [number, number]>;
    if (part.pins.length === 1) {
      const pin = part.pins[0];
      const r = computePinRadius(s, pin.radius) + sp;
      const capsule = isOblongRoundPad(pin)
        ? capsulePolygon(
            pin.position.x, pin.position.y,
            pin.padWidth!, pin.padHeight!, pin.padAngleDeg ?? 0,
            capsuleGrowForRadius(pin, computePinRadius(s, pin.radius)) + sp,
          )
        : null;
      world = capsule ?? [];
      const SEGMENTS = 24;
      if (!capsule) for (let i = 0; i < SEGMENTS; i++) {
        const a = (i / SEGMENTS) * Math.PI * 2;
        world.push([pin.position.x + Math.cos(a) * r, pin.position.y + Math.sin(a) * r]);
      }
    } else {
      const poly = computePartRenderPoly(part, s);
      if (poly) {
        world = sp === 0 ? poly.map(p => [p[0], p[1]] as const) : expandPoly(poly, sp);
      } else {
        const rb = computePartRenderBounds(part, s);
        const x0 = rb.px - sp, y0 = rb.py - sp;
        const x1 = rb.px + rb.pw + sp, y1 = rb.py + rb.ph + sp;
        world = [[x0, y0], [x1, y0], [x1, y1], [x0, y1]];
      }
    }

    // World -> screen through the same label-layer matrix the text overlay
    // uses, so rotate / mirror / butterfly are handled for free.
    const wt = (boardStore.butterfly && part.side === 'bottom' && scene.butterflyRoot)
      ? scene.bottomLabelLayer.worldTransform
      : scene.topLabelLayer.worldTransform;
    const pts: ScreenPoint[] = world.map(([wx, wy]) => [
      wt.a * wx + wt.c * wy + wt.tx,
      wt.b * wx + wt.d * wy + wt.ty,
    ] as ScreenPoint);

    // Match the SDR primary-selection stroke: selectionWidth is screen px,
    // so the HDR line is simply that × 1.25, floored at 1 px.
    const thickness = Math.max(1, s.selectionWidth * 1.25);

    overlay.showPolygon(pts, thickness, rungForIntensity(s.hdrGlowIntensity));
  }

  /** Part indices left lit by the ambient-dim overlay this frame (the
   *  net-member punch-through set from renderSelection). The overlay lights the
   *  selected part unconditionally, so it need not be in this set. */
  private currentLitPartSet(): ReadonlySet<number> | null {
    return this.litPartIndices;
  }

  /** Redraw the Canvas2D label overlay from the active scene's LabelModel using
   *  the per-side label-layer world transforms (so rotate/mirror/butterfly work
   *  for free — bottomLabelLayer.worldTransform includes the butterfly chain).
   *  Called from onTick AFTER app.render() so worldTransforms are current. */
  /** Puts a label model's staggered labels in the layout for the current
   *  rotation. Cheap when already there (one map lookup); also covers a
   *  cached scene shown again after the rotation changed. */
  private syncLabelRotation(model: LabelModel): void {
    const want = rotLayoutKey(boardStore.rotation);
    if (this.labelRotKeys.get(model) === want) return;
    applyRotationLayout(model, want);
    this.labelRotKeys.set(model, want);
    this.overlayDirty = true;
    this.overlayContentDirty = true;
    this.needsRender = true;
  }

  private syncLabelOverlay(overlay: LabelOverlay, scene: BoardScene): void {
    const s = renderSettingsStore.settings;
    const model = scene.labelModel!;
    this.syncLabelRotation(model);
    const wtTop = scene.topLabelLayer.worldTransform;
    const wtBot = scene.bottomLabelLayer.worldTransform;
    const dm = boardStore.dimMode;
    // Ambient-dim + dim-mode is a global setting, but the overlay's dim pass
    // draws NON-lit labels at DIM_ALPHA — that is a SELECTION SPOTLIGHT (some
    // labels lit, the rest suppressed), not the ambient board dim. The Pixi side
    // dims the whole board uniformly and leaves the in-scene labels readable when
    // nothing is selected; if the overlay applied its 0.22 pass with no lit
    // target it would suppress EVERY label, so an unselected board renders dead
    // and dark (BUG-B). Gate the spotlight on there actually being something lit
    // to contrast against — a selected part or highlighted-net members. With no
    // selection every overlay label is drawn lit, matching the readable
    // no-selection look of the OFF (BitmapText) path.
    const litParts = this.currentLitPartSet();
    const hasSpotlightTarget =
      boardStore.selection.partIndex !== null || (litParts?.size ?? 0) > 0;
    const dimActive = hasSpotlightTarget && s.ambientDim && (dm === 'dim' ||
      (dm !== 'off' && (s.searchAutoDim ?? true) && boardStore.searchSelectionActive));
    overlay.draw(model, {
      topMatrix: { a: wtTop.a, b: wtTop.b, c: wtTop.c, d: wtTop.d, tx: wtTop.tx, ty: wtTop.ty },
      bottomMatrix: { a: wtBot.a, b: wtBot.b, c: wtBot.c, d: wtBot.d, tx: wtBot.tx, ty: wtBot.ty },
      scale: Math.abs(this.viewport.scale.x),
      width: this.containerEl.clientWidth, height: this.containerEl.clientHeight,
      showTop: boardStore.showTop, showBottom: boardStore.showBottom,
      selectedPartIndex: boardStore.selection.partIndex,
      selectedPinIndex: boardStore.selection.pinIndex,
      hoverPartIndex: this.hoverPartIndex,
      hoverPinIndex: this.hoverPinIndex,
      dimActive,
      litParts: dimActive ? litParts : null,
      inkedPins: this.inkedPins,
    }, {
      labelMinScreenPx: s.labelMinScreenPx,
      circleLabelMinScreenPx: s.circleLabelMinScreenPx,
      pinNumberMinScreenPx: s.pinNumberMinScreenPx ?? s.circleLabelMinScreenPx,
      twoPinLabelMinScreenPx: s.twoPinLabelMinScreenPx,
      labelZoomHide: s.labelZoomHide,
      selectedLabelMinPx: s.selectedLabelMinPx,
      selectedLabelLodRelax: s.selectedLabelLodRelax ?? 0.75,
      selectedLabelOtherScale: s.selectedLabelOtherScale ?? 0.8,
      fitToPitch: s.labelFitToPitch ?? true,
      fadeRange: s.labelFadeRange ?? 0.5,
    });
  }

  /** Called per frame when viewport scale is actively changing (user is zooming) */
  private onZoomFrame() {
    const s = renderSettingsStore.settings;
    // Hide all labels on first zoom frame — O(1) container toggle, no per-label iteration
    if (s.hideTextDuringZoom && !this.textHiddenForZoom) {
      this.textHiddenForZoom = true;
      const scene = this.activeScene;
      if (scene) {
        scene.topCircleLabelLayer.visible = false;
        scene.bottomCircleLabelLayer.visible = false;
        scene.topTwoPinNetLayer.visible = false;
        scene.bottomTwoPinNetLayer.visible = false;
      }
    }
    // Net (connection) lines stay on screen while the zoom runs. They used to
    // be cleared on the first zoom frame and redrawn only once the zoom had
    // been still for 32 ms — invisible for a wheel notch, but a two-finger
    // pinch changes the scale for as long as the fingers move, so on a
    // tablet the lines were gone for the whole unzoom (field report
    // 2026-10-07: "the connections overlay vanishes completely").
    //
    // The segments are world-space children of the viewport, so they stay in
    // place by themselves; only the stroke width (screen px ÷ scale) goes
    // stale. A lit net is a few dozen segments, so they are simply re-stroked
    // at the new width each zoom frame; a big one only when the scale has
    // moved 20 % since its last stroke. Never from here when the segments
    // themselves are dirty (that recompute is the expensive part and waits
    // for the settle). A live two-finger rotation needs nothing special: it
    // turns the net-line Graphics with the roots (rotateLive), so the cached
    // segments stay right and are re-stroked like any other zoom frame. (They
    // used to be cleared for the whole turn — the 2026-10-13 iPad "vanish".)
    if (this.netLineSegments.length > 0) {
      if (!this.netLinesDirty) {
        const k = Math.abs(this.viewport.scale.x);
        const ratio = this.netLinesStrokeScale > 0 ? k / this.netLinesStrokeScale : Infinity;
        if (this.netLineSegments.length <= 300 || ratio > 1.2 || ratio < 1 / 1.2) {
          this.renderNetLines();
          this.netLinesStrokeScale = k;
        }
      }
      // Stale until the settle redraw (also holds the pulse off meanwhile).
      this.netLinesHiddenForZoom = true;
      this.needsRender = true;
    }
    // Rescale elevated selection labels to maintain constant screen-pixel size
    this.updateElevatedLabels(boardStore.selection, s);
    // Reset settle timer on every zoom frame
    if (this.zoomSettleTimer) clearTimeout(this.zoomSettleTimer);
    // Restore labels + net lines after zoom settles (~2 frames idle)
    this.zoomSettleTimer = setTimeout(() => {
      this.zoomSettleTimer = null;
      if (this.textHiddenForZoom) {
        this.textHiddenForZoom = false;
        this.applyLabelVisibility();
      }
      if (this.netLinesHiddenForZoom) {
        this.netLinesHiddenForZoom = false;
        // Redraw from the cached world-space segments — renderNetLines
        // re-derives the zoom-dependent draw params (lineW/dashLen/fadeDist)
        // from the settled scale. No segment recompute: geometry is
        // zoom-invariant, so forcing netLinesDirty here just rebuilt identical
        // segments. Genuine changes set netLinesDirty at their own sites.
        this.renderNetLines();
        if (this.crossSideGhostParts.size > 0) this.renderCrossSideGhosts();
      }
      this.needsRender = true;
    }, 32);
  }

  /** Update level-of-detail based on current viewport zoom. Returns true if scale changed. */
  private updateLoD(): boolean {
    const scale = Math.abs(this.viewport.scale.x);
    if (scale === this.lastLodScale) return false;
    // Skip if scale change is negligible — 10% threshold avoids cascading LoD updates
    // from viewport deceleration drift (at high zoom, 5% was too loose).
    if (this.lastLodScale > 0 && Math.abs(scale - this.lastLodScale) / this.lastLodScale < 0.1) return false;
    this.lastLodScale = scale;

    const scene = this.activeScene;
    if (!scene) return true;
    const s = renderSettingsStore.settings;

    // Update label visibility via font-size groups (skip if text is hidden for zoom)
    if (!this.textHiddenForZoom) {
      this.applyLabelVisibility();
    }

    // Min border width: ensure borders are at least 1 screen pixel
    updateBorderWidths(scene.borderBatches, s.partBorderWidth, scale);

    return true;
  }


  /** Apply label visibility using font-size groups — O(groups) when nothing changes.
   *  Also keeps labelCounts cache in sync so flushPerfOverlay() never iterates labels. */
  private applyLabelVisibility() {
    const scene = this.activeScene;
    if (!scene) return;
    const s = renderSettingsStore.settings;
    const scale = Math.abs(this.viewport.scale.x);
    const minPx = s.labelMinScreenPx;
    const zoomOk = s.labelZoomHide <= 0 || scale >= s.labelZoomHide;

    let changed = false;
    for (const group of scene.fontSizeGroups) {
      const shouldBeVisible = zoomOk && group.minSize * scale >= minPx;
      if (shouldBeVisible !== group.visible) {
        group.visible = shouldBeVisible;
        for (const lbl of group.labels) lbl.visible = shouldBeVisible;
        changed = true;
      }
    }

    // Group A (circle/1-pin labels): progressive visibility by font-size bucket.
    if (!this.textHiddenForZoom) {
      const circleMinPx = s.circleLabelMinScreenPx;
      // Ensure containers are visible — individual items are toggled per group
      if (!scene.topCircleLabelLayer.visible)    { scene.topCircleLabelLayer.visible = true; changed = true; }
      if (!scene.bottomCircleLabelLayer.visible) { scene.bottomCircleLabelLayer.visible = true; changed = true; }
      for (const group of scene.circleFontSizeGroups) {
        const shouldBeVisible = zoomOk && group.minSize * scale >= circleMinPx;
        if (shouldBeVisible !== group.visible) {
          group.visible = shouldBeVisible;
          for (const item of group.items) item.visible = shouldBeVisible;
          changed = true;
        }
      }
    }

    // Group B (2-pin net labels): progressive visibility by font-size bucket.
    if (!this.textHiddenForZoom) {
      const twoPinMinPx = s.twoPinLabelMinScreenPx;
      if (!scene.topTwoPinNetLayer.visible)    { scene.topTwoPinNetLayer.visible = true; changed = true; }
      if (!scene.bottomTwoPinNetLayer.visible) { scene.bottomTwoPinNetLayer.visible = true; changed = true; }
      for (const group of scene.twoPinFontSizeGroups) {
        const shouldBeVisible = zoomOk && (twoPinMinPx <= 0 || group.minSize * scale >= twoPinMinPx);
        if (shouldBeVisible !== group.visible) {
          group.visible = shouldBeVisible;
          for (const item of group.items) item.visible = shouldBeVisible;
          changed = true;
        }
      }
    }

    if (changed && this.perfVisible) this.rebuildLabelCounts(scene);
  }

  /** Rebuild cached label counts from scratch — called once after scene switch or visibility change */
  private rebuildLabelCounts(scene: BoardScene) {
    let partVis = 0, partTotal = 0, pinVis = 0, pinTotal = 0;
    for (const lbl of scene.topLabels)    { partTotal++; if (lbl.visible) partVis++; }
    for (const lbl of scene.bottomLabels) { partTotal++; if (lbl.visible) partVis++; }
    for (const lbl of scene.topPinLabels)    { pinTotal++; if (lbl.visible) pinVis++; }
    for (const lbl of scene.bottomPinLabels) { pinTotal++; if (lbl.visible) pinVis++; }
    this.labelCounts = { partVis, partTotal, pinVis, pinTotal };
  }

  // --- Orientation ---

  /**
   * BVR files use Y-up math convention. Screen uses Y-down.
   * Always flip Y to convert, matching OpenBoardView's CoordToScreen (ty = -1 * ...).
   * User can toggle Mirror Y for manual override.
   */
  private needsYFlip(board: BoardData): boolean {
    if (board.flipY !== undefined) return board.flipY;
    return getFormat(board.format)?.flipY ?? false;
  }

  /** Apply per-layer trace, via, and component sub-layer visibility */
  private applyLayerVisibility(scene: BoardScene) {
    const { layerStates, showVias, showSilkscreen, showPads, showCopperDrops, showComponents, showPins, showOutlines, showLabels, showTop, showBottom } = boardStore;
    // Butterfly draws the two sides flat and apart; traces, vias and pours
    // belong to the board as a whole (inner layers to neither side), so they
    // are hidden for as long as the mode is on. The user's own toggles are
    // left alone and come back when Butterfly is turned off.
    const copper = !this.copperHidden;
    const showTraces = boardStore.showTraces && copper;
    const showSurfaces = boardStore.showSurfaces && copper;
    // Trace layer master toggle
    if (scene.traceLayer) scene.traceLayer.visible = showTraces;
    // Per-layer trace containers. A *selected* layer is revealed transiently —
    // shown even if its visibility toggle is off — without mutating its state
    // (deselecting reverts it). Pinning, by contrast, turns the layer on
    // permanently in the store, so the pinned layer is already visible here.
    const { selectedLayerIndex, fixatedLayerIndex } = boardStore;
    for (let i = 0; i < scene.traceLayerContainers.length; i++) {
      const c = scene.traceLayerContainers[i];
      if (!c) continue;
      const stateVisible = i < layerStates.length ? layerStates[i].visible : true;
      c.visible = showTraces && (stateVisible || i === selectedLayerIndex);
    }
    // Layer emphasis: bump one layer's traces to the top and dim the rest.
    // A pinned layer wins outright (it's kept visible); otherwise the selected
    // layer bumps (always revealed above). A pinned layer the user has since
    // re-hidden drops out of emphasis (avoids an all-dim / nothing-on-top state).
    if (scene.traceLayerContainers.length > 0) {
      const pinnedVisible = fixatedLayerIndex != null
        && fixatedLayerIndex < layerStates.length
        && layerStates[fixatedLayerIndex].visible;
      const emphasized: number | null =
          pinnedVisible ? fixatedLayerIndex
        : (fixatedLayerIndex == null && selectedLayerIndex != null) ? selectedLayerIndex
        : null;
      for (let i = 0; i < scene.traceLayerContainers.length; i++) {
        const c = scene.traceLayerContainers[i];
        if (!c) continue;
        c.zIndex = i === emphasized ? 10 : 0;
        c.alpha = emphasized === null || i === emphasized ? 1 : LAYER_DIM_ALPHA;
      }
    }
    // Surfaces — master toggle + same per-layer visibility/emphasis as traces
    // so each layer's copper-fill follows that layer's row in the layer panel.
    if (scene.surfacesLayer) scene.surfacesLayer.visible = showSurfaces;
    for (let i = 0; i < scene.surfacesLayerContainers.length; i++) {
      const c = scene.surfacesLayerContainers[i];
      if (!c) continue;
      const stateVisible = i < layerStates.length ? layerStates[i].visible : true;
      c.visible = showSurfaces && (stateVisible || i === selectedLayerIndex);
    }
    // Via overlay
    if (scene.viaLayer) scene.viaLayer.visible = showVias && copper;
    // Silkscreen — master toggle, plus follow top/bottom side visibility. The
    // master is applied to each side container as well, not only to the
    // shared layer: in Butterfly the bottom silk is reparented out of that
    // layer into butterflyRoot (setupButterfly), where the layer's own
    // visibility no longer reaches it — which is how the toggle stopped
    // hiding the bottom silk the moment Butterfly came on (2026-09-28).
    if (scene.silkscreenLayer)  scene.silkscreenLayer.visible  = showSilkscreen;
    if (scene.silkscreenTop)    scene.silkscreenTop.visible    = showSilkscreen && showTop;
    if (scene.silkscreenBottom) scene.silkscreenBottom.visible = showSilkscreen && showBottom;
    // Copper pads — parented inside the side layers so each container is
    // gated by both the master `showPads` toggle and its own side toggle.
    if (scene.padsTop)          scene.padsTop.visible          = showPads && showTop;
    if (scene.padsBottom)       scene.padsBottom.visible       = showPads && showBottom;
    // Standalone copper drops (GND stitching, power-rail tie pads, mounting
    // pads). Default OFF — independent toggle from real pin pads.
    if (scene.copperDropsTop)      scene.copperDropsTop.visible      = showCopperDrops && showTop;
    if (scene.copperDropsBottom)   scene.copperDropsBottom.visible   = showCopperDrops && showBottom;
    // Component sub-layer visibility (master: showComponents)
    scene.topFillLayer.visible       = showComponents;
    scene.bottomFillLayer.visible    = showComponents;
    scene.topPinLayer.visible        = showComponents && showPins;
    scene.bottomPinLayer.visible     = showComponents && showPins;
    scene.topOutlineLayer.visible    = showComponents && showOutlines;
    scene.bottomOutlineLayer.visible = showComponents && showOutlines;
    scene.topLabelLayer.visible      = showComponents && showLabels;
    scene.bottomLabelLayer.visible   = showComponents && showLabels;
    // 2R Tools — "Pinos por cima": tira o fundo da boardview (fica só pino/net/código/leitura)
    const bare = this.pinsOnTop;
    scene.outlineGfx.visible = !bare;
    if (bare) {
      scene.topFillLayer.visible = false;
      scene.bottomFillLayer.visible = false;
      if (scene.traceLayer) scene.traceLayer.visible = false;
      if (scene.surfacesLayer) scene.surfacesLayer.visible = false;
      if (scene.viaLayer) scene.viaLayer.visible = false;
      if (scene.silkscreenLayer) scene.silkscreenLayer.visible = false;
      if (scene.silkscreenTop) scene.silkscreenTop.visible = false;
      if (scene.silkscreenBottom) scene.silkscreenBottom.visible = false;
      if (scene.copperDropsTop) scene.copperDropsTop.visible = false;
      if (scene.copperDropsBottom) scene.copperDropsBottom.visible = false;
    }
  }

  // --- Flip management ---

  /** Apply orientation, view flips, user rotation and mirror to the scene root */
  private applyFlips(board: BoardData, scene: BoardScene) {
    // applyFlips — no logging (fires frequently from onBoardUpdate)
    const butterfly = boardStore.butterfly;
    const autoFlipY = this.needsYFlip(board);
    const rotation = boardStore.rotation * Math.PI / 180;
    const cx = (board.bounds.minX + board.bounds.maxX) / 2;
    const cy = (board.bounds.minY + board.bounds.maxY) / 2;

    // When the board is rotated 90° or 270°, the visual X and Y axes are swapped
    // relative to board coordinates. Mirror operations must work in visual/screen
    // space, so swap mirrorX↔mirrorY when the axes are transposed.
    const rot90 = Math.round(boardStore.rotation / 90) % 4;
    const axesSwapped = rot90 === 1 || rot90 === 3;
    const mirrorX = axesSwapped ? boardStore.mirrorY : boardStore.mirrorX;
    const mirrorY = axesSwapped ? boardStore.mirrorX : boardStore.mirrorY;

    if (butterfly) {
      // Butterfly mode: top above, bottom below — flipped as if hinging on the bottom edge
      this.setupButterfly(board, scene);

      const bw = board.bounds.maxX - board.bounds.minX;
      const bh = board.bounds.maxY - board.bounds.minY;

      // The spread is laid out at a right angle — the mirror across the seam
      // and the separation along a screen axis are only right there — and a
      // free angle (two-finger rotation) shows that layout turned rigidly by
      // the residual about the common centre, which is what the live gesture
      // showed. The base survives gesture commits: re-choosing the nearest
      // right angle at every commit swapped the separation axis and the
      // hinge at 45°, and the halves jumped ("butterfly positioning broken
      // on a rotated board", 2026-09-28). A right angle reached from a right
      // angle is a button press and re-lays out as always.
      const deg = boardStore.rotation;
      const isRight = (d: number) => Math.abs(d / 90 - Math.round(d / 90)) < 1e-6;
      if (this.butterflyBaseDeg === null || (isRight(deg) && isRight(this.butterflyLastDeg))) {
        this.butterflyBaseDeg = ((Math.round(deg / 90) * 90) % 360 + 360) % 360;
      }
      this.butterflyLastDeg = deg;
      const baseRot = this.butterflyBaseDeg * Math.PI / 180;
      let residual = rotation - baseRot;
      residual = Math.atan2(Math.sin(residual), Math.cos(residual));
      const resCos = Math.cos(residual), resSin = Math.sin(residual);
      // Everything that reads "are the axes swapped" follows the BASE here,
      // not the nearest right angle: at 72° from base 0 the nearest is 90,
      // and taking the swap from it flipped the bottom half's mirror onto
      // the other axis — same positions, wrong hinge.
      const baseSwapped = (this.butterflyBaseDeg / 90) % 2 === 1;
      const bMirrorX = baseSwapped ? boardStore.mirrorY : boardStore.mirrorX;
      const bMirrorY = baseSwapped ? boardStore.mirrorX : boardStore.mirrorY;
      // After rotation, compute visual extents to decide separation axis
      const sinR = Math.abs(Math.sin(baseRot));
      const cosR = Math.abs(Math.cos(baseRot));
      const visualW = bw * cosR + bh * sinR;
      const visualH = bw * sinR + bh * cosR;

      // Separate along the shorter visual axis (side-by-side when vertical);
      // equal dimensions: default to side-by-side
      const separateX = visualH >= visualW;
      const sepDim = separateX ? visualW : visualH;
      const gap = sepDim * 0.05;
      const halfSep = sepDim / 2 + gap / 2;

      const flipY = autoFlipY !== bMirrorY;
      const sx = bMirrorX ? -1 : 1;
      const topSy = flipY ? -1 : 1;

      // Butterfly bottom-half mirroring.
      //
      // X-fold boards (butterflyFoldAxis='x'): the parser already X-mirrored bottom
      // parts during fold processing — they're at their overlaid positions. No
      // additional mirror needed; both halves use the same scale.
      //
      // Y-fold boards (butterflyFoldAxis='y'): parser already Y-mirrored the bottom;
      // renderer Y-mirrors to undo it so the bottom shows at its unfolded position.
      //
      // Default (no native fold): the fold-open view needs exactly ONE screen-axis
      // mirror across the joint — vertical separation → screen-Y, horizontal →
      // screen-X. Under 90°/270° rotation, board X and Y map to the opposite
      // screen axes, so that single screen mirror is achieved by flipping the
      // OTHER board axis. Flipping both at once would 180°-rotate the bottom
      // half (the "left ends up on the right" symptom on auto-rotated tall boards).
      let botScaleX: number, botScaleY: number;
      if (board.butterflyFoldAxis === 'x') {
        botScaleX = sx;
        botScaleY = topSy;
      } else if (board.butterflyFoldAxis === 'y') {
        botScaleX = sx;
        botScaleY = -topSy;
      } else {
        const mirrorBoardX = separateX !== baseSwapped;
        botScaleX = mirrorBoardX ? -sx : sx;
        botScaleY = mirrorBoardX ? topSy : -topSy;
      }

      const dx = separateX ? halfSep : 0;
      const dy = separateX ? 0 : halfSep;

      // Top half: shifted left/up; bottom half: shifted right/down, mirrored
      // along the fold axis. The shifts are the base layout's, turned by the
      // residual; each root's own rotation is base + residual = rotation.
      const rdx = dx * resCos - dy * resSin;
      const rdy = dx * resSin + dy * resCos;
      scene.root.pivot.set(cx, cy);
      scene.root.position.set(cx - rdx, cy - rdy);
      scene.root.rotation = rotation;
      scene.root.scale.set(sx, topSy);

      const broot = scene.butterflyRoot!;
      broot.pivot.set(cx, cy);
      broot.position.set(cx + rdx, cy + rdy);
      broot.rotation = rotation;
      broot.scale.set(botScaleX, botScaleY);

      // Counter-flip labels + pin numbers for readability (handedness-aware)
      const topLabelRot = -rotation * sx * topSy;
      const botLabelRot = -rotation * botScaleX * botScaleY;
      const fp = this.lastFlipParams;
      if (!fp || !fp.butterfly ||
          fp.topRot !== topLabelRot || fp.topSx !== sx || fp.topSy !== topSy ||
          fp.botRot !== botLabelRot || fp.botSx !== botScaleX || fp.botSy !== botScaleY) {
        for (const arr of [scene.topLabels, scene.topPinLabels, scene.topDiodeLabels, scene.viaLabels]) {
          for (const label of arr) { label.rotation = topLabelRot; label.scale.set(sx, topSy); }
        }
        for (const arr of [scene.bottomLabels, scene.bottomPinLabels, scene.bottomDiodeLabels]) {
          for (const label of arr) { label.rotation = botLabelRot; label.scale.set(botScaleX, botScaleY); }
        }
        this.lastFlipParams = { butterfly: true, topRot: topLabelRot, topSx: sx, topSy, botRot: botLabelRot, botSx: botScaleX, botSy: botScaleY };
      }
    } else {
      // Normal mode
      this.teardownButterfly(scene);
      this.butterflyBaseDeg = null;

      // When viewing bottom-only, auto-mirror to simulate physically flipping
      // the board over. flipAxis controls the hinge: 'x' flips around horizontal
      // axis (top-to-bottom), 'y' flips around vertical axis (left-to-right).
      const viewingBottom = !boardStore.showTop && boardStore.showBottom;
      const flipAroundY = viewingBottom && boardStore.flipAxis === 'y';
      const flipAroundX = viewingBottom && boardStore.flipAxis === 'x';
      const flipX = mirrorX !== flipAroundY;
      const flipY = (autoFlipY !== mirrorY) !== flipAroundX;

      scene.root.pivot.set(cx, cy);
      scene.root.position.set(cx, cy);
      scene.root.rotation = rotation;
      scene.root.scale.set(flipX ? -1 : 1, flipY ? -1 : 1);

      // Counter-flip labels + pin numbers so text stays readable.
      // When an odd number of axes are flipped, coordinate handedness reverses and
      // the counter-rotation sign must flip too: label.rotation = -R * lsx * lsy.
      const lsx = flipX ? -1 : 1;
      const lsy = flipY ? -1 : 1;
      const labelRot = -rotation * lsx * lsy;
      const fp2 = this.lastFlipParams;
      if (!fp2 || fp2.butterfly ||
          fp2.topRot !== labelRot || fp2.topSx !== lsx || fp2.topSy !== lsy) {
        for (const arr of [scene.labels, scene.topPinLabels, scene.bottomPinLabels, scene.topDiodeLabels, scene.bottomDiodeLabels, scene.viaLabels]) {
          for (const label of arr) { label.rotation = labelRot; label.scale.set(lsx, lsy); }
        }
        this.lastFlipParams = { butterfly: false, topRot: labelRot, topSx: lsx, topSy: lsy, botRot: 0, botSx: 1, botSy: 1 };
      }
    }
  }

  /** Set up butterfly mode: move bottom layer into its own root */
  private setupButterfly(board: BoardData, scene: BoardScene) {
    if (scene.butterflyRoot) {
      // Already built — re-attach to viewport if detached (happens after tab switch)
      if (!scene.butterflyRoot.parent) {
        this.viewport.addChild(scene.butterflyRoot);
        this.viewport.removeChild(this.netLinesGfx);
        this.viewport.addChild(this.netLinesGfx);
        this.viewport.removeChild(this.selectionLabelLayer);
        this.viewport.addChild(this.selectionLabelLayer);
      }
      return;
    }
    log.render.log('setupButterfly');

    // Create butterfly root with a copy of the outline
    const broot = new Container();
    const boutline = new Graphics();
    drawOutline(boutline, board, renderSettingsStore.settings, this.activeBoardColorHex());

    broot.addChild(boutline);

    // Move bottomLayer from root into butterfly root
    scene.root.removeChild(scene.bottomLayer);
    broot.addChild(scene.bottomLayer);
    // The bottom silkscreen lives in the shared silkscreenLayer under root;
    // left there it would be drawn un-mirrored beneath the top half. It rides
    // with the bottom half and goes back in teardownButterfly.
    if (scene.silkscreenBottom) broot.addChildAt(scene.silkscreenBottom, 0);

    scene.butterflyRoot = broot;
    scene.butterflyOutline = boutline;

    // Mount the bottom-half dim BEFORE the selection layer so dim renders
    // under the selection highlight (mirrors the scene.root ordering: dim at
    // zIndex 10, selectionGfx at zIndex 30 — note the top-side selectionGfx
    // is rendered via selectionLabelLayer; butterflySelectionGfx renders here
    // in butterflyRoot's local order).
    broot.addChild(this.butterflyDimGfx);
    broot.addChild(this.butterflySelectionGfx);
    this.viewport.addChild(broot);

    // Keep net lines on top of butterfly content, then selection labels on top of net lines.
    this.viewport.removeChild(this.netLinesGfx);
    this.viewport.addChild(this.netLinesGfx);
    this.viewport.removeChild(this.selectionLabelLayer);
    this.viewport.addChild(this.selectionLabelLayer);
  }

  /** Tear down butterfly mode: move bottom layer back into root */
  private teardownButterfly(scene: BoardScene) {
    if (!scene.butterflyRoot) return;

    // Move bottom layer back to main root, then restore selectionGfx as last child.
    // addChild() on an existing child moves it to the end — selectionGfx must always
    // be the last child of scene.root so it renders above pins and borders.
    scene.butterflyRoot.removeChild(scene.bottomLayer);
    scene.root.addChild(scene.bottomLayer);
    if (scene.silkscreenBottom && scene.silkscreenLayer) {
      scene.butterflyRoot.removeChild(scene.silkscreenBottom);
      scene.silkscreenLayer.addChildAt(scene.silkscreenBottom, 0);
    }
    scene.root.addChild(this.netDimGfx);
    scene.root.addChild(this.crossSideGhostGfx);
    scene.root.addChild(this.crossSideGhostOutlineGfx);
    scene.root.addChild(this.netLabelLayer);
    scene.root.addChild(this.selectionGfx);
    scene.root.addChild(this.discoHaloGfx);
    // Elevated labels must always be last (addChild on existing child moves it to end)
    scene.root.addChild(this.elevatedPinBg!);
    scene.root.addChild(this.elevatedPinLabel!);
    scene.root.addChild(this.elevatedPartBg!);
    scene.root.addChild(this.elevatedPartLabel!);

    // Detach butterfly selection gfx + dim before destroying
    scene.butterflyRoot.removeChild(this.butterflySelectionGfx);
    this.butterflySelectionGfx.clear();
    scene.butterflyRoot.removeChild(this.butterflyDimGfx);
    this.butterflyDimGfx.clear();

    // Remove butterfly container from viewport and destroy (bottomLayer already detached)
    this.viewport.removeChild(scene.butterflyRoot);
    scene.butterflyRoot.destroy({ children: true });
    scene.butterflyRoot = null;
    scene.butterflyOutline = null;
  }

  /** Convert world coords (viewport space) to scene-local coords */
  private worldToScene(world: Point, root?: Container): Point {
    const r = root ?? this.activeScene?.root;
    if (!r) return world;

    const sx = r.scale.x;
    const sy = r.scale.y;
    const theta = r.rotation;
    const cx = r.pivot.x;
    const cy = r.pivot.y;

    // Inverse: un-translate (position - pivot offset), un-rotate, un-scale
    const dx = world.x - r.position.x;
    const dy = world.y - r.position.y;
    const cosT = Math.cos(theta);
    const sinT = Math.sin(theta);
    const rx = dx * cosT + dy * sinT;
    const ry = -dx * sinT + dy * cosT;
    return { x: cx + rx / sx, y: cy + ry / sy };
  }

  /** Convert scene-local coords to world coords (viewport space) */
  private sceneToWorld(point: Point, root?: Container): Point {
    const r = root ?? this.activeScene?.root;
    if (!r) return point;

    const sx = r.scale.x;
    const sy = r.scale.y;
    const theta = r.rotation;
    const cx = r.pivot.x;
    const cy = r.pivot.y;

    // Forward: scale, then rotate, then translate (position - pivot offset)
    const dx = (point.x - cx) * sx;
    const dy = (point.y - cy) * sy;
    const cosT = Math.cos(theta);
    const sinT = Math.sin(theta);
    return {
      x: r.position.x + dx * cosT - dy * sinT,
      y: r.position.y + dx * sinT + dy * cosT,
    };
  }

  // --- Scene cache management ---

  /**
   * Look up the metadata color hex for the active board file from the
   * databank store. Returns undefined when there's no active board, no file
   * record, or no resolver match for it.
   */
  private activeBoardColorHex(): string | undefined {
    const fileName = boardStore.fileName;
    if (!fileName) return undefined;
    const file = databankStore.fileByFilename(fileName);
    return file?.board_color_hex || undefined;
  }

  private buildScene(board: BoardData): BoardScene {
    const t0 = performance.now();
    try {
      const diodeBn = this.getMemoizedObdBoardNumber() ?? undefined;
      const graph = buildBoardScene(
        board, renderSettingsStore.settings, this.activeBoardColorHex(), boardStore.partOverrides,
        (pin) => primaryDiodeReading(pin, diodeBn),
        boardStore.rotation,
      );
      // Remember which rotation parity the labels were laid out for — a change
      // (0/180 ↔ 90/270) transposes the screen axes and needs a rebuild so the
      // pin-label stagger follows (see onBoardUpdate's rotated branch).
      this.sceneRot90Parity = rot90Parity(boardStore.rotation);
      if (graph.labelModel) this.labelRotKeys.set(graph.labelModel, rotLayoutKey(boardStore.rotation));
      const elapsed = (performance.now() - t0).toFixed(0);
      log.render.log(`Scene built in ${elapsed}ms: ${board.parts.length} parts, ${graph.topLabels.length + graph.bottomLabels.length} labels`);
      // Surface the scene-build cost on the load-progress overlay when one
      // is open. boardStore's load pipeline opens a "Building scene" phase
      // right before onTabCreated fires, which is what eventually calls into
      // here; pushing detail here gives the user the actual buildBoardScene
      // cost broken out from the rest of the phase (panel mount, GPU upload).
      void import('../store/load-progress-store').then(({ loadProgressStore }) => {
        loadProgressStore.pushLog(`buildBoardScene: ${elapsed}ms (${board.parts.length} parts, ${(graph.topLabels.length + graph.bottomLabels.length).toLocaleString()} labels, ${board.surfaces?.length ?? 0} surfaces)`);
      });

      // Debug vertex overlay (toggled in settings)
      this.clearDebugVertexLabels();
      if (renderSettingsStore.settings.showVertexNumbers) {
        const positions = drawOutlineDebug(graph.outlineGfx, board);
        // Group vertices at the same coordinate → one label per unique position
        const posMap = new Map<string, { p: {x:number;y:number}; indices: number[] }>();
        positions.forEach((p, i) => {
          if (isNaN(p.x)) return;
          const key = `${Math.round(p.x)},${Math.round(p.y)}`;
          const entry = posMap.get(key);
          if (entry) { entry.indices.push(i); }
          else { posMap.set(key, { p, indices: [i] }); }
        });
        this.debugVertexPositions = [];
        for (const { p, indices } of posMap.values()) {
          this.debugVertexPositions.push(p);
          const label = indices.join(',');
          const color = indices.length > 1 ? 0xff6600 : 0xffff00; // orange = duplicates
          const t = new Text({ text: label, style: { fontSize: 11, fill: color, stroke: { color: 0x000000, width: 2 } } });
          t.anchor.set(0, 0.5);
          this.app.stage.addChild(t);
          this.debugVertexLabels.push(t);
        }
      }

      return { ...graph, butterflyRoot: null, butterflyOutline: null };
    } catch (err) {
      log.render.error('buildBoardScene failed — evicting cache entry so re-open will re-parse:', err);
      // Evict the cache entry so the user can re-open the file to get a fresh parse.
      boardStore.evictCacheForBoard(board);
      throw err;
    }
  }

  private clearDebugVertexLabels(): void {
    for (const t of this.debugVertexLabels) t.destroy();
    this.debugVertexLabels = [];
    this.debugVertexPositions = [];
  }

  private updateDebugVertexLabels(): void {
    if (!this.debugVertexLabels.length || !this.activeScene) return;
    let li = 0;
    for (const wp of this.debugVertexPositions) {
      if (isNaN(wp.x)) continue;
      const g = this.activeScene.root.toGlobal({ x: wp.x, y: wp.y });
      this.debugVertexLabels[li].position.set(g.x + 6, g.y);
      li++;
    }
  }

  private getOrBuildScene(board: BoardData): BoardScene {
    const key = this.sceneCacheKey(board);
    let scene = this.sceneCache.get(key);
    if (!scene) {
      scene = this.buildScene(board);
      this.sceneCache.set(key, scene);
    }
    return scene;
  }

  private saveViewportState() {
    if (this.board) {
      this.viewportStates.set(this.board, {
        x: this.viewport.x,
        y: this.viewport.y,
        scaleX: this.viewport.scale.x,
        scaleY: this.viewport.scale.y,
      });
    }
  }

  private restoreViewportState(board: BoardData) {
    const state = this.viewportStates.get(board);
    this.programmaticMove = true;
    if (state) {
      this.viewport.scale.set(state.scaleX, state.scaleY);
      this.viewport.position.set(state.x, state.y);
    } else {
      this.fitToBoard(board);
      // Mark pending so ResizeObserver re-fits after layout settles (e.g.
      // a PDF panel opening shrinks this panel after initial fitToBoard).
      this._pendingFit = true;
    }
  }

  private activateScene(board: BoardData, skipSaveViewport = false) {
    const scene = this.getOrBuildScene(board);
    log.render.log(`activateScene tab=${this.tabId} ${board.format}/${board.parts.length}pts cached=${this.activeScene === scene} ticker=${this.app.ticker.started}`);

    if (this.activeScene === scene) {
      // Same scene — just update layer visibility + flips
      log.render.log('activateScene: same scene, updating flips');
      scene.topLayer.visible = this.isTopVisible;
      scene.bottomLayer.visible = this.isBottomVisible;
      this.applyLayerVisibility(scene);
      this.applyFlips(board, scene);
      this.needsRender = true;
      this.overlayDirty = true;   // flips changed the label-layer transforms
      this.overlayContentDirty = true;
      // Flips move part containers under new transforms — re-cull a few
      // frames so labels aren't culled against the pre-flip worldTransforms
      // (same mechanism as the post-rebuild re-cull).
      this.cullRefreshFrames = 3;
      return;
    }
    log.render.log('activateScene: switching to new scene, old=' + (this.activeScene ? 'yes' : 'null'));

    // Save current viewport state before switching — EXCEPT during reinitApp,
    // where `this.viewport` is a brand-new default (scale 1.0) viewport and
    // `board` is the SAME board whose real view teardownForReinit already saved.
    // Saving here would clobber that good state with 1.0, so restoreViewportState
    // below would restore 100% zoom and the board renders blank (content
    // off-screen). skipSaveViewport preserves the teardown-saved state.
    if (!skipSaveViewport) this.saveViewportState();

    // Detach old scene (netDimGfx + selectionGfx + elevated labels live inside root)
    if (this.activeScene) {
      this.teardownHalo(); // detach halo from old scene's root before switching
      this.activeScene.root.removeChild(this.netDimGfx);
      this.activeScene.root.removeChild(this.crossSideGhostGfx);
      this.activeScene.root.removeChild(this.crossSideGhostOutlineGfx);
      this.activeScene.root.removeChild(this.netLabelLayer);
      this.activeScene.root.removeChild(this.selectionGfx);
      this.activeScene.root.removeChild(this.multiHighlightGfx);
      this.activeScene.root.removeChild(this.elevatedPartBg!);
      this.activeScene.root.removeChild(this.elevatedPartLabel!);
      this.activeScene.root.removeChild(this.elevatedPinBg!);
      this.activeScene.root.removeChild(this.elevatedPinLabel!);
      this.viewport.removeChild(this.activeScene.root);
      if (this.activeScene.butterflyRoot) {
        this.viewport.removeChild(this.activeScene.butterflyRoot);
      }
    }

    // Attach new scene + overlay objects inside root (so board flips apply to them too).
    // scene.root is sortableChildren=true. zIndex order shown below; note that
    // overlay objects whose render order is delegated to selectionLabelLayer
    // (netLabelLayer, selectionGfx, elevated badges) skip scene.root's render
    // pass entirely — the zIndex they carry positions them inside the
    // RenderLayer instead. They're still scene-graph children of scene.root so
    // flip/rotation/scale propagate to them.
    //   zIndex 0:       board content (outline, layers, pins, labels)
    //   zIndex 10:      netDimGfx                    (rendered in scene.root)
    //   zIndex 15:      crossSideGhostGfx            (rendered in scene.root)
    //   zIndex 30:      selectionGfx                 (rendered via selectionLabelLayer
    //                                                 above netLinesGfx, below pin
    //                                                 labels — the glow ring stroke
    //                                                 painted at the pad perimeter is
    //                                                 the "popping out" cue that
    //                                                 survives label coverage on dense
    //                                                 BGAs)
    //   zIndex 35:      netLabelLayer                (rendered via selectionLabelLayer)
    //   zIndex 100-103: elevated selection labels    (rendered via selectionLabelLayer)
    this.viewport.addChild(scene.root);
    scene.root.addChild(this.netDimGfx);
    scene.root.addChild(this.crossSideGhostGfx);
    scene.root.addChild(this.crossSideGhostOutlineGfx);
    scene.root.addChild(this.netLabelLayer);
    scene.root.addChild(this.selectionGfx);
    scene.root.addChild(this.discoHaloGfx);
    // Multi-select / active-worklist outlines — child of scene.root so the
    // board's rotation/flip transforms apply. Rendered via standard root
    // pass (no RenderLayer) at zIndex 28 — sits above ghosts/dim, below
    // the rich selection highlight (30) and pin/net labels (35).
    scene.root.addChild(this.multiHighlightGfx);
    scene.root.addChild(this.elevatedPinBg!);
    scene.root.addChild(this.elevatedPinLabel!);
    scene.root.addChild(this.elevatedPartBg!);
    scene.root.addChild(this.elevatedPartLabel!);
    // Lift selection-related overlays above netLinesGfx in render order — and
    // for selectionGfx, above the raised pin labels too. Logical parent stays
    // scene.root so flips/rotations apply; the render layer only controls
    // draw order (sorted by zIndex within the layer).
    this.selectionLabelLayer.attach(
      this.netLabelLayer,
      this.selectionGfx,
      this.elevatedPartBg!,
      this.elevatedPartLabel!,
      this.elevatedPinBg!,
      this.elevatedPinLabel!,
    );
    this.activeScene = scene;
    this.overlayDirty = true;   // new scene → repaint the label overlay
    this.overlayContentDirty = true;
    this.lastFlipParams = null; // force full label transform on first applyFlips for this scene
    // Set correct label + pin layer visibility for this scene's zoom level
    if (!this.textHiddenForZoom) this.applyLabelVisibility();
    else {
      scene.topCircleLabelLayer.visible = false;
      scene.bottomCircleLabelLayer.visible = false;
      scene.topTwoPinNetLayer.visible = false;
      scene.bottomTwoPinNetLayer.visible = false;
    }
    this.rebuildLabelCounts(scene);

    // Keep net lines on top of all scene content, and the selection-label
    // render layer above the net lines so selection labels never get overdrawn.
    this.viewport.removeChild(this.netLinesGfx);
    this.viewport.addChild(this.netLinesGfx);
    this.viewport.removeChild(this.selectionLabelLayer);
    this.viewport.addChild(this.selectionLabelLayer);

    scene.topLayer.visible = this.isTopVisible;
    scene.bottomLayer.visible = this.isBottomVisible;
    this.applyLayerVisibility(scene);
    this.applyFlips(board, scene);

    // Restore viewport position or fit
    this.restoreViewportState(board);

    // Build spatial hash for fast hit-testing
    this.buildHitGrid(board);

    // Force LoD re-evaluation for the new scene
    this.lastLodScale = -1;
    this.updateLoD();

    this.needsRender = true;
    // Fresh scene → its part containers have not had a world-transform pass yet.
    // Force the culler to re-run over the next few frames once transforms are
    // current (see cullRefreshFrames) so on-screen labels aren't left culled.
    this.cullRefreshFrames = 3;

    // Close the load-progress overlay if this activation corresponds to the
    // file the user is waiting on. Dynamic-import so the renderer doesn't
    // hard-depend on the store; lookup happens once per activation so the
    // cost is negligible. Tab switches between already-cached scenes don't
    // call activateScene's new-scene path, so they skip this naturally.
    const activatingFile = boardStore.fileName;
    if (activatingFile) {
      void import('../store/load-progress-store').then(({ loadProgressStore }) => {
        loadProgressStore.finishIfMatching(activatingFile);
      });
    }
    // The scene is on screen: take the "loading" banner down. The deferral in
    // onBoardUpdate clears its own mark too; this covers every other way a
    // new scene gets activated (rebuilds, the lost-scene recovery branch).
    boardStore.clearSceneBuilding(this.tabId ?? -1);
  }

  private deactivateScene() {
    log.render.log(`deactivateScene tab=${this.tabId}`);
    this.saveViewportState();
    if (this.activeScene) {
      this.teardownButterfly(this.activeScene);
      this.activeScene.root.removeChild(this.netDimGfx);
      this.activeScene.root.removeChild(this.crossSideGhostGfx);
      this.activeScene.root.removeChild(this.crossSideGhostOutlineGfx);
      this.activeScene.root.removeChild(this.netLabelLayer);
      this.activeScene.root.removeChild(this.selectionGfx);
      this.activeScene.root.removeChild(this.discoHaloGfx);
      this.activeScene.root.removeChild(this.multiHighlightGfx);
      this.activeScene.root.removeChild(this.elevatedPartBg!);
      this.activeScene.root.removeChild(this.elevatedPartLabel!);
      this.activeScene.root.removeChild(this.elevatedPinBg!);
      this.activeScene.root.removeChild(this.elevatedPinLabel!);
      this.viewport.removeChild(this.activeScene.root);
      this.activeScene = null;
    }
    this.netDimGfx.clear();
    this.butterflyDimGfx.clear();
    this.crossSideGhostGfx.clear();
    this.crossSideGhostOutlineGfx.clear();
    this.crossSideGhostBakeSig = '';
    this.discoHaloGfx.clear();
    this.discoHaloParts = new Set();
    this.discoHaloDirty = false;
    this.netLabelLayer.removeChildren();
    this.selectionGfx.clear();
  }

  private invalidateAllScenes() {
    // Detach all overlay objects from active scene before destroying — these
    // objects are persistent (reused across rebuilds) and must not be destroyed
    // when scene.root.destroy({ children: true }) is called below.
    if (this.activeScene) {
      // The halo sprite is persistent (reused across rebuilds) and mounted into
      // scene.root, so it MUST be detached here or the scene.root.destroy({
      // children:true }) below destroys it — leaving _haloSprite dangling and
      // crashing the next updateHalo() (spotlight dim mode + selection).
      this.teardownHalo();
      this.activeScene.root.removeChild(this.netDimGfx);
      this.activeScene.root.removeChild(this.crossSideGhostGfx);
      this.activeScene.root.removeChild(this.crossSideGhostOutlineGfx);
      this.activeScene.root.removeChild(this.netLabelLayer);
      this.activeScene.root.removeChild(this.selectionGfx);
      this.activeScene.root.removeChild(this.discoHaloGfx);
      this.activeScene.root.removeChild(this.multiHighlightGfx);
      this.activeScene.root.removeChild(this.elevatedPartBg!);
      this.activeScene.root.removeChild(this.elevatedPartLabel!);
      this.activeScene.root.removeChild(this.elevatedPinBg!);
      this.activeScene.root.removeChild(this.elevatedPinLabel!);
      this.viewport.removeChild(this.activeScene.root);
      if (this.activeScene.butterflyRoot) {
        // Both persistent butterfly overlays live in butterflyRoot; detach both
        // or destroy({children:true}) below kills them and the next rebuild
        // re-adds a dead Graphics (`_gpuData` / `instructions` of null, ticker
        // stopped). butterflyDimGfx was missed here until 2026-09-08.
        this.activeScene.butterflyRoot.removeChild(this.butterflySelectionGfx);
        this.activeScene.butterflyRoot.removeChild(this.butterflyDimGfx);
        // Move bottomLayer back before destroying
        this.activeScene.butterflyRoot.removeChild(this.activeScene.bottomLayer);
        this.viewport.removeChild(this.activeScene.butterflyRoot);
      }
      this.butterflySelectionGfx.clear();
      this.butterflyDimGfx.clear();
    }

    for (const [, scene] of this.sceneCache) {
      if (scene.butterflyRoot) {
        scene.butterflyRoot.removeChild(scene.bottomLayer);
        scene.butterflyRoot.destroy({ children: true });
        scene.butterflyRoot = null;
      }
      scene.root.destroy({ children: true });
    }
    this.sceneCache.clear();
    this.hitGridCache.clear();
    this.activeScene = null;
  }

  // --- Event handlers ---

  private onBoardUpdate() {
    if (this.contextLost || this.reinitializing) {
      log.render.log('onBoardUpdate SKIP: gpu released/reinitializing', 'tab=' + this.tabId);
      return;
    }
    if (!this.viewport) {
      log.render.log('onBoardUpdate SKIP: no viewport', 'tab=' + this.tabId);
      return;
    }
    // Only react when this renderer's tab is active (skip notifications for other tabs)
    if (this.tabId !== null && boardStore.activeTabId !== this.tabId) {
      log.render.log('onBoardUpdate SKIP: tab mismatch', 'mine=' + this.tabId, 'active=' + boardStore.activeTabId);
      return;
    }
    // A board with no scene yet is about to be built on the main thread —
    // ~0.7 s of stalls on a 3369-part board here, seconds on a tablet, and no
    // input is answered meanwhile. Say so BEFORE it starts: record the build
    // in the store, give React a committed frame (rAF) that has been painted
    // (setTimeout 0) so the banner is on screen, then run this same update.
    // A notify that arrives while the frame is pending is folded into the
    // deferred run, which reads the store fresh.
    if (this.sceneBuildDeferral === 'pending') return;
    if (this.sceneBuildDeferral === 'idle') {
      const next = boardStore.board;
      if (next && next !== this.board && !this.sceneCache.has(this.sceneCacheKey(next))) {
        const tabId = this.tabId ?? -1;
        this.sceneBuildDeferral = 'pending';
        boardStore.markSceneBuilding(tabId, boardStore.fileName || next.format);
        requestAnimationFrame(() => setTimeout(() => {
          this.sceneBuildDeferral = 'running';
          try { this.onBoardUpdate(); }
          finally {
            this.sceneBuildDeferral = 'idle';
            boardStore.clearSceneBuilding(tabId);
          }
        }, 0));
        return;
      }
    }
    // The worklist Highlight toggle lives on boardStore; redrawMultiHighlight is
    // otherwise only reached via worklist / selection-set / viewport-move
    // subscriptions, so a bare toggle left the overlay stale until the next
    // pan/zoom. Repaint it as soon as the toggle changes.
    if (boardStore.connectionHighlight !== this.prevConnectionHighlight) {
      this.prevConnectionHighlight = boardStore.connectionHighlight;
      this.redrawMultiHighlight();
      this.needsRender = true;
    }
    // boardStore.board now returns a DERIVED BoardData (filtered/folded) —
    // its reference changes whenever foldMode or selectedBoardIndex changes,
    // so the `boardStore.board !== this.board` check below naturally triggers
    // a scene rebuild on toggle. No separate filter-state tracking needed.

    // D1: this renderer is (or just became) the active tab — settle any
    // rebuild deferred while it was inactive. Covers activation paths that
    // don't route through resume().
    if (this.pendingDeferredRebuild && (this.tabId === null || boardStore.activeTabId === this.tabId)) {
      this.pendingDeferredRebuild = false;
      this.scheduleRebuild();
    }
    // Notify settings store which board is active so per-board overrides take effect
    renderSettingsStore.setActiveBoard(boardStore.fileName);
    log.render.log('onBoardUpdate', 'tab=' + this.tabId,
      'board=' + (boardStore.board ? boardStore.board.format + '/' + boardStore.board.parts.length : 'null'),
      'prev=' + (this.board ? this.board.format + '/' + this.board.parts.length : 'null'),
      'same=' + (boardStore.board === this.board),
      'scene=' + (this.activeScene ? 'yes' : 'null'),
      'tickerStarted=' + this.app.ticker.started);
    // Only log when board reference actually changes (activation/deactivation), not on every store notify
    if (boardStore.board !== this.board) {
      log.render.log(`onBoardUpdate tab=${this.tabId} board=${boardStore.board ? boardStore.board.format + '/' + boardStore.board.parts.length : 'null'} prev=${this.board ? this.board.format + '/' + this.board.parts.length : 'null'} ticker=${this.app.ticker.started}`);
    }
    try {
      const board = boardStore.board;
      // Per-part overrides (right-click hide / send-to-back) — when the Map
      // reference changes, force a scene rebuild even though `board` itself is
      // unchanged. The store replaces the Map on every mutation, so identity
      // equality is correct and cheap.
      const curOverrides = boardStore.partOverrides;
      if (board && board === this.board && this.lastPartOverrides !== null
          && this.lastPartOverrides !== curOverrides) {
        this.lastPartOverrides = curOverrides;
        this.saveViewportState();
        this.invalidateAllScenes();
        this.activateScene(board);
        this.renderSelection();
        return;
      }
      this.lastPartOverrides = curOverrides;
      if (board !== this.board) {
        this.lastFollowQuery = '';
        log.render.log('onBoardUpdate: board changed', board ? 'activating' : 'deactivating');
        if (board) {
          this.activateScene(board);
        } else {
          this.deactivateScene();
        }
        this.board = board;
        // hoverKey is a bare "p{partIndex}:{pinIndex}" identity with no board
        // component — invalidate it on board swap (fold toggle / revision
        // switch) so a stray pointer move that happens to land on the same
        // numeric index against the NEW board doesn't hit the memo fast path
        // and show stale tooltip content (audit A1 hover-key memo).
        this.hoverKey = null;
        // Hydrate this board's persisted worklistes (resolves refdes → partIndex
        // against the freshly-loaded parts) and repaint the multi-highlight.
        void worklistStore.syncToActiveTab().then(() => this.redrawMultiHighlight());
        this.redrawMultiHighlight();
      } else if (board && !this.activeScene) {
        // Same board but scene was lost (e.g. settings update while paused failed
        // to rebuild, or invalidateAllScenes ran without a successful activateScene).
        // Re-activate to recover from blank render.
        log.render.log(`onBoardUpdate tab=${this.tabId} recovering lost scene for ${board.format}/${board.parts.length}`);
        this.activateScene(board);
      } else if (board && this.activeScene) {
        // Detect side flip (top↔bottom) for auto-centering
        const flipped = boardStore.showTop !== this.prevShowTop || boardStore.showBottom !== this.prevShowBottom;
        this.prevShowTop = boardStore.showTop;
        this.prevShowBottom = boardStore.showBottom;

        // Detect rotation change so we can pivot the viewport's view around
        // the user's current focus (not the board center).
        const oldRotation = this.prevRotation;
        const newRotation = boardStore.rotation;
        const rotated = oldRotation !== newRotation;
        this.prevRotation = newRotation;

        // Detect mirror / flip-axis change. Like a side flip and like rotation,
        // these re-sign scene.root's scale, so the world-space net-line cache
        // must be re-projected (see the explicit recompute below).
        const mirrored = boardStore.mirrorX !== this.prevMirrorX
          || boardStore.mirrorY !== this.prevMirrorY
          || boardStore.flipAxis !== this.prevFlipAxis;
        this.prevMirrorX = boardStore.mirrorX;
        this.prevMirrorY = boardStore.mirrorY;
        this.prevFlipAxis = boardStore.flipAxis;

        // Capture the viewport's world center + old flipX/flipY state before
        // applyFlips so we can mirror the center around the board center and
        // keep the same physical region visible.
        const oldVpCenter = (flipped || rotated) ? { x: this.viewport.center.x, y: this.viewport.center.y } : null;
        const oldScale = flipped ? { x: this.activeScene.root.scale.x, y: this.activeScene.root.scale.y } : null;

        // Same board — update layer visibility + flips
        this.activeScene.topLayer.visible = this.isTopVisible;
        this.activeScene.bottomLayer.visible = this.isBottomVisible;
        this.applyLayerVisibility(this.activeScene);
        this.applyFlips(board, this.activeScene);
        this.needsRender = true;
        // Rotation, side flip (top↔bottom), mirror, and flip-axis all change
        // the world transform of every pin (scene.root scale/rotation), so the
        // cached net-line segments (built via sceneToWorld, and living in
        // netLinesGfx OUTSIDE scene.root) become stale. Mark dirty AND
        // immediately redraw — without the redraw call, lines stay at their
        // pre-flip world positions until the next selection / pan / pulse tick
        // re-enters renderNetLines. (renderSelection's selKey fallback repaints
        // too, but only on the next selection change — not on a bare flip.)
        if (rotated || flipped || mirrored) {
          this.netLinesDirty = true;
          this.renderNetLines();
          if (this.crossSideGhostParts.size > 0) this.renderCrossSideGhosts();
        }

        // A 0/180 ↔ 90/270 rotation transposes board vs screen axes, so the
        // pin-number/net-name stagger was computed for the wrong axis (it is
        // baked into label positions at build time). Rebuild — debounced, so
        // spinning through rotations coalesces into one rebuild.
        //
        // Text fast mode (the default) needs no rebuild: the label records
        // carry both layouts and are moved in place. Only the BitmapText path,
        // whose labels are scene objects, still rebuilds.
        if (rotated && this.textFastMode && this.activeScene.labelModel) {
          this.syncLabelRotation(this.activeScene.labelModel);
        } else if (rotated && rot90Parity(newRotation) !== this.sceneRot90Parity) {
          this.scheduleRebuild();
        }

        // After flip: re-center on selected component so the user keeps focus.
        // NOTE: zoomToBounds disabled for now — it over-zooms tiny selections
        // (testpoints, single pads) because 0.25 view-fraction × small bounds
        // = massive zoom-in. Keep the code path around for a future cap-aware
        // version; for now the mirror-about-center branch below handles the
        // no-selection case and the selected case just falls through (scene
        // mirror keeps the part under the viewport since its position also
        // reflects about the board center when we're already centered on it).
        // if (flipped && boardStore.selection.partIndex !== null) {
        //   const part = board.parts[boardStore.selection.partIndex];
        //   if (part) {
        //     const s = renderSettingsStore.settings;
        //     const eb = computePartRenderBounds(part, s);
        //     this.zoomToBounds({ minX: eb.px, minY: eb.py, maxX: eb.px + eb.pw, maxY: eb.py + eb.ph }, this.rootForPart(part), 0.25);
        //   }
        // } else
        if (flipped && oldVpCenter && oldScale) {
          // Mirror the viewport center around the board center to keep the
          // user's physical focus in view after the flip.
          //
          // scene.root's transform is  world = (cx,cy) + R · S · (P - (cx,cy))
          // with R = rotation, S = diag(sx, sy). The world-space "delta
          // vector" before/after a sign flip is related by
          //   v_world_new = R · (S_new · S_old^-1) · R^-1 · v_world_old
          //
          // For any 90°-multiple rotation, R · diag(±1, ±1) · R^-1 is again a
          // diagonal ±1 matrix. Specifically:
          //   • 0° / 180° (axes NOT swapped):  (flipScene.x, flipScene.y)
          //                                    → (flipWorld.x, flipWorld.y)
          //   • 90° / 270° (axes SWAPPED):     (flipScene.x, flipScene.y)
          //                                    → (flipWorld.y, flipWorld.x)
          //
          // The old code assumed the 0°/180° mapping uniformly and broke the
          // preservation on rotated boards (the viewport would mirror around
          // the wrong axis).
          const newScale = this.activeScene.root.scale;
          const cx = (board.bounds.minX + board.bounds.maxX) / 2;
          const cy = (board.bounds.minY + board.bounds.maxY) / 2;
          const dxFlipped = Math.sign(newScale.x) !== Math.sign(oldScale.x);
          const dyFlipped = Math.sign(newScale.y) !== Math.sign(oldScale.y);
          const rot90 = Math.round(boardStore.rotation / 90) % 4;
          const swapped = rot90 === 1 || rot90 === 3;
          const mirrorWorldX = swapped ? dyFlipped : dxFlipped;
          const mirrorWorldY = swapped ? dxFlipped : dyFlipped;
          let nx = oldVpCenter.x;
          let ny = oldVpCenter.y;
          if (mirrorWorldX) nx = 2 * cx - nx;
          if (mirrorWorldY) ny = 2 * cy - ny;
          this.viewport.moveCenter(nx, ny);
        }

        // Rotation re-center: the user expects rotation to pivot around the
        // viewport's current focus, not the board center. Equivalently, after
        // applyFlips moves the world content under a new rotation, pan the
        // viewport so the world point that was at screen-center before the
        // rotation is at screen-center after. Since both old and new applyFlips
        // pivot around the board center (cx, cy), the new world position of
        // that point is the old offset from (cx, cy) rotated by the delta.
        if (rotated && !flipped && oldVpCenter) {
          const cx = (board.bounds.minX + board.bounds.maxX) / 2;
          const cy = (board.bounds.minY + board.bounds.maxY) / 2;
          const deltaRad = (newRotation - oldRotation) * Math.PI / 180;
          const cos = Math.cos(deltaRad);
          const sin = Math.sin(deltaRad);
          const dx = oldVpCenter.x - cx;
          const dy = oldVpCenter.y - cy;
          const nx = cx + dx * cos - dy * sin;
          const ny = cy + dx * sin + dy * cos;
          this.viewport.moveCenter(nx, ny);
        }
      }

      // Skip renderSelection() if all relevant state is unchanged (e.g. tab switch with no selection)
      const sel = boardStore.selection;
      const searchLen = boardStore.searchResultIndices?.size ?? 0;
      const lrs = this.lastRenderedSel;
      if (sel.partIndex !== lrs.partIndex
        || sel.pinIndex !== lrs.pinIndex
        || sel.highlightedNet !== lrs.highlightedNet
        || sel.adjacentNets.size !== lrs.adjacentNetsSize
        || searchLen !== lrs.searchLen
        || this.board !== lrs.board
        || boardStore.dimMode !== lrs.dimMode
        || boardStore.butterfly !== lrs.butterfly
        || boardStore.showTop !== lrs.showTop
        || boardStore.showBottom !== lrs.showBottom
        || boardStore.showGhosts !== lrs.showGhosts
        || boardStore.discoHighlight !== lrs.discoHighlight
        || boardStore.searchSelectionActive !== lrs.searchSelectionActive
        || boardStore.connectionHighlight !== lrs.connectionHighlight
        // Rotation/mirror change must re-run selection so the pooled white
        // name-clones (acquireNetLabel) re-copy the base labels' transform —
        // otherwise the base re-orients via applyFlips but the frozen clone
        // doesn't, leaving a doubled/offset ghost of every highlighted name.
        || boardStore.rotation !== lrs.rotation
        || boardStore.mirrorX !== lrs.mirrorX
        || boardStore.mirrorY !== lrs.mirrorY
        || boardStore.flipAxis !== lrs.flipAxis
        // The net-line mode decides which lines exist (and, in chain-adjacent,
        // which nets glow). Without it here a press of the ribbon button never
        // reached renderSelection and the lines kept the previous mode — even
        // 'off' kept them — until a re-selection (field report 2026-10-13).
        || boardStore.netLineMode !== lrs.netLineMode) {
        this.renderSelection();
        this.lastRenderedSel = { partIndex: sel.partIndex, pinIndex: sel.pinIndex, highlightedNet: sel.highlightedNet, adjacentNetsSize: sel.adjacentNets.size, searchLen, board: this.board, dimMode: boardStore.dimMode, butterfly: boardStore.butterfly, showTop: boardStore.showTop, showBottom: boardStore.showBottom, showGhosts: boardStore.showGhosts, discoHighlight: boardStore.discoHighlight, searchSelectionActive: boardStore.searchSelectionActive, connectionHighlight: boardStore.connectionHighlight, rotation: boardStore.rotation, mirrorX: boardStore.mirrorX, mirrorY: boardStore.mirrorY, flipAxis: boardStore.flipAxis, netLineMode: boardStore.netLineMode };
      }

      // PDF follow mode: search for selected component
      if (boardStore.followPdf && boardStore.selection.partIndex !== null) {
        const followPart = this.board?.parts[boardStore.selection.partIndex];
        log.render.log(`selection trigger: partIndex=${boardStore.selection.partIndex} part=${followPart?.name ?? 'null'}`);
        if (followPart) this.triggerFollowPdf(followPart);
      }

      // Handle focus requests (animated zoom to part/net + blink selection)
      const focus = boardStore.consumeFocusRequest();
      if (focus && focus.fit) {
        // A board-selection / fold-mode change: frame the whole derived board
        // the way the initial load does, rotation included.
        if (this.board) this.fitToBoard(this.board);
        this.needsRender = true;
      } else if (focus) {
        const focusPart = focus.partIndex != null ? this.board?.parts[focus.partIndex] : undefined;
        const focusRoot = focusPart ? this.rootForPart(focusPart) : undefined;
        // Same nav settings apply to both part and net focus. Nets get a
        // larger default target (0.6) because their bbox spans every pin —
        // 25% would leave a 16-pin connector occupying half the screen
        // visually and feel under-zoomed.
        const s = renderSettingsStore.settings;
        const isNet = focus.partIndex == null;
        const target = isNet ? 0.6 : s.navTargetSize;
        // Net focus always frames the WHOLE net: a net spans the board, so
        // honouring 'keep'/'auto' would centre it without unzooming and leave
        // most pins off-screen. Force a fit (snap) for nets; parts still obey
        // the user's navZoomMode.
        const zoomMode = focus.zoomMode ?? (isNet ? 'always' : s.navZoomMode);
        this.zoomToBounds(focus.bounds, focusRoot, target, { zoomMode, scale: focus.scale });
        if (focus.rememberZoom) {       // 2R: Sequência de start lembra o último zoom
          const mag = focus.scale ?? Math.abs(this.viewport.scale.x);
          try { if (mag > 0) localStorage.setItem('2r-seq-zoom', String(mag)); } catch { /* */ }
        }
        // Preview navigation (net tree, single click) deliberately leaves the
        // selection alone, so the blink would draw attention to the previous
        // subject instead of the part we just flew to.
        if (focus.blink !== false) this.startSelectionBlink();
      }
      this.wakeWhilePaused();
    } catch (err) {
      log.render.error('onBoardUpdate crashed:', err);
    }
  }

  // ---- DOM overlays that follow the view (minimap, slide annotations) ----

  private viewListeners = new Set<(e: ViewChange) => void>();
  private viewEmitSig = '';
  private viewPoseScale = -1;
  private viewUserPanned = false;
  private viewPanX = 0;
  private viewPanDx = 0;
  private viewPanDy = 0;
  private viewPanY = 0;

  /** Called after any frame whose view (viewport pose, board transform or
   *  panel size) changed. `userPan` is true when the change was the user
   *  panning — not a zoom, not one of our animated jumps — and then `dx/dy`
   *  is how far it panned (screen px) since the last call. */
  onViewChange(fn: (e: ViewChange) => void): () => void {
    this.viewListeners.add(fn);
    return () => { this.viewListeners.delete(fn); };
  }

  private emitViewChange() {
    const userPan = this.viewUserPanned;
    const dx = this.viewPanDx, dy = this.viewPanDy;
    this.viewUserPanned = false;
    this.viewPanDx = 0;
    this.viewPanDy = 0;
    if (!this.viewListeners.size || !this.viewport || !this.activeScene) return;
    const r = this.activeScene.root.localTransform;
    const b = boardStore.butterfly && this.activeScene.butterflyRoot ? this.activeScene.butterflyRoot.localTransform : null;
    const sig = `${this.lastViewSig}|${r.a},${r.b},${r.c},${r.d},${r.tx},${r.ty}|${b ? `${b.a},${b.b},${b.tx},${b.ty}` : '-'}|${this.containerEl.clientWidth}x${this.containerEl.clientHeight}`;
    if (sig === this.viewEmitSig && !userPan) return;
    this.viewEmitSig = sig;
    for (const fn of this.viewListeners) fn({ userPan, dx, dy });
  }

  /** Everything the minimap draws, in viewport-world space: the transform of
   *  each board root (top, and the mirrored half in Butterfly) and the
   *  rectangle the screen currently shows. */
  getViewModel(): {
    board: BoardData;
    roots: Array<{ m: [number, number, number, number, number, number]; side: 'top' | 'bottom' | 'all' }>;
    view: { x: number; y: number; w: number; h: number };
  } | null {
    if (!this.viewport || !this.activeScene || !this.board) return null;
    const mat = (c: Container): [number, number, number, number, number, number] => {
      const t = c.localTransform;
      return [t.a, t.b, t.c, t.d, t.tx, t.ty];
    };
    const roots: Array<{ m: [number, number, number, number, number, number]; side: 'top' | 'bottom' | 'all' }> = [];
    const broot = boardStore.butterfly ? this.activeScene.butterflyRoot : null;
    if (broot) {
      roots.push({ m: mat(this.activeScene.root), side: 'top' });
      roots.push({ m: mat(broot), side: 'bottom' });
    } else {
      roots.push({ m: mat(this.activeScene.root), side: 'all' });
    }
    const tl = this.viewport.toWorld(0, 0);
    const br = this.viewport.toWorld(this.containerEl.clientWidth, this.containerEl.clientHeight);
    return {
      board: this.board, roots,
      view: { x: Math.min(tl.x, br.x), y: Math.min(tl.y, br.y), w: Math.abs(br.x - tl.x), h: Math.abs(br.y - tl.y) },
    };
  }

  /** Panel size in renderer px. */
  viewSize(): { width: number; height: number } {
    return { width: this.containerEl.clientWidth, height: this.containerEl.clientHeight };
  }

  /** Centre the screen on a viewport-world point (minimap click / drag). */
  centerOnWorld(x: number, y: number) {
    if (!this.viewport) return;
    this.zoomTween = null;
    this.zoomAnim = null;
    this.viewport.moveCenter(x, y);
    this.viewport.emit('moved', { viewport: this.viewport, type: 'drag' });
    this.needsRender = true;
  }

  /** Screen box (renderer px) and name of a part, or null. In Butterfly a
   *  part on the bottom side is measured through the mirrored half. */
  partScreenBox(idx: number | null): { name: string; x: number; y: number; w: number; h: number } | null {
    const part = idx !== null ? this.board?.parts[idx] : undefined;
    if (!part || !this.activeScene) return null;
    let root: Container = this.activeScene.root;
    const broot = boardStore.butterfly ? this.activeScene.butterflyRoot : null;
    if (broot && part.side !== 'both' && (part.side === 'bottom') !== (this.board!.primarySide === 'bottom')) root = broot;
    // The body as drawn — part.bounds only spans the pin centres.
    const rb = computePartRenderBounds(part, renderSettingsStore.settings);
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (const [x, y] of [[rb.px, rb.py], [rb.px + rb.pw, rb.py], [rb.px + rb.pw, rb.py + rb.ph], [rb.px, rb.py + rb.ph]]) {
      const p = root.toGlobal({ x, y });
      minX = Math.min(minX, p.x); minY = Math.min(minY, p.y);
      maxX = Math.max(maxX, p.x); maxY = Math.max(maxY, p.y);
    }
    return { name: part.name, x: minX, y: minY, w: maxX - minX, h: maxY - minY };
  }

  /** Panel px → board-local (top root) coordinates, and back. Annotations are
   *  stored in board space so they stay on the parts while the view moves. */
  screenToBoard(x: number, y: number): { x: number; y: number } | null {
    if (!this.activeScene) return null;
    const p = this.activeScene.root.toLocal({ x, y });
    return { x: p.x, y: p.y };
  }
  boardToScreen(x: number, y: number): { x: number; y: number } | null {
    if (!this.activeScene) return null;
    const p = this.activeScene.root.toGlobal({ x, y });
    return { x: p.x, y: p.y };
  }

  /** The current view as pixels: the WebGL frame plus the Canvas2D label
   *  layer, at the canvas's own backing resolution. `drawExtras` paints on
   *  top in CSS px (the context is pre-scaled). The WebGL buffer is read in
   *  the same task as the render, so no preserveDrawingBuffer is needed. */
  captureView(drawExtras?: (ctx: CanvasRenderingContext2D) => void): HTMLCanvasElement | null {
    if (!this.app?.renderer || !this.activeScene) return null;
    const src = this.app.canvas as HTMLCanvasElement;
    const cssW = this.containerEl.clientWidth, cssH = this.containerEl.clientHeight;
    const scale = Math.max(1, window.devicePixelRatio || 1, src.width / Math.max(1, cssW));
    const out = document.createElement('canvas');
    out.width = Math.round(cssW * scale);
    out.height = Math.round(cssH * scale);
    const ctx = out.getContext('2d');
    if (!ctx) return null;
    try { this.app.render(); } catch (err) { this.handleRenderCrash(err); return null; }
    ctx.drawImage(src, 0, 0, out.width, out.height);
    const overlay = this.ensureLabelOverlay();
    if (overlay && this.activeScene.labelModel) {
      this.syncLabelOverlay(overlay, this.activeScene);
      this.overlayDrawnView = { x: this.viewport.x, y: this.viewport.y, scale: Math.abs(this.viewport.scale.x) };
      ctx.drawImage(overlay.element, 0, 0, out.width, out.height);
    }
    if (drawExtras) {
      ctx.save();
      ctx.scale(out.width / cssW, out.height / cssH);
      drawExtras(ctx);
      ctx.restore();
    }
    return out;
  }

  private scheduleViewSettle() {
    if (this.viewSettleTimer) clearTimeout(this.viewSettleTimer);
    this.viewSettleTimer = setTimeout(() => { this.viewSettleTimer = null; this.settleViewpoint(); }, 600);
  }

  /** The cursor entry, if it is this tab's. */
  private currentNavEntryHere() {
    const cur = navHistoryStore.current;
    return cur?.place?.kind === 'board' && cur.place.tabId === this.tabId ? cur : null;
  }

  /** An animated jump has landed: the entry it served now records the pose it
   *  arrived at (its record-time camera was the pose *before* the jump). */
  private noteArrivalPose() {
    if (navHistoryStore.isRestoring || !this.currentNavEntryHere()) return;
    navHistoryStore.touchCurrentCamera();
  }

  private settleViewpoint() {
    if (navHistoryStore.isRestoring || this.destroyed || !this.board || this.tabId == null || !this.viewport) return;
    const tab = boardStore.tabs.find(t => t.id === this.tabId);
    if (!tab) return;
    const cam = this.navCamera.get();
    const cur = this.currentNavEntryHere();
    const prev = cur?.place?.kind === 'board' ? cur.place.camera : undefined;
    const sw = this.containerEl.clientWidth, sh = this.containerEl.clientHeight;
    const left = !prev || !viewsOverlap(prev, cam, sw, sh);
    if (!left || !navHistoryStore.layers.view) {
      // A small move, or the layer is off: the departure rule — the current
      // entry simply remembers where it was left.
      if (cur) navHistoryStore.touchCurrentCamera();
      return;
    }
    const near = this.findLargestPartNearCenter();
    navHistoryStore.recordViewpoint({
      cause: 'view',
      label: `${near ? `near ${near.name}` : 'region'} · ${Math.abs(cam.scaleX).toFixed(1)}×`,
      place: { kind: 'board', tabId: tab.id, fileKey: tab.cacheKey, fileId: tab.fileId, fileName: tab.fileName,
        side: tab.butterfly || (tab.showTop && tab.showBottom) ? 'both' : tab.showTop ? 'top' : 'bottom', camera: cam },
    });
  }

  /** The Fit button: a deliberate "go to the overview" is a viewpoint. */
  noteFitViewpoint() {
    if (!this.board || this.tabId == null || !this.viewport) return;
    const tab = boardStore.tabs.find(t => t.id === this.tabId);
    if (!tab) return;
    navHistoryStore.record({
      cause: 'view', label: 'Fit board',
      place: { kind: 'board', tabId: tab.id, fileKey: tab.cacheKey, fileId: tab.fileId, fileName: tab.fileName,
        side: tab.butterfly || (tab.showTop && tab.showBottom) ? 'both' : tab.showTop ? 'top' : 'bottom', camera: this.navCamera.get() },
    });
  }

  /**
   * Put the camera back exactly where a navigation-history entry recorded it
   * (the same 400 ms ease as `zoomToBounds`, but an absolute pose — not a
   * fit, which is what the user did *not* want when they pressed back).
   */
  animateToViewport(cam: BoardCamera) {
    if (!this.viewport || this.destroyed) return;
    if (!isFinite(cam.x) || !isFinite(cam.y) || !cam.scaleX || !cam.scaleY) return;
    this.zoomAnim = {
      fromX: this.viewport.position.x,
      fromY: this.viewport.position.y,
      fromScaleX: this.viewport.scale.x,
      fromScaleY: this.viewport.scale.y,
      toX: cam.x, toY: cam.y, toScaleX: cam.scaleX, toScaleY: cam.scaleY,
      elapsed: 0,
      duration: 400,
    };
    this.zoomTween = null;
    this.needsRender = true;
    if (!this.app.ticker.started) this.app.ticker.start();
  }

  private zoomToBounds(
    bounds: { minX: number; minY: number; maxX: number; maxY: number },
    root?: Container,
    viewFraction = 0.25,
    options: { zoomMode?: 'auto' | 'keep' | 'always'; scale?: number } = {},
  ) {
    const bw = bounds.maxX - bounds.minX;
    const bh = bounds.maxY - bounds.minY;
    const sw = this.containerEl.clientWidth;
    const sh = this.containerEl.clientHeight;
    if (sw === 0 || sh === 0) return;

    // Target scale magnitude — part should fill ~viewFraction of the smaller
    // screen dimension. Single absolute cap at 6× (= 600%): a hard ceiling
    // that keeps sub-pixel pan jitter on tiny components manageable. The
    // previous "3× fit-to-board" relative cap silently clipped user-chosen
    // navTargetSize on small boards (e.g. test fixtures and 50 mm modules)
    // so navTargetSize visibly stopped mattering — removed in v0.31.5.
    const maxDim = Math.max(bw, bh, 1);
    const screenMin = Math.min(sw, sh);
    const naturalMag = (screenMin * viewFraction) / maxDim;
    let targetMag = Math.min(naturalMag, 6);

    const mode = options.zoomMode ?? 'always';
    const currentMag = Math.abs(this.viewport.scale.x);
    if (options.scale && options.scale > 0) {
      targetMag = options.scale;          // 2R: zoom exato guardado
    } else if (mode === 'keep' && currentMag > 0) {
      // Never change zoom — just pan to the part's center.
      targetMag = currentMag;
    } else if (mode === 'auto' && currentMag > 0) {
      // Preserve the current zoom when the bbox already lands in the
      // comfortable band on screen (1.5%–70% of the smaller viewport dim).
      // Only truly invisible (<1.5%) or oversized (>70%) parts trigger a snap.
      const screenFrac = (maxDim * currentMag) / screenMin;
      const TOO_SMALL = 0.015;
      const TOO_BIG = 0.70;
      if (screenFrac >= TOO_SMALL && screenFrac <= TOO_BIG) targetMag = currentMag;
      log.render.log(`navZoom: mode=auto screenFrac=${screenFrac.toFixed(3)} target=${targetMag === currentMag ? 'keep' : 'snap'} natural=${naturalMag.toFixed(3)} cur=${currentMag.toFixed(3)}`);
    } else {
      log.render.log(`navZoom: mode=${mode} target=snap natural=${naturalMag.toFixed(3)} cur=${currentMag.toFixed(3)}`);
    }

    // Preserve sign of current scale (negative = flipped)
    const signX = this.viewport.scale.x < 0 ? -1 : 1;
    const signY = this.viewport.scale.y < 0 ? -1 : 1;
    const toScaleX = signX * targetMag;
    const toScaleY = signY * targetMag;

    // Convert scene-local center to world coords for viewport
    const center = this.sceneToWorld({
      x: (bounds.minX + bounds.maxX) / 2,
      y: (bounds.minY + bounds.maxY) / 2,
    }, root);

    // Target viewport position: moveCenter(cx, cy) does position = -cx*scale + screen/2
    const toPosX = -center.x * toScaleX + sw / 2;
    const toPosY = -center.y * toScaleY + sh / 2;

    this.zoomAnim = {
      fromX: this.viewport.position.x,
      fromY: this.viewport.position.y,
      fromScaleX: this.viewport.scale.x,
      fromScaleY: this.viewport.scale.y,
      toX: toPosX,
      toY: toPosY,
      toScaleX,
      toScaleY,
      elapsed: 0,
      duration: 400,
    };
    // A programmatic jump supersedes any in-flight wheel-zoom tween.
    this.zoomTween = null;

    // Ensure ticker is running for the animation
    if (!this.app.ticker.started) this.app.ticker.start();
  }

  /** Ease-out cubic: fast start, smooth deceleration */
  private easeOutCubic(t: number): number {
    return 1 - Math.pow(1 - t, 3);
  }

  // ── PDF Follow Mode ───────────────────────────────────────────────────

  /**
   * Find the visible part with the most pins (>2) closest to the viewport center.
   * Returns the Part or null if nothing qualifies.
   */
  private findLargestPartNearCenter(): Part | null {
    if (!this.board || !this.viewport) return null;

    // Viewport center in scene coords
    const centerWorld = this.viewport.toWorld(
      this.viewport.screenWidth / 2,
      this.viewport.screenHeight / 2,
    );
    const centerScene = this.worldToScene(centerWorld);

    // Visible radius in scene coords (~60% of half-diagonal)
    const cornerWorld = this.viewport.toWorld(0, 0);
    const cornerScene = this.worldToScene(cornerWorld);
    const visibleRadius = Math.sqrt(
      (centerScene.x - cornerScene.x) ** 2 +
      (centerScene.y - cornerScene.y) ** 2,
    );
    const searchRadius = visibleRadius * 0.6;

    let bestPart: Part | null = null;
    let bestScore = -1;

    for (let i = 0; i < this.board.parts.length; i++) {
      const part = this.board.parts[i];
      if (!this.isPartVisible(part)) continue;
      if (part.pins.length <= 2) continue;

      const cx = (part.bounds.minX + part.bounds.maxX) / 2;
      const cy = (part.bounds.minY + part.bounds.maxY) / 2;
      const dist = Math.sqrt((cx - centerScene.x) ** 2 + (cy - centerScene.y) ** 2);
      if (dist > searchRadius) continue;

      const score = part.pins.length * (1 - dist / searchRadius);
      if (score > bestScore) {
        bestScore = score;
        bestPart = part;
      }
    }

    return bestPart;
  }

  /** Build a search query and trigger PDF text search for the given part. */
  /**
   * Trigger PDF follow for a selected component.
   * @param force If true, always overwrites the PDF search field (used by double-click).
   *              If false (single click), respects user-typed search and shows a hint instead.
   */
  private triggerFollowPdf(part: Part, force = false): void {
    const tab = boardStore.tabs.find(t => t.id === this.tabId);
    const pdfNames = tab?.pdfFileNames ?? [];
    if (pdfNames.length === 0) return;

    // Collect unique non-trivial net names, excluding common rails and power nets
    const nets = new Set<string>();
    for (const pin of part.pins) {
      if (!pin.net || pin.net === '(null)') continue;
      const upper = pin.net.toUpperCase();
      // Skip ground, power rails, and generic bus nets
      if (upper === 'GND' || upper === 'VCC' || upper === 'VDD' || upper === 'VSS' ||
          upper.startsWith('PP') || upper === 'VBAT' || upper === 'VBUS' ||
          upper === 'V5S' || upper === 'V3S' || upper === '5V' || upper === '3V3' ||
          upper === '12V' || upper === '1V8' || upper === '1V05') continue;
      nets.add(pin.net);
      if (nets.size >= 4) break; // limit to 4 distinctive nets
    }
    // 2R: componente só com nets de alimentação → usa as 2 primeiras que não são terra
    if (nets.size === 0) {
      for (const pin of part.pins) {
        const u = (pin.net || '').toUpperCase();
        if (u && u !== '(NULL)' && u !== 'GND' && u !== 'VSS') { nets.add(pin.net); if (nets.size >= 2) break; }
      }
    }

    // Pin names as extra disambiguating context (printed on the symbol body).
    // Keep only distinctive alphanumeric ball names (e.g. "A1"); drop purely
    // numeric pin numbers — sequential and non-distinctive, they appear densely
    // in pin/connector tables and bias the lookup toward those tables.
    const pinTokens = new Set<string>();
    for (const pin of part.pins) {
      const t = (pin.number || pin.name || '').trim();
      if (!t || /^\d+$/.test(t)) continue;
      pinTokens.add(t);
      if (pinTokens.size >= 4) break;
    }

    const lookupContext: LookupContextTerm[] = [
      ...[...nets].map((text): LookupContextTerm => ({ text, kind: 'net' })),
      ...[...pinTokens].map((text): LookupContextTerm => ({ text, kind: 'pin' })),
    ];

    // Use @-syntax: net@component (find net on same page as component)
    const navQuery = nets.size > 0
      ? [[...nets][0], part.name].join('@')
      : part.name;

    if (navQuery === this.lastFollowQuery && !force) {
      log.render.log(`skip duplicate query: "${navQuery}"`);
      return;
    }
    this.lastFollowQuery = navQuery;

    const pdfName = pdfNames[0];
    pdfStore.switchTo(pdfName);

    // Check if the PDF search field has user-typed content
    const searchSource = pdfStore.getDocSearchSource(pdfName);

    if (force || searchSource !== 'user') {
      // Empty, lookup-filled, or force → overwrite search with component name and
      // disambiguate by the part's nets + pin numbers. lookupEntity highlights
      // every occurrence and picks/zooms the best-scored one (the schematic
      // symbol placement), handling page navigation itself.
      log.render.log(`triggerFollowPdf: lookup="${part.name}" ctx=${lookupContext.length} pdf="${pdfName}" force=${force}`);
      pdfStore.lookupEntity(pdfName, part.name, lookupContext, 'lookup');
      // Navigation history: a deliberate lookup (double-click) is a stop of
      // its own; the passive follow only annotates the click that caused it.
      const landed = pdfStore.navPlaceFor(pdfName);
      if (force) {
        navHistoryStore.record({ cause: 'lookup', place: landed, query: { surface: 'pdf', text: part.name }, from: part.name });
      } else if (landed) {
        navHistoryStore.noteFollow({ fileName: pdfName, page: landed.page, matchIndex: pdfStore.getDocActiveMatchIndex(pdfName) });
      }
    } else {
      // User-typed search → navigate + selection rectangle + tooltip for double-click
      log.render.log(`triggerFollowPdf: navigate-only query="${navQuery}" pdf="${pdfName}" (user search preserved)`);
      pdfStore.navigateToText(navQuery);
      pdfStore.setLookupHint(pdfName, part.name);
    }

    // Explicit user action (double-click) → activate the PDF panel and focus
    // the search field. Passive follow mode (force=false) stays silent so
    // board clicks don't constantly steal focus.
    if (force) {
      ensurePdfPanel(pdfName);
      // Wait a tick for the PDF panel onDidActiveChange effect to register
      // searchInputRef.current into fileInputRefs.pdfSearch.
      setTimeout(() => {
        const input = fileInputRefs.pdfSearch;
        if (!input) return;
        input.focus();
        input.select();
      }, 0);
    }
  }

  /** Schedule a debounced follow-PDF lookup after viewport movement settles. */
  private scheduleFollowDebounce(): void {
    if (!boardStore.followPdf) return;
    // 2R 12/10/2026: «PDF acompanha» só quando o técnico ligou de propósito (localStorage «2r-follow-pdf-on»)
    if ((() => { try { return localStorage.getItem('2r-follow-pdf-on') !== '1'; } catch { return true; } })()) return;
    if (this.followDebounceTimer) clearTimeout(this.followDebounceTimer);
    this.followDebounceTimer = setTimeout(() => {
      this.followDebounceTimer = null;
      if (!boardStore.followPdf) return;
      if (boardStore.selection.partIndex !== null) {
        const selName = this.board?.parts[boardStore.selection.partIndex]?.name ?? '?';
        log.render.log(`debounce skip: component selected: ${selName} (partIndex=${boardStore.selection.partIndex})`);
        return;
      }
      const part = this.findLargestPartNearCenter();
      log.render.log(`debounce fired: centerPart=${part?.name ?? 'none'} pins=${part?.pins.length ?? 0}`);
      if (part) this.triggerFollowPdf(part);
    }, 500);
  }

  /** (Re)configure viewport drag/pinch/wheel/decelerate plugins from current settings. */
  private applyViewportPlugins(): void {
    const s = renderSettingsStore.settings;
    // Remove existing plugins so we can re-add with new options
    for (const name of ['drag', 'pinch', 'wheel', 'decelerate', 'clamp-zoom'] as const) {
      this.viewport.plugins.remove(name);
    }
    this.viewport
      .drag({ wheel: s.twoFingerPan })
      // The plugin is registered but does nothing: `installTouchPinch` owns the
      // gesture. Its formula cannot be tuned into correctness — it adds
      // `(1 - old/new) * percent * scale` per event, which is a first-order
      // approximation of a multiplicative zoom, so the total depends on how
      // many pointermove events the browser happened to deliver. Measured on
      // one board: the same 4x finger spread came out as 1.8x zoom over three
      // move events and 2.7x over eight. That is the "pinch is inconsistent"
      // report — a flick and a slow spread over the same distance land
      // somewhere different — and no `percent` fixes it.
      //
      // It stays registered because the *drag* plugin stands down only while a
      // pinch plugin exists (`checkButtons`), and `plugins.get('pinch', true)`
      // returns null for a paused one — pausing it would hand two-finger
      // gestures back to drag. `percent: 0` with `noDrag` leaves an inert
      // placeholder that still holds the slot.
      .pinch({ percent: 0, noDrag: true })
      .wheel({
        smooth: s.wheelSmooth,
        percent: 0.3,
        trackpadPinch: true,
        wheelZoom: !s.twoFingerPan,  // disable scroll-to-zoom in two-finger-pan mode
      })
      .clampZoom({ minScale: 0.001, maxScale: 400 });
    // 2R: o app e o index.html usam o viewport e o renderer (zoom mínimo/máximo do RastreCurve, foto, cruz)
    r2w.__2rVP = this.viewport;
    r2w.__2rRend = this;
    R2mira(this.containerEl);
    if (!r2w.__2rClampLoop) {
      r2w.__2rClampLoop = 1;
      (function L() {
        try {
          const v = r2w.__2rVP, m = r2w.__2rMinZoom, M = r2w.__2rMaxZoom;
          if (v && v.scale) {
            const x = Math.abs(v.scale.x);
            if (m && x < m * 0.999) v.setZoom(m, true);
            else if (M && x > M * 1.001) v.setZoom(M, true);
          }
        } catch { /* */ }
        requestAnimationFrame(L);
      })();
    }
    if (!(this.viewport as any).__rcHook) {
      (this.viewport as any).__rcHook = 1;
      this.viewport.on('zoomed', () => {
        const m = r2w.__2rMinZoom, v = this.viewport;
        if (m && v.scale.x < m) v.setZoom(m, true);
        const M = r2w.__2rMaxZoom;
        if (M && v.scale.x > M) v.setZoom(M, true);
      });
    }
    if (!s.disableInertia) {
      this.viewport.decelerate({ friction: 0.95 });
    }
  }

  /**
   * Install a capture-phase wheel listener that resolves the modifier slots
   * of the board's scroll bindings before pixi-viewport sees the event.
   *
   * pixi-viewport has no modifier awareness — its Wheel plugin always zooms
   * (on deltaY, which is 0 for Shift+wheel because the browser has already
   * turned that into a horizontal deltaX) and its Drag plugin always pans.
   * The bare slot stays with pixi-viewport (drag `wheel:` / wheel `wheelZoom:`
   * are configured from `twoFingerPan`); Shift and ⌘ are dispatched here from
   * `wheelShiftAction` / `wheelMetaAction`. Ctrl is never touched: it is the
   * synthesised trackpad pinch in Chrome/Firefox and the fast zoom on a mouse.
   *
   * A modifier pan consumes deltaX AND deltaY. That is what keeps the OS's
   * horizontal-scroll gesture (Shift+wheel, or whatever a utility maps) intact
   * — the axis was decided before the event reached us (issue #40).
   */
  /** Events this renderer re-dispatched onto its canvas, so a listener up
   *  the tree that forwards wheels never forwards one twice. */
  private static readonly forwardedWheels = new WeakSet<Event>();

  /** Re-dispatch a wheel that landed on an overlay of the board panel (the
   *  ribbon, the minimap, the slide sheet) onto the canvas, where pixi-viewport
   *  and the capture handler expect it. Those overlays are siblings of the
   *  canvas host, so a scroll that drifted onto one stopped the pan dead —
   *  "scrolling stops when the mouse goes beyond the rendering area"
   *  (2026-10-22). Returns false for an event that is already a forward. */
  forwardWheel(e: WheelEvent): boolean {
    if (BoardRenderer.forwardedWheels.has(e)) return false;
    const canvas = this.app?.canvas;
    if (!canvas) return false;
    const clone = new WheelEvent('wheel', {
      bubbles: true, cancelable: true, composed: true,
      view: canvas.ownerDocument.defaultView,
      clientX: e.clientX, clientY: e.clientY, screenX: e.screenX, screenY: e.screenY,
      deltaX: e.deltaX, deltaY: e.deltaY, deltaZ: e.deltaZ, deltaMode: e.deltaMode,
      ctrlKey: e.ctrlKey, metaKey: e.metaKey, shiftKey: e.shiftKey, altKey: e.altKey,
      buttons: e.buttons,
    });
    BoardRenderer.forwardedWheels.add(clone);
    e.preventDefault();
    e.stopPropagation();
    canvas.dispatchEvent(clone);
    return true;
  }

  private installShiftWheelHandler(): void {
    // Remove previous listener if viewport was recreated (e.g. context-loss reinit)
    if (this.boundShiftWheel) {
      this.containerEl.removeEventListener('wheel', this.boundShiftWheel, true);
    }
    this.boundShiftWheel = (e: WheelEvent) => {
      // Wake a paused (inactive-panel) board first. The wake listener on the
      // canvas never sees an event this handler consumes below, which since
      // the smooth wheel zoom (2026-07-19) is every zoom-bound and modifier
      // wheel: the board took the zoom and drew nothing (regression of #6).
      this.boundWheelWake?.(e);
      // 2R Tools (Roger, 10/10/2026: «o trackpad da Apple está meio garrado»): no app 2R o
      // trackpad vai direto — pinça amplia/reduz na hora, proporcional ao gesto, e dois
      // dedos arrastam sem a suavização por quadros do pixi-viewport (o macOS já dá a inércia).
      if (trackpadDirect() && !e.metaKey && !e.shiftKey) {
        const sp = trackpadSpeed();
        const pm = pointerMode();
        const isMouse = !e.ctrlKey && (pm === 'mouse' || (pm === 'auto' && looksLikeMouseWheel(e)));
        if (!e.ctrlKey && pm === 'flexbv') {
          // 2R 20/10/2026 (FlexBV): roda e dois dedos dão zoom; arrastar com o clique move a placa
          const roda = e.deltaMode === 1 || (Math.abs(e.deltaY) >= 50 && e.deltaY % 1 === 0);
          this.zoomAtScreen(e.offsetX, e.offsetY, e.deltaY * r2RodaK(e), true,
            WHEEL_DIVISOR / (roda ? mouseZoomSpeed() : parseFloat(localStorage.getItem('2r-flex-tp-zoom') || '8') || 8));
        } else if (isMouse) {
          // roda do mouse: amplia/reduz em volta do ponteiro (padrão do Windows e do FlexBV)
          this.zoomAtScreen(e.offsetX, e.offsetY, (e.deltaY || e.deltaX) * r2RodaK(e), true, WHEEL_DIVISOR / mouseZoomSpeed());
        } else if (e.ctrlKey) {
          if (pm === 'flexbv') { e.preventDefault(); e.stopPropagation(); return; }
          const f = Math.exp(-Math.max(-60, Math.min(60, e.deltaY)) * 0.011 * sp.zoom);
          this.setScaleAtScreen(e.offsetX, e.offsetY, this.viewport.scale.x * f);
        } else if (renderSettingsStore.settings.twoFingerPan && e.deltaMode === 0) {
          const inv = invertFlag('2r-pan-invert');
          this.viewport.x -= e.deltaX * sp.pan * inv;
          this.viewport.y -= e.deltaY * sp.pan * inv;
        } else {
          return;
        }
        this.viewport.emit('moved', { viewport: this.viewport, type: 'wheel' });
        this.needsRender = true;
        this.netLinesDirty = true;
        e.preventDefault();
        e.stopPropagation();
        return;
      }
      if (e.ctrlKey) return;

      const s = renderSettingsStore.settings;
      let action: 'pan' | 'zoom';
      if (e.metaKey) {
        action = s.wheelMetaAction;
      } else if (e.shiftKey) {
        action = s.wheelShiftAction;
      } else if (s.twoFingerPan && (r2RodaDoMouse(e) || (s.wheelDetection && looksLikeMouseWheel(e)))) {
        // 2R 22/10/2026 (Roger): roda do MOUSE dá zoom na placa (Mac e Windows); trackpad continua movendo
        // Safety net: a classic mouse wheel in pan mode would pan jerkily —
        // route it to the mouse-centred zoom path instead.
        action = 'zoom';
      } else if (!s.twoFingerPan && s.smoothZoom) {
        // Plain mouse-wheel zoom: intercept before pixi-viewport's frame-count
        // smoothing and run it through the exponential tween instead.
        action = 'zoom';
      } else {
        // Bare scroll, no override — pixi-viewport's own plugins handle it.
        return;
      }

      if (action === 'zoom') {
        this.zoomAtScreen(e.offsetX, e.offsetY, (e.deltaY || e.deltaX) * r2RodaK(e), true, WHEEL_DIVISOR);
      } else {
        this.viewport.x -= e.deltaX;
        this.viewport.y -= e.deltaY;
      }

      this.viewport.emit('moved', { viewport: this.viewport, type: 'wheel' });
      this.needsRender = true;
      // No netLinesDirty: a pan or zoom never moves the world-space segments (a live turn carries them rigidly, rotateLive), and a dirty flag holds off the in-zoom re-stroke (onZoomFrame).
      e.preventDefault();
      e.stopPropagation();
    };
    this.containerEl.addEventListener('wheel', this.boundShiftWheel, { capture: true, passive: false });
  }

  /** Set an absolute scale while holding one screen point still.
   *
   *  `zoomAtScreen` takes an incremental wheel delta; a pinch knows the scale
   *  it wants outright (start scale times the finger-distance ratio) and must
   *  not route through a delta, because that is exactly the accumulation the
   *  plugin's formula got wrong. Screen coordinates are container CSS px, the
   *  same space `viewport.toWorld` works in here. */
  /** 2R 12/10/2026: afasta no máximo até a placa ocupar metade da área e aproxima no máximo até um pad */
  private __r2B: unknown = null; private __r2Pad = 50;
  private r2Clamp(n: number): number { const L = this.r2Lim(); return Math.max(L[0], Math.min(L[1], n)); }
  private r2Lim(): [number, number] {
    const B = this.board;
    if (!B || !B.bounds || !this.containerEl) return [0.001, 10];
    const W = this.containerEl.clientWidth || 1, H = this.containerEl.clientHeight || 1, b = B.bounds;
    const bw = Math.max(1, b.maxX - b.minX) * (boardStore.butterfly ? 2 : 1), bh = Math.max(1, b.maxY - b.minY);
    if (this.__r2B !== B) {
      this.__r2B = B;
      const rs: number[] = [];
      for (const p of B.parts || []) for (const q of p.pins || []) if (q && q.radius > 0) rs.push(q.radius);
      rs.sort((x, y) => x - y);
      this.__r2Pad = rs.length ? rs[rs.length >> 1] * 2 : 50;
    }
    const mn = 0.5 * Math.min(W / bw, H / bh), mx = Math.min(W, H) / Math.max(0.001, this.__r2Pad);
    return [Math.max(0.001, Math.min(mn, mx)), Math.max(mn, mx)];
  }

  private setScaleAtScreen(screenX: number, screenY: number, targetScale: number): void {
    const s = this.r2Clamp(targetScale);
    const before = this.viewport.toWorld(screenX, screenY);
    this.viewport.scale.set(s, s);
    const after = this.viewport.toWorld(screenX, screenY);
    this.viewport.x += (after.x - before.x) * this.viewport.scale.x;
    this.viewport.y += (after.y - before.y) * this.viewport.scale.y;
  }

  /** Seed (or re-seed) the pinch from whichever two touch pointers are down.
   *
   *  The baseline describes a *pair*. A third finger landing, or one of two
   *  being cancelled and replaced, changes which pointers the gesture runs on
   *  while `startDist` still describes the old ones — the next move would then
   *  divide two unrelated distances and the board would leap. */
  private seedPinch(): void {
    const ids = [...this.activeTouchIds.keys()];
    if (ids.length < 2) { this.pinch = null; return; }
    const [a, b] = ids;
    const pa = this.activeTouchIds.get(a)!;
    const pb = this.activeTouchIds.get(b)!;
    const dist = Math.hypot(pb.x - pa.x, pb.y - pa.y);
    if (dist < 1) { this.pinch = null; return; }
    const rect = this.containerEl.getBoundingClientRect();
    if (this.gestureOwner === 'gesture' && this.gestureReleaseTimer) {
      clearTimeout(this.gestureReleaseTimer);
      this.gestureReleaseTimer = null;
    }
    this.gestureOwner = 'pointer';
    this.pinch = {
      a, b, startDist: dist, startScale: Math.abs(this.viewport.scale.x),
      lastMidX: (pa.x + pb.x) / 2 - rect.left,
      lastMidY: (pa.y + pb.y) / 2 - rect.top,
      startAngle: Math.atan2(pb.y - pa.y, pb.x - pa.x),
      rotBaseRad: this.liveRotate?.appliedRad ?? 0,
    };
  }

  /** Turn the scene roots so they carry `targetRad` beyond the store's
   *  rotation, about the world point under the screen midpoint. Rotating the
   *  picture about P is position' = P + R(Δ)·(position − P), rotation' += Δ
   *  — for both roots in Butterfly, each about the same P. Screen-space
   *  finger angles are CW-positive in a y-down frame, and so is Pixi's
   *  rotation, so the two agree with no sign change. */
  private rotateLive(targetRad: number, midX: number, midY: number, stream: 'pointer' | 'gesture', rawDeg: number): void {
    if (!renderSettingsStore.settings.twoFingerRotate) return;
    const scene = this.activeScene;
    if (!scene) return;
    const lr = this.liveRotate ?? (this.liveRotate = { engaged: false, appliedRad: 0, baseRad: 0, midX, midY, stream, rawDeg });
    lr.midX = midX;
    lr.midY = midY;
    lr.stream = stream;
    lr.rawDeg = rawDeg;
    if (!lr.engaged) {
      const turnedDeg = Math.abs(targetRad) * 180 / Math.PI;
      if (rotationLockStore.locked) {
        if (turnedDeg < renderSettingsStore.settings.rotateUnlockDeg) return;
        // Unlock, and turn on from here — the degrees already turned (rotateUnlockDeg) are the
        // unlock gesture, not rotation the board should catch up on.
        rotationLockStore.setLocked(false);
        lr.baseRad = targetRad;
        boardStore.addToast('Rotation unlocked — turn two fingers to rotate; double-tap with two fingers to lock again.', 'info');
        log.ui.log('touch: rotation unlocked by a two-finger turn');
      } else if (turnedDeg < BoardRenderer.ROTATE_DEAD_ZONE_DEG) {
        return;
      }
      lr.engaged = true;
    }
    const step = (targetRad - lr.baseRad) - lr.appliedRad;
    if (step === 0) return;
    const P = this.viewport.toWorld(midX, midY);
    const cos = Math.cos(step), sin = Math.sin(step);
    // The net lines are world-space children of the viewport, not of the
    // roots, so they turn with the same rigid transform about the same P —
    // O(1), no segment recompute per finger move, and they stay on the pins
    // for the whole gesture. They used to be cleared for as long as a turn was
    // engaged, which on an unlocked iPad (2° dead zone) blanked them on nearly
    // every pinch (field report 2026-10-13). The commit recomputes them
    // through the committed roots and resets this carried transform.
    for (const node of [scene.root, scene.butterflyRoot, this.netLinesGfx, this.netLinesPulseGfx]) {
      if (!node || node.destroyed) continue;
      const dx = node.position.x - P.x, dy = node.position.y - P.y;
      node.position.set(P.x + dx * cos - dy * sin, P.y + dx * sin + dy * cos);
      node.rotation += step;
    }
    lr.appliedRad = targetRad - lr.baseRad;
    this.needsRender = true;
    this.overlayDirty = true;
    this.overlayContentDirty = true;
  }

  /** Two-finger double-tap: lock ⇄ unlock. Locking squares the board — a
   *  locked board sits at a right angle — about the screen centre, as the
   *  buttons do. */
  private toggleRotationLock(): void {
    if (rotationLockStore.locked) {
      rotationLockStore.setLocked(false);
      boardStore.addToast('Rotation unlocked — turn two fingers to rotate; double-tap with two fingers to lock again.', 'info');
      log.ui.log('touch: rotation unlocked by a two-finger double-tap');
      return;
    }
    rotationLockStore.setLocked(true);
    const nearest = (Math.round(boardStore.rotation / 90) * 90) % 360;
    boardStore.setRotation(nearest);
    boardStore.addToast(`Rotation locked at ${nearest}°.`, 'info');
    log.ui.log(`touch: rotation locked by a two-finger double-tap, snapped to ${nearest}°`);
  }

  /** The fingers lifted: hand the angle to the store — snapped to a right
   *  angle when close — and keep the point that was between the fingers
   *  where it is. The store commit runs applyFlips, which rebuilds the root
   *  transform about the board centre and re-centres the viewport about the
   *  screen centre; the pan correction afterwards puts the finger point back,
   *  so the snap too turns about the fingers, not about the screen. */
  private commitLiveRotation(): void {
    const lr = this.liveRotate;
    this.liveRotate = null;
    const scene = this.activeScene;
    if (lr && !lr.engaged && Math.abs(lr.rawDeg) >= 1) {
      log.ui.log(`touch: two-finger turn ended without rotating (stream=${lr.stream}, raw=${lr.rawDeg.toFixed(1)}°, ` +
        `${rotationLockStore.locked ? 'locked' : 'under the dead zone'})`);
    }
    if (!lr || !lr.engaged || !scene) return;
    const mid = { x: lr.midX, y: lr.midY };
    const local = scene.root.toLocal(mid);
    let deg = boardStore.rotation + lr.appliedRad * 180 / Math.PI;
    deg = ((deg % 360) + 360) % 360;
    const nearest = Math.round(deg / 90) * 90;
    const off = ((deg - nearest) % 360 + 540) % 360 - 180;
    // A committed angle within the snap window of a right angle squares up;
    // a window of 0 never snaps.
    const snapDeg = renderSettingsStore.settings.rotateSnapDeg;
    const snapped = snapDeg > 0 && Math.abs(off) <= snapDeg;
    if (snapped) deg = nearest % 360;
    boardStore.setRotation(deg);
    const now = scene.root.toGlobal(local);
    this.viewport.x += mid.x - now.x;
    this.viewport.y += mid.y - now.y;
    this.viewport.emit('moved', { viewport: this.viewport, type: 'pinch' });
    this.needsRender = true;
    // Recompute through the committed roots and draw now: setRotation may not
    // have notified (a turn that snapped back to the angle it started from),
    // and a dirty flag nobody draws from holds off the zoom re-stroke and
    // leaves the gesture's carried transform on the lines.
    this.netLinesDirty = true;
    this.renderNetLines();
    this.overlayContentDirty = true;
    // The one record of what a gesture was, readable off the device: the
    // stream that owned it, the raw angle it reported (pointer: the pair's
    // screen angle; gesture: GestureEvent.rotation as delivered) and what the
    // board turned. Raw and applied disagreeing in sign is the sign bug.
    log.ui.log(`touch: rotation committed at ${boardStore.rotation}° — stream=${lr.stream}, ` +
      `raw=${lr.rawDeg.toFixed(1)}°, board turned ${(lr.appliedRad * 180 / Math.PI).toFixed(1)}° (CW+), ` +
      `snap ${snapped ? 'yes' : 'no'}`);
  }

  /** Two-finger pinch: zoom and pan, owned here rather than by pixi-viewport.
   *
   *  Scale is `startScale * (dist / startDist)` — a function of where the
   *  fingers are *now*, not of how many events got there, so a flick and a
   *  slow spread over the same distance land on the same zoom and a pinch in
   *  followed by a pinch out returns to where it started. The midpoint is held
   *  still while scaling and then carries the pan, so the board stays under
   *  the fingers.
   *
   *  Capture phase on the container: the pinch plugin is inert (see
   *  `applyViewportPlugins`) and the drag plugin stands down at two pointers,
   *  so nothing here needs to stop propagation — pixi-viewport still sees the
   *  moves and keeps its own click/drag bookkeeping honest. */
  private installTouchPinch(): void {
    if (this.boundTouchPinchMove) {
      this.containerEl.removeEventListener('pointermove', this.boundTouchPinchMove, true);
    }
    this.boundTouchPinchMove = (e: PointerEvent) => {
      if (e.pointerType !== 'touch') return;
      const rec = this.activeTouchIds.get(e.pointerId);
      if (!rec) return;
      rec.x = e.clientX;
      rec.y = e.clientY;
      const down = this.touchDownPos.get(e.pointerId);
      if (down) {
        this.twoFingerMaxTravel = Math.max(this.twoFingerMaxTravel, Math.hypot(e.clientX - down.x, e.clientY - down.y));
      }
      if (this.gestureOwner === 'gesture') return;   // WebKit owns this one
      const p = this.pinch;
      if (!p || (e.pointerId !== p.a && e.pointerId !== p.b)) return;
      const pa = this.activeTouchIds.get(p.a);
      const pb = this.activeTouchIds.get(p.b);
      if (!pa || !pb) return;

      const dist = Math.hypot(pb.x - pa.x, pb.y - pa.y);
      if (dist < 1) return;
      const rect = this.containerEl.getBoundingClientRect();
      const midX = (pa.x + pb.x) / 2 - rect.left;
      const midY = (pa.y + pb.y) / 2 - rect.top;

      // Scale about the PREVIOUS midpoint, then translate by the new one's
      // travel. Anchoring on the current midpoint instead looks equivalent and
      // is not: it double-counts the travel by (1 - ratio) per event, which
      // compounds across a gesture. Both fingers stay over the content they
      // started on exactly when pan₁ = mid₀ - ratio·(mid₀ - pan₀) + (mid₁ - mid₀).
      // Invisible only while the two fingers' movements cancel exactly
      // (mid = (f1 + f2) / 2 is constant iff Δf1 = -Δf2), which is a knife
      // edge rather than a description of how anyone pinches — the error
      // grows with however much the midpoint drifts, and a parked finger is
      // simply the extreme of that, not a special case.
      this.setScaleAtScreen(p.lastMidX, p.lastMidY, p.startScale * (dist / p.startDist));
      this.viewport.x += midX - p.lastMidX;
      this.viewport.y += midY - p.lastMidY;
      p.lastMidX = midX;
      p.lastMidY = midY;
      // Turning the pair turns the board (see rotateLive). The angle is the
      // pair's own, wrapped to (−π, π] so a finger crossing the axis does not
      // read as a full turn.
      let dAng = Math.atan2(pb.y - pa.y, pb.x - pa.x) - p.startAngle;
      dAng = Math.atan2(Math.sin(dAng), Math.cos(dAng));
      this.rotateLive(p.rotBaseRad + dAng, midX, midY, 'pointer', dAng * 180 / Math.PI);

      this.viewport.emit('moved', { viewport: this.viewport, type: 'pinch' });
      this.needsRender = true;
      // No netLinesDirty: a pan or zoom never moves the world-space segments (a live turn carries them rigidly, rotateLive), and a dirty flag holds off the in-zoom re-stroke (onZoomFrame).
    };
    this.containerEl.addEventListener('pointermove', this.boundTouchPinchMove, { capture: true });
  }

  /** Mouse-centered zoom at a screen point using the same formula the
   *  shift+wheel handler uses, so drag-zoom and wheel-zoom feel identical.
   *  `rawDelta` is an incremental signed pixel delta: positive = zoom out,
   *  negative = zoom in (matches wheel deltaY sign convention).
   *  `smooth` (default false) routes through the exponential cursor-anchored
   *  tween (smooth-zoom.ts) instead of jumping the scale instantly — used by
   *  wheel/keyboard zoom, gated live on `renderSettingsStore.settings.smoothZoom`.
   *  Drag-zoom keeps `smooth = false`: a continuous gesture must track the
   *  pointer 1:1, not lag behind an animated approach. */
  private zoomAtScreen(screenX: number, screenY: number, rawDelta: number, smooth = false, divisor = 500): void {
    const factor = Math.pow(2, (1 + 0.3) * (-rawDelta / divisor));
    if (r2w.__r2ZA) r2w.__r2ZA.v *= factor;
    if (smooth && renderSettingsStore.settings.smoothZoom) {
      const base = this.zoomTween?.targetScale ?? Math.abs(this.viewport.scale.x);
      const world = this.viewport.toWorld(screenX, screenY);
      this.zoomTween = {
        targetScale: this.r2Clamp(base * factor),
        anchorScreenX: screenX, anchorScreenY: screenY,
        anchorWorldX: world.x, anchorWorldY: world.y,
      };
      this.zoomAnim = null;
      this.needsRender = true;
      return;
    }
    const before = this.viewport.toWorld(screenX, screenY);
    this.viewport.scale.set(this.r2Clamp(this.viewport.scale.x * factor), this.r2Clamp(this.viewport.scale.y * factor));
    const after = this.viewport.toWorld(screenX, screenY);
    this.viewport.x += (after.x - before.x) * this.viewport.scale.x;
    this.viewport.y += (after.y - before.y) * this.viewport.scale.y;
  }

  /**
   * Capture-phase pointerdown handler that implements drag-to-zoom when the
   * resolved action (from dragToZoom + shiftKey) is 'zoom'. If the action is
   * 'pan', the handler returns without consuming the event so pixi-viewport's
   * drag plugin sees it in bubble phase and pans normally.
   *
   * Zoom is vertical-delta, anchored at the INITIAL click point for the
   * duration of the gesture, and delegated to the same mouse-centered zoom
   * helper the wheel handler uses. Sensitivity is 2× that of the scroll
   * wheel so a short drag feels responsive.
   *
   * A 3-px click-vs-drag threshold gates the zoom loop so simple clicks
   * still select parts normally.
   */
  private installDragZoomHandler(): void {
    if (this.boundDragZoomDown) {
      this.containerEl.removeEventListener('pointerdown', this.boundDragZoomDown, true);
    }

    const DRAG_THRESHOLD = 3;
    const DRAG_ZOOM_SPEED = 2; // drag-zoom is 2× as sensitive as wheel

    this.boundDragZoomDown = (e: PointerEvent) => {
      if (e.button !== 0) return;
      const s = renderSettingsStore.settings;
      const action: 'pan' | 'zoom' =
        s.dragToZoom === e.shiftKey ? 'pan' : 'zoom';
      if (action === 'pan') {
        // Cancel any in-flight smooth-zoom tween/animation before the pan begins.
        // The wheel-zoom tween re-pins viewport.x/y every frame (see the ticker),
        // so a drag started while it is still animating gets overwritten each
        // frame — the board only pans once the tween settles. Dropping it here
        // (capture phase, before pixi-viewport's drag plugin sees the pointer)
        // makes the pan take effect immediately. Regression: users on the
        // smoothZoom=true default saw "pan doesn't work right after zooming".
        this.zoomTween = null;
        this.zoomAnim = null;
        return; // pixi-viewport handles the pan itself
      }

      const rect = this.containerEl.getBoundingClientRect();
      const anchorX = e.clientX - rect.left;
      const anchorY = e.clientY - rect.top;
      const startX = e.clientX;
      const startY = e.clientY;
      const pointerId = e.pointerId;
      let lastY = startY;
      let committed = false;

      const onMove = (ev: PointerEvent) => {
        if (ev.pointerId !== pointerId) return;
        if (!committed) {
          const dx = ev.clientX - startX;
          const dy = ev.clientY - startY;
          if (Math.abs(dx) + Math.abs(dy) < DRAG_THRESHOLD) return;
          committed = true;
          this.dragZoomActive = true;
          try { (this.containerEl as Element).setPointerCapture?.(pointerId); } catch { /* ignore */ }
          lastY = ev.clientY;
        }
        const incDy = ev.clientY - lastY;
        lastY = ev.clientY;
        if (incDy !== 0) {
          // Same sign convention as wheel deltaY: positive = zoom out, negative = zoom in.
          // Anchor is fixed at the initial click point; speed is 2× wheel sensitivity.
          this.zoomAtScreen(anchorX, anchorY, incDy * DRAG_ZOOM_SPEED);
          this.viewport.emit('moved', { viewport: this.viewport, type: 'wheel' });
          this.needsRender = true;
          // No netLinesDirty: a zoom never moves the world-space segments, and a dirty flag holds off the in-zoom re-stroke (onZoomFrame).
        }
        this.containerEl.style.cursor = incDy < 0 ? 'zoom-in' : 'zoom-out';
        ev.preventDefault();
        ev.stopPropagation();
      };

      const forceCleanup = () => {
        this.dragZoomActive = false;
        window.removeEventListener('pointermove', onMove, true);
        window.removeEventListener('pointerup', cleanup, true);
        window.removeEventListener('pointercancel', cleanup, true);
        try { (this.containerEl as Element).releasePointerCapture?.(pointerId); } catch { /* ignore */ }
        this.containerEl.style.cursor = '';
        if (this.activeDragZoomCleanup === forceCleanup) this.activeDragZoomCleanup = null;
      };

      const cleanup = (ev: PointerEvent) => {
        if (ev.pointerId !== pointerId) return;
        forceCleanup();
        if (committed) {
          // Block the stale 'clicked' that pixi-viewport will still emit —
          // its InputManager never saw the moves, so it thinks the drag was a click.
          this.dragZoomConsumedClick = true;
          ev.preventDefault();
          ev.stopPropagation();
        }
      };

      window.addEventListener('pointermove', onMove, { capture: true, passive: false });
      window.addEventListener('pointerup', cleanup, { capture: true });
      window.addEventListener('pointercancel', cleanup, { capture: true });
      this.activeDragZoomCleanup = forceCleanup;
    };

    this.containerEl.addEventListener('pointerdown', this.boundDragZoomDown, { capture: true });
  }

  private onSettingsUpdate() {
    if (!this.board || this.contextLost || this.reinitializing) return;
    // onSettingsUpdate — no logging (fires on every settings change)
    // Part-type list / hidden flags may have changed — drop the per-name
    // type-hidden memo so isTypeHidden re-resolves against the new settings.
    this._typeHiddenMemo.clear();
    try {
      const cur = renderSettingsStore.settings;
      const prev = this.lastSettingsSnapshot;

      // Live-sync FPS cap — toggling Performance & Debug → Cap to 60 FPS takes
      // effect without a scene rebuild. PixiJS treats maxFPS = 0 as uncapped.
      const targetMax = boardMaxFps(cur.cap60Fps, cur.touchPerformanceMode);
      if (this.app?.ticker && this.app.ticker.maxFPS !== targetMax) {
        this.app.ticker.maxFPS = targetMax;
      }
      // Live-sync the render resolution (quality preset / touch profile).
      // PixiJS v8 resizes the backing store on assignment; MSAA, by
      // contrast, is fixed at context creation and waits for the next panel.
      const targetRes = boardPixelRatio(cur.touchPerformanceMode, cur.boardResolutionCap);
      if (this.app?.renderer && this.app.renderer.resolution !== targetRes) {
        this.app.renderer.resolution = targetRes;
        this.overlayDirty = true;
        this.overlayContentDirty = true;
        this.needsRender = true;
      }

      // Live-sync perf overlay — single source of truth lives in the setting,
      // both the canvas "i" button and the Settings checkbox flow through here.
      if (this.perfVisible !== cur.showPerfOverlay) {
        this.perfVisible = cur.showPerfOverlay;
        if (!this.perfVisible && this.perfOverlayEl) {
          this.perfOverlayEl.style.display = 'none';
          this.perfAccum = { lod: 0, selection: 0, netLines: 0, gpuRender: 0, frame: 0 };
          this.perfSamples = 0;
          this.perfThrottle = 0;
        } else if (this.perfVisible && this.activeScene) {
          this.rebuildLabelCounts(this.activeScene);
        }
      }

      // Fast path: if only no-rebuild fields differ, skip the expensive scene
      // rebuild and just reconfigure viewport plugins. cap60Fps + showPerfOverlay
      // were live-synced above; the others are interaction-only.
      // applyGlobal structuredClones the settings, so object/array fields get
      // fresh references each call — use JSON equality for deep comparison.
      const INTERACTION_ONLY = new Set<string>([
        'twoFingerPan', 'wheelShiftAction', 'wheelMetaAction', 'wheelDetection', 'wheelSmooth', 'disableInertia', 'dragToZoom',
        'cap60Fps', 'showPerfOverlay', 'smoothZoom',
        // Live-synced above (resolution) or read only at Application.init
        // (MSAA): neither changes a single vertex of the scene.
        'touchPerformanceMode', 'boardResolutionCap', 'boardAntialiasing',
        // Overlay-only: read at label-overlay draw time (OverlayThresholds), so
        // a change needs an overlay repaint, NOT a scene rebuild. Rebuilding on
        // this needlessly redraws all geometry (and can hit the vertex ceiling
        // under an elevated pinSizeScale).
        'selectedLabelMinPx', 'selectedLabelLodRelax', 'selectedLabelOtherScale', 'labelFitToPitch', 'labelFadeRange',
        // Board-ribbon layout: pure DOM (which chips, where the bar sits, how
        // it is oriented). Nothing in the scene reads these, so a drag of the
        // floating bar must not rebuild — every rebuild is a chance to leave a
        // destroyed Graphics in the tree (the `_gpuData of null` crash).
        'overlayLayout', 'overlayPosition', 'overlayOrientation', 'overlayFloatX', 'overlayFloatY',
        'minimapOnPan',
      ]);
      if (prev) {
        let visualChanged = false;
        for (const k of Object.keys(cur) as Array<keyof typeof cur>) {
          if (INTERACTION_ONLY.has(k as string)) continue;
          const a = cur[k];
          const b = prev[k];
          if (a === b) continue;
          if (typeof a === 'object' && a !== null) {
            if (JSON.stringify(a) !== JSON.stringify(b)) { visualChanged = true; break; }
          } else {
            visualChanged = true;
            break;
          }
        }
        if (!visualChanged) {
          this.applyViewportPlugins();
          // Overlay-only keys (e.g. selectedLabelMinPx) still need a repaint —
          // the overlay reads thresholds at draw time, so no rebuild required.
          this.overlayDirty = true;
          this.overlayContentDirty = true;
          this.lastSettingsSnapshot = cur;
          return;
        }
      }

      // Cancel any pending zoom-settle timers (scene is about to be rebuilt)
      if (this.zoomSettleTimer) { clearTimeout(this.zoomSettleTimer); this.zoomSettleTimer = null; }

      this.textHiddenForZoom = false;
      this.netLinesHiddenForZoom = false;
      // Update viewport interaction plugins (cheap, immediate).
      this.applyViewportPlugins();
      // Debounce the expensive scene rebuild so rapid colour-edit changes
      // coalesce and the UI isn't blocked per drag-frame (see scheduleRebuild).
      this.scheduleRebuild();
      // Cheap catch-all: any visual settings change (label thresholds, dim, the
      // textFastMode toggle itself) should repaint the overlay next tick. The
      // thresholds are read at draw time, so this covers them without a rebuild.
      this.overlayDirty = true;
      this.overlayContentDirty = true;
      this.lastSettingsSnapshot = cur;
    } catch (err) {
      log.render.error(`onSettingsUpdate crashed tab=${this.tabId} scene=${this.activeScene ? 'yes' : 'NULL'} ticker=${this.app.ticker.started}:`, err);
      // activeScene may be null after invalidateAllScenes + failed activateScene.
      // The next onBoardUpdate (on resume or tab switch) will detect the missing
      // scene and re-activate it via the "recovering lost scene" path.
    }
  }

  /**
   * Theme switched — swap the live PixiJS background color and trigger a full
   * scene rebuild so getter-driven BOARD_COLORS values take effect.
   */
  /**
   * OBD data changed — the on-pin diode layer draws OBD readings (per net) as
   * a second source, so rebuild when OBD that carries diode values for THIS
   * board arrives. Passing board=null to boardHasDiodeData checks the OBD
   * source only, so XZZ-baked boards (whose layer doesn't depend on OBD) don't
   * thrash on unrelated OBD index churn.
   */
  private onObdUpdate(): void {
    if (!this.board || this.contextLost || this.reinitializing) return;
    if (!renderSettingsStore.settings.showDiodeValues) return;
    const bn = this.getMemoizedObdBoardNumber() ?? undefined;
    if (!boardHasDiodeData(null, bn)) return;
    try {
      this.saveViewportState();
      this.invalidateAllScenes();
      this.activateScene(this.board);
      this.renderSelection();
      this.lastLodScale = -1;
    } catch (err) {
      log.render.warn('onObdUpdate diode rebuild failed:', err);
    }
  }

  /** The dim fades toward the scheme's canvas colour; black on Default. */
  private dimColor(): number {
    return hexToInt(themeStore.activeTheme().board.dimColor ?? '#000000');
  }

  /** 2R Tools — Mesclar / "Pinos por cima": fundo do canvas transparente e
   *  corpos, contorno da placa, cobre, trilhas, vias e serigrafia escondidos,
   *  sobrando pinos, nets, códigos dos componentes e leituras sobre a imagem real. */
  private applyBackgroundAlpha(): void {
    if (this.app && this.app.renderer) {
      this.app.renderer.background.alpha = this.pinsOnTop ? 0 : 1;
    }
  }

  private onCamOverlayUpdate(): void {
    const next = isPinsOnTop();
    if (next === this.pinsOnTop) return;
    this.pinsOnTop = next;
    this.applyBackgroundAlpha();
    if (this.activeScene) this.applyLayerVisibility(this.activeScene);
    this.needsRender = true;
    if (this.app && this.app.renderer && !this.contextLost && !this.reinitializing) this.app.render();
  }

  private onThemeUpdate(): void {
    const board = themeStore.activeTheme().board;
    if (this.app && this.app.renderer) {
      this.app.renderer.background.color = hexToInt(r2Mesa(board.canvasBackground));
      this.applyBackgroundAlpha();
    }
    // A theme change alters BOARD_COLORS (outline / selection / pin+net+part
    // label colours, board fill) even when NO render-setting changed — and the
    // light themes carry no boardOverrides, so routing through onSettingsUpdate
    // would hit its "nothing changed" fast path and skip the rebuild, leaving
    // the already-built BitmapText labels their old colour ("labels staying the
    // same" on a theme switch). Rebuild here whenever the board palette differs.
    // Pure UI-knob / accent changes (theme.board unchanged) skip the rebuild;
    // boardOverride themes (Landrex, custom pin overrides) still rebuild via the
    // render-settings re-merge path wired in themes.ts.
    const key = JSON.stringify(board);
    if (key === this._lastBoardColorKey) return;
    this._lastBoardColorKey = key;
    this.scheduleRebuild();
  }

  /**
   * Debounced full scene rebuild. Colour edits in the theme editors fire on
   * every drag frame; rebuilding the whole PixiJS scene synchronously per frame
   * blocks the colour picker and janks the UI on dense boards. Coalescing into
   * a single rebuild a short time after the LAST change keeps the picker
   * responsive and the board updates once the user pauses. The rebuild also
   * runs off the input-event handler (in the timer), so the UI never blocks
   * mid-interaction. A board switch / Apply pays only the same ~140 ms.
   */
  private scheduleRebuild(): void {
    if (!this.board || this.contextLost || this.reinitializing) return;
    // Settings/theme rebuilds can change net-line color/width derivations
    // without a selection change — drop the A3 memo so the next
    // renderSelection recomputes segments.
    this.lastNetLinesSelKey = null;
    // Settings/theme rebuilds can change net-line color/width derivations
    // without a selection change — drop the A3 memo so the next
    // renderSelection recomputes segments, and force an A5 re-bake.
    this.lastNetLinesSelKey = null;
    this.netLineBakeSig = '';
    if (this._rebuildTimer) clearTimeout(this._rebuildTimer);
    this._rebuildTimer = setTimeout(() => {
      this._rebuildTimer = null;
      if (!this.board || this.contextLost || this.reinitializing || this.destroyed) return;
      // Tab switched away during the debounce window — defer instead (D1).
      if (this.tabId !== null && boardStore.activeTabId !== this.tabId) {
        this.pendingDeferredRebuild = true;
        return;
      }
      this.saveViewportState();
      this.invalidateAllScenes();
      this.activateScene(this.board);
      this.renderSelection();
      this.lastLodScale = -1;
      this.needsRender = true;
    }, 140);
  }

  // --- Selection spotlight (radial darkening around selected part) ---

  /**
   * Build (once, lazily) the radial-gradient texture for the selection
   * spotlight. Solid black at the center, fading smoothly to fully
   * transparent at the edge. No clear core — the brightness of the
   * selected component is preserved by drawing the part's Container
   * ABOVE the spotlight in z-order (see updateHalo).
   *
   * Painted in the scheme's dim colour (black on Default, so Default's
   * texture is the one it always had) and kept per colour: a Sprite tint
   * multiplies, so a black texture cannot be tinted toward a light scheme's
   * paper. On a colour change the old texture is NOT destroyed here — the
   * sprite may still hold it; updateHalo swaps it first, then frees it.
   */
  private buildHaloTexture(color: number): Texture {
    if (this._haloTexture && !this._haloTexture.destroyed && this._haloTextureColor === color) return this._haloTexture;
    const size = 256;
    const canvas = document.createElement('canvas');
    canvas.width = canvas.height = size;
    const ctx = canvas.getContext('2d')!;
    const r = size / 2;
    const rgb = `${(color >> 16) & 255}, ${(color >> 8) & 255}, ${color & 255}`;
    const grad = ctx.createRadialGradient(r, r, 0, r, r, r);
    grad.addColorStop(0.00, `rgba(${rgb}, 0.75)`);
    grad.addColorStop(1.00, `rgba(${rgb}, 0)`);
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, size, size);
    this._haloTexture = Texture.from(canvas);
    this._haloTextureColor = color;
    return this._haloTexture;
  }

  /** Update the spotlight sprite position/visibility to match the current
   *  selection. Called from renderSelection() after the selection state
   *  has been applied. */
  private updateHalo() {
    const sel = boardStore.selection;
    const board = this.board;

    if (boardStore.dimMode !== 'darklight' || sel.partIndex === null || !board) {
      if (this._haloSprite) this._haloSprite.visible = false;
      return;
    }

    const part = board.parts[sel.partIndex];
    if (!part || !this.isPartVisible(part)) {
      if (this._haloSprite) this._haloSprite.visible = false;
      return;
    }

    // (Re)create the sprite if it's missing OR was destroyed underneath us.
    // The halo is parented into the active scene, so a scene rebuild (any
    // settings change) destroys it via `destroy({ children: true })` while this
    // field still references the dead sprite — reading its now-null texture in
    // the `.width` setter below would throw. Rebuild instead of dereferencing it.
    // (Re)create the sprite if it's missing OR was destroyed underneath us.
    // The halo is parented into the active scene, so a scene rebuild (any
    // settings change) destroys it via `destroy({ children: true })` while this
    // field still references the dead sprite — reading its now-null texture in
    // the `.width` setter below would throw. Rebuild instead of dereferencing it.
    if (!this._haloSprite || this._haloSprite.destroyed
        || !this._haloSprite.texture || this._haloSprite.texture.destroyed) {
      if (this._haloSprite && !this._haloSprite.destroyed) {
        try { this._haloSprite.destroy(); } catch { /* ignore */ }
      }
      const prev = this._haloTexture;
      const tex = this.buildHaloTexture(this.dimColor());
      // A texture of the previous dim colour that no live sprite holds any more.
      if (prev && prev !== tex && !prev.destroyed) { try { prev.destroy(true); } catch { /* ignore */ } }
      const spr = new Sprite(tex);
      spr.anchor.set(0.5, 0.5);
      // Decoration only — don't capture pointer events; pins under the
      // halo's painted radius must remain selectable.
      spr.eventMode = 'none';
      this._haloSprite = spr;
    } else {
      // The scheme's dim colour changed since the texture was painted: give
      // the sprite the new one before freeing the old (never while held).
      const old = this._haloSprite.texture;
      const tex = this.buildHaloTexture(this.dimColor());
      if (tex !== old) {
        this._haloSprite.texture = tex;
        try { old.destroy(true); } catch { /* ignore */ }
      }
    }

    const scene = this.activeScene;
    if (!scene) {
      this._haloSprite.visible = false;
      return;
    }

    // Mount the spotlight at the same scene-graph level as netDimGfx — the
    // existing dim overlay — and just before the corresponding selectionGfx.
    // This is exactly the pattern dim mode uses to keep the selected part
    // bright: parts render first, the dim/spotlight darkens them, then
    // selectionGfx re-draws the selected part's outline + bright pins on
    // top. So the spotlight darkens neighbors and the selected part stays
    // visible courtesy of the existing renderSelection machinery — no
    // extra work needed for the part itself.
    const onBottomButterfly = boardStore.butterfly && part.side === 'bottom' && !!scene.butterflyRoot;
    const targetContainer = onBottomButterfly ? scene.butterflyRoot! : scene.root;
    const selSibling = onBottomButterfly ? this.butterflySelectionGfx : this.selectionGfx;

    if (this._haloSprite.parent && this._haloSprite.parent !== targetContainer) {
      this._haloSprite.parent.removeChild(this._haloSprite);
    }
    const selIdx = targetContainer.getChildIndex(selSibling);
    if (this._haloSprite.parent !== targetContainer) {
      if (selIdx >= 0) targetContainer.addChildAt(this._haloSprite, selIdx);
      else targetContainer.addChild(this._haloSprite);
    } else {
      // Already attached — keep it just before the selection sibling.
      const myIdx = targetContainer.getChildIndex(this._haloSprite);
      if (selIdx >= 0 && myIdx !== selIdx - 1 && myIdx !== selIdx) {
        targetContainer.removeChild(this._haloSprite);
        const fresh = targetContainer.getChildIndex(selSibling);
        targetContainer.addChildAt(this._haloSprite, fresh >= 0 ? fresh : targetContainer.children.length);
      }
    }

    // Sprite size — additive growth (not multiplicative), so the dark
    // circle stays generous on tiny passives and doesn't blow up on big
    // BGAs. Floor of 1500 mils (~38 mm) keeps the spotlight imposing on
    // 0402-class parts; for larger parts we add a fixed padding so the
    // gradient extends beyond the part edges without scaling 5× a giant
    // BGA out into the next county.
    const g = focusHaloGeometry(part.bounds);
    this._haloSprite.width  = g.size;
    this._haloSprite.height = g.size;
    this._haloSprite.x = g.x;
    this._haloSprite.y = g.y;
    this._haloSprite.visible = true;
  }

  /** Remove the halo sprite from its parent and hide it (called on scene switch
   *  and destroy so we never leave a dangling reference). */
  private teardownHalo() {
    if (this._haloSprite) {
      if (this._haloSprite.parent) this._haloSprite.parent.removeChild(this._haloSprite);
      this._haloSprite.visible = false;
    }
  }

  // --- Selection blink ---

  private startSelectionBlink() {
    // Clear any existing blink
    if (this.selectionBlinkTimer) {
      clearTimeout(this.selectionBlinkTimer);
      this.selectionBlinkTimer = null;
    }
    this.selectionBlinkPhase = 1;
    // The one full pass: this is the draw of the new selection itself.
    this.renderSelection();

    // Nothing to blink without a primary part — a net focus has none — and
    // each phase would still force a full scene render. On a 39k-trace board
    // that is ~35 ms a render here, twelve times over three seconds, for no
    // visible change at all: measured at 6x throttle as a 210 ms stall every
    // 250 ms until +3.9 s, exactly the blink window.
    if (boardStore.selection.partIndex === null) {
      this.selectionBlinkPhase = 0;
      return;
    }

    const blinkInterval = 250; // ms per phase
    // Each phase forces a full scene render — pixi has no partial redraw —
    // so the blink costs twelve renders over three seconds. On a board where
    // one render already exceeds two 60 Hz frames (39k traces: ~35 ms on a
    // desktop, several hundred on an A12Z), twelve of them is the sluggish
    // three seconds that used to follow a tap on a reference from the PDF.
    // There the blink is a single red flash: same cue, two renders.
    const heavyScene = this.lastRenderMs > 40;
    const totalPhases = heavyScene ? 2 : 12;    // 12 × 250ms = 3 s, or one flash

    // Every later phase redraws ONLY the primary outline. `selectionBlinkPhase`
    // is read in exactly one place — the primary outline's colour — so that is
    // the whole visible effect of a phase. The ticks used to call the full
    // renderSelection(): thirteen rebuilds of every member pin of the lit net,
    // 250 ms apart, for three seconds. On a desktop that is ~28 ms each and
    // invisible; on an A12Z iPad in WebKit, with a 4077-pin GND lit from a PDF
    // tap, each rebuild is several hundred ms and the twelve of them saturate
    // the main thread for the whole window — the "tap lookup blocks pan and
    // zoom for 5–10 s" report. For a net focus there is no primary part, so
    // those twelve rebuilds drew nothing at all.
    const tick = (phase: number) => {
      this.selectionBlinkPhase = phase;
      this.renderSelectionPrimary();
      this.needsRender = true;
      if (phase < totalPhases) {
        this.selectionBlinkTimer = setTimeout(() => tick(phase + 1), blinkInterval);
      } else {
        this.selectionBlinkPhase = 0;
        this.selectionBlinkTimer = null;
        this.renderSelectionPrimary();
      }
      // Flush to GPU even if ticker is paused (e.g. panel inactive during search focus)
      if (!this.app.ticker.started && !this.contextLost) {
        try { this.app.render(); } catch (err) { this.handleRenderCrash(err); }
      }
    };

    this.selectionBlinkTimer = setTimeout(() => tick(2), blinkInterval);
  }

  // --- Selection rendering (always rebuilt, lightweight) ---

  /** Reuse or create a BitmapText in the net label pool, copying properties from a source label.
   *  Inherits the source's `fontFamily` so the clone binds to the same BitmapFont atlas —
   *  otherwise a shadow-baked source label gets cloned onto a plain 'monospace' atlas with
   *  different glyph metrics, producing a low-res ghost sitting a few pixels above the original. */
  private acquireNetLabel(srcLabel: BitmapText) {
    const srcFontSize = srcLabel.style.fontSize as number;
    const srcFontFamily = srcLabel.style.fontFamily as string;
    // Walk past any non-BitmapText children sitting at the current pool
    // index. `renderSelection` raises the selected part's pin labels into
    // netLabelLayer mid-pass, and when `pinNetLabelBg` is enabled those are
    // Container wrappers (background Graphics + BitmapText) rather than bare
    // BitmapTexts. A later `acquireNetLabel` call (e.g. the dim re-clone
    // loop) would otherwise reuse one of those wrappers as a BitmapText and
    // crash on `label.style.fontSize` since Container has no `.style`.
    while (
      this.netLabelPoolIdx < this.netLabelLayer.children.length
      && !(this.netLabelLayer.children[this.netLabelPoolIdx] instanceof BitmapText)
    ) {
      this.netLabelPoolIdx++;
    }
    let label: BitmapText;
    if (this.netLabelPoolIdx < this.netLabelLayer.children.length) {
      label = this.netLabelLayer.children[this.netLabelPoolIdx] as BitmapText;
      label.text = srcLabel.text;
      label.style.fontSize = srcFontSize;
      label.style.fontFamily = srcFontFamily;
    } else {
      label = new BitmapText({
        text: srcLabel.text,
        style: { fontSize: srcFontSize, fill: BOARD_COLORS.labelPin, fontFamily: srcFontFamily },
      });
      this.netLabelLayer.addChild(label);
    }
    // Inherit the source's anchor rather than assuming centred. Single-pin
    // parts anchor their name label's *bottom* to a point above the pad
    // (anchorY 1.0) so it clears the net name; cloning that at 0.5 would drop
    // the white selection copy half a line and ghost the original. Pooled
    // labels must be re-anchored too — the previous occupant's anchor sticks.
    label.anchor.copyFrom(srcLabel.anchor);
    label.x = srcLabel.x;
    label.y = srcLabel.y;
    label.rotation = srcLabel.rotation;
    label.scale.copyFrom(srcLabel.scale);
    label.alpha = 1;
    label.visible = true;
    this.netLabelPoolIdx++;
  }

  /** Draw (only) the primary selection outline into its child Graphics. One
   *  polygon — cheap enough to redraw on every frame whose zoom changed (the
   *  outline's padding and stroke are zoom-dependent, selectionOutlineWorld)
   *  without touching the member boxes and rings in the parent, whose
   *  geometry rebuild is the expensive part. Called from renderSelection too,
   *  so there is one drawing of it. */
  private renderSelectionPrimary(): void {
    this.primarySelGfx?.clear();
    this.butterflyPrimarySelGfx?.clear();
    const sel = boardStore.selection;
    if (sel.partIndex === null || !this.board) return;
    const part = this.board.parts[sel.partIndex];
    // No side-visibility gate here, on purpose: selectPart() does not flip
    // the view to the part's side (focusPart does), and the outline has
    // always been drawn regardless — the label-raise below is what checks
    // visibility. Keeping that parity also keeps the selection findable when
    // a search result sits on the other side.
    // 2R 18/10/2026: peça do lado escondido não desenha seleção por cima do lado à vista
    if (!part || !this.isPartVisible(part)) return;
    const s = renderSettingsStore.settings;
    const butterfly = boardStore.butterfly && !!this.activeScene?.butterflyRoot;
    const gfx = butterfly && part.side === 'bottom' ? this.butterflyPrimarySelGfx : this.primarySelGfx;
    const { pad, stroke } = this.selOutline(part);
    this.lastSelectionPaintScale = this.viewScale();
    // 2R 24/10/2026: a seleção acende o contorno que já existe (o desenhado no componente);
    // window.__r2SelCaixa=true volta à caixa com folga
    const R2b = r2w.__r2SelCaixa ? null : (part as any).__r2box;
    const R2f = () => (R2b ? (R2b.poly ? drawPoly(gfx, R2b.poly) : gfx.rect(R2b.x, R2b.y, R2b.w, R2b.h)) : emitPartOutlineShape(gfx, part, s, pad));
    // Primary (clicked) part: bold WHITE accent + stronger fill so it is
    // unmistakably THE selection amid muted net-members (#23). White stays
    // distinct from the yellow members, the worklist mark colours
    // (amber/red/green) and the cyan selection-set, and matches the white
    // selected-part name label. Focus-blink still flashes red.
    // A palette theme names its own (red on Dark / Landrex, ink on the light schemes).
    const tb = themeStore.activeTheme().board;
    const PRIMARY_SEL = hexToInt(tb.selectedPart ?? '#ffffff');
    const blinkRed = this.selectionBlinkPhase > 0 && this.selectionBlinkPhase % 2 === 1;
    const selColor = blinkRed ? 0xcc2222 : PRIMARY_SEL;
    if (R2b) {
      // 2R 24/10/2026 (Roger: «quando selecionar… linha mais grossa com 20% de efeito neon, só no contorno»)
      R2f(); gfx.stroke({ width: stroke * 7, color: selColor, alpha: 0.07 });
      R2f(); gfx.stroke({ width: stroke * 4.5, color: selColor, alpha: 0.13 });
      R2f(); gfx.stroke({ width: stroke * 2.2, color: selColor, alpha: 1 });
    } else {
      R2f();
      // The wash under the outline (0.50.2): a scheme with a highlighter washes in that colour.
      const washColor = tb.highlighter ? hexToInt(tb.highlighter) : PRIMARY_SEL;
      gfx.fill({ color: washColor, alpha: Math.min(0.22, s.selectionFillAlpha * 3 + 0.08) });
      // ×1.25 over the setting (default 2 px → 2.5 px): enough primacy over
      // the member boxes, without the band the old ×1.7 world-mil stroke became.
      gfx.stroke({ width: stroke * 1.25, color: selColor, alpha: 1.0 });
    }
  }

  private renderSelection() {
    const perf = this.perfVisible;
    const selStart = perf ? performance.now() : 0;

    // HMR safety-net: make sure decoration layers are non-interactive every
    // time we render selection. The constructor sets these once, but Vite
    // HMR can replace the module without re-instantiating the Application
    // (we never call app.destroy() — see CLAUDE.md), leaving stale layers
    // with default 'auto' eventMode that capture clicks over painted lines /
    // dim / spotlight area. Idempotent — the assignments are cheap.
    this.netDimGfx.eventMode = 'none';
    this.netLinesGfx.eventMode = 'none';
    this.crossSideGhostGfx.eventMode = 'none';
    this.selectionGfx.eventMode = 'none';
    this.butterflySelectionGfx.eventMode = 'none';
    this.butterflyDimGfx.eventMode = 'none';
    this.netLabelLayer.eventMode = 'none';
    if (this._haloSprite) this._haloSprite.eventMode = 'none';

    this.needsRender = true;
    // Net-line geometry depends on (net, part, pin, board) AND on the board's
    // orientation: segments are cached in WORLD space (clipToRectEdge →
    // sceneToWorld bakes each part's root transform in), so flipping sides /
    // mirroring / rotating moves the parts but would leave the cached lines
    // behind — they'd render stuck in the pre-flip positions. Include the
    // orientation in the key so a flip recomputes. Hover-dim state is still
    // excluded so it stays cheap (A3).
    {
      const selKey = this.netLinesGeometryKey();
      if (selKey !== this.lastNetLinesSelKey || this.board !== this.lastNetLinesSelBoard) {
        this.lastNetLinesSelKey = selKey;
        this.lastNetLinesSelBoard = this.board;
        this.netLinesDirty = true; // selection actually changed → recompute chain geometry
      }
    }
    this.overlayDirty = true;  // selection/dim change → repaint the label overlay
    this.overlayContentDirty = true;
    // Cancel any in-progress blink from a previous selection
    if (this.selectionBlinkTimer) {
      clearTimeout(this.selectionBlinkTimer);
      this.selectionBlinkTimer = null;
    }
    this.selectionBlinkPhase = 0;
    this.netDimGfx.clear();
    this.butterflyDimGfx.clear();
    this.inkedPins = null;
    for (const { label, fill } of this.inkRecoloured) {
      if (!label.destroyed) label.style.fill = fill;
    }
    this.inkRecoloured.length = 0;
    // Restore any pin labels previously raised above the dim overlay back to
    // their original parents (top/bottom pin layers inside the part container).
    // Visibility is not touched here — LoD (applyLabelVisibility) owns the
    // .visible flag for these labels whether raised or restored.
    if (this.raisedPinLabels.length > 0) {
      for (let i = this.raisedPinLabels.length - 1; i >= 0; i--) {
        const { child, parent, index } = this.raisedPinLabels[i];
        if (child.parent === this.netLabelLayer) {
          this.netLabelLayer.removeChild(child);
        }
        const insertAt = Math.min(index, parent.children.length);
        parent.addChildAt(child, insertAt);
      }
      this.raisedPinLabels.length = 0;
    }
    // Hide all pooled net labels instead of removing (avoids GC churn)
    for (let i = 0; i < this.netLabelLayer.children.length; i++) {
      this.netLabelLayer.children[i].visible = false;
    }
    this.netLabelPoolIdx = 0;
    this.selectionGfx.clear();
    this.butterflySelectionGfx.clear();
    this.crossSideGhostGfx.clear();
    this.crossSideGhostOutlineGfx.clear();
    this.crossSideGhostBakeSig = '';
    this.crossSideGhostParts = new Set();
    this.discoHaloGfx.clear();
    this.discoHaloParts = new Set();
    this.discoHaloDirty = false;
    if (!this.board) return;

    const s = renderSettingsStore.settings;
    const sel = boardStore.selection;
    const butterfly = boardStore.butterfly && !!this.activeScene?.butterflyRoot;

    // Highlight the selected part's in-scene name label by cloning it as a white
    // BitmapText into netLabelLayer (zIndex 20, above board content at zIndex 0).
    // This is the same mechanism used by the net dim code when a pin is selected —
    // acquireNetLabel creates a fill:0xffffff clone at the same position, so the
    // visual result is identical regardless of whether a pin or only a part is selected.
    // (BitmapText style.fill has no runtime effect and tint can't brighten past fill,
    // so modifying the original label in-place cannot achieve full white.)
    this.selectedPartLabelClone = null;
    if (sel.partIndex !== null && this.activeScene) {
      const lbl = this.activeScene.partLabelByIndex.get(sel.partIndex);
      // Clone even when the base label is zoom-CULLED (visible=false): the
      // selected part's name should always read white so it's obvious what's
      // selected, regardless of zoom. (Was gated on `lbl.visible`, which made
      // the white name appear only when zoomed in far enough.)
      if (lbl) {
        this.acquireNetLabel(lbl);
        // The selected part's name clone is always the first pool entry consumed
        // in this pass. Track it so updateSelectedPartLabelAlpha() can fade it
        // when the part fills the screen.
        this.selectedPartLabelClone = this.netLabelLayer.children[this.netLabelPoolIdx - 1] as BitmapText;
      }
    }

    // Pick the right Graphics target for a part (butterfly bottom → butterflySelectionGfx)
    const gfxFor = (part: { side: string }) =>
      butterfly && part.side === 'bottom' ? this.butterflySelectionGfx : this.selectionGfx;

    // ── Highlight all search results ──
    const searchIndices = boardStore.searchResultIndices;
    if (searchIndices.size > 0) {
      const topSearchOutlines: (() => void)[] = [];
      const botSearchOutlines: (() => void)[] = [];
      for (const idx of searchIndices) {
        if (idx === sel.partIndex) continue; // selected part drawn separately
        const part = this.board.parts[idx];
        if (!part || !this.isPartVisible(part)) continue;
        const gfx = gfxFor(part);
        const outlines = gfx === this.butterflySelectionGfx ? botSearchOutlines : topSearchOutlines;
        outlines.push(() => emitPartOutlineShape(gfx, part, s, s.selectionPadding));
      }
      for (const fn of topSearchOutlines) fn();
      if (topSearchOutlines.length > 0) {
        this.selectionGfx.fill({ color: BOARD_COLORS.labelPin, alpha: s.selectionFillAlpha * 0.5 });
        this.selectionGfx.stroke({ width: s.selectionWidth * 0.7, color: BOARD_COLORS.butterflySelection, alpha: 0.5 });
      }
      for (const fn of botSearchOutlines) fn();
      if (botSearchOutlines.length > 0) {
        this.butterflySelectionGfx.fill({ color: BOARD_COLORS.labelPin, alpha: s.selectionFillAlpha * 0.5 });
        this.butterflySelectionGfx.stroke({ width: s.selectionWidth * 0.7, color: BOARD_COLORS.butterflySelection, alpha: 0.5 });
      }
    }

    this.renderSelectionPrimary();
    if (sel.partIndex !== null) {

      // Raise the selected part's pin labels into netLabelLayer so they render
      // above the selection fill (zIndex 30) and the netDim overlay alike.
      // Skip butterfly-bottom labels — they live in butterflyRoot and would
      // render mirrored if moved into scene.root's netLabelLayer.
      // Visibility is NOT forced here — LoD (applyLabelVisibility) still owns
      // the .visible flag, so a label that LoD has hidden (pin numbers not yet
      // rendering at the current zoom) stays hidden even when its part is
      // selected. That matches "pin number / net name labels should only render
      // as soon as pin numbers are" for the selected part.
      const selPart = this.board.parts[sel.partIndex];
      const skipRaise = butterfly && selPart?.side === 'bottom';
      if (selPart && this.isPartVisible(selPart) && !skipRaise && this.activeScene) {
        const pinLabels = this.activeScene.pinLabelsByPartIndex.get(sel.partIndex);
        if (pinLabels) {
          for (const child of pinLabels) {
            if (!child.parent || child.parent === this.netLabelLayer) continue;
            const parent = child.parent as Container;
            const index = parent.getChildIndex(child);
            this.raisedPinLabels.push({ child, parent, index });
            parent.removeChild(child);
            this.netLabelLayer.addChild(child);
          }
        }
      }
    }

    // ── Determine the effective net to highlight (selection or hover in ambient dim) ──
    const dimMode = boardStore.dimMode;
    // Auto-dim on search only *promotes* a user who already runs with dim;
    // it never overrides an explicit dimMode === 'off' (issue #19).
    const searchForcesDim = dimMode !== 'off' && (s.searchAutoDim ?? true) && boardStore.searchSelectionActive;
    // 'dim' mode (or search-forced dim) draws the full dark overlay.
    // 'darklight' mode skips the overlay rect and only shows the spotlight sprite.
    const showDim = dimMode === 'dim' || searchForcesDim;
    const showSpotlight = dimMode === 'darklight';
    const primaryNet = sel.highlightedNet
      || (s.ambientDim && showDim && boardStore.showHoverInfo ? this.hoverNet : null);
    // Set of nets that count as "highlighted" for this frame. For
    // chain-adjacent, includes both the primary and all adjacents; for
    // other modes only the primary. Empty when nothing is selected.
    const activeNets: Array<{ name: string; glowColor: number }> = [];
    const activeNetNames = new Set<string>();
    if (primaryNet) {
      activeNets.push({ name: primaryNet, glowColor: renderSettingsStore.settings.netLineColor ?? COLORS.netHighlight }); // 2R: pads da net na cor da linha
      activeNetNames.add(primaryNet);
      if (boardStore.netLineMode === 'chain-adjacent' && sel.highlightedNet) {
        for (const adj of sel.adjacentNets) {
          if (activeNetNames.has(adj)) continue;
          activeNetNames.add(adj);
          activeNets.push({ name: adj, glowColor: renderSettingsStore.settings.adjacentNetLineColor });
        }
      }
    }
    // "Highlight connections": glow nets shared by ≥2 active-worklist parts.
    // These get the same per-net highlight treatment below but are deliberately
    // NOT fed into the net-line recompute — only an explicitly-selected net
    // draws connecting lines. Computed from the worklist directly so the parts
    // no longer need to be in the cyan selectionSetStore (which would override
    // their mark colours).
    if (boardStore.connectionHighlight) {
      for (const netName of this.computeSharedWorklistNets()) {
        if (activeNetNames.has(netName)) continue;
        activeNetNames.add(netName);
        activeNets.push({ name: netName, glowColor: SHARED_NET_GLOW });
      }
    }
    // Kept for the dim/spotlight gating which only cares about "any net active".
    const effectiveNet = primaryNet;
    // Ambient dim: draw overlay even when nothing is selected/hovered.
    const needsAmbientDim = s.ambientDim && showDim && !effectiveNet;

    // Either ambient dim or the spotlight is in play — both darken the
    // selected part's pins, so we re-draw them above the overlay below.
    // Spotlight-only mode skips the dim rect (that would dim the whole
    // board); only the per-part pin redraw runs.
    const spotlightActive = showSpotlight && sel.partIndex !== null && !effectiveNet;
    if (needsAmbientDim || spotlightActive) {
      if (needsAmbientDim) {
        const b = this.board.bounds;
        const bw = b.maxX - b.minX;
        const bh = b.maxY - b.minY;
        const pad = Math.max(bw, bh) * 5;
        const cx = (b.minX + b.maxX) / 2;
        const cy = (b.minY + b.maxY) / 2;
        this.netDimGfx.rect(cx - pad, cy - pad, pad * 2, pad * 2);
        this.netDimGfx.fill({ color: this.dimColor(), alpha: s.dimOverlayAlpha });
        // Butterfly: mirror the dim into the bottom-half's own gfx so the
        // bottom side also dims (it lives in butterflyRoot, not scene.root).
        if (butterfly) {
          this.butterflyDimGfx.rect(cx - pad, cy - pad, pad * 2, pad * 2);
          this.butterflyDimGfx.fill({ color: this.dimColor(), alpha: s.dimOverlayAlpha });
        }
      }

      // Part-only selection under dim/spotlight: the part's pins are
      // rendered into the original pin layer beneath the overlay, so they
      // get darkened. Re-draw them via selectionGfx (which renders above
      // the overlay) at full alpha so the selected part stays bright.
      if (sel.partIndex !== null) {
        const selPart = this.board.parts[sel.partIndex];
        if (selPart && this.isPartVisible(selPart)) {
          const gfx = gfxFor(selPart);
          const pinDrawsByColor = new Map<number, (() => void)[]>();
          const storedPads = selPart.pins.length === 2 ? this.activeScene?.twoPinPadPolys.get(sel.partIndex) : null;
          const clamp = this.activeScene?.pinRadiusClamp.get(sel.partIndex) ?? Infinity;

          // The pin sprite is a circle, or a capsule when the file gives the
          // pad as an oblong stroke (drawPinShape); when "Show pads" is on,
          // the pad-overlay layer covers it with the real pad shape. The
          // selection halo follows whichever is visible: pad shape when pads
          // are on, otherwise the SAME call the sprite used — so the halo can
          // never reveal geometry the canvas is hiding, and never stamps a
          // circle in the waist of a capsule.
          const usePadShapeForSel = boardStore.showPads;
          for (let pi = 0; pi < selPart.pins.length; pi++) {
            const pin = selPart.pins[pi];
            const isPin1 = pi === 0 && selPart.pins.length > 2;
            const pinColor = (isPin1 && s.showPin1Marker) ? COLORS.pin1 : resolvePinColor(s, pin.net, pin.side);
            let arr = pinDrawsByColor.get(pinColor);
            if (!arr) { arr = []; pinDrawsByColor.set(pinColor, arr); }
            const pb = pin.padBounds;
            if (usePadShapeForSel && storedPads && storedPads[pi]) {
              const padPoly = storedPads[pi];
              arr.push(() => drawPoly(gfx, padPoly));
            } else if (usePadShapeForSel && pb) {
              const padGeom: PadGeometry = {
                bounds: pb,
                shape: pin.padShape,
                width: pin.padWidth,
                height: pin.padHeight,
                angleDeg: pin.padAngleDeg,
                cornerRadius: pin.padCornerRadius,
                polygon: pin.padPolygon,
              };
              arr.push(() => drawPadShape(gfx, padGeom));
            } else {
              const r = Math.min(computePinRadius(s, pin.radius), clamp);
              arr.push(() => drawPinShape(gfx, pin, r));
            }
          }
          for (const [color, fns] of pinDrawsByColor) {
            for (const fn of fns) fn();
            gfx.fill({ color, alpha: 1.0 });
          }

          // The selected part's name clone is already acquired unconditionally
          // at the top of renderSelection; duplicating here renders the same
          // label twice on top of itself. Pin labels are already raised into
          // netLabelLayer above (unconditional raise in the part-outline branch).
        }
      }
    }

    // Hoisted accumulators — populated per-net inside the loop, drained once.
    const seenParts = new Set<number>();
    const ghostPartIndices: number[] = [];
    const seenGhosts = new Set<number>();
    const topPartOutlines: (() => void)[] = [];
    const botPartOutlines: (() => void)[] = [];
    const topByColor = new Map<number, (() => void)[]>();
    const botByColor = new Map<number, (() => void)[]>();
    // Highlight glow draw fns, grouped by glow color so adjacent nets render
    // their pads in adjacentNetLineColor while the primary net stays yellow.
    const topHighlightsByColor = new Map<number, (() => void)[]>();
    const botHighlightsByColor = new Map<number, (() => void)[]>();
    const affectedTopNames = new Set<string>();
    const affectedBotNames = new Set<string>();
    // Light schemes (a theme with a highlighter): the primary net's pins get a
    // highlighter / ink treatment instead of the glow, which does not show on
    // paper. Each entry draws the pin's shape grown by `g` world units.
    const theme = themeStore.activeTheme();
    const lightStyle = theme.board.highlighter ? s.lightSelectionStyle : null;
    // `reach`: how far a halo may grow past this pin before it reaches a
    // neighbour drawn at its largest (Infinity off a dense part).
    type LitPin = { shape: (g: number) => void; color: number; partIndex: number; pinIndex: number; reach: number };
    const litTop: LitPin[] = [];
    const litBot: LitPin[] = [];

    // The per-net highlight runs for a real selection (primaryNet + adjacents)
    // AND for shared "connection" nets even when nothing is singly selected.
    // Dim/spotlight machinery, however, stays tied to a real selection — a
    // bare multi-select shouldn't dim the whole board.
    const dimForHighlight = showDim && !!primaryNet;
    if (activeNets.length > 0) {
      // ── Dim overlay (once per frame, not per-net) ─────────────────────
      if (dimForHighlight) {
        const b = this.board.bounds;
        const bw = b.maxX - b.minX;
        const bh = b.maxY - b.minY;
        const pad = Math.max(bw, bh) * 5;
        const cx = (b.minX + b.maxX) / 2;
        const cy = (b.minY + b.maxY) / 2;
        this.netDimGfx.rect(cx - pad, cy - pad, pad * 2, pad * 2);
        this.netDimGfx.fill({ color: this.dimColor(), alpha: s.dimOverlayAlpha });
        if (butterfly) {
          this.butterflyDimGfx.rect(cx - pad, cy - pad, pad * 2, pad * 2);
          this.butterflyDimGfx.fill({ color: this.dimColor(), alpha: s.dimOverlayAlpha });
        }
      }

      // ── Per-net highlight loop ───────────────────────────────────────
      for (const { name: netName, glowColor } of activeNets) {
        const net = this.board.nets.get(netName);
        if (!net) continue;

        const netUpper = netName.toUpperCase();
        const skipGhosts = netUpper.includes('GND') || isOutlineOnlyNet(s, netUpper);

        // Part outlines + ghost gathering for this net.
        for (const ref of net.pinIndices) {
          if (seenParts.has(ref.partIndex)) continue;
          seenParts.add(ref.partIndex);
          const part = this.board.parts[ref.partIndex];
          if (!part) continue;
          if (!this.isPartVisible(part)) {
            // Type-hidden parts vanish completely — no ghost. Only cross-side
            // (other-layer) parts earn a ghost outline on net select.
            if (!butterfly && !skipGhosts && boardStore.showGhosts
                && !this.isTypeHidden(part.name) && !seenGhosts.has(ref.partIndex)) {
              seenGhosts.add(ref.partIndex);
              ghostPartIndices.push(ref.partIndex);
            }
            continue;
          }

          if (s.showSelectionHalo) {
            // The clicked ("primary") part is drawn separately below with a bold
            // white accent (see the `sel.partIndex` block), so keep it OUT of the
            // muted net-member batch — otherwise it gets both treatments. (#23)
            if (ref.partIndex === sel.partIndex) continue;
            const gfx = gfxFor(part);
            const isBot = gfx === this.butterflySelectionGfx;
            const outlines = isBot ? botPartOutlines : topPartOutlines;
            outlines.push(() => emitPartOutlineShape(gfx, part, s, s.selectionPadding));
          }
        }

        // resolvePinColor walks every pin-group rule and splits its keyword
        // list on each call. Every pin of one net resolves to the same colour
        // for its side, so resolve once per (net, side) per pass — on a
        // 4077-pin rail that was 4077 identical rule walks per redraw.
        const pinColorCache = new Map<string, number>();
        const pinColorFor = (netName: string, side: 'top' | 'bottom'): number => {
          const key = `${netName}|${side}`;
          let c = pinColorCache.get(key);
          if (c === undefined) { c = resolvePinColor(s, netName, side); pinColorCache.set(key, c); }
          return c;
        };
        // Pin glow + dim-redraw collectors for this net.
        for (const ref of net.pinIndices) {
          const part = this.board.parts[ref.partIndex];
          const pin = part?.pins[ref.pinIndex];
          if (!pin || !part || !this.isPartVisible(part)) continue;

          const gfx = gfxFor(part);
          const isBotGfx = gfx === this.butterflySelectionGfx;

          const isPin1 = ref.pinIndex === 0 && part.pins.length > 2;
          // 2R 20/10/2026: com os pads em cinza, a net escolhida acende inteira na cor da linha
          const pinColor = r2PadsColoridos()
            ? ((isPin1 && s.showPin1Marker) ? COLORS.pin1 : pinColorFor(pin.net, pin.side))
            : glowColor;

          // Affected names for label re-clone.
          if (part.side === 'bottom') affectedBotNames.add(part.name);
          else affectedTopNames.add(part.name);

          // Resolve pad geometry once.
          const storedPads = part.pins.length === 2 ? this.activeScene?.twoPinPadPolys.get(ref.partIndex) : null;
          const pb = pin.padBounds;
          const pushDim = (fn: () => void) => {
            // 2R 20/10/2026: pads da net sempre preenchidos (mesmo sem escurecer a placa)
            if (!dimForHighlight && r2PadsColoridos()) return;
            const map = isBotGfx ? botByColor : topByColor;
            let arr = map.get(pinColor);
            if (!arr) { arr = []; map.set(pinColor, arr); }
            arr.push(fn);
          };
          const isSelectedPin =
            ref.partIndex === sel.partIndex && ref.pinIndex === sel.pinIndex;
          const pushGlow = (fn: () => void) => {
            // Landrex / "clean" mode: suppress the yellow halo overlay around
            // every pin on the highlighted net. The explicitly-clicked pin is
            // exempt — it always keeps its halo so the user sees what they
            // selected. Pin recolouring (pushDim path) still runs for the rest,
            // so the selected net is still distinguishable by pin colour.
            if (!s.showSelectionHalo && !isSelectedPin) return;
            const map = isBotGfx ? botHighlightsByColor : topHighlightsByColor;
            let arr = map.get(glowColor);
            if (!arr) { arr = []; map.set(glowColor, arr); }
            arr.push(fn);
          };

          // Same showPads gate as the single-pin selection redraw above —
          // glow + dim must trace the same shape as the pin sprite, or the
          // halo would re-reveal the real pad outline that we just stopped
          // drawing in the pin layer. Off-pads goes through drawPinShape for
          // exactly that reason: it IS the sprite's own call, so a capsule
          // glows as a capsule without the halo widening to the raw pad.
          const usePadShapeForGlow = boardStore.showPads;
          if (lightStyle && glowColor === COLORS.netHighlight) {
            // Drawn in its own pass below, dim or not: the halo goes UNDER the
            // pin, so the pin has to be redrawn on top of it either way.
            let shape: (g: number) => void;
            // The pin's half-size across its narrow side — the side a dense
            // part's neighbour sits on.
            let rSelf: number;
            const clamp = this.activeScene?.pinRadiusClamp.get(ref.partIndex) ?? Infinity;
            if (usePadShapeForGlow && storedPads && storedPads[ref.pinIndex]) {
              const padPoly = storedPads[ref.pinIndex];
              shape = () => drawPoly(gfx, padPoly);   // a stored polygon cannot grow; the halo stroke widens it
              let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
              for (const [x, y] of padPoly) { x0 = Math.min(x0, x); x1 = Math.max(x1, x); y0 = Math.min(y0, y); y1 = Math.max(y1, y); }
              rSelf = Math.min(x1 - x0, y1 - y0) / 2;
            } else if (usePadShapeForGlow && pb) {
              const padGeom: PadGeometry = {
                bounds: pb, shape: pin.padShape, width: pin.padWidth, height: pin.padHeight,
                angleDeg: pin.padAngleDeg, cornerRadius: pin.padCornerRadius, polygon: pin.padPolygon,
              };
              shape = (g) => drawPadShape(gfx, padGeom, g);
              rSelf = Math.min(pb.maxX - pb.minX, pb.maxY - pb.minY) / 2;
            } else {
              const r = Math.min(computePinRadius(s, pin.radius), clamp);
              shape = (g) => drawPinShape(gfx, pin, r, g);
              rSelf = r;
            }
            // The clamp is 45 % of the part's pitch, so a neighbour is never
            // drawn past 0.55 × pitch from this pin's centre: the halo may fill
            // the gap up to there and no further.
            const reach = clamp < Infinity ? Math.max(0, (clamp / 0.45) * 0.55 - rSelf) : Infinity;
            (isBotGfx ? litBot : litTop).push({ shape, color: pinColor, partIndex: ref.partIndex, pinIndex: ref.pinIndex, reach });
          } else if (usePadShapeForGlow && storedPads && storedPads[ref.pinIndex]) {
            const padPoly = storedPads[ref.pinIndex];
            pushDim(() => drawPoly(gfx, padPoly));
            pushGlow(() => drawPoly(gfx, padPoly));
          } else if (usePadShapeForGlow && pb) {
            const grow = s.netHighlightGrow;
            const padGeom: PadGeometry = {
              bounds: pb,
              shape: pin.padShape,
              width: pin.padWidth,
              height: pin.padHeight,
              angleDeg: pin.padAngleDeg,
              cornerRadius: pin.padCornerRadius,
              polygon: pin.padPolygon,
            };
            pushDim(() => drawPadShape(gfx, padGeom));
            pushGlow(() => drawPadShape(gfx, padGeom, grow));
          } else {
            const clamp = this.activeScene?.pinRadiusClamp.get(ref.partIndex) ?? Infinity;
            const r = Math.min(computePinRadius(s, pin.radius), clamp);
            pushDim(() => drawPinShape(gfx, pin, r));
            pushGlow(() => drawPinShape(gfx, pin, r, s.netHighlightGrow));
          }
        }
      }

      // ── Drain accumulated outlines + glow (once per frame) ───────────
      // Net-member parts stay clearly visible (full net colour) so it's obvious
      // which parts are connected; the distinction from the primary comes from
      // the primary's bold WHITE outline (drawn in the `sel.partIndex` block
      // above), not from dimming the members. (#23)
      const memberWidth = s.selectionWidth;
      const memberStrokeAlpha = 0.85;
      for (const fn of topPartOutlines) fn();
      if (topPartOutlines.length > 0) {
        this.selectionGfx.fill({ color: BOARD_COLORS.labelPin, alpha: s.selectionFillAlpha });
        this.selectionGfx.stroke({ width: memberWidth, color: COLORS.netHighlight, alpha: memberStrokeAlpha });
      }
      for (const fn of botPartOutlines) fn();
      if (botPartOutlines.length > 0) {
        this.butterflySelectionGfx.fill({ color: BOARD_COLORS.labelPin, alpha: s.selectionFillAlpha });
        this.butterflySelectionGfx.stroke({ width: memberWidth, color: COLORS.netHighlight, alpha: memberStrokeAlpha });
      }

      // Re-clone affected labels above the dim overlay.
      if (dimForHighlight && this.activeScene) {
        const selectedPartName = sel.partIndex !== null ? this.board.parts[sel.partIndex]?.name : null;
        if (this.isTopVisible) {
          for (const srcLabel of this.activeScene.topLabels) {
            if (!srcLabel.visible || !affectedTopNames.has(srcLabel.text)) continue;
            if (selectedPartName && srcLabel.text === selectedPartName) continue;
            this.acquireNetLabel(srcLabel);
          }
        }
        if (this.isBottomVisible && !butterfly) {
          for (const srcLabel of this.activeScene.bottomLabels) {
            if (!srcLabel.visible || !affectedBotNames.has(srcLabel.text)) continue;
            if (selectedPartName && srcLabel.text === selectedPartName) continue;
            this.acquireNetLabel(srcLabel);
          }
        }
      }

      // Light-scheme pass for the primary net (see lightStyle above).
      if (lightStyle) {
        const ink = hexToInt(theme.board.selectedPart ?? theme.board.labelPart);
        const hl = hexToInt(theme.board.highlighter!);
        const haloW = Math.max(s.netHighlightGrow * 3, 8);   // world units, each side of the pin
        const ringW = Math.max(s.selectionWidth * 0.6, 1);
        const pass = (gfx: Graphics, lit: LitPin[]) => {
          if (lit.length === 0) return;
          if (lightStyle !== 'ink') {
            // Highlighter halo: the pin's own shape, filled and stroked wide in yellow.
            for (const p of lit) p.shape(0);
            gfx.fill({ color: hl, alpha: 0.95 });
            // Stroked per halo width: on a fine-pitch part the halo stops where
            // a neighbour could begin (`reach`), so it never paints over pins
            // that are not on the net — the 8-mil floor holds only where it fits.
            const byWidth = new Map<number, LitPin[]>();
            for (const p of lit) {
              const w = Math.min(haloW, p.reach);
              if (w <= 0) continue;
              const a = byWidth.get(w); if (a) a.push(p); else byWidth.set(w, [p]);
            }
            for (const [w, pins] of byWidth) {
              for (const p of pins) p.shape(0);
              gfx.stroke({ width: w * 2, color: hl, alpha: 0.95, join: 'round' });
            }
          } else {
            // White rim around the ink pin.
            for (const p of lit) p.shape(0);
            gfx.stroke({ width: ringW * 3, color: 0xffffff, alpha: 1, join: 'round' });
          }
          if (lightStyle === 'highlighter') {
            // The pin in its own colour, then a thin ink ring just outside it.
            const byColor = new Map<number, ((g: number) => void)[]>();
            for (const p of lit) { const a = byColor.get(p.color); if (a) a.push(p.shape); else byColor.set(p.color, [p.shape]); }
            for (const [color, shapes] of byColor) { for (const sh of shapes) sh(0); gfx.fill({ color, alpha: 1 }); }
            for (const p of lit) p.shape(s.netHighlightGrow * 0.5);
            gfx.stroke({ width: ringW, color: ink, alpha: 1 });
          } else {
            for (const p of lit) p.shape(0);
            gfx.fill({ color: ink, alpha: 1 });
          }
        };
        pass(this.selectionGfx, litTop);
        pass(this.butterflySelectionGfx, litBot);
        // Ink-filled pins: their labels must read against the ink, not the pin
        // colour they were built against. The overlay reads `inkedPins`; on the
        // BitmapText path only the selected part's raised labels sit above the
        // fill, so those are recoloured here and given back on the next pass.
        if (lightStyle !== 'highlighter' && (litTop.length > 0 || litBot.length > 0)) {
          const inked = new Map<number, Set<number>>();
          for (const p of litTop.length > 0 ? litTop.concat(litBot) : litBot) {
            let set = inked.get(p.partIndex);
            if (!set) { set = new Set(); inked.set(p.partIndex, set); }
            set.add(p.pinIndex);
          }
          this.inkedPins = inked;
          const selInked = sel.partIndex !== null ? inked.get(sel.partIndex) : undefined;
          if (selInked) {
            for (const { child } of this.raisedPinLabels) {
              if (!(child instanceof BitmapText)) continue;
              const info = pinLabelInk.get(child);
              if (!info || !selInked.has(info.pinIndex)) continue;
              this.inkRecoloured.push({ label: child, fill: child.style.fill });
              child.style.fill = info.color;
            }
          }
        }
      }

      // Pin redraws above dim, grouped by pin color (full alpha).
      for (const [color, fns] of topByColor) {
        for (const fn of fns) fn();
        this.selectionGfx.fill({ color, alpha: 1.0 });
      }
      for (const [color, fns] of botByColor) {
        for (const fn of fns) fn();
        this.butterflySelectionGfx.fill({ color, alpha: 1.0 });
      }

      // Highlight glow on top, per glow color (yellow for primary, bluish
      // for adjacents). Each color group flushes its own fill, then a stroke
      // on the same path traces a crisp ring at the glow's outer edge — that
      // ring sits beyond the pad and outside any pin label that renders on
      // top of selectionGfx, so it carries the "highlighted" cue past the
      // label coverage on dense BGA rails.
      const ringW = s.selectionWidth * 0.6;
      for (const [glowColor, fns] of topHighlightsByColor) {
        for (const fn of fns) fn();
        this.selectionGfx.fill({ color: glowColor, alpha: s.netHighlightAlpha });
        this.selectionGfx.stroke({ width: ringW, color: glowColor, alpha: 0.95 });
      }
      for (const [glowColor, fns] of botHighlightsByColor) {
        for (const fn of fns) fn();
        this.butterflySelectionGfx.fill({ color: glowColor, alpha: s.netHighlightAlpha });
        this.butterflySelectionGfx.stroke({ width: ringW, color: glowColor, alpha: 0.95 });
      }

      // ── Trace highlight (PRIMARY net only) ───────────────────────────
      if (primaryNet && this.board.traces && this.board.traces.length > 0 && boardStore.showTraces && !this.copperHidden) {
        const netName = primaryNet;
        const { layerStates } = boardStore;
        const traceByColor = new Map<number, { sx: number; sy: number; ex: number; ey: number }[]>();
        for (const t of this.board.traces) {
          if (t.net !== netName) continue;
          let color: number = COLORS.netHighlight;
          if (t.layer != null && t.layer < layerStates.length) {
            color = layerStates[t.layer].color;
          }
          let arr = traceByColor.get(color);
          if (!arr) { arr = []; traceByColor.set(color, arr); }
          arr.push({ sx: t.start.x, sy: t.start.y, ex: t.end.x, ey: t.end.y });
        }
        for (const [c, segs] of traceByColor) {
          for (const s2 of segs) {
            this.selectionGfx.moveTo(s2.sx, s2.sy);
            this.selectionGfx.lineTo(s2.ex, s2.ey);
          }
          this.selectionGfx.stroke({ width: 3, color: c as number & 0xffffff, alpha: 0.9, join: 'round', cap: 'round' });
        }
      }

      // ── Via highlight (PRIMARY net only) ─────────────────────────────
      if (primaryNet && this.board.vias && this.board.vias.length > 0 && boardStore.showVias && this.activeScene) {
        const netName = primaryNet;
        const { layerStates } = boardStore;
        const connMap = this.activeScene.viaConnectedLayers;
        const selectedPart = sel.partIndex !== null ? this.board.parts[sel.partIndex] : null;
        const sourceLayer = selectedPart?.layer ?? -1;
        const byColor = new Map<number, { x: number; y: number }[]>();

        for (let vi = 0; vi < this.board.vias.length; vi++) {
          const via = this.board.vias[vi];
          if (via.net !== netName) continue;
          const connected = connMap[vi] ?? [];
          let color: number = COLORS.netHighlight;
          if (connected.length >= 2 && layerStates.length > 0) {
            let targetIdx: number;
            if (connected[0] === sourceLayer) {
              targetIdx = connected[connected.length - 1];
            } else if (connected[connected.length - 1] === sourceLayer) {
              targetIdx = connected[0];
            } else {
              targetIdx = Math.abs(connected[0] - sourceLayer) > Math.abs(connected[connected.length - 1] - sourceLayer)
                ? connected[0]
                : connected[connected.length - 1];
            }
            if (targetIdx < layerStates.length) color = layerStates[targetIdx].color;
          } else if (connected.length === 1 && layerStates.length > 0) {
            const idx = connected[0];
            if (idx < layerStates.length) color = layerStates[idx].color;
          }
          let arr = byColor.get(color);
          if (!arr) { arr = []; byColor.set(color, arr); }
          arr.push(via.position);
        }
        for (const [c, positions] of byColor) {
          for (const { x, y } of positions) {
            this.selectionGfx.moveTo(x - 12, y).lineTo(x + 12, y);
            this.selectionGfx.moveTo(x, y - 12).lineTo(x, y + 12);
            this.selectionGfx.circle(x, y, 10);
          }
          this.selectionGfx.stroke({ width: 2.5, color: c as number & 0xffffff, alpha: 0.95 });
        }
      }

      this.crossSideGhostParts = new Set(ghostPartIndices);
    }

    // Text-fast-mode overlay: `seenParts` is exactly the set of net-member
    // parts that punch through the ambient-dim overlay (their pins/labels are
    // re-drawn above netDimGfx). Empty when nothing is highlighted, in which
    // case only the selected part stays lit (the overlay handles that). A fresh
    // Set is allocated per renderSelection call, so aliasing the field is safe.
    // Pure search-dim (auto-dim promoted by an active search, no net
    // selected): the Pixi path dims around the search RESULTS — feed the
    // match set into the overlay's lit-part set so Text fast mode
    // spotlights them identically (v0.31.40 review parity follow-up).
    if (seenParts.size === 0 && searchForcesDim && !effectiveNet) {
      const matches = boardStore.searchResultIndices;
      if (matches && matches.size > 0) {
        for (const idx of matches) seenParts.add(idx);
      }
    }
    this.litPartIndices = seenParts;

    // ── Disco mode: collect part indices on the highlighted net so the
    //    ticker can pulse a red outline over each (both sides). ────────────
    if (boardStore.discoHighlight && sel.highlightedNet) {
      const netEntry = this.board.nets.get(sel.highlightedNet);
      if (netEntry) {
        const set = new Set<number>();
        for (const ref of netEntry.pinIndices) set.add(ref.partIndex);
        this.discoHaloParts = set;
      }
    }

    // ── Cross-side ghost components (hidden side, pulsing semi-transparent) ──
    this.renderCrossSideGhosts();
    this.renderDiscoHalo();

    // ── Elevated labels for selected part/pin ───────────────────────────────
    this.updateElevatedLabels(sel, s);

    // ── Selection overlay (big centered text) ─────────────────────────────
    this.updateSelectionOverlay(sel, s);

    // ── Selection halo ────────────────────────────────────────────────────
    this.updateHalo();

    if (perf) this.perfAccum.selection += performance.now() - selStart;

    const nlStart = perf ? performance.now() : 0;
    this.renderNetLines();
    if (perf) this.perfAccum.netLines += performance.now() - nlStart;
  }

  /**
   * Elevated selection labels — floating name badges for the selected part and pin.
   *
   * These are the primary visual feedback for the current selection and must render
   * on top of ALL board content. They use zIndex 100-103 on scene.root (which has
   * sortableChildren=true) so they overlap pins, borders, and the selection highlight.
   *
   * Architecture:
   *   - 4 persistent PixiJS objects: partBg + partLbl, pinBg + pinLbl
   *   - Created once in init(), reused across scene switches (never destroyed mid-session)
   *   - Attached to scene.root so they follow board flips/rotations
   *   - Counter-flip transform keeps text readable when the board is flipped/rotated
   *
   * Customisation points (for manual editing):
   *   - screenFontPx: label font size in screen pixels (constant across zoom levels)
   *   - pad / cornerR: background padding and corner radius
   *   - partBg fill: color 0x000000, alpha 0.75 (dark semi-transparent)
   *   - pinBg fill: color 0x1a1a2e, alpha 0.85 (dark blue semi-transparent)
   *   - Pin label placement: tries above pin first, flips below if overlapping part label
   */
  private updateElevatedLabels(
    sel: { partIndex: number | null; pinIndex: number | null; highlightedNet: string | null; adjacentNets: Set<string> },
    s: import('../store/render-settings').RenderSettings,
  ) {
    const partBg = this.elevatedPartBg!;
    const partLbl = this.elevatedPartLabel!;
    const pinBg = this.elevatedPinBg!;
    const pinLbl = this.elevatedPinLabel!;

    // Hide all labels by default — early returns leave them hidden
    partBg.visible = false;
    partLbl.visible = false;
    pinBg.visible = false;
    pinLbl.visible = false;

    if (!this.board || sel.partIndex === null || !this.activeScene) return;
    const part = this.board.parts[sel.partIndex];
    if (!part) return;

    // The selected part's name must read clearly WHITE at every zoom. The clone
    // sits directly over the (same-size) base part label, so keeping it opaque
    // covers no more pins than the base label already did — the old fade to 0.55
    // only let the grey base show through, making the name look grey when zoomed
    // in. Keep it fully white.
    const clone = this.selectedPartLabelClone;
    if (clone && clone.visible) {
      clone.alpha = 1;
    }

    // Font size is constant in screen pixels — divide by viewport scale to get world units
    const vpScale = Math.abs(this.viewport.scale.x);
    const screenFontPx = 18;                       // ← change this to resize labels
    const fontSize = screenFontPx / vpScale;
    const pad = 4 / vpScale;                        // ← background padding around text
    const cornerR = 3 / vpScale;                    // ← background corner radius

    // Counter-flip: scene root may be flipped (scale.x or scale.y negative) or rotated.
    // Labels must stay upright and readable, so we invert the root's transform on each label.
    const root = this.activeScene.root;
    const lsx = Math.sign(root.scale.x) || 1;       // -1 when horizontally flipped
    const lsy = Math.sign(root.scale.y) || 1;       // -1 when vertically flipped
    const labelRot = -root.rotation * lsx * lsy;     // cancel root rotation

    const applyCounterFlip = (lbl: BitmapText) => {
      lbl.scale.set(lsx, lsy);
      lbl.rotation = labelRot;
    };

    const applyCounterFlipGfx = (gfx: Graphics, cx: number, cy: number) => {
      gfx.position.set(cx, cy);
      gfx.scale.set(lsx, lsy);
      gfx.rotation = labelRot;
    };

    // Estimate text dimensions directly from font metrics (avoids stale getBounds during zoom)
    const charW = fontSize * 0.6;   // approximate character width for bitmap font
    const lineH = fontSize * 1.15;  // approximate line height
    const measure = (text: string) => ({
      w: text.length * charW + pad * 2,
      h: lineH + pad * 2,
    });

    // ── Part label: centered on the part's bounding box ──
    let partLabelCx = 0, partLabelCy = 0, partLabelHW = 0, partLabelHH = 0;
    if (s.showElevatedPartLabel) {
      const rb = computePartRenderBounds(part, s);
      partLabelCx = rb.px + rb.pw / 2;
      partLabelCy = rb.py + rb.ph / 2;
      partLbl.style.fontSize = fontSize;
      partLbl.text = part.name;
      partLbl.x = partLabelCx;
      partLbl.y = partLabelCy;
      applyCounterFlip(partLbl);
      partLbl.visible = true;

      const pm = measure(part.name);
      partLabelHW = pm.w / 2;
      partLabelHH = pm.h / 2;
      partBg.clear();
      partBg.roundRect(-partLabelHW, -partLabelHH, pm.w, pm.h, cornerR);
      partBg.fill({ color: 0x000000, alpha: 0.75 });
      applyCounterFlipGfx(partBg, partLabelCx, partLabelCy);
      partBg.visible = true;
    }

    // ── Pin label: positioned above (or below) the selected pin ──
    if (s.showElevatedPinLabel && sel.pinIndex !== null && sel.pinIndex >= 0) {
      const pin = part.pins[sel.pinIndex];
      if (pin) {
        const pinId = pinDisplayId(pin, sel.pinIndex);
        const hasNet = pin.net && pin.net !== '(null)' && pin.net !== '';
        const pinText = hasNet ? `${pin.net} (${pinId})` : pinId;
        pinLbl.style.fontSize = fontSize;
        pinLbl.text = pinText;
        const cx = pin.position.x;
        const clamp = this.activeScene?.pinRadiusClamp.get(sel.partIndex!) ?? Infinity;
        const r = Math.min(computePinRadius(s, pin.radius), clamp);
        const yOffset = (r + fontSize * 0.8) * lsy;

        const pnm = measure(pinText);
        const pinHalfW = pnm.w / 2;
        const pinHalfH = pnm.h / 2;

        // Default: above the pin. If that overlaps the part label, flip below.
        let cy = pin.position.y - yOffset;
        if (s.showElevatedPartLabel) {
          const overlaps = cx + pinHalfW > partLabelCx - partLabelHW &&
                           cx - pinHalfW < partLabelCx + partLabelHW &&
                           cy + pinHalfH > partLabelCy - partLabelHH &&
                           cy - pinHalfH < partLabelCy + partLabelHH;
          if (overlaps) {
            // Try below the pin
            cy = pin.position.y + yOffset;
            // If still overlapping, push pin label fully clear of part label
            const stillOverlaps = cx + pinHalfW > partLabelCx - partLabelHW &&
                                  cx - pinHalfW < partLabelCx + partLabelHW &&
                                  cy + pinHalfH > partLabelCy - partLabelHH &&
                                  cy - pinHalfH < partLabelCy + partLabelHH;
            if (stillOverlaps) {
              cy = partLabelCy + partLabelHH + pinHalfH + pad;
            }
          }
        }

        pinLbl.x = cx;
        pinLbl.y = cy;
        applyCounterFlip(pinLbl);
        pinLbl.visible = true;

        pinBg.clear();
        pinBg.roundRect(-pinHalfW, -pinHalfH, pnm.w, pnm.h, cornerR);
        pinBg.fill({ color: 0x1a1a2e, alpha: 0.85 });
        applyCounterFlipGfx(pinBg, cx, cy);
        pinBg.visible = true;
      }
    }

    // Z-priority swap: when a pin is selected, its label should render above the
    // part label. When only a part is selected, reverse the order.
    // scene.root.sortableChildren=true uses zIndex for ordering.
    if (sel.pinIndex !== null && sel.pinIndex >= 0) {
      // Pin selected → pin badge on very top (zIndex 102/103 > 100/101)
      partBg.zIndex = 100;
      partLbl.zIndex = 101;
      pinBg.zIndex = 102;
      pinLbl.zIndex = 103;
    } else {
      // Only part selected → part badge on very top
      pinBg.zIndex = 100;
      pinLbl.zIndex = 101;
      partBg.zIndex = 102;
      partLbl.zIndex = 103;
    }
  }

  /** Update the DOM selection overlay at top-center of the board view */
  private updateSelectionOverlay(
    sel: { partIndex: number | null; pinIndex: number | null; highlightedNet: string | null; adjacentNets: Set<string> },
    s: import('../store/render-settings').RenderSettings,
  ) {
    if (!this.selectionOverlayEl) return;
    if (!s.showSelectionOverlay || !this.board || sel.partIndex === null) {
      this.selectionOverlayEl.style.display = 'none';
      return;
    }
    const part = this.board.parts[sel.partIndex];
    if (!part) {
      this.selectionOverlayEl.style.display = 'none';
      return;
    }

    let text: string;
    if (sel.pinIndex !== null) {
      const pin = part.pins[sel.pinIndex];
      const pinName = pin?.name ?? `${sel.pinIndex}`;
      const net = sel.highlightedNet && sel.highlightedNet !== '(null)' && sel.highlightedNet !== ''
        ? sel.highlightedNet : null;
      text = net ? `${part.name}.${pinName}→${net}` : `${part.name}.${pinName}`;
    } else {
      text = part.name;
    }

    this.selectionOverlayEl.textContent = text;
    this.selectionOverlayEl.style.display = '';
  }

  /** Build a refdes → partIndex map for the current board in a single O(N)
   *  pass. Shared by the worklist-resolution sites (computeSharedWorklistNets
   *  and redrawMultiHighlight) so both re-resolve stored entries identically.
   *  Last-write-wins on duplicate refdes (matches redrawMultiHighlight's prior
   *  inline loop). Empty map when there's no board. */
  private buildRefdesIndex(): Map<string, number> {
    // Cached per board identity — derived boards are fresh objects, so a
    // simple identity check is a correct invalidation (A4).
    if (this.refdesIndexCache && this.refdesIndexBoard === this.board) {
      return this.refdesIndexCache;
    }
    const byRefdes = new Map<string, number>();
    const parts = this.board?.parts;
    if (parts) {
      for (let i = 0; i < parts.length; i++) {
        const n = parts[i]?.name;
        if (n) byRefdes.set(n, i);
      }
    }
    this.refdesIndexBoard = this.board;
    this.refdesIndexCache = byRefdes;
    return byRefdes;
  }

  /** Nets shared by ≥2 parts in the **active worklist** — used when the
   *  Highlight toggle is on. Resolves refdes → partIndex against the live board
   *  so fold-mode / sub-board changes don't stale-index. Same exclusion rules
   *  as the former selection-set glow (GND / outline-only filtered out). Returns
   *  [] when the worklist has fewer than 2 resolved parts. */
  private computeSharedWorklistNets(): string[] {
    if (!this.board) return [];
    const worklist = worklistStore.activeWorklist;
    if (!worklist || worklist.entries.length < 2) return [];
    const s = renderSettingsStore.settings;
    // O(1) refdes lookup instead of a findIndex per entry (was O(entries × parts)).
    const byRefdes = this.buildRefdesIndex();
    const count = new Map<string, number>();
    for (const e of worklist.entries) {
      const partIdx = byRefdes.get(e.refdes);
      if (partIdx === undefined) continue;
      const part = this.board.parts[partIdx];
      if (!part) continue;
      const seen = new Set<string>();
      for (const pin of part.pins) {
        const net = pin.net;
        if (!net || seen.has(net)) continue;
        seen.add(net);
        const up = net.toUpperCase();
        if (up.includes('GND') || isOutlineOnlyNet(s, up)) continue;
        count.set(net, (count.get(net) ?? 0) + 1);
      }
    }
    const result: string[] = [];
    for (const [net, c] of count) if (c >= 2) result.push(net);
    return result;
  }

  // --- Net lines rendering ---

  /** Everything the cached net-line segments are a function of: the lit
   *  net / part / pin, the mode (which lines exist at all — 'off' none, star
   *  vs chain a different set, chain-adjacent the adjacent nets too), and the
   *  board's orientation (segments are baked in WORLD space through each
   *  root's transform). Pan and zoom are deliberately absent: they never move
   *  world-space segments. One key, so a new input cannot be added to one
   *  check and forgotten in another — the mode was missing from both. */
  private netLinesGeometryKey(): string {
    const sel = boardStore.selection;
    const mode = boardStore.netLineMode;
    return `${sel.highlightedNet ?? ''}|${sel.partIndex ?? -1}|${sel.pinIndex ?? -1}`
      + `|${mode}|${mode === 'chain-adjacent' ? [...sel.adjacentNets].join(',') : ''}`
      + `|${boardStore.butterfly}|${boardStore.showTop}|${boardStore.showBottom}`
      + `|${boardStore.flipAxis}|${boardStore.mirrorX}|${boardStore.mirrorY}|${boardStore.rotation}`;
  }

  /** Put the net-line Graphics back in plain world space. A live two-finger
   *  rotation turns them rigidly with the roots (rotateLive) instead of
   *  recomputing per move; any recompute projects through the roots as they
   *  are now, so the carried turn must be dropped at the same moment or it
   *  would be applied twice. */
  private resetNetLinesTransform() {
    for (const g of [this.netLinesGfx, this.netLinesPulseGfx]) {
      if (!g || g.destroyed) continue;
      if (g.rotation !== 0 || g.position.x !== 0 || g.position.y !== 0) {
        g.rotation = 0;
        g.position.set(0, 0);
      }
    }
  }

  /** Recompute cached net line segments (start/end points + color) when selection or viewport changes */
  /** 2R 24/10/2026: nomes dos componentes da net (etiquetas do ui/boardripper_alt.py, via window.__2rRs) */
  __r2Tags: Array<{ n: string; x: number; y: number; y1: number; d: string; dc: number }> = [];
  private recomputeNetLineSegments() {
    this.__r2Tags = [];
    void this.clipToRectEdge; // 2R: as linhas saem do pino; a função fica para o modo antigo do upstream
    (r2w.__2rRs || (r2w.__2rRs = new Set())).add(this);
    this.netLineSegments = [];
    this.netLineSegmentsByColor.clear();
    this.netLineFadeDist = 0;
    this.netLinesDirty = false;
    this.resetNetLinesTransform();

    const mode = boardStore.netLineMode;
    if (!this.board || mode === 'off') return;

    const sel = boardStore.selection;
    if (!sel.highlightedNet) return;

    const s = renderSettingsStore.settings;

    type NetEntry = { name: string; color: number };
    const activeNets: NetEntry[] = [{ name: sel.highlightedNet, color: s.netLineColor }];
    if (mode === 'chain-adjacent') {
      for (const adj of sel.adjacentNets) {
        activeNets.push({ name: adj, color: s.adjacentNetLineColor });
      }
    }

    for (const entry of activeNets) {
      this.appendNetLineSegmentsFor(entry.name, entry.color, mode, sel, s);
    }
    // One line per recompute (a selection or mode change, never per frame):
    // the record to read off a device when "the lines did not change".
    log.render.log(`net lines: mode=${mode} net=${sel.highlightedNet} part=${sel.partIndex ?? '-'} pin=${sel.pinIndex ?? '-'} adjacent=${sel.adjacentNets.size} segments=${this.netLineSegments.length}`);

    // Bucketise by colour once. The per-frame renderNetLines path iterates
    // these directly with no further allocation (was: rebuilt each frame).
    for (const seg of this.netLineSegments) {
      let arr = this.netLineSegmentsByColor.get(seg.color);
      if (!arr) { arr = []; this.netLineSegmentsByColor.set(seg.color, arr); }
      arr.push(seg);
    }
  }

  /** Build segments for a single net and append them to `netLineSegments`,
   *  tagging each with `color`. Extracted from the original
   *  recomputeNetLineSegments body. */
  private appendNetLineSegmentsFor(
    netName: string,
    color: number,
    mode: NetLineMode,
    sel: SelectionState,
    s: import('../store/render-settings').RenderSettings,
  ) {
    if (!this.board) return;
    const net = this.board.nets.get(netName);
    if (!net) return;

    // Skip GND/NC nets — GND connects too many components, NC is not a real net.
    const netUpper = netName.toUpperCase();
    if (netUpper.includes('GND') || isOutlineOnlyNet(s, netUpper)) return;

    // For chain-adjacent, force chain topology on adjacent nets even if the
    // primary selection prefers star — star requires a part anchor that the
    // adjacent net does not have. The selected net keeps its mode.
    const isPrimary = netName === sel.highlightedNet;
    const effectiveMode: NetLineMode = isPrimary ? mode : 'chain';

    if (effectiveMode === 'star' && sel.partIndex !== null && isPrimary) {
      // ── Star topology from selected part to all others on the net ──
      const selectedPartIdx = sel.partIndex;
      const selectedPart = this.board.parts[selectedPartIdx];
      if (!selectedPart) return;

      const selectedRoot = this.rootForPart(selectedPart);
      const selEB = computePartRenderBounds(selectedPart, s);
      const selectedPin = sel.pinIndex !== null ? selectedPart.pins[sel.pinIndex] : null;
      const selCenterW = selectedPin
        ? this.sceneToWorld(selectedPin.position, selectedRoot)
        : this.sceneToWorld({ x: selEB.px + selEB.pw / 2, y: selEB.py + selEB.ph / 2 }, selectedRoot);

      const partNetPins = new Map<number, number[]>();
      for (const ref of net.pinIndices) {
        if (ref.partIndex === sel.partIndex) continue;
        let arr = partNetPins.get(ref.partIndex);
        if (!arr) { arr = []; partNetPins.set(ref.partIndex, arr); }
        arr.push(ref.pinIndex);
      }

      let targetCount = 0;
      for (const [partIndex, pinIndices] of partNetPins) {
        const part = this.board.parts[partIndex];
        if (!part) continue;
        const isGhost = !this.isPartVisible(part) && this.crossSideGhostParts.has(partIndex);
        if (!this.isPartVisible(part) && !isGhost) continue;

        const root = isGhost ? this.activeScene?.root : this.rootForPart(part);

        let bestPin: Point | null = null;
        let bestDist = Infinity;
        for (const pi of pinIndices) {
          const pin = part.pins[pi];
          if (!pin) continue;
          const pw = this.sceneToWorld(pin.position, root);
          const dx = pw.x - selCenterW.x;
          const dy = pw.y - selCenterW.y;
          const d = dx * dx + dy * dy;
          if (d < bestDist) { bestDist = d; bestPin = pw; }
        }

        if (bestPin) {
          // 2R: a linha sai do PINO (não da borda do componente); BOTTOM em azul-claro
          this.netLineSegments.push({ start: selCenterW, end: bestPin, color: r2w.__r2OutraFace !== false && part.side === 'bottom' ? 4178935 : color });
        }
        targetCount++;
      }

      const vpScale = Math.abs(this.viewport.scale.x);
      this.netLineFadeDist = Math.max(this.netLineFadeDist, targetCount > 8 ? 60 / vpScale : 0);
    } else {
      // ── Chain mode ──
      // 2R 20/10/2026 (Roger): linha liga PINO a PINO (árvore mínima pelos pinos mais próximos de cada par de componentes)
      const f = new Map<number, number[]>();
      for (const ref of net.pinIndices) {
        let q = f.get(ref.partIndex);
        if (!q) { q = []; f.set(ref.partIndex, q); }
        q.push(ref.pinIndex);
      }
      const R2BB = (v: Part, w: Container | undefined) => {
        const k = computePartRenderBounds(v, s);
        const c4 = [[k.px, k.py], [k.px + k.pw, k.py], [k.px, k.py + k.ph], [k.px + k.pw, k.py + k.ph]]
          .map(q => this.sceneToWorld({ x: q[0], y: q[1] }, w));
        let x0 = Infinity, x1 = -Infinity, y0 = Infinity, y1 = -Infinity;
        for (const q of c4) { if (q.x < x0) x0 = q.x; if (q.x > x1) x1 = q.x; if (q.y < y0) y0 = q.y; if (q.y > y1) y1 = q.y; }
        return { x0, x1, y0, y1 };
      };
      // 2R 24/10/2026 22h (Roger: «quando tem uma linha que vai para a outra face da placa, tem que ter outra NET com cor
      // diferente»): pinos da net na outra face entram na linha, e o trecho até eles sai em azul-claro
      // (window.__r2OutraFace=false desliga)
      const R2OF = r2w.__r2OutraFace !== false, R2OC = 4178935;
      const ol: boolean[] = [], h: Point[][] = [], bx: Array<{ x0: number; x1: number; y0: number; y1: number }> = [], ix: number[] = [];
      for (const [pI, qs] of f) {
        const v = this.board.parts[pI];
        if (!v) continue;
        const x = !this.isPartVisible(v) && this.crossSideGhostParts.has(pI);
        const oface = !x && R2OF && !this.isPartVisible(v) && !v.hidden && !this.isTypeHidden(v.name) && !boardStore.butterfly;
        if (!this.isPartVisible(v) && !x && !oface) continue;
        const w = x || oface ? this.activeScene?.root : this.rootForPart(v);
        const pts: Point[] = [], st = qs.length > 40 ? qs.length / 40 : 1;
        for (let z = 0; z < qs.length; z += st) {
          const pn = v.pins[qs[Math.floor(z)]];
          if (pn) pts.push(this.sceneToWorld(pn.position, w));
        }
        const BB = R2BB(v, w);
        if (!pts.length) pts.push({ x: (BB.x0 + BB.x1) / 2, y: (BB.y0 + BB.y1) / 2 });
        h.push(pts); bx.push(BB); ix.push(pI); ol.push(v.side === 'bottom');
      }
      // 2R: valor de diodo da net (o mesmo em todos os pinos) vai no card branco
      let R2D = '', R2DC = 0;
      try {
        const bn = this.getMemoizedObdBoardNumber() ?? undefined;
        for (const pI of ix) {
          for (const qi of f.get(pI) || []) {
            const pn = this.board.parts[pI]?.pins[qi];
            if (!pn) continue;
            const kn = primaryDiodeReading(pn, bn);
            if (kn && kn.kind && kn.kind !== 'none') {
              R2D = kn.kind === 'open' ? 'OL' : kn.mv === 0 ? '0' : kn.mv != null ? (kn.mv / 1e3).toFixed(3) : String(kn.raw ?? '');
              R2DC = diodeReadingColor(kn);
              break;
            }
          }
          if (R2D) break;
        }
      } catch { /* */ }
      this.__r2Tags = ix.map((pI, k) => ({ n: this.board!.parts[pI]?.name || '', x: (bx[k].x0 + bx[k].x1) / 2, y: bx[k].y0, y1: bx[k].y1, d: R2D, dc: R2DC }));
      const N = h.length;
      if (N < 2) return;
      const D = new Float64Array(N * N), S: Array<[Point, Point] | undefined> = new Array(N * N);
      for (let a = 0; a < N; a++)
        for (let c = a + 1; c < N; c++) {
          let Bd = Infinity, P: Point | null = null, Q: Point | null = null;
          for (const u of h[a])
            for (const y of h[c]) {
              const F = y.x - u.x, G = y.y - u.y, H = F * F + G * G;
              if (H < Bd) { Bd = H; P = u; Q = y; }
            }
          D[a * N + c] = D[c * N + a] = Bd;
          S[a * N + c] = [P!, Q!];
          S[c * N + a] = [Q!, P!];
        }
      // 2R 24/10/2026 22h (Roger: «quando for bottom é uma cor a net e top outra cor… manter isso padrão»): TOP amarelo,
      // BOTTOM azul-claro; trecho que troca de face fica na cor da face de destino (a que não está à vista)
      const vb = !this.isTopVisible && this.isBottomVisible;
      const linha = (P: Point, a: number, Q: Point, c: number) => {
        const ba = ol[a], bc = ol[c], cb = !R2OF ? false : ba === bc ? ba : !vb;
        this.netLineSegments.push({ start: P, end: Q, color: cb ? R2OC : color });
      };
      const inT = new Uint8Array(N), K = new Float64Array(N).fill(Infinity), par = new Int32Array(N).fill(-1);
      K[0] = 0;
      for (let it = 0; it < N; it++) {
        let a = -1, Bm = Infinity;
        for (let c = 0; c < N; c++) if (!inT[c] && K[c] < Bm) { Bm = K[c]; a = c; }
        if (a < 0) break;
        inT[a] = 1;
        if (par[a] >= 0) {
          const sg = S[par[a] * N + a];
          if (sg && sg[0]) linha(sg[0], par[a], sg[1], a);
        }
        for (let c = 0; c < N; c++) if (!inT[c] && D[a * N + c] < K[c]) { K[c] = D[a * N + c]; par[c] = a; }
      }
    }
  }

  /** Draw cached net line segments with current animation state */
  private renderNetLines() {
    this.needsRender = true;

    if (this.netLinesDirty) { this.recomputeNetLineSegments(); this.netLineBakeSig = ''; }
    if (this.netLineSegments.length === 0) {
      this.netLinesGfx.clear();
      this.netLinesPulseGfx?.clear();
      return;
    }

    const s = renderSettingsStore.settings;
    const vpScale = Math.abs(this.viewport.scale.x);
    // 2R 26/10/2026 (Roger: «linha da net com a metade da espessura»): ×0,5 → ×0,575 em 27/10 (+15%) (window.__r2NetLineK)
    const lineW = (s.netLineWidth * (r2w.__r2NetLineK ?? 0.575)) / vpScale;

    const pulseT = s.netLinePulse ? (Math.sin(this.netLinePulsePhase * Math.PI * 2) + 1) / 2 : 0;
    const pulseColor = 0xcc2222;

    const dashLen = s.netLineDashLength / vpScale;
    const dashOffset = s.netLineDashed ? (this.netLinePulsePhase * dashLen * 2) : 0;

    const useFade = this.netLineFadeDist > 0;
    const fadeDist = useFade ? 60 / vpScale : 0;

    // A5 fast path — plain solid lines (no fade, no dash): geometry is baked
    // once into netLinesGfx (base colors) + a pulse-colored child layer, and
    // the pulse animates only the child's alpha. The per-frame cost drops
    // from full path re-issue to one alpha write.
    if (!useFade && !s.netLineDashed) {
      const sig = `${lineW.toFixed(4)}|${s.netLineAlpha}|${s.netLineGlow ?? 0.3}`;
      if (sig !== this.netLineBakeSig) {
        this.netLineBakeSig = sig;
        if (!this.netLinesPulseGfx || this.netLinesPulseGfx.destroyed) {
          this.netLinesPulseGfx = new Graphics();
          this.netLinesPulseGfx.eventMode = 'none';
          // Same transform as its sibling — a live rotation carries one on both.
          this.netLinesPulseGfx.position.copyFrom(this.netLinesGfx.position);
          this.netLinesPulseGfx.rotation = this.netLinesGfx.rotation;
        }
        // Sibling immediately above netLinesGfx (added later = painted later).
        // NEVER netLinesGfx.addChild(...) — see the field note on the A5 field.
        const pulseParent = this.netLinesGfx.parent;
        if (pulseParent && this.netLinesPulseGfx.parent !== pulseParent) {
          this.netLinesPulseGfx.zIndex = this.netLinesGfx.zIndex;
          pulseParent.addChild(this.netLinesPulseGfx);
        }
        this.netLinesGfx.clear();       // clears geometry only; children survive
        this.netLinesPulseGfx.clear();
        for (const [baseColor, segs] of this.netLineSegmentsByColor) {
          // 2R 20/10/2026: efeito neon (brilho em volta da linha), força em netLineGlow; 26/10: brilho ×0,4 (window.__r2NeonK)
          const R2G = (s.netLineGlow ?? 0.3) * (r2w.__r2NeonK ?? 0.4);
          if (R2G > 0) {
            for (const [wm, am] of [[4, 0.35], [2.2, 1]]) {
              for (const { start, end } of segs) { this.netLinesGfx.moveTo(start.x, start.y); this.netLinesGfx.lineTo(end.x, end.y); }
              this.netLinesGfx.stroke({ width: lineW * wm, color: baseColor, alpha: Math.min(1, R2G * am), cap: 'round', join: 'round' });
            }
          }
          for (const { start, end } of segs) {
            this.netLinesGfx.moveTo(start.x, start.y);
            this.netLinesGfx.lineTo(end.x, end.y);
            this.netLinesPulseGfx.moveTo(start.x, start.y);
            this.netLinesPulseGfx.lineTo(end.x, end.y);
          }
          this.netLinesGfx.stroke({ width: lineW, color: baseColor, alpha: s.netLineAlpha });
        }
        this.netLinesPulseGfx.stroke({ width: lineW, color: pulseColor, alpha: s.netLineAlpha });
      }
      this.netLinesPulseGfx!.alpha = s.netLinePulse ? pulseT : 0;
      return;
    }

    // Slow path (fade and/or dashed): geometry genuinely changes per frame.
    if (this.netLinesPulseGfx) this.netLinesPulseGfx.alpha = 0;
    this.netLinesGfx.clear();
    for (const [baseColor, segs] of this.netLineSegmentsByColor) {
      const color = s.netLinePulse ? this.lerpColor(baseColor, pulseColor, pulseT) : baseColor;
      for (const { start, end } of segs) {
        if (useFade) {
          this.drawNetLineWithFade(start, end, fadeDist, lineW, color, s.netLineAlpha, s.netLineDashed, dashLen, dashOffset);
        } else {
          this.drawDashedLine(start, end, dashLen, dashOffset, lineW, color, s.netLineAlpha);
        }
      }
    }
  }

  /**
   * Draw cross-side ghost outlines for net-connected parts on the hidden
   * board side. Called from renderSelection() and the ticker for pulse
   * animation. Ghosts are semi-transparent with a pulsing opacity driven by
   * netLinePulsePhase. Disco mode owns its own gfx layer (renderDiscoHalo).
   */
  /** Cross-side ghosts: the hidden-side members of the lit net, pulsing.
   *
   *  The geometry is baked ONCE per (ghost set, settings) signature and the
   *  pulse animates the two layers' `alpha` — the same A5 crossfade pattern
   *  the net lines use. It used to clear and re-issue every ghost's outline,
   *  fill, stroke and every pin fill on every ticker frame for as long as the
   *  net stayed lit, when the only thing a frame changes is two alphas. A
   *  rail like GND has members on both sides, so its ghost set is most of the
   *  board: measured at 6x CPU throttle, ~210 ms of PixiJS `execute` per
   *  frame, every frame, until the user selected something else — on an A12Z
   *  iPad in WebKit that was the "tap lookup blocks pan and zoom for 5–10 s"
   *  report, and the blink fix alone did not touch it.
   *
   *  Alphas are exact: the body fill was `ghostAlpha * 0.5` and the pins
   *  `ghostAlpha`, so the fill layer bakes body at 0.5 and pins at 1 and
   *  animates `alpha = ghostAlpha`; the outline layer bakes at 1 and animates
   *  `alpha = outlineAlpha`. Two layers because one Graphics has one alpha. */
  private renderCrossSideGhosts() {
    if (this.crossSideGhostParts.size === 0 || !this.board) {
      if (this.crossSideGhostBakeSig !== '') {
        this.crossSideGhostGfx.clear();
        this.crossSideGhostOutlineGfx.clear();
        this.crossSideGhostBakeSig = '';
        this.needsRender = true;
      }
      return;
    }
    const s = renderSettingsStore.settings;
    const sig = `${[...this.crossSideGhostParts].join(',')}|${s.selectionWidth}|${s.pinSizeScale}`
      + `|${this.activeScene ? 1 : 0}`;
    if (sig !== this.crossSideGhostBakeSig) this.bakeCrossSideGhosts(sig);

    // Pulse alpha between 0.12 and 0.35 (fill) / 0.25 and 0.60 (outline).
    const pulse = (Math.sin(this.netLinePulsePhase * Math.PI * 2) + 1) / 2;
    this.crossSideGhostGfx.alpha = 0.12 + pulse * 0.23;
    this.crossSideGhostOutlineGfx.alpha = 0.25 + pulse * 0.35;
    this.needsRender = true;
  }

  private bakeCrossSideGhosts(sig: string) {
    const fill = this.crossSideGhostGfx;
    const outline = this.crossSideGhostOutlineGfx;
    fill.clear();
    outline.clear();
    if (!this.board) { this.crossSideGhostBakeSig = ''; return; }
    const s = renderSettingsStore.settings;
    const ghostColor = 0x44ccff; // cyan tint to distinguish from normal highlights

    for (const partIndex of this.crossSideGhostParts) {
      const part = this.board.parts[partIndex];
      if (!part) continue;

      drawPartOutline(fill, part, s, 0);
      fill.fill({ color: ghostColor, alpha: 0.5 });
      drawPartOutline(outline, part, s, 0);
      outline.stroke({ width: s.selectionWidth, color: ghostColor, alpha: 1 });

      // Pins — same shape the sprite uses, capsules included.
      for (const pin of part.pins) {
        const clamp = this.activeScene?.pinRadiusClamp.get(partIndex) ?? Infinity;
        const r = Math.min(computePinRadius(s, pin.radius), clamp);
        drawPinShape(fill, pin, r);
      }
      if (part.pins.length > 0) fill.fill({ color: ghostColor, alpha: 1 });
    }
    this.crossSideGhostBakeSig = sig;
  }

  /**
   * Disco mode — same-net parts heartbeat red on both sides. Two batched
   * passes into a single Graphics: an unpadded fill over each part's body
   * shape, then an outline expanded by `pad` to sit just outside the
   * existing border. Alpha rides a threshold-clamped sine so the cycle
   * reads as a blink (~70% silent / ~30% active), not a constant glow.
   *
   * Silent-phase fast-path: while `pulse === 0` we skip path building
   * entirely. One `clear()` runs on the transition into silence to drop
   * the previous frame's red; afterwards the gfx layer is already empty
   * and `needsRender` stays false so the GPU isn't re-submitted for nothing.
   */
  private renderDiscoHalo() {
    const preview = boardStore.previewPulse;
    // The burst OWNS this layer: while it runs, net-wide disco is suppressed so
    // exactly one component blinks and you cannot mistake "look here" for
    // "these are on the net". Once it decays into the beacon the two coexist,
    // because the beacon is a stroke ring and disco is a solid fill.
    const discoOn =
      boardStore.discoHighlight && this.discoHaloParts.size > 0 && preview?.phase !== 'burst';
    const burstPart  = preview?.phase === 'burst'  ? preview.partIndex : null;
    const beaconPart = preview?.phase === 'beacon' ? preview.partIndex : null;

    const clearIfDirty = () => {
      if (this.discoHaloDirty) {
        this.discoHaloGfx.clear();
        this.discoHaloDirty = false;
        this.needsRender = true;
      }
    };

    if (!this.board || (!discoOn && burstPart === null && beaconPart === null)) {
      clearIfDirty();
      return;
    }

    // Threshold-clamped sine — duty cycle ≈ arccos(2·SILENT − 1)/π active.
    // SILENT = 0.79 ⇒ active ≈ 29% of every 1-second cycle.
    const sine = (Math.sin(this.netLinePulsePhase * Math.PI * 2) + 1) / 2;
    const SILENT = 0.79;
    const pulse = sine > SILENT ? (sine - SILENT) / (1 - SILENT) : 0;

    // Beacon: one short flash every BEACON_PERIOD, on its own clock so it is
    // visibly slower than the 1 s heartbeat rather than a harmonic of it.
    const BEACON_PERIOD = 2000;
    const BEACON_ON = 320;
    let beaconAlpha = 0;
    if (beaconPart !== null) {
      const t = performance.now() % BEACON_PERIOD;
      if (t < BEACON_ON) beaconAlpha = Math.sin((t / BEACON_ON) * Math.PI);
    }

    const drawsDisco  = discoOn && pulse > 0;
    const drawsBurst  = burstPart !== null && pulse > 0;
    const drawsBeacon = beaconPart !== null && beaconAlpha > 0;
    if (!drawsDisco && !drawsBurst && !drawsBeacon) {
      clearIfDirty();
      return;
    }

    const s = renderSettingsStore.settings;
    const width = Math.max(s.selectionWidth * 1.2, 2);
    const pad = Math.max(s.selectionPadding * 0.5, 1);
    const RED = 0xff2a2a;        // disco / burst — solid fill
    const BEACON_RED = 0xcc2222; // matches the focus blink's red
    const gfx = this.discoHaloGfx;

    /** Single-pin parts have no polygon outline — emit a pin-shaped circle
     *  instead. Everything else delegates to the shared `drawPartOutline`. */
    const emitShape = (part: Part, sp: number) => emitPartOutlineShape(gfx, part, s, sp);

    /** Parts taking the solid-red treatment this frame: the whole net in disco
     *  mode, or the single previewed part during its burst. */
    const solid: number[] = drawsBurst
      ? [burstPart as number]
      : drawsDisco ? Array.from(this.discoHaloParts) : [];

    gfx.clear();

    if (solid.length > 0) {
      // Pass 1 — body fills (no padding, sits exactly on the part shape).
      for (const partIndex of solid) {
        const part = this.board.parts[partIndex];
        if (part) emitShape(part, 0);
      }
      gfx.fill({ color: RED, alpha: pulse });

      // Pass 2 — outlines, padded so they ring (not overlay) the part border.
      for (const partIndex of solid) {
        const part = this.board.parts[partIndex];
        if (part) emitShape(part, pad);
      }
      gfx.stroke({ width, color: RED, alpha: pulse });
    }

    // Pass 3 — the beacon: ring only, no fill. Deliberately a different mark
    // from the solid disco body so both can be on screen at once.
    if (drawsBeacon) {
      const part = this.board.parts[beaconPart as number];
      if (part) {
        emitShape(part, pad * 2);
        gfx.stroke({ width: width * 1.3, color: BEACON_RED, alpha: beaconAlpha });
      }
    }

    this.discoHaloDirty = true;
    this.needsRender = true;
  }

  /** Clip a ray from `from` toward `to` to the edge of a part's bounding rect, returning world coords */
  private clipToRectEdge(from: Point, to: Point, eb: { px: number; py: number; pw: number; ph: number }, root?: Container): Point {
    const tl = this.sceneToWorld({ x: eb.px, y: eb.py }, root);
    const br = this.sceneToWorld({ x: eb.px + eb.pw, y: eb.py + eb.ph }, root);
    const minX = Math.min(tl.x, br.x), maxX = Math.max(tl.x, br.x);
    const minY = Math.min(tl.y, br.y), maxY = Math.max(tl.y, br.y);

    const dx = to.x - from.x;
    const dy = to.y - from.y;
    if (Math.abs(dx) < 0.001 && Math.abs(dy) < 0.001) return from;

    // Find intersection with each of the 4 rect edges, pick the one closest to `to` (largest t)
    let bestT = 0;
    const corners: Point[] = [
      { x: minX, y: minY }, { x: maxX, y: minY },
      { x: maxX, y: maxY }, { x: minX, y: maxY },
    ];
    for (let i = 0; i < 4; i++) {
      const t = this.rayEdgeIntersect(from, to, corners[i], corners[(i + 1) % 4]);
      if (t !== null && t > bestT) bestT = t;
    }

    return { x: from.x + dx * bestT, y: from.y + dy * bestT };
  }

  /** Find parametric t along ray (from→to) where it intersects edge segment (a→b). Returns null if no hit. */
  private rayEdgeIntersect(from: Point, to: Point, a: Point, b: Point): number | null {
    const dx = to.x - from.x;
    const dy = to.y - from.y;
    const ex = b.x - a.x;
    const ey = b.y - a.y;
    const denom = dx * ey - dy * ex;
    if (Math.abs(denom) < 1e-10) return null;
    const t = ((a.x - from.x) * ey - (a.y - from.y) * ex) / denom;
    const u = ((a.x - from.x) * dy - (a.y - from.y) * dx) / denom;
    if (t >= 0 && t <= 1 && u >= 0 && u <= 1) return t;
    return null;
  }

  /** Draw a dashed line between two world-space points */
  private drawDashedLine(from: Point, to: Point, dashLen: number, dashOffset: number, width: number, color: number, alpha: number) {
    const dx = to.x - from.x;
    const dy = to.y - from.y;
    const totalLen = Math.sqrt(dx * dx + dy * dy);
    if (totalLen < 0.001) return;

    const ux = dx / totalLen;
    const uy = dy / totalLen;
    const gapLen = dashLen;
    const segLen = dashLen + gapLen;

    // Batch all dash segments, then stroke once
    let pos = -(dashOffset % segLen);
    let hasSegments = false;
    while (pos < totalLen) {
      const segStart = Math.max(0, pos);
      const segEnd = Math.min(totalLen, pos + dashLen);
      if (segEnd > segStart) {
        this.netLinesGfx.moveTo(from.x + ux * segStart, from.y + uy * segStart);
        this.netLinesGfx.lineTo(from.x + ux * segEnd, from.y + uy * segEnd);
        hasSegments = true;
      }
      pos += segLen;
    }
    if (hasSegments) {
      this.netLinesGfx.stroke({ width, color, alpha });
    }
  }

  /** Draw a net line with alpha fade-in near the start to reduce clutter with many lines.
   *  Non-dashed mode: batches all fade segments per alpha level into a single stroke call. */
  private drawNetLineWithFade(from: Point, to: Point, fadeDist: number, width: number, color: number, alpha: number, dashed: boolean, dashLen: number, dashOffset: number) {
    const dx = to.x - from.x;
    const dy = to.y - from.y;
    const totalLen = Math.sqrt(dx * dx + dy * dy);
    if (totalLen < 0.001) return;

    const ux = dx / totalLen;
    const uy = dy / totalLen;
    const fadeEnd = Math.min(fadeDist, totalLen * 0.4);

    if (dashed) {
      // Dashed: each drawDashedLine call already batches internally
      const fadeSteps = 4;
      for (let i = 0; i < fadeSteps; i++) {
        const t0 = (i / fadeSteps) * fadeEnd;
        const t1 = ((i + 1) / fadeSteps) * fadeEnd;
        const stepAlpha = alpha * ((i + 1) / fadeSteps) * 0.7;
        const segFrom: Point = { x: from.x + ux * t0, y: from.y + uy * t0 };
        const segTo: Point = { x: from.x + ux * t1, y: from.y + uy * t1 };
        this.drawDashedLine(segFrom, segTo, dashLen, dashOffset + t0, width, color, stepAlpha);
      }
      if (fadeEnd < totalLen) {
        const remainFrom: Point = { x: from.x + ux * fadeEnd, y: from.y + uy * fadeEnd };
        this.drawDashedLine(remainFrom, to, dashLen, dashOffset + fadeEnd, width, color, alpha);
      }
    } else {
      // Non-dashed: batch all fade segments by alpha level, one stroke() per level
      const fadeSteps = 4;
      for (let i = 0; i < fadeSteps; i++) {
        const t0 = (i / fadeSteps) * fadeEnd;
        const t1 = ((i + 1) / fadeSteps) * fadeEnd;
        const stepAlpha = alpha * ((i + 1) / fadeSteps) * 0.7;
        this.netLinesGfx.moveTo(from.x + ux * t0, from.y + uy * t0);
        this.netLinesGfx.lineTo(from.x + ux * t1, from.y + uy * t1);
        this.netLinesGfx.stroke({ width, color, alpha: stepAlpha });
      }
      // Remaining line at full alpha
      if (fadeEnd < totalLen) {
        this.netLinesGfx.moveTo(from.x + ux * fadeEnd, from.y + uy * fadeEnd);
        this.netLinesGfx.lineTo(to.x, to.y);
        this.netLinesGfx.stroke({ width, color, alpha });
      }
    }
  }

  /** Linearly interpolate between two hex colors */
  private lerpColor(a: number, b: number, t: number): number {
    const ar = (a >> 16) & 0xff, ag = (a >> 8) & 0xff, ab = a & 0xff;
    const br = (b >> 16) & 0xff, bg = (b >> 8) & 0xff, bb = b & 0xff;
    const r = Math.round(ar + (br - ar) * t);
    const g = Math.round(ag + (bg - ag) * t);
    const bl = Math.round(ab + (bb - ab) * t);
    return (r << 16) | (g << 8) | bl;
  }

  // --- Hit testing ---

  /** Build a spatial hash grid for O(1) hit-test lookups.
   *  Each part is inserted into every grid cell its bounding box overlaps.
   *  Results are cached per-board so tab switches are instant. */
  private buildHitGrid(board: BoardData) {
    const cacheKey = this.sceneCacheKey(board);
    const cached = this.hitGridCache.get(cacheKey);
    if (cached) {
      this.hitGrid = cached.grid;
      this.hitGridCellSize = cached.cellSize;
      return;
    }

    const grid = new Map<string, number[]>();
    if (board.parts.length === 0) {
      this.hitGrid = grid;
      this.hitGridCellSize = 1;
      this.hitGridCache.set(cacheKey, { grid, cellSize: 1 });
      return;
    }
    // Cell size: use board bounds divided into a reasonable grid (~50x50 cells)
    const bw = board.bounds.maxX - board.bounds.minX || 1;
    const bh = board.bounds.maxY - board.bounds.minY || 1;
    const cellSize = Math.max(bw, bh) / 50;
    this.hitGridCellSize = cellSize;

    for (let pi = 0; pi < board.parts.length; pi++) {
      const part = board.parts[pi];
      if (part.hidden) continue; // skip parts filtered out by deriveBoardView
      // Use part bounds (authoritative, already includes pin positions)
      const b = part.bounds;
      if (b.minX === b.maxX && b.minY === b.maxY && part.pins.length === 0) continue;
      let minX = b.minX, minY = b.minY, maxX = b.maxX, maxY = b.maxY;
      // Expand by a margin for click tolerance
      const margin = cellSize * 0.5;
      minX -= margin; minY -= margin; maxX += margin; maxY += margin;

      const x0 = Math.floor(minX / cellSize);
      const y0 = Math.floor(minY / cellSize);
      const x1 = Math.floor(maxX / cellSize);
      const y1 = Math.floor(maxY / cellSize);
      for (let gx = x0; gx <= x1; gx++) {
        for (let gy = y0; gy <= y1; gy++) {
          const key = `${gx},${gy}`;
          let cell = grid.get(key);
          if (!cell) { cell = []; grid.set(key, cell); }
          cell.push(pi);
        }
      }
    }
    this.hitGrid = grid;
    this.hitGridCache.set(cacheKey, { grid, cellSize });
  }

  /** Get candidate part indices from the spatial hash for a given scene-space point */
  private hitGridCandidates(x: number, y: number): number[] {
    if (this.hitGridCellSize <= 0) return [];
    const gx = Math.floor(x / this.hitGridCellSize);
    const gy = Math.floor(y / this.hitGridCellSize);
    return this.hitGrid.get(`${gx},${gy}`) ?? [];
  }

  /** Get the root container a part belongs to (different in butterfly mode) */
  private rootForPart(part: { side: string }): Container | undefined {
    if (!this.activeScene) return undefined;
    if (boardStore.butterfly && this.activeScene.butterflyRoot && part.side === 'bottom') {
      return this.activeScene.butterflyRoot;
    }
    return this.activeScene.root;
  }

  /** Find the part (and optionally pin) under a world-space point. Returns the
   *  smallest part in the overlap stack — see hitTestStack. Used by hover,
   *  double-click PDF lookup, and as the default pick. */
  /** Nearest pin to a world point among spatial-hash candidates, within a few
   *  pin-pitches. Used by Resize Mode so a dense-BGA net-label click still
   *  resolves to a specific pin (→ its net highlights) when hitTestStack falls
   *  through to the part body. Returns null if nothing is close. */
  private nearestPin(world: Point): { partIndex: number; pinIndex: number } | null {
    if (!this.board) return null;
    const butterfly = boardStore.butterfly && this.activeScene?.butterflyRoot;
    const localTop = this.worldToScene(world, this.activeScene?.root);
    const localBot = butterfly ? this.worldToScene(world, this.activeScene!.butterflyRoot!) : localTop;
    const candidates = new Set<number>();
    for (const pi of this.hitGridCandidates(localTop.x, localTop.y)) candidates.add(pi);
    if (butterfly) for (const pi of this.hitGridCandidates(localBot.x, localBot.y)) candidates.add(pi);
    let best: { partIndex: number; pinIndex: number } | null = null;
    let bestD2 = Infinity;
    for (const pi of candidates) {
      const part = this.board.parts[pi];
      if (!part) continue;
      const local = (butterfly && part.side === 'bottom') ? localBot : localTop;
      for (let pj = 0; pj < part.pins.length; pj++) {
        const p = part.pins[pj].position;
        const dx = p.x - local.x, dy = p.y - local.y;
        const d2 = dx * dx + dy * dy;
        if (d2 < bestD2) { bestD2 = d2; best = { partIndex: pi, pinIndex: pj }; }
      }
    }
    const maxD = (renderSettingsStore.settings.clickThreshold * 6) / Math.abs(this.viewport.scale.x);
    return best && bestD2 <= maxD * maxD ? best : null;
  }

  private hitTest(world: Point): { partIndex: number; pinIndex: number } | null {
    return this.hitTestStack(world)[0] ?? null;
  }

  /** Every part under a world-space point, ranked SMALLEST render-area first
   *  (most specific = most likely intended). Each entry carries the pin index
   *  when a pad/pin under the point belongs to that part, else -1. This is the
   *  basis for smallest-wins selection, click-cycling through stacked parts,
   *  and the per-part right-click menu (#23). Non-overlapping parts return a
   *  single-entry array, so all existing callers are unaffected. */
  private hitTestStack(world: Point): { partIndex: number; pinIndex: number }[] {
    if (!this.board) return [];

    const s = renderSettingsStore.settings;
    const butterfly = boardStore.butterfly && this.activeScene?.butterflyRoot;

    // In butterfly mode, convert world coords per-part using the correct root.
    const localTop = this.worldToScene(world, this.activeScene?.root);
    const localBot = butterfly
      ? this.worldToScene(world, this.activeScene!.butterflyRoot!)
      : localTop;

    // Spatial hash → candidate parts near the pointer (both roots for butterfly)
    const candidateSet = new Set<number>();
    for (const pi of this.hitGridCandidates(localTop.x, localTop.y)) candidateSet.add(pi);
    if (butterfly) {
      for (const pi of this.hitGridCandidates(localBot.x, localBot.y)) candidateSet.add(pi);
    }

    // Widen the distance-based pin catch radius by pinSizeScale so an enlarged
    // circle pin (drawn via computePinRadius, which now includes pinSizeScale)
    // stays pin-hittable instead of falling through to the part body. No-op at
    // the default scale of 1.
    const threshold = (s.clickThreshold / Math.abs(this.viewport.scale.x)) * (s.pinSizeScale || 1);
    const hits: StackHit[] = [];

    for (const pi of candidateSet) {
      const part = this.board.parts[pi];
      if (!this.isPartVisible(part)) continue;

      const local = part.side === 'bottom' ? localBot : localTop;

      // Best pin/pad under the point for THIS part (pad-exact where available,
      // else within click threshold). Same detection as before, per-part.
      let pinIndex = -1;
      let pinDist2 = Infinity;
      // Whether the winning pin was hit by genuine pad CONTAINMENT (poly / rect)
      // vs merely falling within the zoom-scaled distance threshold. #24: a
      // distance-only hit on a nearby test point must not outrank the component
      // the click is actually inside.
      let pinContained = false;
      const padPolys = part.pins.length === 2 ? this.activeScene?.twoPinPadPolys.get(pi) : null;
      if (padPolys) {
        for (let pni = 0; pni < 2; pni++) {
          const poly = padPolys[pni];
          if (pointInConvexPoly(local.x, local.y, poly)) {
            const cx = poly.reduce((a: number, p: [number, number]) => a + p[0], 0) / poly.length;
            const cy = poly.reduce((a: number, p: [number, number]) => a + p[1], 0) / poly.length;
            const d2 = (local.x - cx) ** 2 + (local.y - cy) ** 2;
            if (d2 < pinDist2) { pinDist2 = d2; pinIndex = pni; pinContained = true; }
          }
        }
      } else {
        for (let pni = 0; pni < part.pins.length; pni++) {
          const pin = part.pins[pni];
          const pb = pin.padBounds;
          if (pb) {
            if (local.x >= pb.minX && local.x <= pb.maxX && local.y >= pb.minY && local.y <= pb.maxY) {
              const cx = (pb.minX + pb.maxX) / 2, cy = (pb.minY + pb.maxY) / 2;
              const d2 = (local.x - cx) ** 2 + (local.y - cy) ** 2;
              if (d2 < pinDist2) { pinDist2 = d2; pinIndex = pni; pinContained = true; }
            }
          } else {
            const dx = pin.position.x - local.x, dy = pin.position.y - local.y;
            const d2 = dx * dx + dy * dy;
            if (d2 < pinDist2 && d2 < threshold * threshold) { pinDist2 = d2; pinIndex = pni; pinContained = false; }
          }
        }
      }

      const rb = computePartRenderBounds(part, s);
      const bodyContains =
        local.x >= rb.px && local.x <= rb.px + rb.pw &&
        local.y >= rb.py && local.y <= rb.py + rb.ph;

      // Part is "under the point" if its body contains it or a pad/pin was hit.
      const area = rb.pw * rb.ph;
      if (pinIndex >= 0) {
        // Pin/pad hit → default to the pin (net highlight, as before). `sub`
        // keeps the pin entry ahead of the body entry for the same part. The hit
        // is "contained" if the pad enclosed the point OR the body does — a bare
        // distance-threshold pin hit (test point near the click) is not.
        hits.push({ partIndex: pi, pinIndex, area, sub: 0, contained: pinContained || bodyContains });
        // On 2-pin parts the two pads cover the whole footprint, so the body is
        // otherwise unreachable — offer the WHOLE COMPONENT as the next cycle
        // step so the part itself can be selected (no net). (#23 follow-up)
        if (part.pins.length === 2 && bodyContains) {
          hits.push({ partIndex: pi, pinIndex: -1, area, sub: 1, contained: true });
        }
      } else if (bodyContains) {
        hits.push({ partIndex: pi, pinIndex: -1, area, sub: 0, contained: true });
      }
    }

    // Contained hits first (the click is genuinely inside them), then smallest
    // render area (most-specific stacked part, #23), then pin before whole-body.
    hits.sort(compareStackHits);
    return hits.map(h => ({ partIndex: h.partIndex, pinIndex: h.pinIndex }));
  }

  /** Find the trace segment closest to a world-space point, respecting layer visibility */
  private traceHitTest(world: Point): { traceIndex: number; net: string } | null {
    if (!this.board?.traces || !boardStore.showTraces || this.copperHidden) return null;

    const { layerStates } = boardStore;
    const local = this.worldToScene(world, this.activeScene?.root);
    // Threshold: half trace width + a generous pointer tolerance scaled by zoom
    const zoomScale = Math.abs(this.viewport.scale.x);
    const pointerTol = 8 / zoomScale; // 8 CSS px converted to scene units

    let grid = this.traceGridCache.get(this.board);
    if (!grid) {
      const b = this.board.bounds;
      const cellSize = Math.max(b.maxX - b.minX, b.maxY - b.minY, 1) / 50;
      grid = buildTraceGrid(this.board.traces, cellSize);
      this.traceGridCache.set(this.board, grid);
    }
    const candidates = queryTraceGrid(grid, local.x, local.y, pointerTol);

    let bestDist = Infinity;
    let bestIdx = -1;

    for (const i of candidates) {
      const t = this.board.traces[i];
      // Skip traces on hidden layers
      if (t.layer != null && t.layer < layerStates.length && !layerStates[t.layer].visible) continue;

      const halfW = (t.width || 1) / 2;
      const threshold = halfW + pointerTol;

      // Point-to-line-segment distance
      const ax = t.start.x, ay = t.start.y;
      const bx = t.end.x, by = t.end.y;
      const abx = bx - ax, aby = by - ay;
      const len2 = abx * abx + aby * aby;
      let dist: number;
      if (len2 < 0.001) {
        // Degenerate segment (zero length)
        const dx = local.x - ax, dy = local.y - ay;
        dist = Math.sqrt(dx * dx + dy * dy);
      } else {
        const t0 = Math.max(0, Math.min(1, ((local.x - ax) * abx + (local.y - ay) * aby) / len2));
        const px = ax + t0 * abx, py = ay + t0 * aby;
        const dx = local.x - px, dy = local.y - py;
        dist = Math.sqrt(dx * dx + dy * dy);
      }
      if (dist < threshold && dist < bestDist) {
        bestDist = dist;
        bestIdx = i;
      }
    }

    if (bestIdx >= 0) {
      return { traceIndex: bestIdx, net: this.board.traces[bestIdx].net };
    }
    return null;
  }

  // --- Click handling ---

  private handleHover(e: PointerEvent) {
    // Any real pointer movement beyond the tolerance ends a click-cycle, so the
    // next click starts fresh at the smallest part and hover shows it (#23).
    // Runs before the hover-info gate so it applies even with tooltips off.
    if (this.board && this.clickCycle) {
      const w = this.viewport.toWorld(e.offsetX, e.offsetY);
      const tol = BoardRenderer.CYCLE_TOLERANCE_PX / Math.abs(this.viewport.scale.x);
      if (Math.abs(this.clickCycle.x - w.x) > tol || Math.abs(this.clickCycle.y - w.y) > tol) {
        this.clickCycle = null;
        this.clearPendingCycleAdvance();
      }
    }

    if (!this.board || !this.activeScene || !boardStore.showHoverInfo) {
      this.hideTooltip();
      this.setHoverNet(null);
      return;
    }

    // e.offsetX/Y are canvas-relative — same as containerEl coords since canvas fills the container
    const world = this.viewport.toWorld(e.offsetX, e.offsetY);
    const hit = this.hitTest(world);
    if (hit && hit.pinIndex >= 0) {
      const part = this.board.parts[hit.partIndex];
      const pin = part?.pins[hit.pinIndex];
      if (pin && part) {
        // Same pin as last frame and tooltip content is already current —
        // just reposition (no DOM rewrite / measure). Falls through to a
        // full showTooltip if the tooltip was hidden mid-hover (tooltipSize
        // cleared) so it comes back with content instead of staying blank.
        const key = `p${hit.partIndex}:${hit.pinIndex}`;
        if (key === this.hoverKey && this.tooltipSize) {
          this.repositionTooltip(e.offsetX, e.offsetY);
          return;
        }
        this.hoverKey = key;
        this.setHoverPin(hit.partIndex, hit.pinIndex);
        const pinId = pin.number || String(hit.pinIndex + 1);
        const diodeStr = pin.diode && pin.diode.kind !== 'none'
          ? `Diode ${formatDiode(pin.diode)}` : undefined;
        this.showTooltip(e.offsetX, e.offsetY, {
          net: pin.net ?? '',
          part: part.name,
          pin: pinId,
          pinIndex: hit.pinIndex,
          value: part.meta?.value,
          packageName: part.meta?.package,
          diode: diodeStr,
        });
        this.setHoverNet(pin.net || null);
        return;
      }
    }
    // Fallback: check traces
    const traceHit = this.traceHitTest(world);
    if (traceHit) {
      const key = `t${traceHit.traceIndex}`;
      if (key === this.hoverKey && this.tooltipSize) {
        this.repositionTooltip(e.offsetX, e.offsetY);
        return;
      }
      this.hoverKey = key;
      this.setHoverPin(null, null);
      const t = this.board.traces![traceHit.traceIndex];
      const layerName = t.layer != null && this.board.layerNames?.[t.layer]
        ? this.board.layerNames[t.layer] : '';
      this.showTooltip(e.offsetX, e.offsetY, {
        net: traceHit.net,
        part: layerName ? `trace · ${layerName}` : 'trace',
      });
      this.setHoverNet(traceHit.net || null);
      return;
    }
    this.hoverKey = null;
    this.setHoverPin(null, null);
    this.hideTooltip();
    this.setHoverNet(null);
  }

  /** Track the hovered pin and repaint the label overlay when it changes, so
   *  the pin under the pointer gets the full label size (same bump as the
   *  selected pin). One overlay repaint per pin change, not per move. */
  private setHoverPin(partIndex: number | null, pinIndex: number | null) {
    if (partIndex === this.hoverPartIndex && pinIndex === this.hoverPinIndex) return;
    this.hoverPartIndex = partIndex;
    this.hoverPinIndex = pinIndex;
    if (renderSettingsStore.settings.textFastMode) {
      this.overlayDirty = true;
      this.overlayContentDirty = true;
      this.needsRender = true;
    }
  }

  /** Update hover net and redraw selection overlay if ambient dim needs it */
  /** One finger, and it has not travelled past what counts as a tap. */
  private touchIsResting(): boolean {
    return this.activeTouchIds.size <= 1
      && this.pointerTravelPx <= BoardRenderer.TOUCH_CLICK_DRAG_TOLERANCE_PX;
  }

  /** Drop everything hover owns, and any hover scheduled for the next frame.
   *  Called when a touch turns into a gesture: whatever the resting finger had
   *  lit would otherwise stay lit for the whole pinch, and a lit net is
   *  re-drawn on every zoom frame. */
  private clearHoverState(): void {
    if (this.hoverRafId !== null) { cancelAnimationFrame(this.hoverRafId); this.hoverRafId = null; }
    this.lastHoverEvent = null;
    if (this.hoverKey !== null || this.hoverNet !== null
        || this.hoverPartIndex !== null || this.hoverPinIndex !== null) {
      this.hideTooltip();
      this.setHoverPin(null, null);
      this.setHoverNet(null);
    }
  }

  private setHoverNet(net: string | null) {
    if (net === this.hoverNet) return;
    this.hoverNet = net;
    // In ambient dim mode, hover changes which pins are punched through the overlay
    const s2 = renderSettingsStore.settings;
    const dm = boardStore.dimMode;
    if (s2.ambientDim && (dm === 'dim' || (dm !== 'off' && (s2.searchAutoDim ?? true) && boardStore.searchSelectionActive))) {
      this.renderSelection();
    }
  }

  private showTooltip(x: number, y: number, info: { net: string; part: string; pin?: string; pinIndex?: number; value?: string; packageName?: string; diode?: string }) {
    const el = this.tooltipEl;
    if (!el) return;

    const hasNet = info.net && info.net !== '(null)';
    // Reuse pre-created spans — avoids DOM allocation + forced reflow on every mousemove
    if (this.tooltipNetSpan) {
      this.tooltipNetSpan.textContent = hasNet ? info.net : '';
      this.tooltipNetSpan.style.display = hasNet ? '' : 'none';
    }
    if (this.tooltipDetailSpan) {
      // 2R: «U7800 | Pin 3» com o separador em elemento próprio (estilizado no CSS)
      this.tooltipDetailSpan.textContent = info.part;
      if (info.pin) this.tooltipDetailSpan.append(Object.assign(document.createElement('i'), { className: 'r2-sep', textContent: '|' }), `Pin ${info.pin}`);
    }
    // Cross-board compare line. Without it the board highlight only says
    // "this pin is different" and leaves you to go and find what it differs
    // to — which is the question the mark raises.
    if (this.tooltipCompareSpan) {
      const line = this.formatCompareForPin(info.part, info.pinIndex);
      this.tooltipCompareSpan.textContent = line ?? '';
      this.tooltipCompareSpan.style.display = line ? '' : 'none';
      this.tooltipCompareSpan.dataset.status = line ? (this.lastCompareTooltipStatus ?? '') : '';
    }
    // Meta line: value / package from PartMeta (TVW + any parser that fills it).
    // Hidden when both fields are empty so non-TVW boards keep the compact tooltip.
    if (this.tooltipMetaSpan) {
      const value = info.value?.trim() ?? '';
      const pkg = info.packageName?.trim() ?? '';
      const parts = [value, pkg].filter(Boolean);
      const metaLine = parts.join(' · ');
      this.tooltipMetaSpan.textContent = metaLine;
      this.tooltipMetaSpan.style.display = metaLine ? '' : 'none';
    }
    // OBD enrichment: if the hovered net has cached OpenBoardData readings,
    // append a compact "d 0.45 · 3.30 V · 47k Ω · 📝" line.
    if (this.tooltipObdSpan) {
      // XZZ-baked diode (pin-level) + OBD readings (net-level) on one line.
      const obdLine = hasNet ? this.formatObdForNet(info.net) : '';
      const combined = [info.diode, obdLine].filter(Boolean).join('   ·   ');
      this.tooltipObdSpan.textContent = combined;
      this.tooltipObdSpan.style.display = combined ? '' : 'none';
    }
    // Worklist enrichment: if the hovered part is on the active worklist, show
    // its mark / water flag / note so the tech sees prior work without opening
    // the panel. Part-level only (info.part); traces have no worklist entry.
    if (this.tooltipWorklistSpan) {
      const wl = this.formatWorklistForPart(info.part);
      this.tooltipWorklistSpan.innerHTML = wl ?? '';   // icons are trusted SVG; text is escaped
      this.tooltipWorklistSpan.style.display = wl ? '' : 'none';
    }
    // Net-level worklist line (mark / surge / recorded readings / note) — parallel
    // to and independent of the OBD line above.
    if (this.tooltipWorklistNetSpan) {
      const wn = hasNet ? this.formatWorklistForNet(info.net) : null;
      this.tooltipWorklistNetSpan.innerHTML = wn ?? '';
      this.tooltipWorklistNetSpan.style.display = wn ? '' : 'none';
    }

    el.style.display = 'block';
    // Single measure right after the content rewrite (no left/top='0' pre-measure
    // dance — measuring after display='block' with final content gives the same
    // numbers) and cache it so subsequent same-target moves reposition without
    // any layout read (audit A1).
    const tw0 = el.offsetWidth;
    const th0 = el.offsetHeight;
    this.tooltipSize = { w: tw0, h: th0 };
    this.repositionTooltip(x, y);
  }

  /** Status of the line `formatCompareForPin` last produced, so the tooltip can
   *  colour it without the formatter returning a tuple. */
  private lastCompareTooltipStatus: string | null = null;

  /**
   * The compare line for a hovered pin, or null when no comparison is painted
   * on this board or this is not the compared part.
   *
   * Reads the same projection the overlay draws from, so the colour under the
   * cursor and the words in the tooltip can never disagree.
   */
  private formatCompareForPin(partName: string, pinIndex: number | undefined): string | null {
    this.lastCompareTooltipStatus = null;
    if (pinIndex == null) return null;
    const tabId = this.tabId ?? boardStore.activeTabId;
    if (tabId == null) return null;
    const hl = partCompareStore.highlightFor(tabId);
    if (!hl || hl.partName.trim().toUpperCase() !== partName.trim().toUpperCase()) return null;
    const info = hl.pins.get(pinIndex);
    if (!info) {
      // The pin exists on this board but the alignment never paired it.
      return `↔ ${hl.otherBoard}: not matched`;
    }
    this.lastCompareTooltipStatus = info.status;
    const where = hl.otherBoard || 'other board';
    const net = info.otherNet || 'n/c';
    switch (info.status) {
      case 'only-a':
      case 'only-b': return `↔ ${where}: no such pin`;
      case 'nc':     return `↔ ${where}: ${info.reason || 'unconnected on both'}`;
      case 'same':   return `↔ ${where}: same net`;
      default: {
        // The other board's net is the answer. A note is added only where the
        // two names alone do not show why the row reads as it does — never to
        // restate the colour.
        const note = info.reason || STATUS_NOTE[info.status] || '';
        return `↔ ${where}: ${net}${note ? ` — ${note}` : ''}`;
      }
    }
  }

  /** Position the tooltip using the cached size — no layout reads. */
  private repositionTooltip(x: number, y: number) {
    const el = this.tooltipEl;
    const size = this.tooltipSize;
    if (!el || !size) return;
    const { w: tw, h: th } = size;
    const offset = 14;
    const cw = this.containerEl.clientWidth;
    const ch = this.containerEl.clientHeight;
    const left = Math.max(2, Math.min(x - tw / 2, cw - tw - 2));
    // Prefer above the cursor; drop below if there's no room; then clamp inside
    // the container so the tooltip never spills off the top or bottom edge.
    let top = y - th - offset;
    if (top < 2) top = y + offset;
    top = Math.max(2, Math.min(top, ch - th - 2));
    // Position via transform (not left/top) so a hover move is a compositor-only
    // update — no layout invalidation, no WebGL-canvas recomposite each frame.
    // The CSS pins left/top at 0 so this translate is the absolute position.
    el.style.transform = `translate(${Math.round(left)}px, ${Math.round(top)}px)`;
  }

  private hideTooltip() {
    if (this.tooltipEl) this.tooltipEl.style.display = 'none';
    this.hoverKey = null;
    this.tooltipSize = null;
  }

  /** Worklist line (HTML) for a hovered part: mark icon (or a pinned icon),
   *  water icon, and the note — no worklist name (only the active worklist is
   *  ever shown). Note text is HTML-escaped; the icon SVGs are trusted. Null
   *  when the part isn't on the active worklist. */
  private formatWorklistForPart(refdes: string): string | null {
    const wl = worklistStore.activeWorklist;
    if (!wl || !refdes) return null;
    const e = wl.entries.find(x => x.refdes === refdes);
    if (!e) return null;
    const head: string[] = [];
    if (e.mark !== 'none') head.push(PART_MARK_SVG[e.mark]);
    if (e.waterdamage) head.push(WATER_SVG);
    const lines: string[] = [];
    if (head.length) lines.push(head.join(' '));
    if (e.note?.trim()) lines.push(escapeHtml(e.note.trim()));   // note on its own line
    return lines.length ? lines.join('<br>') : null;             // nothing → hide the line
  }

  /** Worklist line (HTML) for a hovered net: mark icon, surge icon, every
   *  recorded reading (kind icon/letter + value, V→diode→Ω), and the note —
   *  no worklist name. Independent of the OBD line. Null when not on the list. */
  private formatWorklistForNet(net: string): string | null {
    const wl = worklistStore.activeWorklist;
    if (!wl || !net) return null;
    const e = wl.netEntries?.find(x => x.netName === net);
    if (!e) return null;
    const head: string[] = [];
    if (e.mark !== 'none') head.push(NET_MARK_SVG[e.mark]);
    if (e.surge) head.push(SURGE_SVG);
    const readings = MEAS_KINDS
      .map(k => e.measurements?.[k])
      .filter((m): m is NetMeasurement => !!m && m.status === 'recorded' && !!m.value)
      .map(m => `${MEAS_SVG[m.kind] ?? escapeHtml(MEAS_LETTER[m.kind])} ${escapeHtml(m.value!)}`);
    if (readings.length) head.push(readings.join(' · '));
    const lines: string[] = [];
    if (head.length) lines.push(head.join(' '));
    if (e.note?.trim()) lines.push(escapeHtml(e.note.trim()));   // note on its own line
    return lines.length ? lines.join('<br>') : null;             // nothing → hide the line
  }

  /** Compose the OBD reading line for the currently-hovered net. Empty
   *  string when there is no board number, no cached OBD data, or no net
   *  match — the caller hides the span in that case. Hot path: called on
   *  every pin-hover move, so the work beyond a Map lookup must be cheap.
   *  Wrapped in try/catch because a throw here would propagate up through
   *  the pointermove handler and noisily fill the console on every move. */
  /** Cached board-number for the current `boardStore.fileName`. The 6-regex
   *  pass in extractBoardNumberFromFilename was running on every pointermove
   *  (R-3 in 2026-05-07-renderer.md). The filename only changes on board
   *  load / tab switch, so caching against it is sufficient. `null` is a
   *  valid memoised "no match" — distinguished from "not yet computed" by
   *  the sentinel filename `undefined`. */
  private _obdMemoFileName: string | undefined = undefined;
  private _obdMemoBoardNumber: string | null = null;

  private getMemoizedObdBoardNumber(): string | null {
    const tab = boardStore.activeTab;
    const key = tab ? `${tab.fileId ?? ''}|${tab.fileName}` : '';
    if (key !== this._obdMemoFileName) {
      this._obdMemoFileName = key;
      this._obdMemoBoardNumber = obdBoardNumberFor(tab);
    }
    return this._obdMemoBoardNumber;
  }

  private formatObdForNet(netName: string): string {
    try {
      const bn = this.getMemoizedObdBoardNumber();
      if (!bn) return '';
      const nets = obdNetIndex(bn).get(netName) ?? [];
      if (nets.length === 0) return '';
      const diodes = uniqOf(nets, n => n.diode);
      const volts = uniqOf(nets, n => n.voltage);
      const ohms = uniqOf(nets, n => n.resistance);
      const hasComment = nets.some(n => Array.isArray(n.comments) && n.comments.length > 0);
      const parts: string[] = [];
      if (diodes.length) parts.push(`d ${diodes.join('/')}`);
      if (volts.length) parts.push(`${volts.join('/')} V`);
      if (ohms.length) parts.push(`${ohms.join('/')} Ω`);
      if (parts.length === 0 && !hasComment) return '';
      return (parts.join(' · ') + (hasComment ? ' 📝' : '')).trim();
    } catch (e) {
      log.render.warn('OBD tooltip lookup failed', e);
      return '';
    }
  }

  private handleClick(world: Point) {
    if (this.dragZoomConsumedClick) {
      this.dragZoomConsumedClick = false;
      return;
    }
    // A gesture that moved is a drag, whatever pixi-viewport thinks it saw.
    // Shift+drag is drag-to-zoom, and without this it also lands here as a
    // shift+click and adds the part under the cursor to the worklist.
    // `dragZoomActive` covers the click pixi emits *during* the drag; the
    // travel test covers one emitted at release, for gestures whose moves were
    // hidden from pixi by some other handler.
    const dragTol = this.gestureIsTouch
      ? BoardRenderer.TOUCH_CLICK_DRAG_TOLERANCE_PX
      : BoardRenderer.CLICK_DRAG_TOLERANCE_PX;
    if (this.dragZoomActive || this.pointerTravelPx > dragTol) {
      this.lastPointerShift = false;
      this.clickCycle = null;
      this.clearPendingCycleAdvance();
      return;
    }
    // A gesture that ever had two fingers on it is a pinch, and one the
    // browser cancelled was taken over by its own recogniser. Neither is a
    // tap, and neither is distinguishable by distance — see the field
    // comments on `gestureWasMultiTouch`. The flags are deliberately NOT
    // cleared here: they are cleared when the next gesture starts, because a
    // pinch releases one finger at a time and pixi-viewport can emit its
    // stale `clicked` on either release.
    if (this.gestureWasMultiTouch || this.gestureWasCancelled) {
      log.ui.log(`touch: swallowed a stale click (multiTouch=${this.gestureWasMultiTouch} ` +
        `cancelled=${this.gestureWasCancelled} travel=${Math.round(this.pointerTravelPx)}px)`);
      this.lastPointerShift = false;
      this.clickCycle = null;
      this.clearPendingCycleAdvance();
      return;
    }
    // Resize Mode intercepts the click: classify the element under the cursor
    // and open its resize popup instead of selecting. Pan/zoom are unaffected
    // (pixi-viewport only emits 'clicked' when the pointer didn't drag).
    if (resizeModeStore.enabled) {
      this.lastPointerShift = false;
      this.handleResizeClick(world);
      return;
    }
    // Slide mode: ⌘+click (Ctrl+click off macOS), or any tap with the
    // toolbar's Several parts toggle on, adds a part to / removes it from the
    // multi-selection, so a slide can caption several parts at once. Shift
    // is left alone: Shift+click still adds to the worklist here too.
    const addMod = this.lastPointerAddMod;
    this.lastPointerAddMod = false;
    if (slideStore.enabled && !this.lastPointerShift && (addMod || slideStore.multi)) {
      this.lastPointerShift = false;
      this.clickCycle = null;
      this.clearPendingCycleAdvance();
      const hit = this.hitTestStack(world)[0];
      if (hit && this.tabId !== null) {
        // The first add keeps the part already selected in the set too.
        const primary = boardStore.selection.partIndex;
        if (primary !== null && selectionSetStore.current.ordered.length === 0 && primary !== hit.partIndex) {
          selectionSetStore.add(this.tabId, primary);
        }
        // A selected part that is not the one in focus gets the focus (its
        // reading boxes) first; picking it again removes it. Without this a
        // tablet, which has no plain-click alternative while the toggle is on,
        // could never get back to an earlier part's readings.
        const name = this.board?.parts[hit.partIndex]?.name ?? null;
        if (selectionSetStore.has(hit.partIndex) && slideStore.focusPart !== name) {
          slideStore.setFocusPart(name);
          return;
        }
        selectionSetStore.toggle(this.tabId, hit.partIndex);
        // The part just picked is the one whose readings get typed in next.
        if (selectionSetStore.has(hit.partIndex)) slideStore.setFocusPart(name);
        else if (slideStore.focusPart === name) slideStore.setFocusPart(null);
      }
      return;
    }
    const shift = this.lastPointerShift;
    this.lastPointerShift = false;

    const stack = this.hitTestStack(world);
    if (stack.length > 0) {
      if (shift) {
        // Shift+click adds the smallest part under the cursor to the worklist.
        this.clickCycle = null;
        this.clearPendingCycleAdvance();
        this.shiftClickToWorklist(stack[0].partIndex);
        return;
      }

      // Stacked-selection cycling (#23): the first click at a spot selects the
      // smallest overlapping part; clicking again at the same spot advances
      // through the stack (smallest-first, wrapping).
      const tol = BoardRenderer.CYCLE_TOLERANCE_PX / Math.abs(this.viewport.scale.x);
      const key = stack.map(h => h.partIndex).join(',');
      const cyc = this.clickCycle;
      // The selection test is load-bearing, not belt-and-braces. Without it,
      // clearing the selection from anywhere but the board left the cycle
      // pointing at the same spot, and a click there took the "same spot
      // again" branch — which, on a stack of one, does nothing at all. The
      // part became unclickable until the user clicked somewhere else first.
      const sameSpot = !!cyc && cyc.key === key &&
        cyc.selectedPartIndex === boardStore.selection.partIndex &&
        Math.abs(cyc.x - world.x) <= tol && Math.abs(cyc.y - world.y) <= tol;

      if (!sameSpot) {
        this.clearPendingCycleAdvance();
        this.clickCycle = { x: world.x, y: world.y, key, index: 0, selectedPartIndex: stack[0].partIndex };
        this.selectStackEntry(stack[0]);
        return;
      }

      // Same spot again → advance to the next part, but DEFER the advance so a
      // following double-click (PDF lookup) can cancel it and stay put.
      if (stack.length > 1) {
        this.clearPendingCycleAdvance();
        this.pendingCycleAdvance = setTimeout(() => {
          this.pendingCycleAdvance = null;
          const c = this.clickCycle;
          if (!c || c.key !== key) return;
          c.index = (c.index + 1) % stack.length;
          c.selectedPartIndex = stack[c.index].partIndex;
          this.selectStackEntry(stack[c.index]);
        }, BoardRenderer.CYCLE_DBL_GUARD_MS);
      }
      return;
    }

    // No part hit → fall back to trace highlight, else clear selection.
    this.clickCycle = null;
    this.clearPendingCycleAdvance();
    const traceHit = this.traceHitTest(world);
    if (traceHit && traceHit.net) {
      boardStore.highlightNet(
        boardStore.selection.highlightedNet === traceHit.net ? null : traceHit.net
      );
      return;
    }
    if (!shift) boardStore.selectPart(null);
  }

  /** Resize Mode click: classify the element under the cursor (text label →
   *  pin → part body) and open the matching resize popup at the click point.
   *  Text wins over the pin beneath it so a net-name label is directly
   *  editable. Empty space closes the popup. */
  private handleResizeClick(world: Point) {
    // Popup goes at the real cursor (client px === position:fixed coords).
    const pageX = this.lastPointerClient.x;
    const pageY = this.lastPointerClient.y;
    // Canvas-local CSS px for the label overlay hit-test (its boxes are in the
    // container's CSS coordinate space, NOT viewport device px).
    const rect = this.containerEl.getBoundingClientRect();
    const localX = pageX - rect.left;
    const localY = pageY - rect.top;

    const labelHit = this.textFastMode?.hitTest(localX, localY);
    const stack = this.hitTestStack(world);
    const top = stack.length > 0 ? stack[0] : null;
    const topPart = top ? this.board?.parts[top.partIndex] : null;

    // 1. Component (part) NAME label → select the whole part, Component group.
    if (labelHit?.kind === 'part') {
      boardStore.selectPart(labelHit.partIndex);
      resizeModeStore.openGroup('part', pageX, pageY, this.board?.parts[labelHit.partIndex]?.name ?? null);
      return;
    }

    // 2. Pin-level intent — a pin/pad hit, OR a pin-number / net-name label.
    //    Prefer the SPECIFIC pin under the cursor so its net highlights (a plain
    //    selectPart highlights no net — the BGA "menu opens but nothing
    //    selected" bug). Fall back to the nearest pin, then the part.
    const pinLevel = !!labelHit || (top != null && top.pinIndex >= 0);
    if (pinLevel) {
      let selPart = top && top.pinIndex >= 0 ? top.partIndex : -1;
      let selPin = top && top.pinIndex >= 0 ? top.pinIndex : -1;
      if (selPin < 0) {
        const near = this.nearestPin(world);   // covers dense BGA label clicks
        if (near) { selPart = near.partIndex; selPin = near.pinIndex; }
      }
      if (selPin >= 0) {
        const part = this.board?.parts[selPart];
        const pin = part?.pins[selPin];
        boardStore.selectPin(selPart, selPin);
        const ctx = part && pin ? `${part.name} · ${pin.net || pinDisplayId(pin, selPin)}` : null;
        resizeModeStore.openGroup('pin', pageX, pageY, ctx);
        return;
      }
      // No pin resolvable — still open the pin group; select the label's part.
      if (labelHit) boardStore.selectPart(labelHit.partIndex);
      resizeModeStore.openGroup('pin', pageX, pageY, this.board?.parts[labelHit?.partIndex ?? -1]?.name ?? null);
      return;
    }

    // 3. Part body hit (no pin, no label).
    if (top) {
      boardStore.selectPart(top.partIndex);
      resizeModeStore.openGroup('part', pageX, pageY, topPart?.name ?? null);
      return;
    }

    // 3. A highlighted-net connection line? (segments only exist while a net is
    //    lit — which the pin selection above provides). Point-to-segment test.
    if (this.netLineSegments.length > 0) {
      const thr = (renderSettingsStore.settings.clickThreshold * 1.5) / Math.abs(this.viewport.scale.x);
      const thr2 = thr * thr;
      for (const seg of this.netLineSegments) {
        if (pointSegDist2(world.x, world.y, seg.start.x, seg.start.y, seg.end.x, seg.end.y) <= thr2) {
          resizeModeStore.openGroup('netline', pageX, pageY, boardStore.selection.highlightedNet);
          return;
        }
      }
    }

    // 4. Empty board area → board transparency (clears any selection).
    boardStore.selectPart(null);
    resizeModeStore.openGroup('board', pageX, pageY, null);
  }

  /** Select a stack entry — a pin selection when a pad/pin was hit, else the
   *  whole part. */
  private selectStackEntry(hit: { partIndex: number; pinIndex: number }) {
    if (hit.pinIndex >= 0) boardStore.selectPin(hit.partIndex, hit.pinIndex);
    else boardStore.selectPart(hit.partIndex);
  }

  /** Shift+click → toggle a part in the active worklist (auto-creates one on
   *  first use). Both directions toast; the sidebar force-opens only on the
   *  very first add so the user learns where rows go. */
  private shiftClickToWorklist(partIndex: number) {
    const refdes = boardStore.board?.parts[partIndex]?.name;
    if (!refdes) return;
    const wl = worklistStore.activeWorklist;
    if (wl && wl.entries.some(e => e.refdes === refdes)) {
      worklistStore.removeEntry(wl.id, refdes);
      boardStore.addToast(`Removed '${refdes}' from ${wl.name}`, 'info');
    } else {
      const firstUse = !wl;
      worklistStore.pushRefdesToActive(refdes);
      const name = worklistStore.activeWorklist?.name ?? 'worklist';
      boardStore.addToast(`Added '${refdes}' to ${name}`, 'info');
      if (firstUse) openBoardSidebarTab('worklist');
    }
  }

  /** Cancel a pending deferred cycle advance (used by pointer-move reset and by
   *  double-click, which must never cycle). */
  private clearPendingCycleAdvance() {
    if (this.pendingCycleAdvance != null) {
      clearTimeout(this.pendingCycleAdvance);
      this.pendingCycleAdvance = null;
    }
  }

  /** Redraw the multi-select + active-worklist outline overlay.
   *
   *  Width rule matches native part borders (see board-scene.ts
   *  `updateBorderWidths`): `max(s.partBorderWidth, minScreenPx/scale)`.
   *  Highlight uses a 2-px floor (regular borders use 1-px) so it reads as
   *  visibly heavier than a normal outline without becoming a blob on small
   *  components. The stroke sits OUTSIDE the bbox via expanded-rect geometry
   *  (path runs `half` mils outside the bbox on each side) so the part body
   *  is never covered.
   *
   *  Colour:
   *    • Active-worklist entries  → coloured by per-entry mark
   *      (none/replaced/reworked/cleaned), via shared MARK_COLOR_HEX so the
   *      panel UI and the canvas agree on what each state looks like.
   *    • Ephemeral selection set → cyan (distinct from any mark colour).
   *
   *  Highlight set is rebuilt from `refdes` each frame against the live
   *  board so fold-mode / sub-board changes (which re-derive part indices)
   *  don't paint outlines on the wrong components.
   *
   *  Called on store notify, on viewport `moved`, and on board change. */
  private redrawMultiHighlight(force = true): void {
    const gfx = this.multiHighlightGfx;
    if (!gfx) return;
    if (force) this.multiHighlightDirty = true;
    const board = this.board;
    if (!board) { gfx.clear(); return; }
    const s = renderSettingsStore.settings;
    const scale = this.viewport?.scale?.x ?? 1;
    // Same formula as `updateBorderWidths` for part borders, just with a
    // 2-px floor instead of 1-px so the highlight reads as heavier.
    const minScreenPx = 2;
    const width = Math.max(s.partBorderWidth, scale > 0 ? minScreenPx / scale : 1);
    // Pan frames don't change what's highlighted; zoom frames only matter once
    // the screen-space stroke width moves ≥2% (same tolerance updateBorderWidths
    // uses). Skip the clear+restroke entirely otherwise (A4).
    if (!this.multiHighlightDirty && this.lastMultiHighlightWidth > 0 &&
        Math.abs(width - this.lastMultiHighlightWidth) / this.lastMultiHighlightWidth < 0.02) {
      return;
    }
    this.multiHighlightDirty = false;
    this.lastMultiHighlightWidth = width;
    gfx.clear();
    const half = width / 2;
    const drawOutline = (idx: number, color: number, alpha: number) => {
      const part = board.parts[idx];
      if (!part) return;
      if (!this.isPartVisible(part)) return;
      // Use computePartRenderBounds — the same function the part borders use.
      // Raw `part.bounds` is the pin-cloud envelope and gives degenerate
      // shapes for 2-pin parts (a line) and BGAs (just the pin grid, no
      // body padding). render-bounds applies the 40% body expansion that
      // 2-pin parts get, plus any partType body-shape override.
      const rb = computePartRenderBounds(part, s);
      gfx.rect(rb.px - half, rb.py - half, rb.pw + width, rb.ph + width)
         .stroke({ color, alpha, width });
    };
    const tabId = boardStore.activeTabId;
    if (tabId == null) return;
    // Active worklist outlines — only when the Highlight toggle is on so the
    // board is uncluttered by default. Mark colours are preserved (no cyan
    // override). Ephemeral selection drawn over the top so a part in both
    // retains the brighter cyan cue.
    const worklist = worklistStore.activeWorklist;
    if (worklist && boardStore.connectionHighlight) {
      // Build refdes → partIndex only inside this branch (the Highlight toggle
      // is off by default) so we can re-resolve stored worklist entries whose
      // cached partIndex may be stale after a fold-mode change re-derived the
      // board. Keeps the per-frame 'moved' path allocation-free when off.
      const byRefdes = this.buildRefdesIndex();
      for (const e of worklist.entries) {
        const idx = byRefdes.get(e.refdes);
        if (idx == null) continue;
        // `?? MARK_COLOR_HEX.none` guards an out-of-vocab mark from a stale /
        // malformed stored entry — Color conversion of `undefined` would throw
        // inside this unguarded 'moved' handler.
        drawOutline(idx, MARK_COLOR_HEX[e.mark] ?? MARK_COLOR_HEX.none, 0.95);
      }
    }
    const sel = selectionSetStore.current;
    for (const idx of sel.ordered) {
      drawOutline(idx, 0x00e5ff, 1.0);
    }

    this.drawCompareHighlight(gfx, width, drawOutline);
  }

  /** Colour of a compared pin, or null for the statuses not worth marking. */
  private static compareMarkColor(status: PinDiffStatus): number | null {
    switch (status) {
      // A real disagreement between the two boards.
      case 'differs': case 'only-a': case 'only-b':
        return COMPARE_DIFFER_COLOR;
      // The same net under another name, or nearly so.
      case 'renamed': case 'similar': case 'partial':
        return COMPARE_PARTIAL_COLOR;
      // `same`, `bulk` and `nc` are deliberately unmarked. On a 400-pin BGA
      // where 390 pins agree, painting those would bury the ten that do not —
      // the standing outline already says which part is under comparison.
      default:
        return null;
    }
  }

  /**
   * Paint the active comparison onto the board: a standing outline around the
   * compared part, and a mark on each pin that is not a plain match.
   *
   * Drawn into `multiHighlightGfx` rather than a layer of its own — it is the
   * same kind of thing as the cyan multi-select (a persistent, store-driven
   * overlay), it already lives in `invalidateAllScenes`'s detach list, and a
   * new Graphics is exactly the shape of bug that took out the halo sprite and
   * `butterflyDimGfx`.
   *
   * Pin marks reuse the net-highlight's shape resolution so a mark traces the
   * pin as drawn — pad outline when pads are shown, the pin sprite otherwise,
   * clamped to the same per-part radius.
   */
  private drawCompareHighlight(
    gfx: Graphics,
    width: number,
    drawOutline: (idx: number, color: number, alpha: number) => void,
  ): void {
    const tabId = this.tabId ?? boardStore.activeTabId;
    if (tabId == null) return;
    const hl = partCompareStore.highlightFor(tabId);
    if (!hl) {
      if (import.meta.env.DEV) this.lastCompareMarks = null;
      return;
    }

    const board = this.board;
    if (!board) return;
    const partIndex = this.buildRefdesIndex().get(hl.partName);
    if (partIndex == null) return;
    const part = board.parts[partIndex];
    if (!part || !this.isPartVisible(part)) return;

    drawOutline(partIndex, COMPARE_OUTLINE_COLOR, 1.0);

    const s = renderSettingsStore.settings;
    const storedPads = part.pins.length === 2
      ? this.activeScene?.twoPinPadPolys.get(partIndex)
      : null;
    const clamp = this.activeScene?.pinRadiusClamp.get(partIndex) ?? Infinity;
    const grow = s.netHighlightGrow;

    // One stroke call per colour, not per pin: a Graphics flushes its path on
    // every `stroke()`, so per-pin stroking on a big BGA is hundreds of draws.
    const byColor = new Map<number, Array<() => void>>();
    for (const [pinIndex, info] of hl.pins) {
      const color = BoardRenderer.compareMarkColor(info.status);
      if (color == null) continue;
      const pin = part.pins[pinIndex];
      if (!pin) continue;
      let arr = byColor.get(color);
      if (!arr) { arr = []; byColor.set(color, arr); }
      if (boardStore.showPads && storedPads && storedPads[pinIndex]) {
        const poly = storedPads[pinIndex];
        arr.push(() => drawPoly(gfx, poly));
      } else if (boardStore.showPads && pin.padBounds) {
        const padGeom: PadGeometry = {
          bounds: pin.padBounds,
          shape: pin.padShape,
          width: pin.padWidth,
          height: pin.padHeight,
          angleDeg: pin.padAngleDeg,
          cornerRadius: pin.padCornerRadius,
          polygon: pin.padPolygon,
        };
        arr.push(() => drawPadShape(gfx, padGeom, grow));
      } else {
        const r = Math.min(computePinRadius(s, pin.radius), clamp);
        arr.push(() => drawPinShape(gfx, pin, r, grow));
      }
    }
    for (const [color, fns] of byColor) {
      for (const fn of fns) fn();
      gfx.stroke({ color, alpha: 1, width: width * 1.2 });
    }

    if (import.meta.env.DEV) {
      // What actually reached the canvas, for `tests/compare-highlight.spec.ts`.
      // Counting marks is the closest an E2E can get to "the right pins are
      // red" without pixel comparison.
      this.lastCompareMarks = {
        part: hl.partName,
        differ: byColor.get(COMPARE_DIFFER_COLOR)?.length ?? 0,
        partial: byColor.get(COMPARE_PARTIAL_COLOR)?.length ?? 0,
      };
    }
  }

  /** Double-click on a component → force-search it in the linked PDF (overwrites user search). */
  private handleDblClick(e: MouseEvent) {
    // A double-click drives PDF lookup, never the click-cycle — cancel any
    // pending same-spot advance the two clicks scheduled (#23).
    this.clearPendingCycleAdvance();
    if (!this.board) return;
    // Look up the currently-selected part (what the user sees highlighted, incl.
    // a part they cycled to), falling back to the smallest under the cursor.
    let partIndex = boardStore.selection.partIndex;
    if (partIndex == null) {
      const rect = this.containerEl.getBoundingClientRect();
      const worldPoint = this.viewport.toWorld(e.clientX - rect.left, e.clientY - rect.top);
      partIndex = this.hitTest(worldPoint)?.partIndex ?? null;
    }
    if (partIndex == null) return;
    const part = this.board.parts[partIndex];
    if (part) this.triggerFollowPdf(part, true);
  }

  /**
   * Open the board menu from a touch gesture (long press, or hold + second
   * finger tap). The finger still on the glass will come up later and produce
   * (a) pixi-viewport's `clicked`, which would change the selection under the
   * menu, and (b) the browser's compatibility `click`, which would land on
   * the menu or close it — both are swallowed once.
   */
  private openTouchMenu(x: number, y: number) {
    this.dragZoomConsumedClick = true;
    // The trap lives exactly as long as the held finger: it is disarmed a
    // moment after that finger's pointerup, whether or not a click came of
    // it. A fixed 700 ms window from the open ate the user's first tap on a
    // menu row whenever the browser sent no compatibility click for the
    // release (a hold that moved, a long hold) — the row did nothing.
    const swallow = (ev: Event) => { ev.stopPropagation(); ev.preventDefault(); disarm(); };
    const onUp = () => { window.removeEventListener('pointerup', onUp, true); setTimeout(disarm, 80); };
    const disarm = () => {
      document.removeEventListener('click', swallow, { capture: true });
      window.removeEventListener('pointerup', onUp, true);
      clearTimeout(cap);
    };
    document.addEventListener('click', swallow, { capture: true });
    window.addEventListener('pointerup', onUp, true);
    const cap = setTimeout(disarm, 10_000);   // never leave it armed for good
    this.handleRightClick({ clientX: x, clientY: y });
  }

  private camSnapshot() {
    return { x: this.viewport.x, y: this.viewport.y, sx: this.viewport.scale.x, sy: this.viewport.scale.y };
  }

  /** Undo the few px of zoom a tapping second finger fed the pinch path. */
  private restoreCam(c: { x: number; y: number; sx: number; sy: number }) {
    this.viewport.scale.set(c.sx, c.sy);
    this.viewport.position.set(c.x, c.y);
    this.programmaticMove = true;
    this.needsRender = true;
    // No netLinesDirty: a camera pose never moves the world-space segments.
  }

  private handleRightClick(e: { clientX: number; clientY: number }) {
    if (!this.board) return;
    const rect = this.containerEl.getBoundingClientRect();
    const worldPoint = this.viewport.toWorld(
      e.clientX - rect.left,
      e.clientY - rect.top,
    );
    const stack = this.hitTestStack(worldPoint);
    if (stack.length === 0) return;
    const top = stack[0];
    const part = this.board.parts[top.partIndex];
    if (!part) return;
    const pin = top.pinIndex >= 0 ? part.pins[top.pinIndex] : null;
    const pinId = pin ? pinDisplayId(pin, top.pinIndex) : null;
    const netName = pin?.net || null;
    // Every part under the point, smallest-first — the menu repeats its action
    // row per part so any stacked part can be pinned / looked up (#23). Dedupe
    // by refdes: 2-pin parts contribute both a pin and a whole-part cycle entry,
    // but the menu only needs one row per component.
    const overlap = [...new Set(
      stack
        .map(h => this.board!.parts[h.partIndex]?.name)
        .filter((n): n is string => !!n),
    )];
    contextMenuStore.showBoard(e.clientX, e.clientY, part.name, pinId, netName, overlap);
  }

  /**
   * Animated fit-to-board (no scale cap), used by the FitBoard overlay
   * button + initial board open.
   */
  fitToBoard(board?: BoardData) {
    const b = board?.bounds ?? this.board?.bounds;
    if (!b) return;
    this.programmaticMove = true;
    // Defense-in-depth against the same reinit race the ResizeObserver guards:
    // a pending-fit timer could fire during reinitApp() when app.renderer isn't
    // ready / viewport is stale. reinitApp sizes the fresh viewport itself.
    if (this.reinitializing || !this.app?.renderer || !this.viewport) return;

    // Sync viewport dimensions to current container size — the container may have
    // been resized (e.g. dockview panel split) since the viewport was created.
    const cw = this.containerEl.clientWidth;
    const ch = this.containerEl.clientHeight;
    if (cw > 0 && ch > 0) {
      this.viewport.resize(cw, ch);
      this.app.renderer.resize(cw, ch);
    }

    const pad = renderSettingsStore.settings.fitPadding;
    const bw = b.maxX - b.minX;
    const bh = b.maxY - b.minY;

    if (boardStore.butterfly) {
      // Butterfly separates along the shorter visual axis (mirrors applyFlips logic).
      const rotation = boardStore.rotation * Math.PI / 180;
      const sinR = Math.abs(Math.sin(rotation));
      const cosR = Math.abs(Math.cos(rotation));
      const visualW = bw * cosR + bh * sinR;
      const visualH = bw * sinR + bh * cosR;
      const separateX = visualH >= visualW;
      const sepDim = separateX ? visualW : visualH;
      const gap = sepDim * 0.05;
      // Double the dimension along the separation axis
      const fitW = separateX ? bw * 2 + gap + pad * 2 : bw + pad * 2;
      const fitH = separateX ? bh + pad * 2 : bh * 2 + gap + pad * 2;
      this.viewport.fit(false, fitW, fitH);
    } else {
      this.viewport.fit(false, bw + pad * 2, bh + pad * 2);
    }
    this.viewport.moveCenter((b.minX + b.maxX) / 2, (b.minY + b.maxY) / 2);
    this.needsRender = true;
    if (!this.app.ticker.started) this.app.ticker.start();
  }

  /**
   * Returns true if the entire bbox is comfortably visible in the viewport.
   * Uses a small inset margin so the bbox never sits flush against the edge.
   */
  private bboxOnScreen(bounds: { minX: number; minY: number; maxX: number; maxY: number }, root?: Container): boolean {
    const sw = this.containerEl.clientWidth;
    const sh = this.containerEl.clientHeight;
    if (sw === 0 || sh === 0) return false;
    const insetPx = 24;
    const tl = this.sceneToWorld({ x: bounds.minX, y: bounds.minY }, root);
    const br = this.sceneToWorld({ x: bounds.maxX, y: bounds.maxY }, root);
    const screenTL = this.viewport.toScreen(tl.x, tl.y);
    const screenBR = this.viewport.toScreen(br.x, br.y);
    const minSX = Math.min(screenTL.x, screenBR.x);
    const maxSX = Math.max(screenTL.x, screenBR.x);
    const minSY = Math.min(screenTL.y, screenBR.y);
    const maxSY = Math.max(screenTL.y, screenBR.y);
    return minSX >= insetPx && maxSX <= sw - insetPx
        && minSY >= insetPx && maxSY <= sh - insetPx;
  }

  /**
   * Pan-only: translate the viewport so the bbox center lands at the screen
   * center. Scale is unchanged. Animated via the existing zoomAnim slot.
   */
  private panToBounds(bounds: { minX: number; minY: number; maxX: number; maxY: number }, root?: Container) {
    this.programmaticMove = true;
    const sw = this.containerEl.clientWidth;
    const sh = this.containerEl.clientHeight;
    if (sw === 0 || sh === 0) return;
    const center = this.sceneToWorld({
      x: (bounds.minX + bounds.maxX) / 2,
      y: (bounds.minY + bounds.maxY) / 2,
    }, root);
    const toScaleX = this.viewport.scale.x;
    const toScaleY = this.viewport.scale.y;
    const toPosX = -center.x * toScaleX + sw / 2;
    const toPosY = -center.y * toScaleY + sh / 2;

    this.zoomAnim = {
      fromX: this.viewport.position.x,
      fromY: this.viewport.position.y,
      fromScaleX: toScaleX,
      fromScaleY: toScaleY,
      toX: toPosX,
      toY: toPosY,
      toScaleX,
      toScaleY,
      elapsed: 0,
      duration: 300,
    };
    // A programmatic jump supersedes any in-flight wheel-zoom tween.
    this.zoomTween = null;
    if (!this.app.ticker.started) this.app.ticker.start();
  }

  /**
   * Pan to a part if any part of its bbox is outside the viewport. Otherwise
   * no-op. Used by the Parts dropdown when on-select = panIfOffscreen.
   */
  panToPartIfOffscreen(partIndex: number) {
    const part = this.board?.parts[partIndex];
    if (!part) return;
    const root = this.rootForPart(part);
    if (this.bboxOnScreen(part.bounds, root)) return;
    this.panToBounds(part.bounds, root);
  }

  /**
   * Pan to a net if its pin bbox is fully off-screen. Otherwise no-op.
   * Used by the Nets dropdown when on-select = panIfOffscreen.
   */
  panToNetIfOffscreen(netName: string) {
    if (!this.board) return;
    const net = this.board.nets.get(netName);
    if (!net || net.pinIndices.length === 0) return;

    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (const { partIndex, pinIndex } of net.pinIndices) {
      const pin = this.board.parts[partIndex]?.pins[pinIndex];
      if (!pin) continue;
      if (pin.position.x < minX) minX = pin.position.x;
      if (pin.position.y < minY) minY = pin.position.y;
      if (pin.position.x > maxX) maxX = pin.position.x;
      if (pin.position.y > maxY) maxY = pin.position.y;
    }
    if (!isFinite(minX)) return;

    const bounds = { minX, minY, maxX, maxY };
    if (this.bboxOnScreen(bounds)) return;
    this.panToBounds(bounds);
  }

  private panView(direction: PanDirection) {
    if (!this.viewport) return;
    const { keyboardPanFraction } = renderSettingsStore.settings;
    const stepX = this.viewport.screenWidth * keyboardPanFraction;
    const stepY = this.viewport.screenHeight * keyboardPanFraction;
    const dx = direction === 'left' ? stepX : direction === 'right' ? -stepX : 0;
    const dy = direction === 'up' ? stepY : direction === 'down' ? -stepY : 0;
    this.viewport.position.set(this.viewport.position.x + dx, this.viewport.position.y + dy);
    this.needsRender = true;
    // No netLinesDirty: a pan never moves the world-space segments.
  }

  private zoomKeyboard(direction: ZoomDirection) {
    if (!this.viewport) return;
    let cx = this.viewport.screenWidth / 2;
    let cy = this.viewport.screenHeight / 2;
    // 2R 24/10/2026 21h30 (Roger): botões/teclado aproximam na cruz do centro; a rodinha/pinça continua no mouse.
    // localStorage «2r-zoom-tecla-mouse»="1" volta ao zoom na direção do mouse
    try {
      if (localStorage.getItem('2r-zoom-tecla-mouse') === '1') {
        const M = r2w.__r2MouseXY, R = this.containerEl.getBoundingClientRect();
        if (M && Date.now() - M.t < 15e3 && M.x >= R.left && M.x <= R.right && M.y >= R.top && M.y <= R.bottom) { cx = M.x - R.left; cy = M.y - R.top; }
      }
    } catch { /* */ }
    const { keyboardZoomDelta } = renderSettingsStore.settings;
    const rawDelta = direction === 'in' ? -keyboardZoomDelta : keyboardZoomDelta;
    this.zoomAtScreen(cx, cy, rawDelta, true);
    this.viewport.emit('moved', { viewport: this.viewport, type: 'wheel' });
    this.needsRender = true;
    // No netLinesDirty: a zoom never moves the world-space segments; the
    // zoom-frame re-stroke and its settle redraw the width. A dirty flag here
    // made that settle recompute — in mode 'off' that emptied the cache.
  }

  destroy() {
    if (this.r2BoundVis) {
      document.removeEventListener('visibilitychange', this.r2BoundVis);
      window.removeEventListener('focus', this.r2BoundVis);
      window.removeEventListener('pageshow', this.r2BoundVis);
      this.r2BoundVis = null;
    }
    this.destroyed = true;
    // destroy() is the full-teardown path (tab closed) and does NOT route
    // through teardownForReinit() — unregister here too, or a closed tab's
    // Application would stay referenced in renderer-registry.ts forever.
    if (this.tabId !== null) { unregisterRenderer(this.tabId); navHistoryStore.unregisterBoardCamera(this.tabId, this.navCamera); }
    if (this.selectionBlinkTimer) {
      clearTimeout(this.selectionBlinkTimer);
      this.selectionBlinkTimer = null;
    }
    this.teardownHalo();
    this.zoomTween = null;
    if (this.zoomSettleTimer) { clearTimeout(this.zoomSettleTimer); this.zoomSettleTimer = null; }
    if (this.netLineSettleTimer) { clearTimeout(this.netLineSettleTimer); this.netLineSettleTimer = null; }
    if (this._pendingFitTimer) { clearTimeout(this._pendingFitTimer); this._pendingFitTimer = null; }
    if (this._rebuildTimer) { clearTimeout(this._rebuildTimer); this._rebuildTimer = null; }
    if (this._deepPauseTimer) { clearTimeout(this._deepPauseTimer); this._deepPauseTimer = null; }
    if (this.wheelIdleTimer) { clearTimeout(this.wheelIdleTimer); this.wheelIdleTimer = null; }
    if (this.followDebounceTimer) { clearTimeout(this.followDebounceTimer); this.followDebounceTimer = null; }
    this.unsubscribeBoard?.();
    this.unsubscribeSettings?.();
    this.unsubscribeResizeMode?.();
    this.unsubscribeTheme?.();
    this.unsubscribeCamOverlay?.();
    this.unsubscribeObd?.();
    this.unsubscribeViewCommands?.();
    this.unsubscribeSelectionSet?.();
    this.unsubscribePartCompare?.();
    this.unsubscribeWorklist?.();
    if (this.boundPointerTravel) {
      window.removeEventListener('pointermove', this.boundPointerTravel, true);
      this.boundPointerTravel = null;
    }
    if (this.boundPointerRelease) {
      window.removeEventListener('pointerup', this.boundPointerRelease, true);
      window.removeEventListener('pointercancel', this.boundPointerRelease, true);
      this.boundPointerRelease = null;
    }
    if (this.boundTouchPinchMove) {
      this.containerEl.removeEventListener('pointermove', this.boundTouchPinchMove, true);
      this.boundTouchPinchMove = null;
    }
    if (this.boundGestureEnd) {
      this.containerEl.removeEventListener('gestureend', this.boundGestureEnd);
      this.boundGestureEnd = null;
    }
    if (this.gestureReleaseTimer) { clearTimeout(this.gestureReleaseTimer); this.gestureReleaseTimer = null; }
    if (this.boundShiftCapture) {
      this.containerEl.removeEventListener('pointerdown', this.boundShiftCapture, true);
      this.boundShiftCapture = null;
    }
    this.resizeObserver?.disconnect();
    // Null the field too: Blink's V8ResizeObserverCallback keeps the callback
    // closure alive while the observer object is reachable, and every arrow
    // created in init() shares one closure context whose `this` is this
    // renderer — one surviving callback pins the whole renderer (heap-snapshot
    // verified, 2026-07-12 memory-leak investigation).
    this.resizeObserver = null;
    if (this.boundShiftWheel) {
      this.containerEl.removeEventListener('wheel', this.boundShiftWheel, true);
      this.boundShiftWheel = null;
    }
    // Force-cleanup any in-flight drag-zoom gesture so its window-scoped
    // listeners don't outlive this BoardRenderer and then dereference a
    // disposed viewport on the next pointerup.
    if (this.activeDragZoomCleanup) {
      this.activeDragZoomCleanup();
      this.activeDragZoomCleanup = null;
    }
    if (this.boundDragZoomDown) {
      this.containerEl.removeEventListener('pointerdown', this.boundDragZoomDown, true);
      this.boundDragZoomDown = null;
    }
    if (this.boundContextMenu) {
      this.containerEl.removeEventListener('contextmenu', this.boundContextMenu);
    }
    if (this.boundDblClick) {
      this.containerEl.removeEventListener('dblclick', this.boundDblClick);
      this.boundDblClick = null;
    }
    if (this.longPressTimer) { clearTimeout(this.longPressTimer); this.longPressTimer = null; }
    this.longPressStart = null;
    if (this.boundLongPressDown) {
      this.containerEl.removeEventListener('pointerdown', this.boundLongPressDown, true);
      this.boundLongPressDown = null;
    }
    if (this.boundLongPressMove) {
      this.containerEl.removeEventListener('pointermove', this.boundLongPressMove, true);
      this.boundLongPressMove = null;
    }
    if (this.boundLongPressEnd) {
      this.containerEl.removeEventListener('pointerup', this.boundLongPressEnd, true);
      this.containerEl.removeEventListener('pointercancel', this.boundLongPressEnd, true);
      this.boundLongPressEnd = null;
    }
    if (this.tooltipCanvas && this.boundHover) {
      this.tooltipCanvas.removeEventListener('pointermove', this.boundHover);
      this.tooltipCanvas.removeEventListener('pointerleave', this.boundHideTooltip!);
      if (this.boundWheelWake) this.tooltipCanvas.removeEventListener('wheel', this.boundWheelWake);
      if (this.boundPointerCapture) this.tooltipCanvas.removeEventListener('pointerdown', this.boundPointerCapture);
      this.tooltipCanvas = null;
    }
    if (this.hoverRafId !== null) { cancelAnimationFrame(this.hoverRafId); this.hoverRafId = null; }
    this.boundHover = null;
    this.boundHideTooltip = null;
    this.boundWheelWake = null;
    this.boundPointerCapture = null;
    this.tooltipEl?.remove();
    this.tooltipEl = null;
    // Tear down the Canvas2D label overlay (removes its containerEl-sibling canvas).
    this.textFastMode?.destroy();
    this.textFastMode = null;
    // Same for the HDR glow layer — also a containerEl sibling.
    this.hdrOverlay?.destroy();
    this.hdrOverlay = null;
    this.tooltipNetSpan = null;
    this.tooltipDetailSpan = null;
    this.tooltipMetaSpan = null;
    this.tooltipObdSpan = null;
    if (this.boundGestureStart) {
      this.containerEl.removeEventListener('gesturestart', this.boundGestureStart);
      this.boundGestureStart = null;
    }
    if (this.boundGestureChange) {
      this.containerEl.removeEventListener('gesturechange', this.boundGestureChange);
      this.boundGestureChange = null;
    }
    if (this.perfToggleBtn && this.perfToggleBtnHandler) {
      this.perfToggleBtn.removeEventListener('click', this.perfToggleBtnHandler);
      this.perfToggleBtnHandler = null;
    }
    if (this.hudEl) {
      this.hudEl.remove();
      this.hudEl = null;
    }
    this.selectionOverlayEl?.parentElement?.removeChild(this.selectionOverlayEl);
    this.selectionOverlayEl = null;
    this.perfOverlayEl?.parentElement?.removeChild(this.perfOverlayEl);
    this.perfOverlayEl = null;
    this.perfToggleBtn?.parentElement?.removeChild(this.perfToggleBtn);
    this.perfToggleBtn = null;
    if (this.initialized) {
      // Clean up scene objects
      try { this.invalidateAllScenes(); } catch { /* ignore */ }
      try { this.netDimGfx?.clear(); } catch { /* ignore */ }
      try { this.netLabelLayer?.removeChildren(); } catch { /* ignore */ }
      try { this.selectionGfx?.clear(); } catch { /* ignore */ }
      try { this.netLinesGfx?.clear(); } catch { /* ignore */ }
      this.stopTicker();
    }
    // Remove context loss listeners before discarding the canvas
    this.removeContextLossHandlers();
    // Do NOT call app.destroy() — its stage/ticker teardown plus
    // renderer.destroy(true) clears the module-level pools shared by ALL
    // PixiJS Applications (GlobalResourceRegistry.release → batchPool
    // corruption). But renderer.destroy(false) is safe: it runs every
    // per-renderer system destroy — GlContextSystem removes its
    // webglcontextlost/restored listeners (which otherwise pin the whole
    // WebGLRenderer from a GC root — heap-snapshot verified), loses the GL
    // context, and GraphicsContextSystem releases its managed contexts'
    // batches back to the (patched) pool — WITHOUT touching global state.
    try {
      // Drop every viewport listener ('moved'/'clicked'/plugin handlers).
      // PixiJS's event system keeps closed viewports reachable via pooled
      // FederatedPointerEvent.target / overTargets state, so listeners left
      // on the viewport pin their closures — and through the shared init()
      // closure context, this whole renderer + its last board (heap-snapshot
      // verified: ~15 MB retained per opened board before this fix).
      this.viewport?.removeAllListeners();
    } catch { /* ignore */ }
    try {
      const canvas = this.app?.renderer?.canvas as HTMLCanvasElement | undefined;
      // Defensive: detach the shared ticker callback before nulling app, so the
      // onTick → this closure can't keep this renderer alive even if a shared
      // ticker is ever introduced (each Application currently owns its ticker).
      this.app?.ticker?.remove(this.onTick);
      try {
        this.app?.renderer?.destroy(false);
      } catch {
        // Fallback: at least force-release the WebGL context so the browser
        // reclaims the GPU slot (browsers cap contexts at ~8-16).
        const gl = (this.app?.renderer as unknown as { gl?: WebGL2RenderingContext })?.gl;
        gl?.getExtension('WEBGL_lose_context')?.loseContext();
      }
      canvas?.parentElement?.removeChild(canvas);
    } catch { /* ignore */ }

    // Break strong reference cycles so GC can collect the Application + scene graph.
    // The onTick arrow function captures `this`, so we must sever the chain:
    //   BoardRenderer → app → ticker → onTick → BoardRenderer
    // The `app` and `viewport` fields are typed non-nullable to keep call-sites
    // clean across the file; null them out via an unknown cast since this is
    // the only teardown path and no subsequent calls run after disposal.
    // Explicitly destroy the halo texture/sprite — teardownHalo() only detaches
    // them from the scene. The GPU side is already freed by loseContext above;
    // this frees the JS-side Texture/Sprite wrappers immediately rather than
    // waiting for GC of the whole renderer.
    try { this._haloSprite?.destroy(); } catch { /* ignore */ }
    try { this._haloTexture?.destroy(true); } catch { /* ignore */ }
    this._haloSprite = null;
    this._haloTexture = null;
    this.activeScene = null;
    this.sceneCache.clear();
    this.hitGridCache.clear();
    // viewportStates is a WeakMap — entries die with their boards, no clear() needed.
    this.board = null;
    // lastRenderedSel.board holds a full BoardData — even a pinned renderer
    // shell must not retain the parsed board after close.
    this.lastRenderedSel.board = null;
    (this as unknown as { app: unknown }).app = null;
    (this as unknown as { viewport: unknown }).viewport = null;
  }
}
