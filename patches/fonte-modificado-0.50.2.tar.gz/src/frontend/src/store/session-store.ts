import { boardStore } from './board-store';
import { boardCache } from './board-cache';
import { pdfStore } from './pdf-store';
import { log } from './log-store';
import { databankStore } from './databank-store';
import { ensurePdfPanel } from './dockview-api';

const SESSION_KEY = 'boardripper-session';
const DEBOUNCE_MS = 500;

export interface SessionEntry {
  kind: 'board' | 'pdf';
  fileName: string;
  fileSize: number;
  fileLastModified: number;
  fileId?: number;
  active?: boolean;
}

export interface SavedSession {
  version: 1;
  savedAt: number;
  entries: SessionEntry[];
}

/** Build the current open set from the board + PDF stores. */
function snapshot(): SessionEntry[] {
  const boards: SessionEntry[] = boardStore.openBoardEntries().map(b => ({
    kind: 'board',
    fileName: b.fileName,
    fileSize: b.fileSize,
    fileLastModified: b.fileLastModified,
    fileId: b.fileId,
    active: b.active || undefined,
  }));
  const pdfs: SessionEntry[] = pdfStore.openPdfEntries().map(p => ({
    kind: 'pdf',
    fileName: p.fileName,
    fileSize: p.fileSize,
    fileLastModified: p.fileLastModified,
    fileId: p.fileId,
  }));
  return [...boards, ...pdfs];
}

/** Write the current open set to localStorage immediately. */
export function captureNow(): void {
  try {
    const session: SavedSession = { version: 1, savedAt: Date.now(), entries: snapshot() };
    localStorage.setItem(SESSION_KEY, JSON.stringify(session));
  } catch (e) {
    log.cache.warn('session: capture failed', e);
  }
}

export function readSession(): SavedSession | null {
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    if (!raw) return null;
    const s = JSON.parse(raw) as SavedSession;
    if (!s || s.version !== 1 || !Array.isArray(s.entries)) return null;
    return s;
  } catch {
    return null;
  }
}

export function clearSession(): void {
  try { localStorage.removeItem(SESSION_KEY); } catch { /* ignore */ }
}

let inited = false;
let debounceTimer: ReturnType<typeof setTimeout> | null = null;

function scheduleCapture(): void {
  if (debounceTimer !== null) clearTimeout(debounceTimer);
  debounceTimer = setTimeout(() => { debounceTimer = null; captureNow(); }, DEBOUNCE_MS);
}

/** Wire continuous capture: subscribe to board + PDF changes (debounced) and
 *  flush on beforeunload. Idempotent. Restore is driven separately by the
 *  SessionRestorePrompt, so initSessionStore does NOT auto-restore. */
export function initSessionStore(): void {
  if (inited) return;
  inited = true;
  boardStore.subscribe(scheduleCapture);
  pdfStore.subscribe(scheduleCapture);
  window.addEventListener('beforeunload', captureNow);
}

/** Reopen every entry in a saved session, then focus the previously-active
 *  board. Resolves databank-first (dropped files live under incoming/), with
 *  the IndexedDB board cache as a board-only fallback. Collects unavailable
 *  files into one summary toast. Never called automatically — the restore
 *  prompt invokes it on the user's explicit Reopen. */
export async function restoreSession(session: SavedSession): Promise<void> {
  await databankStore.ensureLoaded();
  // ensureLoaded() returns before the full file stream completes, so pre-hydrate
  // the rows this session references by id (non-mutating, works mid-stream).
  // Name-only legacy entries need a full-list scan, so only then wait for the
  // stream to finish.
  const wantIds = session.entries
    .map(e => e.fileId)
    .filter((v): v is number => typeof v === 'number');
  const rowsById = new Map(
    (wantIds.length ? await databankStore.fetchFileRows(wantIds) : []).map(r => [r.id, r] as const),
  );
  if (session.entries.some(e => e.fileId == null)) {
    await databankStore.whenFilesComplete();
  }
  const unavailable: string[] = [];
  let activeBoardName: string | null = null;
  let opened = 0;   // count only items that genuinely opened (a panel/tab), not just loaded

  for (const e of session.entries) {
    try {
      const dbFile =
        (e.fileId != null ? (rowsById.get(e.fileId) ?? databankStore.fileById(e.fileId)) : undefined) ??
        databankStore.findFileByName(e.fileName, e.fileSize) ??
        null;

      if (e.kind === 'board') {
        if (dbFile && dbFile.file_type === 'board') {
          const file = await databankStore.fetchFileBuffer(dbFile);
          await boardStore.loadFile(file);
          boardStore.setTabFileId(e.fileName, dbFile.id);   // tag for binding rehydration below
        } else if (!(await boardStore.loadFromCache(e.fileName, e.fileSize, e.fileLastModified))) {
          unavailable.push(e.fileName);
          continue;
        }
        opened++;
        if (e.active) activeBoardName = e.fileName;
      } else {
        // pdf — must replicate openPdfFiles' full sequence (addPdf + loadFile +
        // ensurePdfPanel), otherwise the doc loads invisibly and never opens a panel.
        if (dbFile && dbFile.file_type === 'pdf') {
          const file = await databankStore.fetchFileBuffer(dbFile);
          boardStore.addPdf(file);
          await pdfStore.loadFile(file, dbFile.id);
          ensurePdfPanel(file.name);
          opened++;
        } else {
          // Local-drop / picker PDF: no databank row, but pdfStore.loadFile put
          // its bytes in the cache. Rebuild a File so the normal open path runs.
          const bytes = await boardCache.getPdfBytes(e.fileName, e.fileSize, e.fileLastModified);
          if (!bytes) { unavailable.push(e.fileName); continue; }
          const file = new File([bytes], e.fileName, { type: 'application/pdf', lastModified: e.fileLastModified });
          boardStore.addPdf(file);
          await pdfStore.loadFile(file);
          ensurePdfPanel(file.name);
          opened++;
        }
      }
    } catch (err) {
      log.ui.warn(`session restore: ${e.fileName} failed`, err);
      unavailable.push(e.fileName);
    }
  }

  // Re-establish the runtime board↔PDF link from the durable backend bindings, so
  // a reloaded board shows its ∞ link (and auto-switch works) without re-opening
  // it from the Library. Only auto_open rows + PDFs that actually reopened are
  // linked (a ∞-unlink demotes auto_open=false, so it stays unlinked).
  for (const tab of boardStore.tabs) {
    if (tab.fileId == null) continue;
    try {
      for (const b of await databankStore.getBindingsFor(tab.fileId)) {
        if (!b.auto_open) continue;
        const pdf = databankStore.fileById(b.pdf_file_id);
        if (pdf && pdfStore.loadedFileNames.includes(pdf.filename)) {
          boardStore.addPdfBinding(tab.id, pdf.filename);
        }
      }
    } catch (err) {
      log.ui.warn(`session restore: binding rehydrate for ${tab.fileName} failed`, err);
    }
  }

  if (activeBoardName) {
    const tab = boardStore.tabs.find(t => t.fileName === activeBoardName);
    if (tab) boardStore.switchTab(tab.id);
  }

  // 2R 27/10 (Roger: tirar o recado vermelho) — placas do Acervo 2R não ficam no computador; não reabrir não é erro
  if (unavailable.length > 0) log.ui.warn(`session restore: ${unavailable.length} não reabertos: ${unavailable.join(', ')}`);
  if (opened > 0) boardStore.addToast(`${opened} placa${opened > 1 ? 's' : ''} reaberta${opened > 1 ? 's' : ''} da última sessão`, 'info');
}
