import type { BoardData, BoardRevision, Part, Pin } from '../parsers';
import { Emitter } from './emitter';
import { boardCache } from './board-cache';
import { parseBoardFile, getFormat, getFileExtension } from '../parsers';
import { bundleAscFiles, identifyAscSection } from '../parsers/bdv-asc-parser';
import { ASC_SECTIONS, ascSectionFromName } from '../parsers/asc-siblings';
import { parseBoardFileInWorker, isWorkerTransportError } from '../parsers/parse-in-worker';
import { FZKeyError } from '../parsers/fz-parser';
import { fzKeyStore } from './fz-key-store';
import { computeBBox, generateSyntheticOutline, detectGhostComponents, computeAdjacentNets, buildNets, flagMechanicalParts } from '../parsers/types';
import { renderSettingsStore, partBridgesHierarchy } from './render-settings';
import { log } from './log-store';
import { loadProgressStore } from './load-progress-store';
import { fileViewPrefsStore } from './file-view-prefs-store';
import { createLayerStates, defaultLayerColor } from './layer-store';
import { themeStore, type Theme } from './themes';
import type { LayerState } from './layer-store';
import { deriveBoardView } from './derive-board-view';
import { navHistoryStore } from './nav-history-store';
import type { NavCause } from './nav-history';
import type { FoldMode } from './derive-board-view';
import { looseMatch, r2Match } from '../r2/loose-match';


export interface SelectionState {
  partIndex: number | null;
  pinIndex: number | null;
  highlightedNet: string | null;
  /** Nets reachable from `highlightedNet` through 2-pin components, populated
   *  only when `netLineMode === 'chain-adjacent'`. Empty otherwise. Derived
   *  state — recomputed in `highlightNet()` and `cycleNetLineMode()`,
   *  not persisted. */
  adjacentNets: Set<string>;
}

/**
 * Net-line visualization mode. Cycles via the toolbar button:
 *   off            → no connecting lines drawn
 *   star           → lines radiate from the selected pin/part to nearest
 *                    pin on every other part on the net (anchor required)
 *   chain          → greedy minimum-spanning tree across all parts on the
 *                    selected net
 *   chain-adjacent → chain mode + propagate the highlight one hop through
 *                    2-pin components to adjacent nets (drawn in
 *                    `adjacentNetLineColor`); ground nets are skipped,
 *                    power rails terminate (no further recursion)
 */
export type NetLineMode = 'off' | 'star' | 'chain' | 'chain-adjacent';

/** Tri-state ghost-button mode (cycled by GhostsButton):
 *   - 'off'    — no cross-side hint at all
 *   - 'ghosts' — when a net is highlighted, hidden-side parts on that net
 *                draw as cyan ghost outlines
 *   - 'disco'  — same-net parts (both sides) get a red heartbeat halo */
export type GhostMode = 'off' | 'ghosts' | 'disco';

export interface BoardTab {
  id: number;
  fileName: string;
  board: BoardData | null;
  /** Databank file id once this board is known to the server library (set when
   *  opened from the Library or after a drop is ingested). Lets session restore
   *  and board↔PDF binding resolve by id instead of name+size. */
  fileId?: number;
  /** Cache key used to load this board (empty string if loaded fresh from file) */
  cacheKey: string;
  selection: SelectionState;
  showTop: boolean;
  showBottom: boolean;
  butterfly: boolean;
  searchQuery: string;
  rotation: number;
  mirrorX: boolean;
  mirrorY: boolean;
  flipAxis: 'x' | 'y';
  netLineMode: NetLineMode;
  /** When true, nets shared by ≥2 multi-selected parts (the cyan selection
   *  set, typically loaded from a worklist) are highlighted on the canvas.
   *  Connecting net-lines are NOT drawn for these — only an explicitly
   *  selected net gets lines. Toggled from the Worklist "Connections" button. */
  connectionHighlight: boolean;
  dimMode: 'off' | 'dim' | 'darklight';
  showHoverInfo: boolean;
  followPdf: boolean;
  showTraces: boolean;
  showComponents: boolean;
  showVias: boolean;
  showSilkscreen: boolean;
  showPads: boolean;
  /** Show standalone copper pads not bound to any component pin (GND
   *  stitching, power-rail drops, mounting-hole pads). Default OFF — these
   *  visually clutter the board around components but carry no schematic
   *  meaning. Only TVW currently tags pads with `attached`; for other
   *  formats this flag is a no-op. */
  showCopperDrops: boolean;
  /** Show copper-fill polygons (ground planes, power pours). Default OFF —
   *  the dim copper-tint fill is informative but visually heavy. Currently
   *  only TVW Surface blocks populate the data; other formats are a no-op. */
  showSurfaces: boolean;
  showPins: boolean;
  showOutlines: boolean;
  showLabels: boolean;
  /** See [[GhostMode]]. Default `'ghosts'`, persisted per-tab. The boolean
   *  getters `showGhosts` / `discoHighlight` are derived from this. */
  ghostMode: GhostMode;
  /** Per-layer visibility and color state (multi-layer boards only) */
  layerStates: LayerState[];
  /** Layer whose traces are bumped to the top of the z-stack while nothing is
   *  pinned (transient — set by clicking a layer row). null = none. */
  selectedLayerIndex: number | null;
  /** Pinned layer whose traces stay on top regardless of selection. Exactly
   *  one at a time; overrides selectedLayerIndex while set. null = none. */
  fixatedLayerIndex: number | null;
  pdfFileNames: string[];  // references into pdfFiles registry (1:N)
  /** When true, parts flagged in board.ghosts are filtered from the rendered
   *  parts list. Set via toggleHideGhosts(). Persists across revision switches
   *  on the same tab. */
  hideGhosts: boolean;
  /** Per-pair role overrides for the ghost detector. Set entries are pair
   *  signatures `${minIdx}-${maxIdx}` whose role is flipped (the auto-detected
   *  dominator is treated as the stale one and vice-versa). Used by the
   *  Revisions tab swap button so the user can override the detector when
   *  the heuristic picks the wrong side. */
  swappedGhostPairs: Set<string>;
  /** When true, every member of every BOM-alternate cluster is rendered
   *  (overlapping). When false (default), only the cluster's selected primary
   *  is shown — secondaries are filtered from the rendered parts list. */
  showBomAlternates: boolean;
  /** Per-cluster primary overrides. Key is a stable cluster signature (sorted
   *  member refdes joined by `,`); value is the chosen member's refdes. Empty
   *  for clusters where the auto-picked default is fine. */
  bomClusterSelections: Map<string, string>;
  /** Per-part user overrides. Keyed by stable partName (refdes) so the entry
   *  survives derive-board-view re-runs even though partIndex can shift in
   *  some fold modes. `hidden` removes the part entirely (no fill, no border,
   *  no pins); `sendToBack` is identical to the auto `mechanical` flag (fill
   *  is skipped). Cleared via the right-click menu's "Show part normally". */
  partOverrides: Map<string, { hidden?: boolean; sendToBack?: boolean }>;
  /** XZZ fold resolution. 'suggested' uses the parser's auto-fold output;
   *  'all-sides' renders the raw pre-fold layout (both halves side-by-side). */
  foldMode: FoldMode;
  /** XZZ multi-board selection. null = show all boards. An index selects the
   *  board at that position in `board.boards` (or the legacy
   *  `board.boardGroups`). */
  selectedBoardIndex: number | null;
  /** Boards (indices into `board.boards`) the user has flipped top ↔ bottom
   *  because the parser's side decision was wrong for this file. Persisted
   *  per file in file-view-prefs. */
  swappedBoards: Set<number>;
  /** True while the current selection was established via focusPart() or
   *  focusNet() (search-style paths). Cleared by canvas clicks (selectPart,
   *  selectPin), by highlightNet, and by any method that resets to
   *  emptySelection. Used by the renderer to OR-in auto-dim even when the
   *  user's dimMode is 'off'. */
  searchSelectionActive: boolean;
  /** Cached presented view of `board` — computed from (board, foldMode,
   *  selectedBoardIndex) via `deriveBoardView`. Invalidated whenever any of
   *  those inputs change. Consumers should read `boardStore.board` (which
   *  returns this) rather than `tab.board` directly. */
  _derivedBoard?: BoardData;
  _derivedBoardKey?: string;
}

export interface PdfEntry {
  file: File;
  /** Board tab IDs this PDF is bound to (empty = unbound) */
  boundTabIds: Set<number>;
}

/** How long the previewed part gets the loud solid-red heartbeat before it
 *  settles into the quiet 2-second beacon. */
export const PREVIEW_BURST_MS = 5500;

/** Marker state for a previewed component. `burst` is the arrival heartbeat —
 *  it takes over the disco layer entirely so exactly one part blinks — and
 *  `beacon` is the indefinite reminder that follows, drawn as a stroke ring
 *  rather than a fill so it stays distinguishable from net-wide disco. */
export interface PreviewPulse {
  partIndex: number;
  phase: 'burst' | 'beacon';
}

/**
 * How a selection came about, for the navigation history
 * (docs/specs/2026-09-29-navigation-history-design.md §5). Every selection
 * mutator takes it as an optional trailing argument with a default per
 * method — `selectPart`/`selectPin`/`highlightNet`/`promotePartOnNet` are a
 * click, `focusPart`/`focusNet` a search result — and the few callers whose
 * intent differs (a word clicked in the PDF, the MCP bridge) pass it.
 */
export interface NavOpts {
  cause?: NavCause;
  /** Label of the place a lookup started from (`820-02016.pdf · p.47`). */
  from?: string;
  via?: 'mcp' | 'worklist' | 'list';
}

export interface FocusRequest {
  /** Frame the whole derived board (fit-to-view) instead of zooming to `bounds`. */
  fit?: boolean;
  partIndex: number | null;
  bounds: { minX: number; minY: number; maxX: number; maxY: number };
  /** Blink the selection once the camera arrives. Default true. Preview
   *  navigation sets this false: it deliberately leaves the selection alone,
   *  so blinking would draw attention to the *previous* subject rather than
   *  the part being previewed. */
  blink?: boolean;
  /** 2R Tools: força o modo de zoom deste pedido ('keep' = só centraliza). */
  zoomMode?: 'auto' | 'keep' | 'always';
  /** 2R Tools: escala exata (zoom guardado da Sequência de start). */
  scale?: number;
  /** 2R Tools: guardar o zoom em uso depois de chegar (Sequência de start). */
  rememberZoom?: boolean;
}

const emptySelection: SelectionState = {
  partIndex: null,
  pinIndex: null,
  highlightedNet: null,
  adjacentNets: new Set<string>(),
};

/** A multi-board XZZ pack opens the way XZZ's own viewer shows it: every
 *  half where the file draws it, both sides visible. The folded view stays
 *  one click away in the board panel. */
function applyPackDefaults(tab: BoardTab, board: BoardData): void {
  if (board.format !== 'XZZ' || !board.boards || board.boards.length < 2) return;
  tab.foldMode = 'all-sides';
  tab.showTop = true;
  tab.showBottom = true;
}

/** Compute (or return the cached) derived BoardData for a tab. Re-derives
 *  only when the inputs change so `useSyncExternalStore` gets a stable
 *  reference on unchanged state. */
/** The part as the renderer draws it. Since packs open in the file's own
 *  layout (foldMode 'all-sides'), a part's drawn position is the DERIVED
 *  view's, not the parser's: on iPhone16_16Plus Q4400 sits at x=3037 in the
 *  file and x=5506 on screen. Every camera request must use this, or the
 *  search box flies to the seam between the halves and shows nothing (v0.37.3).
 *  Indices line up — deriveBoardView maps parts 1:1 and marks the dropped
 *  ones `hidden` rather than removing them. */
function viewPart(tab: BoardTab, idx: number): Part | undefined {
  return ensureDerivedBoard(tab)?.parts[idx] ?? tab.board?.parts[idx];
}

function ensureDerivedBoard(tab: BoardTab): BoardData | null {
  if (!tab.board) return null;
  const key = `${tab.foldMode}|${tab.selectedBoardIndex ?? 'all'}|${[...tab.swappedBoards].sort().join(',')}`;
  if (tab._derivedBoard && tab._derivedBoardKey === key) return tab._derivedBoard;
  tab._derivedBoard = deriveBoardView(tab.board, tab.foldMode, tab.selectedBoardIndex, tab.swappedBoards);
  tab._derivedBoardKey = key;
  return tab._derivedBoard;
}
/** Force re-derivation on next read (used after tab.board itself changes). */
function invalidateDerivedBoard(tab: BoardTab): void {
  tab._derivedBoard = undefined;
  tab._derivedBoardKey = undefined;
}

/** Auto-rotate tall boards 90°/270° so they display wide on screen.
 *  270° when the format's Y axis is flipped (most boardview formats),
 *  otherwise 90°. Matches the convention `loadFile` has always used.
 *
 *  X-fold XZZ boards need 90° instead of 270° (an extra 180° relative to
 *  the Y-fold case): after the parser X-flips the bottom half into the top
 *  half's region, the "natural top of board" sits in a coordinate frame
 *  that, when rotated 270°, lands 180° away from where the user expects
 *  it. Empirically verified against A2338 820-02773 and a sweep of Apple
 *  X-fold MLBs; Y-fold boards (820-02016) continue through the standard
 *  branch and are untouched. */
function computeAutoRotation(board: BoardData): number {
  const w = board.bounds.maxX - board.bounds.minX;
  const h = board.bounds.maxY - board.bounds.minY;
  if (h <= w) return 0;
  const flipY = board.flipY ?? getFormat(board.format)?.flipY ?? false;
  const isXFold = board.butterflyFoldAxis === 'x';
  if (isXFold) return flipY ? 90 : 270;
  return flipY ? 270 : 90;
}

/** Pick `flipAxis` so the on-screen flip is always a top-bottom mirror
 *  (hinge = horizontal screen axis), regardless of how the board is rotated.
 *
 *  - Unrotated (0°/180°):  scale.y=-1 flips Y directly in screen space →
 *    need `flipAxis='x'` (which sets `flipY` sign).
 *  - Rotated (90°/270°):   scene X maps to screen Y after rotation, so we
 *    need `scale.x=-1` instead → `flipAxis='y'` (which sets `flipX` sign).
 */
function flipAxisForRotation(rotationDeg: number): 'x' | 'y' {
  const rot90 = Math.round(rotationDeg / 90) % 4;
  const axesSwapped = rot90 === 1 || rot90 === 3;
  return axesSwapped ? 'y' : 'x';
}

/** The next multiple of 90° clockwise (+1) or counter-clockwise (−1) of
 *  `deg`; from a multiple itself, the one beyond it. */
function nextRightAngle(deg: number, dir: 1 | -1): number {
  const q = deg / 90;
  const onStep = Math.abs(q - Math.round(q)) < 1e-6;
  const next = onStep ? Math.round(q) + dir : (dir > 0 ? Math.ceil(q) : Math.floor(q));
  return ((next * 90) % 360 + 360) % 360;
}

/** The buttons' hinge rule, applied only from a right angle: from a free
 *  angle (left by the two-finger rotation) the button just turns the picture
 *  to the next right angle, and the parity swap — a 180° change of the
 *  bottom view — would be a jump, not a step. */
function buttonFlipAxis(flipAxis: 'x' | 'y', oldRotationDeg: number, newRotationDeg: number): 'x' | 'y' {
  const q = oldRotationDeg / 90;
  if (Math.abs(q - Math.round(q)) > 1e-6) return flipAxis;
  return rotateFlipAxis(flipAxis, oldRotationDeg, newRotationDeg);
}

/** When the rotation crosses an axes-swap boundary (90°↔0°, 270°↔180°, …),
 *  flip the board-axis hinge identifier so the *screen* direction the user
 *  selected stays the same. Without this, manual rotation silently inverts
 *  the meaning of the flip-axis toggle every 90°. */
function rotateFlipAxis(flipAxis: 'x' | 'y', oldRotationDeg: number, newRotationDeg: number): 'x' | 'y' {
  const oldSwapped = Math.round(oldRotationDeg / 90) % 2 === 1;
  const newSwapped = Math.round(newRotationDeg / 90) % 2 === 1;
  if (oldSwapped === newSwapped) return flipAxis;
  return flipAxis === 'x' ? 'y' : 'x';
}

/** Re-calibrate view orientation for the currently-derived board.
 *
 *  When a multi-board selection or fold mode changes, the derived BoardData
 *  can have a very different aspect ratio and fold axis than the raw file.
 *  Re-run the same heuristics `loadFile` uses on first open:
 *
 *  - `rotation` — auto-rotate tall boards so they display wide on screen
 *    (matches `autoRotation` logic on raw-board load).
 *  - `flipAxis` — pick based on the *screen* aspect (after rotation), so
 *    pressing "flip" mirrors along the board's visibly-longest side
 *    regardless of how the file stored the board.
 *  - `mirrorY` / `mirrorX` — reset to false. The historical "X-fold →
 *    mirrorY, Y-fold → mirrorX" convention was a render-time compensation
 *    for the XZZ parser leaving the butterfly bottom-half un-mirrored.
 *    The parser now fully unfolds geometry inside parseXZZ
 *    (`p.x = 2 * fold.axis - p.x` for X-fold bottom pins, equivalent for
 *    Y-fold), so no compensation is needed. Keeping the auto-mirrors
 *    visibly broke A2338 820-02773 (horizontal mirror after 270°
 *    autoRotation rotated the Y-flip into screen-X).
 */
function syncMirrorsToDerivedFold(tab: BoardTab): void {
  const derived = ensureDerivedBoard(tab);
  if (!derived) return;
  const rotation = computeAutoRotation(derived);
  tab.rotation = rotation;

  tab.flipAxis = flipAxisForRotation(rotation);

  tab.mirrorY = false;
  tab.mirrorX = false;
}

/** Extract a "820-XXXXX" board code (5 digits) from a file name, or null if absent. */
function extract820Code(fileName: string): string | null {
  const m = fileName.match(/820-(\d{5})/i);
  return m ? m[1] : null;
}

function findBestNameMatch(source: string, candidates: string[]): string | null {
  const srcCode = extract820Code(source);
  if (srcCode !== null) {
    // Strict mode: only bind when the 820-XXXXX code matches exactly.
    return candidates.find(c => extract820Code(c) === srcCode) ?? null;
  }
  // No 820-XXXXX pattern — do not auto-bind.
  return null;
}

let nextTabId = 1;

/* ── Persistent view preferences ── */
const VIEW_PREFS_KEY = 'boardripper-view-prefs';

interface ViewPrefs {
  netLineMode: NetLineMode;
  dimMode: 'off' | 'dim' | 'darklight';
  showHoverInfo: boolean;
  followPdf: boolean;
  /** When true, newly opened single-layer boards default to butterfly mode.
   *  Toggled by the user clicking the butterfly toolbar button. */
  defaultButterfly: boolean;
}

const DEFAULT_VIEW_PREFS: ViewPrefs = { netLineMode: 'off', dimMode: 'dim', showHoverInfo: true, followPdf: false, defaultButterfly: false };

/**
 * Build a renderable BoardData from a base board + a chosen revision +
 * the current "hide ghosts" state. When hideGhosts is on, ghost-flagged
 * parts are filtered out and bounds/outline are recomputed from the
 * remaining geometry. When off, the revision's full part list is used.
 * Returns a NEW object reference so the renderer's identity check fires.
 */
/** Symmetric signature for a ghost-detector pair; used as a Set key. */
export function ghostPairSig(a: number, b: number): string {
  return a < b ? `${a}-${b}` : `${b}-${a}`;
}

/** Stable empty-set fallback so the snapshot getter doesn't churn identity. */
const EMPTY_GHOST_SWAPS: ReadonlySet<string> = new Set<string>();
const EMPTY_SWAPPED_BOARDS: ReadonlySet<number> = new Set<number>();
const EMPTY_PART_OVERRIDES: ReadonlyMap<string, { hidden?: boolean; sendToBack?: boolean }> = new Map();
/** Stable empty-map fallback for the bomClusterSelections snapshot getter. */
const EMPTY_BOM_SELECTIONS: ReadonlyMap<string, string> = new Map<string, string>();

/**
 * Stable signature for a BOM-alternate cluster: sorted member refdes joined
 * by `,`. Survives parser re-runs as long as the cluster's membership is
 * unchanged (parts at the same overlap site with the same ref-des set).
 */
export function bomClusterSig(memberRefdes: readonly string[]): string {
  return [...memberRefdes].sort().join(',');
}

function buildRenderedBoard(
  base: BoardData,
  rev: BoardRevision,
  hideGhosts: boolean,
  swappedPairs: Set<string>,
  showBomAlternates: boolean,
  bomSelections: ReadonlyMap<string, string>,
): BoardData {
  // Per-revision traces/vias/layerNames override global ones when present
  const traceOverrides: Partial<BoardData> = {};
  if (rev.traces)     traceOverrides.traces = rev.traces;
  if (rev.vias)       traceOverrides.vias = rev.vias;
  if (rev.layerNames) traceOverrides.layerNames = rev.layerNames;

  // Build the set of part indices to drop from the rendered list.
  const drop = new Set<number>();

  // Ghost filtering — hide whichever side of each pair the user has currently
  // chosen as the ghost (auto-detected `partIndex` by default, `dominatorIndex`
  // when the pair's role has been swapped via the Revisions tab).
  if (hideGhosts) {
    for (const g of rev.ghosts) {
      const sig = ghostPairSig(g.partIndex, g.dominatorIndex);
      drop.add(swappedPairs.has(sig) ? g.dominatorIndex : g.partIndex);
    }
  }

  // BOM-alternate filtering — when `showBomAlternates` is off (default), each
  // cluster contributes only its selected primary; the rest are dropped. The
  // selected primary is the user's per-cluster override (when present and
  // pointing at a current member) or the auto-picked default from the parser.
  const clusters = rev.bomClusters;
  if (!showBomAlternates && clusters && clusters.length > 0) {
    for (const c of clusters) {
      const sig = bomClusterSig(c.memberRefdes);
      const requested = bomSelections.get(sig);
      const chosenRefdes = requested && c.memberRefdes.includes(requested)
        ? requested
        : c.defaultPrimaryRefdes;
      for (let k = 0; k < c.memberIndices.length; k++) {
        if (c.memberRefdes[k] !== chosenRefdes) drop.add(c.memberIndices[k]);
      }
    }
  }

  if (drop.size === 0) {
    return {
      ...base,
      ...traceOverrides,
      parts: rev.parts,
      bounds: rev.bounds,
      outline: rev.outline,
      nets: rev.nets,
      ghosts: rev.ghosts.length > 0 ? rev.ghosts : undefined,
      bomClusters: clusters && clusters.length > 0 ? clusters : undefined,
      activeRevision: rev.index,
    };
  }

  const filteredParts: Part[] = [];
  for (let i = 0; i < rev.parts.length; i++) {
    if (!drop.has(i)) filteredParts.push(rev.parts[i]);
  }
  const allPoints = filteredParts.flatMap(p => p.pins.map(pin => pin.position));
  const outline = generateSyntheticOutline(allPoints);
  const bounds = computeBBox([...outline, ...allPoints]);
  // Net pinIndices are partIndex-based against the parts array they were built
  // from. After dropping parts the indices shift, so rebuild nets against the
  // filtered array — otherwise highlights, net-lines and adjacency all resolve
  // pins to whichever part now occupies the original index.
  return {
    ...base,
    ...traceOverrides,
    parts: filteredParts,
    bounds,
    outline,
    nets: buildNets(filteredParts),
    ghosts: rev.ghosts.length > 0 ? rev.ghosts : undefined,
    bomClusters: clusters && clusters.length > 0 ? clusters : undefined,
    activeRevision: rev.index,
  };
}

/** Apply the current tab's filters (hideGhosts + BOM-alternate hiding) to the
 *  raw `tab.board` set by loadFile. No-op when neither filter would drop any
 *  parts (avoids the bounds/outline rebuild on clean files). */
function applyBoardFilters(tab: BoardTab): void {
  if (!tab.board) return;
  const hasBomClusters = !!tab.board.bomClusters && tab.board.bomClusters.length > 0;
  const hasGhostsToFilter = tab.hideGhosts && !!tab.board.ghosts && tab.board.ghosts.length > 0;
  const hasBomFilter = !tab.showBomAlternates && hasBomClusters;
  if (!hasGhostsToFilter && !hasBomFilter) return;
  const rev = tab.board.revisions?.find(r => r.index === tab.board?.activeRevision)
    ?? syntheticRevisionFromBoard(tab.board);
  tab.board = buildRenderedBoard(
    tab.board, rev, tab.hideGhosts, tab.swappedGhostPairs,
    tab.showBomAlternates, tab.bomClusterSelections,
  );
  invalidateDerivedBoard(tab);
}

/** Synthesize a BoardRevision from a single-revision board so that
 *  buildRenderedBoard can run uniformly for files without revisions[]. */
function syntheticRevisionFromBoard(b: BoardData): BoardRevision {
  return {
    index: 1,
    label: 'rev 1',
    componentCount: b.parts.length,
    parts: b.parts,
    bounds: b.bounds,
    outline: b.outline,
    nets: b.nets,
    ghosts: b.ghosts ?? detectGhostComponents(b.parts),
    bomClusters: b.bomClusters,
  };
}

function loadViewPrefs(): ViewPrefs {
  // 2R Tools (Roger, 10/10/2026): «deixar as linhas sempre visíveis por padrão» —
  // liga as linhas das nets (corrente) uma vez; quem desligar depois continua desligado.
  try {
    const in2r = typeof window !== 'undefined' && !!(window as unknown as { __2rAcervo?: unknown }).__2rAcervo;
    if (in2r && localStorage.getItem('2r-netlines-default') !== '1') {
      localStorage.setItem('2r-netlines-default', '1');
      const cur = JSON.parse(localStorage.getItem(VIEW_PREFS_KEY) || '{}');
      localStorage.setItem(VIEW_PREFS_KEY, JSON.stringify({ ...cur, netLineMode: 'chain' }));
    }
    // «essa função de escurecer a tela quando seleciono um componente é horrível, desabilita
    // isso… deixa só um contorno no componente» (Roger, 10/10/2026, 22:41)
    if (in2r && localStorage.getItem('2r-dim-off') !== '1') {
      localStorage.setItem('2r-dim-off', '1');
      const cur = JSON.parse(localStorage.getItem(VIEW_PREFS_KEY) || '{}');
      localStorage.setItem(VIEW_PREFS_KEY, JSON.stringify({ ...cur, dimMode: 'off' }));
    }
  } catch { /* */ }
  try {
    const raw = localStorage.getItem(VIEW_PREFS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<ViewPrefs> & { showNetLines?: boolean; showNetDim?: boolean };
      // Migrate legacy boolean: false → 'off', true → 'star' (the most common
      // previous behavior, since users typically had a part selected when
      // net lines were on; PDF lookups still get chain regardless).
      const merged: ViewPrefs = { ...DEFAULT_VIEW_PREFS, ...parsed };
      if (parsed.netLineMode === undefined && typeof parsed.showNetLines === 'boolean') {
        merged.netLineMode = parsed.showNetLines ? 'star' : 'off';
      }
      // Sanitize against invalid persisted values
      if (
        merged.netLineMode !== 'off' &&
        merged.netLineMode !== 'star' &&
        merged.netLineMode !== 'chain' &&
        merged.netLineMode !== 'chain-adjacent'
      ) {
        merged.netLineMode = 'off';
      }
      // Migrate legacy showNetDim boolean → dimMode tri-state
      if (merged.dimMode === undefined || (merged.dimMode !== 'off' && merged.dimMode !== 'dim' && merged.dimMode !== 'darklight')) {
        if (typeof parsed.showNetDim === 'boolean') {
          merged.dimMode = parsed.showNetDim ? 'dim' : 'off';
        } else {
          merged.dimMode = 'dim';
        }
      }
      return merged;
    }
  } catch { /* ignore */ }
  return { ...DEFAULT_VIEW_PREFS };
}

function saveViewPrefs(p: ViewPrefs) {
  try { localStorage.setItem(VIEW_PREFS_KEY, JSON.stringify(p)); } catch { /* ignore */ }
}

export interface Toast {
  id: number;
  message: string;
  type: 'error' | 'info';
  timestamp: number;
  /** Optional action button (e.g. Undo). Clicking it runs + dismisses. */
  action?: { label: string; run: () => void };
}

/** The board name the Tebo-ICT / eM-Test tools print at the head of every
 *  section file, before the two-space gap that separates it from the licence
 *  block: ` X555LD R36        Tebo-ICT,  license #Style` → `X555LD R36`.
 *  Returns '' when no file carries a plausible one. */
function ascHeaderBoardName(read: Array<{ text: string }>): string {
  for (const { text } of read) {
    const first = text.split(/\r?\n/, 1)[0] ?? '';
    const m = /^\s*([A-Za-z0-9][A-Za-z0-9 ._-]{2,39}?)\s{2,}\S/.exec(first);
    if (m) return m[1].trim();
  }
  return '';
}

/** Read a set of plain `.asc` section files and bundle them into one virtual
 *  file for the BDV ASC parser. Returns null when none of them holds a
 *  recognisable section.
 *
 *  The name is the sources' longest common prefix (`LA-L031P_pins.asc` +
 *  `LA-L031P_nails.asc` → `LA-L031P`), then the board name the vendor prints
 *  in every section's header (the delivery whose files are bare `Pins.asc` /
 *  `Nails.asc` has no shared prefix at all, and `Format.asc` is a poor name
 *  for a board), and only then the first file's stem — so the tab is named
 *  after the board rather than after whichever file was clicked first.
 *  `lastModified` takes the newest source so the board cache keys stably
 *  across re-opens instead of missing every time. */
async function mergeAscFiles(files: File[]): Promise<File | null> {
  const read = await Promise.all(files.map(async f => ({ name: f.name, text: await f.text() })));
  const bundled = bundleAscFiles(read);
  if (!bundled) return null;
  const stems = files.map(f => f.name.replace(/\.[^.]*$/, ''));
  let prefix = stems[0];
  for (const stem of stems.slice(1)) {
    let i = 0;
    while (i < prefix.length && i < stem.length && prefix[i] === stem[i]) i++;
    prefix = prefix.slice(0, i);
  }
  prefix = prefix.replace(/[\s._-]+$/, '');
  const name = `${prefix || ascHeaderBoardName(read) || stems[0]}.asc`;
  const lastModified = Math.max(...files.map(f => f.lastModified));
  log.parser.log(`(asc) merged ${files.length} section files into "${name}": ${files.map(f => f.name).join(', ')}`);
  return new File([bundled], name, { type: 'text/plain', lastModified });
}

/** True when the board carries anything drawn for the board as a whole rather
 *  than for one side — the geometry Butterfly mode has to hide. */
export function boardHasCopper(board: BoardData | null | undefined): boolean {
  if (!board) return false;
  return (board.traces?.length ?? 0) > 0 || (board.vias?.length ?? 0) > 0 || (board.surfaces?.length ?? 0) > 0;
}

export const BUTTERFLY_COPPER_HIDDEN_MESSAGE =
  'Butterfly shows both sides flat, so traces, vias and copper layers are hidden while it is on.';

/* 2R 27/10/2026 («estudo vira placa sozinho»): buscar/selecionar uma peça do outro lado NÃO vira a placa;
   quem vira é o ponto a ponto (R2ladoPeca) e o duplo clique no PDF. */
const R2_VIRA_SOZINHO = false;

class BoardStore extends Emitter {
  private _tabs: BoardTab[] = [];
  private _activeTabId: number | null = null;
  private _focusRequest: FocusRequest | null = null;
  /** Previewed part + when the preview started. Survives until another preview
   *  replaces it or the selection moves — the beacon is meant to still be there
   *  when you look back at the board a minute later. */
  private _preview: { partIndex: number; startedAt: number } | null = null;
  private _previewBurstTimer: ReturnType<typeof setTimeout> | null = null;
  private _pdfFiles: Map<string, PdfEntry> = new Map();
  private _toasts: Toast[] = [];
  private _nextToastId = 1;
  /** Guard against concurrent loadFile calls for the same file */
  private _loading = new Set<string>();
  /** Tabs whose board has arrived but whose scene is not on screen yet
   *  (tabId → file name). Parsing runs in a worker and never blocks; what
   *  follows — mounting the renderer and building the scene — runs on the
   *  main thread and does, for as long as it takes, with no input answered.
   *  Set before the panel is created, cleared by the renderer once the scene
   *  is active (or when the tab is closed). Together with `_loading` this is
   *  what BackgroundLoadBanner shows, so the pause reads as "loading" and
   *  not as a hang. */
  private _sceneBuilding = new Map<number, string>();
  private _backgroundLoadsSnap: { count: number; names: string[] } = { count: 0, names: [] };
  private _backgroundLoadsDirty = false;
  /** Original File objects for currently-open board tabs, keyed by fileName.
   *  Kept so "reparse current board" can re-read the raw bytes without
   *  re-prompting the user. Cleared when a tab closes. File references are
   *  cheap Blob handles — memory cost is negligible. */
  private _openFiles: Map<string, File> = new Map();
  /** Callback fired when a new board tab is created (tabId, fileName) */
  onTabCreated: ((tabId: number, fileName: string) => void) | null = null;
  /** Callback fired when a board tab is closed (tabId) */
  onTabClosed: ((tabId: number) => void) | null = null;

  constructor() {
    super();
    // Live-update chain-adjacent adjacency when the part-type hierarchyBridge
    // flags change under an active highlight, so Settings ▸ Part Types toggles
    // take effect without re-selecting the net. Singleton — never unsubscribed.
    renderSettingsStore.subscribe(() => this.refreshAdjacency());
  }

  get tabs(): BoardTab[] { return this._tabs; }
  get activeTabId(): number | null { return this._activeTabId; }
  get pdfFiles(): Map<string, PdfEntry> { return this._pdfFiles; }
  get toasts(): Toast[] { return this._toasts; }

  addToast(message: string, type: 'error' | 'info' = 'error', action?: Toast['action'], durationMs = 6000) {
    const toast: Toast = { id: this._nextToastId++, message, type, timestamp: Date.now(), action };
    this._toasts = [...this._toasts, toast];
    this.notify();
    setTimeout(() => this.dismissToast(toast.id), durationMs);
  }

  dismissToast(id: number) {
    const next = this._toasts.filter(t => t.id !== id);
    if (next.length !== this._toasts.length) {
      this._toasts = next;
      this.notify();
    }
  }

  /** Look up a specific tab by id (for per-panel sidebar use). */
  getTab(tabId: number): BoardTab | null {
    return this._tabs.find(t => t.id === tabId) ?? null;
  }

  get activeTab(): BoardTab | null {
    return this._tabs.find(t => t.id === this._activeTabId) ?? null;
  }

  /** Identity of every open board tab, for session persistence. fileSize /
   *  lastModified come from the in-memory File when present, else from the
   *  cacheKey (`${fileName}:${size}:${lastModified}`). */
  openBoardEntries(): { fileName: string; fileSize: number; fileLastModified: number; fileId?: number; active: boolean }[] {
    return this._tabs.map(t => {
      const f = this._openFiles.get(t.fileName);
      let size = f?.size ?? 0;
      let modified = f?.lastModified ?? 0;
      if ((!size || !modified) && t.cacheKey) {
        const lastColon = t.cacheKey.lastIndexOf(':');
        const prevColon = t.cacheKey.lastIndexOf(':', lastColon - 1);
        if (lastColon > 0 && prevColon > 0) {
          size = size || Number(t.cacheKey.slice(prevColon + 1, lastColon)) || 0;
          modified = modified || Number(t.cacheKey.slice(lastColon + 1)) || 0;
        }
      }
      return { fileName: t.fileName, fileSize: size, fileLastModified: modified, fileId: t.fileId, active: t.id === this._activeTabId };
    });
  }

  /** Tag an open board tab with its databank file id (after a drop is ingested
   *  or when opened from the Library). No-op if no tab matches the name. */
  setTabFileId(fileName: string, fileId: number) {
    const tab = this._tabs.find(t => t.fileName === fileName);
    if (tab && tab.fileId !== fileId) { tab.fileId = fileId; this.notify(); }
  }

  get board(): BoardData | null {
    const tab = this.activeTab;
    if (!tab?.board) return null;
    return ensureDerivedBoard(tab);
  }
  /** Untransformed board as emitted by the parser. Most code should use
   *  `board` (the derived view) instead — this exists only for places that
   *  genuinely need the full parts array (e.g. serialising the cache). */
  get rawBoard(): BoardData | null { return this.activeTab?.board ?? null; }
  get fileName(): string { return this.activeTab?.fileName ?? ''; }

  /** Boards being parsed or having their scene built — a stable reference
   *  while nothing changes (useSyncExternalStore). */
  get backgroundLoads(): { count: number; names: string[] } {
    if (this._backgroundLoadsDirty) {
      const names = [...new Set([...this._loading, ...this._sceneBuilding.values()])];
      this._backgroundLoadsSnap = { count: names.length, names };
      this._backgroundLoadsDirty = false;
    }
    return this._backgroundLoadsSnap;
  }

  private setLoading(name: string, on: boolean) {
    if (on) this._loading.add(name); else this._loading.delete(name);
    this._backgroundLoadsDirty = true;
    this.notify();
  }

  /** A tab's scene is about to be built on the main thread. Set here before
   *  the panel exists and again by the renderer right before it blocks. */
  markSceneBuilding(tabId: number, name: string) {
    if (this._sceneBuilding.get(tabId) === name) return;
    this._sceneBuilding.set(tabId, name);
    this._backgroundLoadsDirty = true;
    this.notify();
  }

  /** The scene is on screen (or the tab is gone). */
  clearSceneBuilding(tabId: number) {
    if (!this._sceneBuilding.delete(tabId)) return;
    this._backgroundLoadsDirty = true;
    this.notify();
  }
  get selection(): SelectionState { return this.activeTab?.selection ?? emptySelection; }
  get showTop(): boolean { return this.activeTab?.showTop ?? true; }
  get showBottom(): boolean { return this.activeTab?.showBottom ?? true; }
  get butterfly(): boolean { return this.activeTab?.butterfly ?? false; }
  get searchQuery(): string { return this.activeTab?.searchQuery ?? ''; }
  get rotation(): number { return this.activeTab?.rotation ?? 0; }
  get mirrorX(): boolean { return this.activeTab?.mirrorX ?? false; }
  get mirrorY(): boolean { return this.activeTab?.mirrorY ?? false; }
  get flipAxis(): 'x' | 'y' { return this.activeTab?.flipAxis ?? 'x'; }
  get netLineMode(): NetLineMode { return this.activeTab?.netLineMode ?? 'off'; }
  get connectionHighlight(): boolean { return this.activeTab?.connectionHighlight ?? false; }
  get showTraces(): boolean { return this.activeTab?.showTraces ?? true; }
  get showComponents(): boolean { return this.activeTab?.showComponents ?? true; }
  get showVias(): boolean { return this.activeTab?.showVias ?? false; }
  get showSilkscreen(): boolean { return this.activeTab?.showSilkscreen ?? true; }
  get showPads(): boolean { return this.activeTab?.showPads ?? true; }
  get showCopperDrops(): boolean { return this.activeTab?.showCopperDrops ?? false; }
  get showSurfaces(): boolean { return this.activeTab?.showSurfaces ?? false; }
  get showPins(): boolean { return this.activeTab?.showPins ?? true; }
  get showOutlines(): boolean { return this.activeTab?.showOutlines ?? true; }
  get showLabels(): boolean { return this.activeTab?.showLabels ?? true; }
  // 2R 30/10/2026 (Roger: «restaura o ghost na íntegra do projeto original do 0.50»): igual ao upstream
  get ghostMode(): GhostMode { return this.activeTab?.ghostMode ?? 'ghosts'; }
  get showGhosts(): boolean { return this.ghostMode !== 'off'; }
  get discoHighlight(): boolean { return this.ghostMode === 'disco'; }
  get hideGhosts(): boolean { return this.activeTab?.hideGhosts ?? false; }
  get swappedGhostPairs(): ReadonlySet<string> { return this.activeTab?.swappedGhostPairs ?? EMPTY_GHOST_SWAPS; }
  get showBomAlternates(): boolean { return this.activeTab?.showBomAlternates ?? false; }
  get bomClusterSelections(): ReadonlyMap<string, string> { return this.activeTab?.bomClusterSelections ?? EMPTY_BOM_SELECTIONS; }
  get partOverrides(): ReadonlyMap<string, { hidden?: boolean; sendToBack?: boolean }> { return this.activeTab?.partOverrides ?? EMPTY_PART_OVERRIDES; }
  get foldMode(): FoldMode { return this.activeTab?.foldMode ?? 'suggested'; }
  get selectedBoardIndex(): number | null { return this.activeTab?.selectedBoardIndex ?? null; }
  get swappedBoards(): ReadonlySet<number> { return this.activeTab?.swappedBoards ?? EMPTY_SWAPPED_BOARDS; }
  get layerStates(): LayerState[] { return this.activeTab?.layerStates ?? []; }
  get selectedLayerIndex(): number | null { return this.activeTab?.selectedLayerIndex ?? null; }
  get fixatedLayerIndex(): number | null { return this.activeTab?.fixatedLayerIndex ?? null; }
  get dimMode(): 'off' | 'dim' | 'darklight' { return this.activeTab?.dimMode ?? 'dim'; }
  /** @deprecated alias kept for backward compat — callers should migrate to dimMode */
  get showNetDim(): boolean { return this.dimMode === 'dim'; }
  get showHoverInfo(): boolean { return this.activeTab?.showHoverInfo ?? true; }
  get followPdf(): boolean { return this.activeTab?.followPdf ?? false; }
  get searchSelectionActive(): boolean { return this.activeTab?.searchSelectionActive ?? false; }

  /** All PDF Files bound to the active board tab */
  get boundPdfFiles(): File[] {
    const names = this.activeTab?.pdfFileNames ?? [];
    return names
      .map(n => this._pdfFiles.get(n)?.file)
      .filter((f): f is File => f != null);
  }

  /** All PDF filenames currently loaded */
  get pdfFileNames(): string[] {
    return [...this._pdfFiles.keys()];
  }

  /** Add a PDF to the registry. Does NOT bind it to any tab. */
  addPdf(file: File) {
    if (!this._pdfFiles.has(file.name)) {
      this._pdfFiles.set(file.name, { file, boundTabIds: new Set() });
    }
  }

  /** Add a PDF binding to the active board tab (appends, doesn't replace) */
  bindPdf(pdfFileName: string) {
    const tab = this.activeTab;
    if (!tab) return;
    this.addPdfBinding(tab.id, pdfFileName);
  }

  /** Add a PDF binding to a specific board tab (appends if not already bound) */
  addPdfBinding(tabId: number, pdfFileName: string) {
    const tab = this._tabs.find(t => t.id === tabId);
    if (!tab) return;
    if (tab.pdfFileNames.includes(pdfFileName)) return; // already bound

    tab.pdfFileNames.push(pdfFileName);
    const entry = this._pdfFiles.get(pdfFileName);
    if (entry) entry.boundTabIds.add(tab.id);
    this.notify();
  }

  /** Remove a specific PDF binding from a board tab */
  removePdfBinding(tabId: number, pdfFileName: string) {
    const tab = this._tabs.find(t => t.id === tabId);
    if (!tab) return;
    const idx = tab.pdfFileNames.indexOf(pdfFileName);
    if (idx === -1) return;

    tab.pdfFileNames.splice(idx, 1);
    const entry = this._pdfFiles.get(pdfFileName);
    if (entry) entry.boundTabIds.delete(tab.id);
    this.notify();
  }

  /** Clear all PDF bindings from a board tab */
  clearPdfBindings(tabId: number) {
    const tab = this._tabs.find(t => t.id === tabId);
    if (!tab) return;
    for (const name of tab.pdfFileNames) {
      const entry = this._pdfFiles.get(name);
      if (entry) entry.boundTabIds.delete(tab.id);
    }
    tab.pdfFileNames = [];
    this.notify();
  }

  /** Toggle a PDF binding on a board tab (add if missing, remove if present) */
  togglePdfBinding(tabId: number, pdfFileName: string) {
    const tab = this._tabs.find(t => t.id === tabId);
    if (!tab) return;
    if (tab.pdfFileNames.includes(pdfFileName)) {
      this.removePdfBinding(tabId, pdfFileName);
    } else {
      this.addPdfBinding(tabId, pdfFileName);
    }
  }

  /** Remove a PDF from the registry and unbind from all tabs */
  removePdf(pdfFileName: string) {
    const entry = this._pdfFiles.get(pdfFileName);
    if (!entry) return;
    for (const tab of this._tabs) {
      const idx = tab.pdfFileNames.indexOf(pdfFileName);
      if (idx !== -1) tab.pdfFileNames.splice(idx, 1);
    }
    this._pdfFiles.delete(pdfFileName);
    this.notify();
  }

  /** Bind a newly-opened PDF to an open board tab whose filename matches.
   *  Returns the matched tab's filename so the caller can promote a strong
   *  match to a persistent DB binding (in databank-store). Returns null when
   *  no name match exists — we no longer fall back to the active tab,
   *  because that caused the active board to "absorb" any stray PDF the
   *  user opened, including PDFs unrelated to it. */
  autoBindPdf(pdfFileName: string): string | null {
    const matchName = findBestNameMatch(pdfFileName, this._tabs.map(t => t.fileName));
    if (!matchName) return null;
    const tab = this._tabs.find(t => t.fileName === matchName);
    if (!tab) return null;
    if (!tab.pdfFileNames.includes(pdfFileName)) {
      tab.pdfFileNames.push(pdfFileName);
      const entry = this._pdfFiles.get(pdfFileName);
      if (entry) entry.boundTabIds.add(tab.id);
      this.notify();
    }
    return matchName;
  }

  /** Try to auto-bind a board tab to an existing PDF by partial filename match */
  autoBindBoard(boardFileName: string) {
    const tab = this._tabs.find(t => t.fileName === boardFileName);
    if (!tab) return;
    const pdfNames = [...this._pdfFiles.keys()];
    const match = findBestNameMatch(boardFileName, pdfNames);
    if (match && !tab.pdfFileNames.includes(match)) {
      tab.pdfFileNames.push(match);
      const entry = this._pdfFiles.get(match);
      if (entry) entry.boundTabIds.add(tab.id);
      this.notify();
    }
  }

  get selectedPart(): Part | null {
    const tab = this.activeTab;
    if (tab && tab.board && tab.selection.partIndex !== null) {
      return tab.board.parts[tab.selection.partIndex] ?? null;
    }
    return null;
  }

  get selectedPin(): Pin | null {
    const part = this.selectedPart;
    const tab = this.activeTab;
    if (part && tab && tab.selection.pinIndex !== null) {
      return part.pins[tab.selection.pinIndex] ?? null;
    }
    return null;
  }

  /** A colour-scheme switch (decision 2026-10-11): the dim goes off on every
   *  open board and as the default for new ones, and a copper layer still on
   *  the old scheme's default colour moves to the new scheme's. A colour the
   *  user picked by hand stays. */
  applyThemeChange(prev: Theme) {
    for (const tab of this._tabs) {
      tab.dimMode = 'off';
      if (tab.layerStates.length) {
        tab.layerStates = tab.layerStates.map((l, i) =>
          l.color === defaultLayerColor(l.name, i, prev) ? { ...l, color: defaultLayerColor(l.name, i) } : l);
      }
    }
    saveViewPrefs({ ...loadViewPrefs(), dimMode: 'off' });
    this.notify();
  }

  /** 2R: muda a aba ativa de fora (lado da placa no ponto a ponto / duplo clique no PDF) e avisa. */
  r2Patch(patch: Partial<BoardTab>) { this.updateActiveTab(patch); this.notify(); }
  r2Notify() { this.notify(); }

  private updateActiveTab(patch: Partial<BoardTab>) {
    const tab = this.activeTab;
    if (!tab) return;
    Object.assign(tab, patch);
  }

  /** Build a fresh BoardTab with default view state, register it as the active
   *  tab, and notify. Shared by loadFile and loadFromCache. */
  private makeTab(fileName: string): BoardTab {
    const id = nextTabId++;
    const vp = loadViewPrefs();
    const tab: BoardTab = {
      id,
      fileName,
      board: null,
      selection: { ...emptySelection, adjacentNets: new Set<string>() },
      showTop: true,
      showBottom: false,
      butterfly: false,
      searchQuery: '',
      rotation: 0,
      mirrorX: false,
      mirrorY: false,
      flipAxis: 'x',
      netLineMode: vp.netLineMode,
      connectionHighlight: false,
      dimMode: vp.dimMode,
      showHoverInfo: vp.showHoverInfo,
      followPdf: vp.followPdf,
      showTraces: true,
      showComponents: true,
      showVias: false,
      showSilkscreen: true,
      showPads: true,
      showCopperDrops: false,
      showSurfaces: false,
      showPins: true,
      showOutlines: true,
      showLabels: true,
      ghostMode: 'ghosts',
      layerStates: [],
      selectedLayerIndex: null,
      fixatedLayerIndex: null,
      pdfFileNames: [],
      cacheKey: '',
      hideGhosts: false,
      swappedGhostPairs: new Set<string>(),
      showBomAlternates: false,
      bomClusterSelections: new Map<string, string>(),
      partOverrides: new Map(),
      foldMode: 'suggested',
      selectedBoardIndex: null,
      swappedBoards: new Set<number>(),
      searchSelectionActive: false,
    };
    this._tabs.push(tab);
    this._activeTabId = id;
    this.notify();
    return tab;
  }

  /** Apply a cached BoardData onto a freshly-made tab (rotation, sides, layers,
   *  filters, parser-note toasts, auto-bind). Shared by loadFile's cache-hit
   *  path and loadFromCache. Does NOT touch _openFiles or applySavedViewPrefs. */
  private applyCachedBoard(tab: BoardTab, cached: BoardData, fileName: string, fileSize: number, lastModified: number): void {
    flagMechanicalParts(cached.parts);
    tab.board = cached;
    applyPackDefaults(tab, cached);
    invalidateDerivedBoard(tab);
    applyBoardFilters(tab);
    tab.cacheKey = boardCache.makeCacheKey(fileName, fileSize, lastModified);
    tab.rotation = this.autoRotation(cached);
    tab.flipAxis = flipAxisForRotation(tab.rotation);
    if (cached.flipAxis) tab.flipAxis = cached.flipAxis;
    const cachedFmt = getFormat(cached.format);
    // Initial side = user's perception of "top". For inverted files
    // (primarySide='bottom'), the user's "Top" button is mapped to the
    // file's side='bottom' in selectTop, so set showBottom=true on open.
    const wantsBottomOnOpen = cachedFmt?.swapSides || cached.primarySide === 'bottom';
    if (wantsBottomOnOpen) {
      tab.showTop = false;
      tab.showBottom = true;
    }
    // Trace-layer default is always TOP regardless of primarySide. The
    // primarySide swap drives only the user-facing side toggle (which
    // happened above); the layer list represents the file's etch stack
    // so users expect TOP-of-stack visible on first open.
    // For formats where the side toggle (not per-layer toggles) is the primary
    // visibility control (hasLayers=false — e.g. Altium), default ALL layers to
    // visible so the side toggle alone gates trace visibility. Butterfly
    // formats (TVW) keep the primary-only default.
    if (cached.layerNames) {
      tab.layerStates = createLayerStates(cached.layerNames, undefined, !cachedFmt?.hasLayers);
    }
    const vp = loadViewPrefs();
    if (vp.defaultButterfly) {
      tab.butterfly = true;
      tab.showTop = true;
      tab.showBottom = true;
    }
    if (cached.parserNotes) {
      for (const note of cached.parserNotes) this.addToast(note, 'info');
    }
    this.autoBindBoard(fileName);
  }

  async loadFile(file: File) {
    const existing = this._tabs.find(t => t.fileName === file.name);
    if (existing) {
      this._activeTabId = existing.id;
      this.notify();
      // Dismiss any in-flight load-progress overlay. databankStore.fetchFileBuffer
      // calls loadProgressStore.start() BEFORE we get here, so when the user
      // re-opens an already-loaded file from the library the overlay is mid-
      // "Downloading" phase and blocks the canvas until it times out. Same for
      // any other caller that pre-warms the overlay (drag-drop never does, but
      // future callers might). dismiss() is safe to call when no load is
      // active (no-op).
      loadProgressStore.dismiss();
      return;
    }

    // Guard against concurrent loads of the same file. Same dismiss
    // rationale as above — fetchFileBuffer already opened the overlay.
    if (this._loading.has(file.name)) {
      loadProgressStore.dismiss();
      return;
    }
    this.setLoading(file.name, true);

    try {
      const tab = this.makeTab(file.name);
      const id = tab.id;
      // makeTab already called notify() — the tab is visible from this point.

      try {
        loadProgressStore.start(file.name, file.size);
        loadProgressStore.setPhase('Cache lookup', 'Checking IndexedDB for previously-parsed board');
        this._openFiles.set(file.name, file);
        const cached = await boardCache.get(file.name, file.size, file.lastModified);
        if (cached) {
          loadProgressStore.pushLog(`Cache hit: ${cached.parts.length} parts, ${cached.nets.size} nets`);
          log.cache.log(`Loaded from cache: ${file.name} (${cached.parts.length} parts, ${cached.nets.size} nets)`);
          this.applyCachedBoard(tab, cached, file.name, file.size, file.lastModified);
          // Per-file user overrides win over both auto-rotation and the
          // parser-supplied flipAxis. Async fetch — we apply once the
          // record lands. The board is already visible by then; the
          // applyPrefs call only does work if at least one override is set.
          void this.applySavedViewPrefs(tab, file);
          // Hand off to the renderer. Don't finish() here — buildBoardScene
          // runs inside BoardRenderer.activateScene which is what the user
          // is actually waiting on, especially on cold-cache opens of large
          // boards like NM-G611. Renderer calls finishIfMatching when done.
          loadProgressStore.setPhase('Building scene', 'Renderer mounting + buildBoardScene + first frame');
          this.markSceneBuilding(id, file.name);
          this.onTabCreated?.(id, file.name);
          this.notify();
          return;
        }

        log.parser.log(`Parsing: ${file.name} (${(file.size / 1024).toFixed(0)} KB)`);
        loadProgressStore.setPhase('Reading file bytes', `${(file.size / 1024 / 1024).toFixed(2)} MB`);
        this._openFiles.set(file.name, file);
        const t0 = performance.now();
        const buffer = await file.arrayBuffer();
        loadProgressStore.pushLog(`Read ${buffer.byteLength.toLocaleString()} bytes into memory`);
        loadProgressStore.setPhase('Parsing', `${file.name.split('.').pop()?.toUpperCase()} format`);
        let board;
        try {
          board = await parseBoardFileInWorker(buffer, file.name);
        } catch (e) {
          // Encrypted FZ files need a user-supplied key. Both "missing" and
          // "invalid" reasons open the dialog so the user can fetch/paste/replace.
          // NOTE: `buffer` was transferred to the worker and is detached —
          // every retry below reads fresh bytes from the File.
          if (e instanceof FZKeyError) {
            // .cae is the same container under a different key (issue #25), so
            // the prompt has to name the one this file needs.
            const kind = getFileExtension(file.name) === '.cae' ? 'cae' : 'fz';
            if (e.reason === 'invalid') fzKeyStore.clearKey(kind);
            const ok = await fzKeyStore.ensureFzKey(kind);
            if (!ok) throw e;
            board = await parseBoardFileInWorker(await file.arrayBuffer(), file.name);
          } else if (isWorkerTransportError(e)) {
            log.parser.warn(`Worker parse failed for ${file.name} — retrying inline`);
            board = await parseBoardFile(await file.arrayBuffer(), file.name);
          } else {
            throw e;
          }
        }
        const elapsed = (performance.now() - t0).toFixed(0);
        log.parser.log(`Parsed OK in ${elapsed}ms: format=${board.format}, parts=${board.parts.length}, nets=${board.nets.size}, outline=${board.outline.length} pts`);
        loadProgressStore.pushLog(`Parsed ${board.parts.length} parts, ${board.nets.size} nets, ${board.outline.length} outline pts`);

        // Log side detection summary
        const fmt = getFormat(board.format);
        const topParts = board.parts.filter(p => p.side === 'top').length;
        const botParts = board.parts.filter(p => p.side === 'bottom').length;
        const topNails = board.nails.filter(n => n.side === 'top').length;
        const botNails = board.nails.filter(n => n.side === 'bottom').length;
        const topTP = board.parts.filter(p => p.side === 'top' && p.pins.length === 1).length;
        const botTP = board.parts.filter(p => p.side === 'bottom' && p.pins.length === 1).length;
        log.parser.log(
          `Side detection: top=${topParts} parts/${topNails} nails, bottom=${botParts} parts/${botNails} nails` +
          (topTP + botTP > 0 ? `, testpoints=${topTP}T/${botTP}B` : '') +
          (fmt?.flipY ? ', flipY=ON' : '') +
          (fmt?.swapSides ? ', swapSides=ON' : ''),
        );

        loadProgressStore.setPhase('Post-process', 'Mechanical-part detection, derived-view, filters');
        const tPost = performance.now();
        flagMechanicalParts(board.parts);
        tab.board = board;
        applyPackDefaults(tab, board);
        invalidateDerivedBoard(tab);
        applyBoardFilters(tab);
        log.perf.log(`post-parse: ${(performance.now() - tPost).toFixed(0)}ms (flagMechanical + derive + filters)`);
        tab.rotation = this.autoRotation(board);
        tab.flipAxis = flipAxisForRotation(tab.rotation);
        if (board.flipAxis) tab.flipAxis = board.flipAxis;
        // Per-file user overrides win over auto-detection — see
        // applySavedViewPrefs for the schema; async so the load path
        // doesn't block on IndexedDB.
        void this.applySavedViewPrefs(tab, file);
        const wantsBottomOnOpen = fmt?.swapSides || board.primarySide === 'bottom';
        if (wantsBottomOnOpen) {
          tab.showTop = false;
          tab.showBottom = true;
        }
        // See the cached-path comment above: hasLayers=false formats (Altium)
        // default every layer visible so the side toggle is the only gate.
        if (board.layerNames) {
          tab.layerStates = createLayerStates(board.layerNames, undefined, !fmt?.hasLayers);
        }
        const vp = loadViewPrefs();
        if (vp.defaultButterfly) {
          tab.butterfly = true;
          tab.showTop = true;
          tab.showBottom = true;
        }

        // Cache write runs in the background — the renderer handoff below must
        // not wait on IndexedDB serialization (hundreds of ms on big boards),
        // and a failed write must not fail the load (the board is already good).
        loadProgressStore.pushLog('Cache write scheduled (background)');
        const tCache = performance.now();
        void boardCache.put(file.name, file.size, file.lastModified, board)
          .then(() => log.perf.log(`cache put: ${(performance.now() - tCache).toFixed(0)}ms (background)`))
          .catch(e => log.cache.error(`Cache write failed for ${file.name}:`, e));

        if (board.parserNotes) {
          for (const note of board.parserNotes) this.addToast(note, 'info');
        }

        this.autoBindBoard(file.name);
      } catch (err) {
        log.parser.error(`Failed to load ${file.name}:`, err);
        const errMsg = err instanceof Error ? err.message : String(err);
        this.addToast(`Failed to load ${file.name}: ${errMsg}`, 'error');
        loadProgressStore.abort(errMsg);
        const idx = this._tabs.indexOf(tab);
        if (idx !== -1) this._tabs.splice(idx, 1);
        if (this._activeTabId === tab.id) {
          this._activeTabId = this._tabs.length > 0 ? this._tabs[this._tabs.length - 1].id : null;
        }
        this.notify();
        return;
      }

      // Create panel AFTER board + rotation are ready so the renderer sees correct state.
      // Renderer closes the overlay once activateScene finishes — see above.
      loadProgressStore.setPhase('Building scene', 'Renderer mounting + buildBoardScene + first frame');
      this.markSceneBuilding(id, file.name);
      this.onTabCreated?.(id, file.name);
      this.notify();
    } finally {
      this.setLoading(file.name, false);
    }
  }

  /** Open a board tab directly from the IndexedDB cache, without an original
   *  File — used by session restore when a dropped board never reached the
   *  databank (Electron / upload failed / file removed). Re-parse is unavailable
   *  for such a tab until the user drags the file in again. Returns false if the
   *  cache has no current entry (parser-version checked). */
  async loadFromCache(fileName: string, fileSize: number, lastModified: number): Promise<boolean> {
    if (this._tabs.some(t => t.fileName === fileName)) return true; // already open
    const cached = await boardCache.get(fileName, fileSize, lastModified);
    if (!cached) return false;
    const tab = this.makeTab(fileName);
    this.applyCachedBoard(tab, cached, fileName, fileSize, lastModified);
    this.markSceneBuilding(tab.id, fileName);
    this.onTabCreated?.(tab.id, fileName);
    this.notify();
    return true;
  }

  private autoRotation(board: BoardData): number {
    return computeAutoRotation(board);
  }

  async loadFiles(files: FileList | File[]) {
    const list = Array.from(files);
    // 2R: abrir uma placa nova fecha as outras (e o PDF) — window.__2rFecharTudo vem do App
    {
      const w = window as unknown as { __2rFecharTudo?: (n: string[]) => void };
      if (w.__2rFecharTudo && list.some(f => getFileExtension(f.name).toLowerCase() !== '.pdf' && !this._tabs.some(t => t.fileName === f.name)))
        w.__2rFecharTudo(list.map(f => f.name));
    }
    // Plain-ASC boards arrive as the three files the sections are named after
    // — format.asc / nails.asc / pins.asc (issue #26). Selecting them together
    // means "this is one board", not "open three tabs", so bundle them back
    // into the single document the .bdv form already carries and load that.
    const asc = list.filter(f => getFileExtension(f.name) === '.asc');
    const rest = asc.length > 1 ? list.filter(f => getFileExtension(f.name) !== '.asc') : list;
    if (asc.length > 1) {
      const merged = await mergeAscFiles(asc);
      if (merged) {
        await this.loadFile(merged);
      } else {
        // Nothing recognisable in any of them — fall back to opening each on
        // its own so the per-file error reaches the user instead of silence.
        for (const f of asc) await this.loadFile(f);
      }
    }
    for (const file of rest) {
      await this.loadFile(file);
    }
    if (asc.length === 1) await this.offerAscSiblings(asc[0]);
  }

  /** A single `.asc` picked from the OS file dialog or dropped on the window
   *  is usually one section of a split board — but a sandboxed File has no
   *  folder, so the siblings cannot be found the way the Library finds them.
   *  Say what is missing and offer a picker that takes the rest. */
  private async offerAscSiblings(file: File) {
    const head = await file.slice(0, 8192).text();
    // A file already carrying section markers is a whole bundle, not a piece
    // of one — nothing is missing from it.
    if (/<<\w+\.asc>>/i.test(head)) return;
    const section = ascSectionFromName(file.name) ?? identifyAscSection(head)?.replace('.asc', '');
    if (!section) return;
    const missing = ASC_SECTIONS.filter(s => s !== section);
    this.addToast(
      `"${file.name}" is the ${section} section of a split ASC board — ${missing.join(', ')} are separate files.`,
      'info',
      {
        label: 'Add sections…',
        run: () => this.pickAscSiblings(file),
      },
      12000,
    );
  }

  /** Second half of the offer: take the remaining section files, replace the
   *  partial tab with the merged board. */
  private pickAscSiblings(opened: File) {
    const input = document.createElement('input');
    input.type = 'file';
    input.multiple = true;
    input.accept = '.asc';
    input.onchange = async () => {
      const picked = Array.from(input.files ?? []).filter(f => f.name !== opened.name);
      if (picked.length === 0) return;
      const partial = this._tabs.find(t => t.fileName === opened.name);
      if (partial) this.closeTab(partial.id);
      await this.loadFiles([opened, ...picked]);
    };
    input.click();
  }

  /**
   * Open a tab from an already-parsed BoardData (test/dev helper — skips parsing
   * and cache). Exposed on `window.__boardStore` in DEV builds for Playwright tests.
   */
  openBoardFromData(fileName: string, board: BoardData) {
    const id = nextTabId++;
    const vp = loadViewPrefs();
    const rotation = computeAutoRotation(board);
    const tab: BoardTab = {
      id,
      fileName,
      board,
      cacheKey: '',
      selection: { ...emptySelection, adjacentNets: new Set<string>() },
      showTop: true,
      showBottom: false,
      butterfly: false,
      searchQuery: '',
      rotation,
      mirrorX: false,
      mirrorY: false,
      flipAxis: flipAxisForRotation(rotation),
      netLineMode: vp.netLineMode,
      connectionHighlight: false,
      dimMode: vp.dimMode,
      showHoverInfo: vp.showHoverInfo,
      followPdf: vp.followPdf,
      showTraces: true,
      showComponents: true,
      showVias: false,
      showSilkscreen: true,
      showPads: true,
      showCopperDrops: false,
      showSurfaces: false,
      showPins: true,
      showOutlines: true,
      showLabels: true,
      ghostMode: 'ghosts',
      layerStates: [],
      selectedLayerIndex: null,
      fixatedLayerIndex: null,
      pdfFileNames: [],
      hideGhosts: false,
      swappedGhostPairs: new Set<string>(),
      showBomAlternates: false,
      bomClusterSelections: new Map<string, string>(),
      partOverrides: new Map(),
      foldMode: 'suggested',
      selectedBoardIndex: null,
      swappedBoards: new Set<number>(),
      searchSelectionActive: false,
    };
    applyBoardFilters(tab);
    this._tabs.push(tab);
    this._activeTabId = id;
    this.notify();
  }

  /** Evict the cache entry for the given board data (call after a scene build failure). */
  evictCacheForBoard(board: BoardData): void {
    const tab = this._tabs.find(t => t.board === board);
    if (tab?.cacheKey) {
      boardCache.deleteEntry(tab.cacheKey);
      tab.cacheKey = '';
    }
  }

  switchTab(tabId: number) {
    // A "scene building" mark describes the tab being brought to screen. A
    // tab hidden before its scene was built is not blocking anyone; when it
    // is shown again the renderer re-marks it right before it builds.
    for (const id of [...this._sceneBuilding.keys()]) if (id !== tabId) this.clearSceneBuilding(id);
    const tab = this._tabs.find(t => t.id === tabId);
    if (tab && this._activeTabId !== tabId) {
      this._activeTabId = tabId;
      // Navigation history: arriving on another board is a viewpoint (layer 4),
      // committed only if the user stays on it.
      navHistoryStore.recordViewpoint({
        cause: 'view', label: tab.fileName,
        place: { kind: 'board', tabId: tab.id, fileKey: tab.cacheKey, fileId: tab.fileId, fileName: tab.fileName,
          side: tab.butterfly || (tab.showTop && tab.showBottom) ? 'both' : tab.showTop ? 'top' : 'bottom' },
      });
      this.notify();
    }
  }

  closeTab(tabId: number) {
    const idx = this._tabs.findIndex(t => t.id === tabId);
    if (idx === -1) return;
    this.clearSceneBuilding(tabId);

    // Unbind all PDFs
    const tab = this._tabs[idx];
    for (const name of tab.pdfFileNames) {
      const entry = this._pdfFiles.get(name);
      if (entry) entry.boundTabIds.delete(tab.id);
    }

    // Clear search cache if it referenced the closed tab's board
    if (this._cachedSearchBoard && tab.board === this._cachedSearchBoard) {
      this._cachedSearchBoard = null;
    }

    // Drop the File reference if no other tab holds it (file names are unique
    // per tab today, but keep the guard in case that changes).
    if (!this._tabs.some(t => t.id !== tabId && t.fileName === tab.fileName)) {
      this._openFiles.delete(tab.fileName);
    }

    this._tabs.splice(idx, 1);
    this.onTabClosed?.(tabId);

    if (this._activeTabId === tabId) {
      if (this._tabs.length > 0) {
        const newIdx = Math.min(idx, this._tabs.length - 1);
        this._activeTabId = this._tabs[newIdx].id;
      } else {
        this._activeTabId = null;
      }
    }
    this.notify();
  }

  selectPart(partIndex: number | null, nav?: NavOpts) {
    this._clearPreviewPulse();
    // Hierarchical net-lines (chain-adjacent): selecting a 2-pin component by
    // its body — which otherwise highlights no net — seeds the highlight from
    // one pin's net so the one-hop adjacency lights up the *other* pin's net
    // too, drawing chains for BOTH pins. Other modes / pin counts keep the
    // plain part-only selection (no net highlighted).
    let highlightedNet: string | null = null;
    if (partIndex !== null && this.activeTab?.netLineMode === 'chain-adjacent') {
      const part = this.activeTab.board?.parts[partIndex];
      if (part && part.pins.length === 2) {
        highlightedNet = part.pins.find(p => p.net)?.net ?? null;
      }
    }
    this.updateActiveTab({
      selection: { partIndex, pinIndex: null, highlightedNet, adjacentNets: this._resolveAdjacentNets(highlightedNet) },
      searchSelectionActive: false,
    });
    if (partIndex !== null) this._recordNav(this.activeTab, nav?.cause ?? 'click', nav);
    this.notify();
  }

  selectPin(partIndex: number, pinIndex: number, nav?: NavOpts) {
    this._clearPreviewPulse();
    const tab = this.activeTab;
    const part = tab?.board?.parts[partIndex];
    const pin = part?.pins[pinIndex];
    this.updateActiveTab({
      selection: { partIndex, pinIndex, highlightedNet: pin?.net || null, adjacentNets: this._resolveAdjacentNets(pin?.net || null) },
      searchSelectionActive: false,
    });
    this._recordNav(tab, nav?.cause ?? 'click', nav);
    this.notify();
  }

  /**
   * Record the tab's current selection as a visit in the navigation history.
   * A cleared selection is not a visit (clicking empty canvas is not a
   * navigation; the departure rule still captures the camera). The place is
   * named by refdes / pin number / net name, never by index — indices shift
   * under fold-mode, revision and BOM changes.
   */
  private _recordNav(tab: BoardTab | null, cause: NavCause, nav?: NavOpts) {
    if (!tab?.board) return;
    const sel = tab.selection;
    if (sel.partIndex == null && !sel.highlightedNet) return;
    const part = sel.partIndex != null ? tab.board.parts[sel.partIndex] : undefined;
    if (sel.partIndex != null && !part) return;   // a stale index names nothing
    const pin = part && sel.pinIndex != null ? part.pins[sel.pinIndex] : undefined;
    navHistoryStore.record({
      cause,
      place: {
        kind: 'board',
        tabId: tab.id,
        fileKey: tab.cacheKey,
        fileId: tab.fileId,
        fileName: tab.fileName,
        part: part?.name,
        pin: pin ? (pin.number || pin.name || undefined) : undefined,
        net: sel.highlightedNet ?? undefined,
        side: tab.butterfly || (tab.showTop && tab.showBottom) ? 'both' : tab.showTop ? 'top' : 'bottom',
      },
      from: nav?.from,
      via: nav?.via,
    });
  }

  /** Restore-time side setter (navigation history). Leaves butterfly alone. */
  setSideVisibility(tabId: number, showTop: boolean, showBottom: boolean) {
    const tab = this._tabs.find(t => t.id === tabId);
    if (!tab || tab.butterfly) return;
    if (tab.showTop === showTop && tab.showBottom === showBottom) return;
    Object.assign(tab, { showTop, showBottom });
    this.notify();
  }

  /** Returns `computeAdjacentNets(board, netName, hierarchyDepth)` when the
   *  current `netLineMode` is `'chain-adjacent'` and the board is loaded;
   *  otherwise returns an empty Set.  Centralises the "should we populate
   *  adjacency?" decision so every call-site stays a one-liner. */
  private _resolveAdjacentNets(netName: string | null): Set<string> {
    return this._adjacentNetsFor(this.activeTab, netName);
  }

  /** Tab-scoped form of the above. Split out because `selectPinInTab` can
   *  target a background tab, where resolving against the *active* tab's board
   *  would compute the chain from the wrong netlist. */
  private _adjacentNetsFor(tab: BoardTab | null, netName: string | null): Set<string> {
    if (!tab?.board || !netName) return new Set<string>();
    if (tab.netLineMode !== 'chain-adjacent') return new Set<string>();
    return computeAdjacentNets(tab.board, netName, renderSettingsStore.settings.hierarchyDepth, this._hierarchyBridgePred());
  }

  /** Predicate for `computeAdjacentNets` — marks parts whose PartType opted
   *  into hierarchy bridging (>2-pin pass-through, e.g. current-sense
   *  resistors). Resolved against the live render settings each call. */
  private _hierarchyBridgePred(): (part: Part) => boolean {
    const s = renderSettingsStore.settings;
    return (part: Part) => partBridgesHierarchy(part.name, s);
  }

  /** Recompute adjacentNets for the live selection — invoked when the
   *  hierarchyBridge part-type flags change under an active chain-adjacent
   *  highlight. No-op (and no notify) when the mode is inactive or the
   *  resulting set is unchanged, so unrelated settings edits stay quiet. */
  private refreshAdjacency(): void {
    const tab = this.activeTab;
    if (!tab?.board || tab.netLineMode !== 'chain-adjacent') return;
    const net = tab.selection.highlightedNet;
    if (!net) return;
    const next = computeAdjacentNets(tab.board, net, renderSettingsStore.settings.hierarchyDepth, this._hierarchyBridgePred());
    const cur = tab.selection.adjacentNets;
    if (next.size === cur.size) {
      let same = true;
      for (const n of next) if (!cur.has(n)) { same = false; break; }
      if (same) return;
    }
    this.updateActiveTab({ selection: { ...tab.selection, adjacentNets: next } });
    this.notify();
  }

  highlightNet(netName: string | null, nav?: NavOpts) {
    const tab = this.activeTab;
    if (!tab) return;
    this.updateActiveTab({
      selection: { ...tab.selection, highlightedNet: netName, adjacentNets: this._resolveAdjacentNets(netName) },
      searchSelectionActive: false,
    });
    if (netName) this._recordNav(tab, nav?.cause ?? 'click', nav);
    this.notify();
  }

  selectTop(both = false) {
    const tab = this.activeTab;
    if (!tab) return;
    if (both) {
      this.updateActiveTab({ showTop: true, showBottom: true, butterfly: false });
    } else {
      // When the board's primarySide is 'bottom', the file labels sides inverted
      // relative to the user's expectation. The user pressing "Top" wants to see
      // the physical CPU side, which lives under side='bottom' in the file — so
      // we trigger the bottom-view rendering (scene.root is auto-mirrored there,
      // which correctly un-mirrors the bottom-frame coordinates into physical view).
      const swap = tab.board?.primarySide === 'bottom';
      this.updateActiveTab({
        showTop: swap ? false : true,
        showBottom: swap ? true : false,
        butterfly: false,
      });
    }
    this.notify();
  }

  selectBottom(both = false) {
    const tab = this.activeTab;
    if (!tab) return;
    if (both) {
      this.updateActiveTab({ showTop: true, showBottom: true, butterfly: false });
    } else {
      const swap = tab.board?.primarySide === 'bottom';
      this.updateActiveTab({
        showTop: swap ? true : false,
        showBottom: swap ? false : true,
        butterfly: false,
      });
    }
    this.notify();
  }

  toggleButterfly() {
    const tab = this.activeTab;
    if (!tab) return;
    const newButterfly = !tab.butterfly;
    if (newButterfly) {
      this.updateActiveTab({ butterfly: true, showTop: true, showBottom: true });
      // Butterfly lays the two sides out flat, so anything that belongs to
      // the board as a whole rather than to one side — traces, vias, copper
      // pours, and with them the layer stack — has no place to be drawn and
      // is hidden by the renderer while the mode is on (every format, not
      // only layered ones). Say so once, but only when there is copper to
      // hide; a BVR board with no traces would get a toast about nothing.
      if (boardHasCopper(tab.board)) {
        this.addToast(BUTTERFLY_COPPER_HIDDEN_MESSAGE, 'info', undefined, 5000);
      }
    } else {
      this.updateActiveTab({ butterfly: false, showTop: true, showBottom: false });
    }
    // Persist the user's choice so subsequent board opens default to it.
    saveViewPrefs({ ...loadViewPrefs(), defaultButterfly: newButterfly });
    this.notify();
  }

  /** Async post-load step: if the user has previously saved a rotation /
   *  mirror override for this file, apply it on top of the auto-detected
   *  values. Called from both the cache-hit and fresh-parse branches of
   *  loadFile; no-op when no record exists. */
  private async applySavedViewPrefs(tab: BoardTab, file: File): Promise<void> {
    const prefs = await fileViewPrefsStore.get(file.name, file.size, file.lastModified);
    if (!prefs) return;
    // Tab may have been closed mid-fetch — drop silently.
    if (!this._tabs.includes(tab)) return;
    let changed = false;
    if (prefs.rotation != null && prefs.rotation !== tab.rotation) {
      tab.rotation = prefs.rotation;
      changed = true;
    }
    if (prefs.mirrorX != null && prefs.mirrorX !== tab.mirrorX) {
      tab.mirrorX = prefs.mirrorX;
      changed = true;
    }
    if (prefs.mirrorY != null && prefs.mirrorY !== tab.mirrorY) {
      tab.mirrorY = prefs.mirrorY;
      changed = true;
    }
    if (prefs.flipAxis != null && prefs.flipAxis !== tab.flipAxis) {
      tab.flipAxis = prefs.flipAxis;
      changed = true;
    }
    if (prefs.swappedBoards && prefs.swappedBoards.length > 0) {
      tab.swappedBoards = new Set(prefs.swappedBoards);
      invalidateDerivedBoard(tab);
      changed = true;
    }
    if (changed) {
      log.cache.log(`Applied saved view prefs for ${file.name}: rotation=${prefs.rotation} mirrorX=${prefs.mirrorX} mirrorY=${prefs.mirrorY} flipAxis=${prefs.flipAxis}`);
      this.notify();
    }
  }

  /** Persist the active tab's current rotation / mirror state for its
   *  underlying file. Called from every UI handler that mutates one of
   *  those fields so the user only has to correct each file once. Note:
   *  distinct from `_saveCurrentViewPrefs` (no underscore, this method),
   *  which saves GLOBAL prefs (netLineMode, dimMode, etc.); this one
   *  saves per-file overrides keyed on file identity. */
  private saveFileViewPrefs(tab: BoardTab): void {
    const file = this._openFiles.get(tab.fileName);
    if (!file) return;
    void fileViewPrefsStore.put(file.name, file.size, file.lastModified, {
      rotation: tab.rotation,
      mirrorX: tab.mirrorX,
      mirrorY: tab.mirrorY,
      flipAxis: tab.flipAxis,
      swappedBoards: [...tab.swappedBoards].sort((a, b) => a - b),
    });
  }

  /** Any angle, degrees, as displayed (positive = clockwise on screen). The
   *  two-finger rotation commits here; the buttons stay on 90° steps.
   *
   *  `flipAxis` is deliberately left alone. The buttons' rule keeps the
   *  bottom view's mirror hinge fixed on the *screen* by swapping which
   *  board axis carries it at every parity change — and the two hinges
   *  (`scale.y = -1` vs `scale.x = -1`) differ by exactly 180°, so applying
   *  that rule to a free angle turned the bottom view over at the 45°/135°
   *  boundary on release ("rotation lost, 180° flip", 2026-09-28). A screen
   *  hinge is representable only at right angles; the fingers turn the
   *  picture, so the hinge turns with the board. */
  setRotation(deg: number) {
    const tab = this.activeTab;
    if (!tab) return;
    const r = Math.round((((deg % 360) + 360) % 360) * 10) / 10 % 360;
    if (r === tab.rotation) return;
    this.updateActiveTab({ rotation: r });
    this.saveFileViewPrefs(tab);
    this.notify();
  }

  rotateCW() {
    const tab = this.activeTab;
    if (!tab) return;
    // From a free angle (two-finger rotation) the button goes to the next
    // 90° step in its direction, not to angle + 90.
    const newRotation = nextRightAngle(tab.rotation, +1);
    this.updateActiveTab({ rotation: newRotation, flipAxis: buttonFlipAxis(tab.flipAxis, tab.rotation, newRotation) });
    this.saveFileViewPrefs(tab);
    this.notify();
  }

  rotateCCW() {
    const tab = this.activeTab;
    if (!tab) return;
    const newRotation = nextRightAngle(tab.rotation, -1);
    this.updateActiveTab({ rotation: newRotation, flipAxis: buttonFlipAxis(tab.flipAxis, tab.rotation, newRotation) });
    this.saveFileViewPrefs(tab);
    this.notify();
  }

  /** 180° rotation — the common case for boards photographed from the wrong
   *  end. flipAxis is invariant under a 180° turn (the screen axis-swap parity
   *  is unchanged), so no flipAxis adjustment needed. */
  rotate180() {
    const tab = this.activeTab;
    if (!tab) return;
    this.updateActiveTab({ rotation: (tab.rotation + 180) % 360 });
    this.saveFileViewPrefs(tab);
    this.notify();
  }

  /** Set arbitrary rotation in degrees (from trackpad gesture or other free input). */
  /**
   * Switch the active board to a different revision (multi-revision .cad
   * files only). Builds a new BoardData object reference so that the
   * renderer's reference-equality check fires and a fresh scene is built.
   * Selection is reset because part/pin indices change between revisions.
   */
  setActiveRevision(index: number) {
    const tab = this.activeTab;
    if (!tab || !tab.board || !tab.board.revisions) return;
    const target = tab.board.revisions.find(r => r.index === index);
    if (!target) return;
    if (tab.board.activeRevision === index && !tab.hideGhosts) return;
    tab.board = buildRenderedBoard(tab.board, target, tab.hideGhosts, tab.swappedGhostPairs, tab.showBomAlternates, tab.bomClusterSelections);
    invalidateDerivedBoard(tab);
    tab.selection = emptySelection;
    tab.searchSelectionActive = false;
    tab.searchQuery = '';
    this.notify();
  }

  /**
   * Toggle whether parts flagged as suspicious overlaps (board.ghosts) are
   * hidden from the rendered parts list. Rebuilds the BoardData reference
   * so the renderer picks up the change. Selection resets to avoid dangling
   * indices into the filtered array.
   */
  toggleHideGhosts() {
    const tab = this.activeTab;
    if (!tab || !tab.board) return;
    const next = !tab.hideGhosts;
    tab.hideGhosts = next;
    // Find the current revision (or build from the existing top-level fields
    // for single-revision .cad files where revisions is unset).
    const rev = tab.board.revisions?.find(r => r.index === tab.board?.activeRevision)
      ?? syntheticRevisionFromBoard(tab.board);
    tab.board = buildRenderedBoard(tab.board, rev, next, tab.swappedGhostPairs, tab.showBomAlternates, tab.bomClusterSelections);
    invalidateDerivedBoard(tab);
    tab.selection = emptySelection;
    tab.searchSelectionActive = false;
    this.notify();
  }

  /**
   * Toggle which side of an overlap pair is treated as the ghost. By default
   * the part with the smaller pin count is flagged; calling this swaps the
   * two so the dominator is hidden instead. Rebuilds the rendered board only
   * when hide-mode is on (otherwise just notifies so the UI restyles).
   */
  swapGhostPair(partIndex: number, dominatorIndex: number) {
    const tab = this.activeTab;
    if (!tab || !tab.board) return;
    const sig = ghostPairSig(partIndex, dominatorIndex);
    // Replace the Set so identity changes (snapshot consumers rerender).
    const next = new Set(tab.swappedGhostPairs);
    if (next.has(sig)) next.delete(sig); else next.add(sig);
    tab.swappedGhostPairs = next;
    if (tab.hideGhosts) {
      const rev = tab.board.revisions?.find(r => r.index === tab.board?.activeRevision)
        ?? syntheticRevisionFromBoard(tab.board);
      tab.board = buildRenderedBoard(tab.board, rev, true, next, tab.showBomAlternates, tab.bomClusterSelections);
      invalidateDerivedBoard(tab);
      tab.selection = emptySelection;
    }
    this.notify();
  }

  /**
   * Toggle whether every BOM-alternate cluster member is rendered (overlapping
   * X-ray view) or only the chosen primary per cluster (default). Selection
   * resets to avoid dangling indices into the filtered array.
   */
  toggleShowBomAlternates() {
    const tab = this.activeTab;
    if (!tab || !tab.board) return;
    const next = !tab.showBomAlternates;
    tab.showBomAlternates = next;
    const rev = tab.board.revisions?.find(r => r.index === tab.board?.activeRevision)
      ?? syntheticRevisionFromBoard(tab.board);
    tab.board = buildRenderedBoard(tab.board, rev, tab.hideGhosts, tab.swappedGhostPairs, next, tab.bomClusterSelections);
    invalidateDerivedBoard(tab);
    tab.selection = emptySelection;
    this.notify();
  }

  /**
   * Per-part visibility override. Keyed by refdes (stable across derives).
   * `mode === 'hide'`         → fill, border, pins all skipped.
   * `mode === 'sendToBack'`   → fill skipped (same effect as auto-mechanical);
   *                             border and pins still draw.
   * `mode === null`           → clear override, render normally.
   * Toggling a part already in the requested mode also clears the override.
   * Replaces the Map so snapshot consumers rerender.
   */
  setPartOverride(partName: string, mode: 'hide' | 'sendToBack' | null) {
    const tab = this.activeTab;
    if (!tab) return;
    const next = new Map(tab.partOverrides);
    const existing = next.get(partName);
    if (mode === null) {
      if (!existing) return;
      next.delete(partName);
    } else if (mode === 'hide') {
      if (existing?.hidden) { next.delete(partName); }
      else { next.set(partName, { hidden: true }); }
    } else {
      if (existing?.sendToBack) { next.delete(partName); }
      else { next.set(partName, { sendToBack: true }); }
    }
    tab.partOverrides = next;
    // If we just hid the currently-selected part, clear selection.
    if (mode === 'hide' && tab.selection.partIndex !== null) {
      const part = tab.board?.parts[tab.selection.partIndex];
      if (part?.name === partName) {
        tab.selection = emptySelection;
        tab.searchSelectionActive = false;
      }
    }
    this.notify();
  }

  /** Restore every hidden part on the given tab (or the active tab when no id
   *  is passed). sendToBack overrides stay. tabId matters in split view where
   *  the panel acting may not be the active tab. */
  unhideAllParts(tabId?: number) {
    const tab = tabId != null ? this.getTab(tabId) : this.activeTab;
    if (!tab) return;
    let changed = false;
    const next = new Map(tab.partOverrides);
    for (const [name, o] of next) {
      if (!o.hidden) continue;
      changed = true;
      if (o.sendToBack) next.set(name, { sendToBack: true });
      else next.delete(name);
    }
    if (!changed) return;
    tab.partOverrides = next;
    this.notify();
  }

  /**
   * Override which member of a BOM-alternate cluster is treated as the primary
   * (i.e. the one rendered when `showBomAlternates` is off). Pass the cluster
   * signature (`bomClusterSig` over the full member refdes list) and the
   * chosen member's refdes. Calling with `chosenRefdes === ''` clears the
   * override and falls back to the parser's auto-pick.
   */
  selectBomClusterPrimary(clusterSig: string, chosenRefdes: string) {
    const tab = this.activeTab;
    if (!tab || !tab.board) return;
    // Replace the Map so identity changes (snapshot consumers rerender).
    const next = new Map(tab.bomClusterSelections);
    if (chosenRefdes) next.set(clusterSig, chosenRefdes);
    else next.delete(clusterSig);
    tab.bomClusterSelections = next;
    if (!tab.showBomAlternates) {
      const rev = tab.board.revisions?.find(r => r.index === tab.board?.activeRevision)
        ?? syntheticRevisionFromBoard(tab.board);
      tab.board = buildRenderedBoard(tab.board, rev, tab.hideGhosts, tab.swappedGhostPairs, false, next);
      invalidateDerivedBoard(tab);
      tab.selection = emptySelection;
      tab.searchSelectionActive = false;
    }
    this.notify();
  }

  setFoldMode(mode: FoldMode): void {
    const tab = this.activeTab;
    if (!tab || tab.foldMode === mode) return;
    this.updateActiveTab({ foldMode: mode });
    invalidateDerivedBoard(tab);
    // Clear any stale selection so it doesn't point at a now-hidden part.
    tab.selection = { ...emptySelection };
    tab.searchSelectionActive = false;
    // NOTE: we deliberately do NOT call `syncMirrorsToDerivedFold` here.
    // For butterfly files (1 detected board) toggling fold mode flips
    // between the parser's pre-folded view and the raw side-by-side view,
    // but the user's preferred screen orientation (rotation/mirrorY/flipAxis)
    // shouldn't change with that toggle — the load-time defaults remain
    // correct. Only selection changes warrant a full orientation re-sync.
    this.requestFitDerivedBoard(tab);
    this.notify();
  }

  setSelectedBoardIndex(idx: number | null): void {
    const tab = this.activeTab;
    if (!tab || tab.selectedBoardIndex === idx) return;
    this.updateActiveTab({ selectedBoardIndex: idx });
    invalidateDerivedBoard(tab);
    tab.selection = { ...emptySelection };
    tab.searchSelectionActive = false;
    syncMirrorsToDerivedFold(tab);
    this.requestFitDerivedBoard(tab);
    this.notify();
  }

  /** Flip one board of a pack top ↔ bottom. The parser decides sides from
   *  copper or the exporter's layout rule; this is the escape hatch for the
   *  file that breaks the rule, remembered per file. */
  toggleBoardSideSwap(idx: number): void {
    const tab = this.activeTab;
    if (!tab) return;
    const next = new Set(tab.swappedBoards);
    if (next.has(idx)) next.delete(idx); else next.add(idx);
    tab.swappedBoards = next;
    invalidateDerivedBoard(tab);
    tab.selection = { ...emptySelection };
    tab.searchSelectionActive = false;
    this.saveFileViewPrefs(tab);
    this.notify();
  }

  /** Ask the renderer (on its next onBoardUpdate) to fit the derived board
   *  into view. Uses the existing focus-request plumbing: the renderer picks
   *  it up and calls zoomToBounds which fits and centers. Prevents the
   *  post-selection viewport from ending up stranded where the previous
   *  all-boards view used to show a different board — and also gives the
   *  flip-preservation math a sane starting point (centered inside the
   *  new derived bounds). */
  private requestFitDerivedBoard(tab: BoardTab): void {
    const derived = ensureDerivedBoard(tab);
    if (!derived) return;
    this._focusRequest = { partIndex: null, bounds: { ...derived.bounds }, fit: true };
  }

  // ── Cache control actions ────────────────────────────────────────────
  //
  // Scoped reset operations exposed to the UI. Each one targets a specific
  // cache layer so the user can pick the minimum they need rather than
  // wiping the whole database.

  /** Local debug helper: returns the original File for the active tab so debug
   *  tooling (per-layer PNG export, hex dumps) can re-read the raw bytes. */
  getActiveFile(): File | null {
    const tab = this.activeTab;
    if (!tab) return null;
    return this._openFiles.get(tab.fileName) ?? null;
  }

  /** Re-parse the active tab's board from its original File bytes. Deletes
   *  its IDB cache entry first, then runs parseBoardFile and swaps the new
   *  BoardData into tab.board (new reference → renderer auto-rebuilds).
   *  Selection/search reset. Most common reset: "I just updated the parser,
   *  show me the effect on this board." Returns false if no active tab or
   *  the original File reference was lost (e.g. after a full page reload). */
  async reparseActiveBoard(): Promise<boolean> {
    const tab = this.activeTab;
    if (!tab) return false;
    const file = this._openFiles.get(tab.fileName);
    if (!file) {
      log.cache.error(`reparse: no File reference for ${tab.fileName}`);
      this.addToast(`Cannot re-parse ${tab.fileName} — original file not in memory. Drag-and-drop it again.`, 'error');
      return false;
    }
    try {
      await boardCache.deleteEntry(boardCache.makeCacheKey(file.name, file.size, file.lastModified));
      log.parser.log(`Re-parsing ${file.name}…`);
      const t0 = performance.now();
      const buffer = await file.arrayBuffer();
      const board = await parseBoardFileInWorker(buffer, file.name);
      log.parser.log(`Re-parsed in ${(performance.now() - t0).toFixed(0)}ms`);
      tab.board = board;
      invalidateDerivedBoard(tab);
      applyBoardFilters(tab);
      tab.selection = emptySelection;
      tab.searchSelectionActive = false;
      tab.searchQuery = '';
      await boardCache.put(file.name, file.size, file.lastModified, board);
      this.notify();
      return true;
    } catch (err) {
      log.parser.error(`Re-parse failed for ${tab.fileName}:`, err);
      this.addToast(`Re-parse failed: ${err instanceof Error ? err.message : String(err)}`, 'error');
      return false;
    }
  }

  /** Clear ALL cached parsed boards (IDB boards store) and re-parse every
   *  currently-open tab from its original File. Useful after a parser fix
   *  that affects multiple formats. PDF caches are left alone. */
  async resetBoardCaches(): Promise<void> {
    await boardCache.clear();
    log.cache.log('Board cache cleared');
    let reparsed = 0;
    let skipped = 0;
    for (const tab of this._tabs) {
      const file = this._openFiles.get(tab.fileName);
      if (!file) { skipped++; continue; }
      try {
        const buffer = await file.arrayBuffer();
        const board = await parseBoardFileInWorker(buffer, file.name);
        tab.board = board;
        invalidateDerivedBoard(tab);
        applyBoardFilters(tab);
        tab.selection = emptySelection;
        tab.searchSelectionActive = false;
        tab.searchQuery = '';
        await boardCache.put(file.name, file.size, file.lastModified, board);
        reparsed++;
      } catch (err) {
        log.parser.error(`Re-parse failed for ${tab.fileName}:`, err);
      }
    }
    log.cache.log(`Re-parsed ${reparsed} open tab(s)${skipped ? `, skipped ${skipped} (no File ref)` : ''}`);
    this.addToast(
      reparsed > 0
        ? `Re-parsed ${reparsed} open board${reparsed === 1 ? '' : 's'}.`
        : 'Board cache cleared.',
      'info',
    );
    this.notify();
  }

  /** Clear all PDF-related caches: IDB pdf-text store, in-memory tile
   *  bitmap cache, and glyph/font cache. Watermark filtering moved into
   *  the patched pdf.js worker; nothing to invalidate there. Board caches
   *  are left alone. */
  async resetPdfCaches(): Promise<void> {
    const { invalidateTileCache } = await import('../pdf/tile-manager');
    const { clearFontCache } = await import('../pdf/glyph-extractor');
    await boardCache.clearPdfText();
    invalidateTileCache();
    clearFontCache();
    log.cache.log('PDF caches cleared');
    this.addToast('PDF caches cleared.', 'info');
    this.notify();
  }

  setRotationFree(degrees: number) {
    const tab = this.activeTab;
    if (!tab) return;
    const newRotation = ((degrees % 360) + 360) % 360;
    this.updateActiveTab({ rotation: newRotation, flipAxis: rotateFlipAxis(tab.flipAxis, tab.rotation, newRotation) });
    this.saveFileViewPrefs(tab);
    this.notify();
  }

  flipHorizontal() {
    const tab = this.activeTab;
    if (!tab) return;
    this.updateActiveTab({ mirrorX: !tab.mirrorX });
    this.saveFileViewPrefs(tab);
    this.notify();
  }

  flipVertical() {
    const tab = this.activeTab;
    if (!tab) return;
    this.updateActiveTab({ mirrorY: !tab.mirrorY });
    this.saveFileViewPrefs(tab);
    this.notify();
  }

  toggleFlipAxis() {
    const tab = this.activeTab;
    if (!tab) return;
    this.updateActiveTab({ flipAxis: tab.flipAxis === 'x' ? 'y' : 'x' });
    this.notify();
  }

  private _saveCurrentViewPrefs() {
    const tab = this.activeTab;
    if (!tab) return;
    // Merge with stored prefs so fields not derived from the active tab
    // (e.g. defaultButterfly) survive partial updates.
    saveViewPrefs({ ...loadViewPrefs(), netLineMode: tab.netLineMode, dimMode: tab.dimMode, showHoverInfo: tab.showHoverInfo, followPdf: tab.followPdf });
  }

  /** Cycle the net-line visualization: off → star → chain → chain-adjacent → off. */
  cycleNetLineMode() {
    const tab = this.activeTab;
    if (!tab) return;
    const next: NetLineMode =
      tab.netLineMode === 'off' ? 'star' :
      tab.netLineMode === 'star' ? 'chain' :
      tab.netLineMode === 'chain' ? 'chain-adjacent' : 'off';

    // When entering chain-adjacent: populate adjacentNets from the current
    // highlighted net.  When leaving chain-adjacent: clear the set.
    const net = tab.selection.highlightedNet;
    const adjacentNets = (next === 'chain-adjacent' && tab.board && net)
      ? computeAdjacentNets(tab.board, net, renderSettingsStore.settings.hierarchyDepth, this._hierarchyBridgePred())
      : new Set<string>();

    this.updateActiveTab({
      netLineMode: next,
      selection: { ...tab.selection, adjacentNets },
    });
    this._saveCurrentViewPrefs();
    this.notify();
  }

  /** Toggle/set "highlight connections" — glow nets shared by ≥2 parts in the
   *  cyan selection set. Visual only; net-lines are unaffected. Per-tab, not
   *  persisted (it's tied to an ephemeral selection that doesn't survive
   *  reload). */
  setConnectionHighlight(on: boolean) {
    const tab = this.activeTab;
    if (!tab || tab.connectionHighlight === on) return;
    this.updateActiveTab({ connectionHighlight: on });
    this.notify();
  }

  toggleTraces() {
    const tab = this.activeTab;
    if (!tab) return;
    this.updateActiveTab({ showTraces: !tab.showTraces });
    this.notify();
  }

  toggleComponents() {
    const tab = this.activeTab;
    if (!tab) return;
    this.updateActiveTab({ showComponents: !tab.showComponents });
    this.notify();
  }

  toggleVias() {
    const tab = this.activeTab;
    if (!tab) return;
    this.updateActiveTab({ showVias: !tab.showVias });
    this.notify();
  }

  toggleSilkscreen() {
    const tab = this.activeTab;
    if (!tab) return;
    this.updateActiveTab({ showSilkscreen: !tab.showSilkscreen });
    this.notify();
  }

  togglePads() {
    const tab = this.activeTab;
    if (!tab) return;
    this.updateActiveTab({ showPads: !tab.showPads });
    this.notify();
  }

  toggleCopperDrops() {
    const tab = this.activeTab;
    if (!tab) return;
    this.updateActiveTab({ showCopperDrops: !tab.showCopperDrops });
    this.notify();
  }

  toggleSurfaces() {
    const tab = this.activeTab;
    if (!tab) return;
    this.updateActiveTab({ showSurfaces: !tab.showSurfaces });
    this.notify();
  }

  togglePins() {
    const tab = this.activeTab;
    if (!tab) return;
    this.updateActiveTab({ showPins: !tab.showPins });
    this.notify();
  }

  toggleOutlines() {
    const tab = this.activeTab;
    if (!tab) return;
    this.updateActiveTab({ showOutlines: !tab.showOutlines });
    this.notify();
  }

  toggleLabels() {
    const tab = this.activeTab;
    if (!tab) return;
    this.updateActiveTab({ showLabels: !tab.showLabels });
    this.notify();
  }

  /** Cycle off → ghosts → disco → off. */
  cycleGhostMode() {
    const tab = this.activeTab;
    if (!tab) return;
    const next: GhostMode =
      tab.ghostMode === 'off'    ? 'ghosts' :
      tab.ghostMode === 'ghosts' ? 'disco'  : 'off';
    this.updateActiveTab({ ghostMode: next });
    this.notify();
  }

  toggleLayer(layerIndex: number) {
    const tab = this.activeTab;
    if (!tab || layerIndex < 0 || layerIndex >= tab.layerStates.length) return;
    const states = [...tab.layerStates];
    states[layerIndex] = { ...states[layerIndex], visible: !states[layerIndex].visible };
    this.updateActiveTab({ layerStates: states });
    this.notify();
  }

  /** Toggle all trace layers on or off. If any are visible, turn all off; otherwise all on. */
  toggleAllLayers() {
    const tab = this.activeTab;
    if (!tab || tab.layerStates.length === 0) return;
    const anyVisible = tab.layerStates.some(l => l.visible);
    const states = tab.layerStates.map(l => ({ ...l, visible: !anyVisible }));
    this.updateActiveTab({ layerStates: states });
    this.notify();
  }

  setLayerColor(layerIndex: number, color: number) {
    const tab = this.activeTab;
    if (!tab || layerIndex < 0 || layerIndex >= tab.layerStates.length) return;
    const states = [...tab.layerStates];
    states[layerIndex] = { ...states[layerIndex], color };
    this.updateActiveTab({ layerStates: states });
    this.notify();
  }

  /** Turn a layer on if it's currently hidden — so bumping/pinning it actually
   *  reveals something. No-op when already visible or index out of range. */
  private _revealLayer(layerIndex: number) {
    const tab = this.activeTab;
    if (!tab || layerIndex < 0 || layerIndex >= tab.layerStates.length) return;
    if (tab.layerStates[layerIndex].visible) return;
    const states = [...tab.layerStates];
    states[layerIndex] = { ...states[layerIndex], visible: true };
    tab.layerStates = states;
  }

  /** Bump a layer's traces to the top of the z-stack (transient). Passing the
   *  currently-selected index clears it. Selecting reveals the layer *while
   *  selected* (the renderer shows it even if its visibility toggle is off) but
   *  does NOT mutate the toggle — deselecting reverts it. Has no z-order effect
   *  while a layer is pinned (see fixateLayer). */
  selectLayer(layerIndex: number | null) {
    const tab = this.activeTab;
    if (!tab) return;
    const valid = layerIndex != null && layerIndex >= 0 && layerIndex < tab.layerStates.length;
    // Toggle off when re-selecting the same layer.
    const next = valid && tab.selectedLayerIndex !== layerIndex ? layerIndex : null;
    tab.selectedLayerIndex = next;
    this.notify();
  }

  /** Pin one layer's traces on top (sticky — survives selection changes).
   *  Passing the currently-pinned index unpins it. Pinning a layer reveals it
   *  (turns it on if hidden). Only one layer can be pinned; setting a new index
   *  replaces any previous pin. */
  fixateLayer(layerIndex: number | null) {
    const tab = this.activeTab;
    if (!tab) return;
    const valid = layerIndex != null && layerIndex >= 0 && layerIndex < tab.layerStates.length;
    const next = valid && tab.fixatedLayerIndex !== layerIndex ? layerIndex : null;
    tab.fixatedLayerIndex = next;
    if (next != null) this._revealLayer(next);
    this.notify();
  }

  cycleDimMode() {
    const tab = this.activeTab;
    if (!tab) return;
    // 2R: liga/desliga; Shift+clique liga o holofote (window.__r2DimShift)
    const next: BoardTab['dimMode'] =
      tab.dimMode !== 'off' ? 'off'
      : (window as unknown as { __r2DimShift?: boolean }).__r2DimShift ? 'darklight'
      : 'dim';
    this.updateActiveTab({ dimMode: next });
    this._saveCurrentViewPrefs();
    this.notify();
  }

  /** @deprecated — use cycleDimMode() */
  toggleNetDim() {
    this.cycleDimMode();
  }

  toggleHoverInfo() {
    const tab = this.activeTab;
    if (!tab) return;
    this.updateActiveTab({ showHoverInfo: !tab.showHoverInfo });
    this._saveCurrentViewPrefs();
    this.notify();
  }

  toggleFollowPdf() {
    const tab = this.activeTab;
    if (!tab) return;
    try { localStorage.setItem('2r-follow-pdf-on', tab.followPdf ? '0' : '1'); } catch { /* */ }
    this.updateActiveTab({ followPdf: !tab.followPdf });
    this._saveCurrentViewPrefs();
    this.notify();
  }

  setSearch(query: string) {
    const tab = this.activeTab;
    if (tab && tab.searchQuery !== query) navHistoryStore.recordQuery('board', query);
    this.updateActiveTab({ searchQuery: query });
    this.notify();
  }

  // Cached search results — recomputed only when query or board changes
  private _cachedSearchQuery = '';
  private _cachedSearchBoard: BoardData | null = null;
  private _cachedSearchResults: Part[] = [];
  private _cachedSearchIndices: Set<number> = new Set();

  private _recomputeSearch() {
    const tab = this.activeTab;
    const q = tab?.searchQuery ?? '';
    const board = tab?.board ?? null;
    if (q === this._cachedSearchQuery && board === this._cachedSearchBoard) return;
    this._cachedSearchQuery = q;
    this._cachedSearchBoard = board;
    if (!board || !q) {
      this._cachedSearchResults = [];
      this._cachedSearchIndices = new Set();
      return;
    }
    const ql = q.toLowerCase();
    const results: Part[] = [];
    const indices = new Set<number>();
    for (let i = 0; i < board.parts.length; i++) {
      const p = board.parts[i];
      if (r2Match(p.name, ql) ||
          p.pins.some(pin => r2Match(pin.net, ql))) {
        results.push(p);
        indices.add(i);
      }
    }
    this._cachedSearchResults = results;
    this._cachedSearchIndices = indices;
  }

  get searchResults(): Part[] {
    this._recomputeSearch();
    return this._cachedSearchResults;
  }

  /** Part indices matching the current search query (for renderer highlighting). */
  get searchResultIndices(): Set<number> {
    this._recomputeSearch();
    return this._cachedSearchIndices;
  }

  /** Compute search results for a specific tab (used by per-panel sidebars). */
  searchForTab(tabId: number): Part[] {
    const tab = this.getTab(tabId);
    if (!tab?.board || !tab.searchQuery) return [];
    const ql = tab.searchQuery.toLowerCase();
    return tab.board.parts.filter(p =>
      looseMatch(p.name, ql) ||
      p.pins.some(pin => looseMatch(pin.net, ql))
    );
  }

  get focusRequest(): FocusRequest | null { return this._focusRequest; }

  consumeFocusRequest(): FocusRequest | null {
    const req = this._focusRequest;
    this._focusRequest = null;
    return req;
  }

  /**
   * Select a pin on a board tab that is not necessarily the active one.
   *
   * The cross-board compare tool points at two boards at once: one of them is
   * on screen and the other is a tab away, and clicking a row has to land on
   * the right pin in both. `focusPart` only ever touches the active tab, and
   * `updateActiveTab` is private by design, so this is the one tab-scoped
   * selection entry point.
   *
   * Side flip and focus request mirror `focusPart` — but the focus request is
   * only issued for the active tab, since the renderer consuming it belongs to
   * whichever board is on screen; a request left for a background tab would
   * fire whenever the user next switched to it, long after it meant anything.
   *
   * Returns true when the part was found.
   */
  selectPinInTab(tabId: number, partName: string, pinIndex: number | null, opts: NavOpts & { focus?: boolean } = {}): boolean {
    const tab = this._tabs.find(t => t.id === tabId);
    if (!tab?.board) return false;
    const upper = partName.trim().toUpperCase();
    const idx = tab.board.parts.findIndex(p => p.name.trim().toUpperCase() === upper);
    if (idx < 0) return false;

    const part = viewPart(tab, idx) ?? tab.board.parts[idx];
    if (!tab.butterfly && R2_VIRA_SOZINHO) {
      if (part.side === 'top' && !tab.showTop) {
        Object.assign(tab, { showTop: true, showBottom: false });
      } else if (part.side === 'bottom' && !tab.showBottom) {
        Object.assign(tab, { showTop: false, showBottom: true });
      }
    }

    const net = pinIndex != null ? part.pins[pinIndex]?.net ?? null : null;
    Object.assign(tab, {
      selection: {
        partIndex: idx,
        pinIndex,
        highlightedNet: net || null,
        adjacentNets: this._adjacentNetsFor(tab, net),
      },
      searchSelectionActive: true,
    });
    if (tab.id === this._activeTabId) {
      this._clearPreviewPulse();
      if (opts.focus !== false) this._focusRequest = { partIndex: idx, bounds: part.bounds };
    }
    this._recordNav(tab, opts.cause ?? 'click', opts);
    this.notify();
    return true;
  }

  /** 2R Tools (Roger, 11/10/2026): Sequência de start — vai até o PINO sem mexer
   *  no zoom que o técnico escolheu (só centraliza). `scale` aplica um zoom guardado. */
  focusPinKeepZoom(partIndex: number, pinIndex: number, scale?: number) {
    this._clearPreviewPulse();
    const tab = this.activeTab;
    if (!tab?.board) return;
    const part = viewPart(tab, partIndex) ?? tab.board.parts[partIndex];
    const pin = part?.pins[pinIndex];
    if (!part || !pin) return;
    if (!tab.butterfly && R2_VIRA_SOZINHO) {
      if (part.side === 'top' && !tab.showTop) this.updateActiveTab({ showTop: true, showBottom: false });
      else if (part.side === 'bottom' && !tab.showBottom) this.updateActiveTab({ showTop: false, showBottom: true });
    }
    const r = Math.max(pin.radius || 0, 1);
    this.selectPin(partIndex, pinIndex, { cause: 'search' } as never);
    this._focusRequest = {
      partIndex,
      bounds: { minX: pin.position.x - r, minY: pin.position.y - r, maxX: pin.position.x + r, maxY: pin.position.y + r },
      zoomMode: scale ? 'always' : 'keep', scale, rememberZoom: true,
    };
    this.notify();
  }

  focusPart(name: string, nav?: NavOpts) {
    this._clearPreviewPulse();
    const tab = this.activeTab;
    if (!tab?.board) return;
    const upper = name.toUpperCase();
    const idx = tab.board.parts.findIndex(p => p.name.toUpperCase() === upper);
    if (idx < 0) return;

    const part = viewPart(tab, idx) ?? tab.board.parts[idx];

    // If the part is on the other side and we're not in butterfly mode, flip to it
    if (!tab.butterfly && R2_VIRA_SOZINHO) {
      if (part.side === 'top' && !tab.showTop) {
        this.updateActiveTab({ showTop: true, showBottom: false });
      } else if (part.side === 'bottom' && !tab.showBottom) {
        this.updateActiveTab({ showTop: false, showBottom: true });
      }
    }

    // Preserve the active net highlight when focusing a part that touches it
    // (e.g. clicking a component inside the search Nets spoiler). Otherwise
    // clear it — selecting an unrelated part shouldn't keep stale net state.
    const prevNet = tab.selection.highlightedNet;
    const keepNet = prevNet != null && part.pins.some(p => p.net === prevNet);

    this.updateActiveTab({
      selection: { partIndex: idx, pinIndex: null, highlightedNet: keepNet ? prevNet : null, adjacentNets: keepNet ? this._resolveAdjacentNets(prevNet) : new Set<string>() },
      searchSelectionActive: true,
    });
    this._focusRequest = { partIndex: idx, bounds: part.bounds };
    this._recordNav(tab, nav?.cause ?? 'search', nav);
    this.notify();
  }

  /**
   * Navigate to a component WITHOUT retargeting the inspector.
   *
   * The net tree's single click uses this: it pans/zooms the board to a
   * neighbour so you can see where it sits, while `selection` — and therefore
   * the Info tab's subject and its open net tree — stays exactly where it was.
   * Double click promotes for real (`promotePartOnNet`).
   *
   * No selection blink: the blink renders the *current* selection, which here
   * is still the previous part, so blinking would point at the wrong thing.
   */
  previewPart(name: string) {
    const tab = this.activeTab;
    if (!tab?.board) return;
    const upper = name.toUpperCase();
    const idx = tab.board.parts.findIndex(p => p.name.toUpperCase() === upper);
    if (idx < 0) return;
    const part = viewPart(tab, idx) ?? tab.board.parts[idx];

    // Flip to the part's side, exactly as focusPart does. Changing the visible
    // side is a view change, not a selection change, so it does not violate
    // preview's contract — and without it, previewing a bottom-side neighbour
    // flew the camera to a blank patch of the top side.
    if (!tab.butterfly && R2_VIRA_SOZINHO) {
      if (part.side === 'top' && !tab.showTop) {
        this.updateActiveTab({ showTop: true, showBottom: false });
      } else if (part.side === 'bottom' && !tab.showBottom) {
        this.updateActiveTab({ showTop: false, showBottom: true });
      }
    }

    this._focusRequest = { partIndex: idx, bounds: part.bounds, blink: false };
    this._startPreviewPulse(idx);
    this.notify();
  }

  /** Marker to draw for the previewed part, or null. */
  get previewPulse(): PreviewPulse | null {
    if (!this._preview) return null;
    const elapsed = Date.now() - this._preview.startedAt;
    return {
      partIndex: this._preview.partIndex,
      phase: elapsed < PREVIEW_BURST_MS ? 'burst' : 'beacon',
    };
  }

  private _startPreviewPulse(partIndex: number) {
    if (this._previewBurstTimer) clearTimeout(this._previewBurstTimer);
    this._preview = { partIndex, startedAt: Date.now() };
    // One notify when the burst ends, so net-wide disco (suppressed for the
    // duration) resumes and the beacon takes over without waiting for some
    // unrelated store change to wake the renderer.
    this._previewBurstTimer = setTimeout(() => {
      this._previewBurstTimer = null;
      this.notify();
    }, PREVIEW_BURST_MS);
  }

  /** Drop the preview marker. Called whenever the selection moves: once the
   *  part IS the subject it gets the selection's own treatment, and two
   *  markers on one component reads as a bug. */
  private _clearPreviewPulse() {
    if (this._previewBurstTimer) { clearTimeout(this._previewBurstTimer); this._previewBurstTimer = null; }
    this._preview = null;
  }

  /**
   * Promote a component reached from the net tree to be the inspector's subject.
   *
   * Selects the component *by the pin that sits on `net`* rather than the bare
   * part. That distinction is the whole point: `ComponentInfoBody` derives the
   * net tree from `selection.pinIndex`, and `focusPart()` sets `pinIndex: null`
   * — so promoting via focusPart blanked the tree you were walking even though
   * the net stayed lit on the board. Keeping a pin selected means the same net
   * stays fanned out under the new subject, with the previous part now a row
   * in it, so walking a rail is a sequence of reversible steps.
   *
   * Side-flip and camera behaviour are copied from `focusPart` so promoting
   * feels identical to any other navigation.
   */
  promotePartOnNet(partIndex: number, pinIndex: number, nav?: NavOpts) {
    this._clearPreviewPulse();
    const tab = this.activeTab;
    const part = tab ? viewPart(tab, partIndex) : undefined;
    if (!tab?.board || !part) return;
    const pin = part.pins[pinIndex];

    if (!tab.butterfly && R2_VIRA_SOZINHO) {
      if (part.side === 'top' && !tab.showTop) {
        this.updateActiveTab({ showTop: true, showBottom: false });
      } else if (part.side === 'bottom' && !tab.showBottom) {
        this.updateActiveTab({ showTop: false, showBottom: true });
      }
    }

    const net = pin?.net || null;
    this.updateActiveTab({
      selection: { partIndex, pinIndex, highlightedNet: net, adjacentNets: this._resolveAdjacentNets(net) },
      searchSelectionActive: true,
    });
    this._focusRequest = { partIndex, bounds: part.bounds };
    this._recordNav(tab, nav?.cause ?? 'click', nav);
    this.notify();
  }

  focusNet(name: string, nav?: NavOpts) {
    const tab = this.activeTab;
    if (!tab?.board) return;
    // Case-insensitive net lookup — try exact match first, then scan
    let net = tab.board.nets.get(name);
    if (!net) {
      const upper = name.toUpperCase();
      for (const [k, v] of tab.board.nets) {
        if (k.toUpperCase() === upper) { net = v; name = k; break; }
      }
    }
    if (!net || net.pinIndices.length === 0) return;

    // Compute bounding box of all pins on this net — at their DRAWN positions
    // (see viewPart); a pack lays parts out differently from the file.
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (const { partIndex, pinIndex } of net.pinIndices) {
      const pin = viewPart(tab, partIndex)?.pins[pinIndex];
      if (!pin) continue;
      if (pin.position.x < minX) minX = pin.position.x;
      if (pin.position.y < minY) minY = pin.position.y;
      if (pin.position.x > maxX) maxX = pin.position.x;
      if (pin.position.y > maxY) maxY = pin.position.y;
    }
    if (!isFinite(minX)) return;

    // Pad the bounds so a single-pin net doesn't zoom to infinity
    const pad = Math.max(maxX - minX, maxY - minY, 200) * 0.1;
    minX -= pad; minY -= pad; maxX += pad; maxY += pad;

    this.updateActiveTab({
      selection: { partIndex: null, pinIndex: null, highlightedNet: name, adjacentNets: this._resolveAdjacentNets(name) },
      searchSelectionActive: true,
    });
    this._focusRequest = { partIndex: null, bounds: { minX, minY, maxX, maxY } };
    this._recordNav(tab, nav?.cause ?? 'search', nav);
    this.notify();
  }
}

export const boardStore = new BoardStore();

// Scheme switches turn the dim off (see applyThemeChange). Only a change of
// the active scheme counts — accent / background / chrome knobs notify the
// same store and must not touch the dim.
{
  let seenSwitch = themeStore.lastSwitch.seq;
  themeStore.subscribe(() => {
    const { seq, prev } = themeStore.lastSwitch;
    if (seq === seenSwitch) return;
    seenSwitch = seq;
    boardStore.applyThemeChange(prev);
  });
}

// Expose for integration tests (Playwright) — DEV builds only
if (typeof window !== 'undefined' && import.meta.env.DEV) {
  (window as { __boardStore?: typeof boardStore }).__boardStore = boardStore;
}
