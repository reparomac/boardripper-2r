/**
 * Estado da SOBREPOSIÇÃO da câmera do microscópio sobre a placa (2R Tools).
 *
 * Mostra a imagem da câmera USB por cima da boardview com opacidade/escala/
 * rotação reguláveis, pra comparar a placa real com o desenho. Store de módulo
 * simples (mesmo padrão do Sidebar.utils) + hook via useSyncExternalStore.
 */
import { useSyncExternalStore } from 'react';

export interface CameraOverlayState {
  on: boolean;
  opacity: number;   // 0..100 (%)
  scale: number;     // 0.2..4
  rotation: number;  // -180..180 (graus)
  flipX: boolean;
  x: number;         // deslocamento em px
  y: number;
  align: boolean;    // modo alinhar: o vídeo captura o mouse p/ arrastar
  deviceId: string;
  /** 'camera' = imagem por cima da placa (modo antigo);
   *  'pins'   = imagem real EMBAIXO e só pinos/nets/códigos/leituras por cima,
   *             sem o fundo da boardview. */
  mode: 'camera' | 'pins';
  /** origem da imagem real: câmera ao vivo ou foto carregada do disco */
  source: 'camera' | 'photo';
  /** opacidade da camada da boardview no modo 'pins' (0..100 %) */
  pinsOpacity: number;
}

const LS = 'boardripper-2r-camera-overlay';

function load(): CameraOverlayState {
  const base: CameraOverlayState = {
    on: false, opacity: 50, scale: 1, rotation: 0, flipX: false,
    x: 0, y: 0, align: false, deviceId: '',
    mode: 'camera', source: 'camera', pinsOpacity: 100,
  };
  try {
    const raw = localStorage.getItem(LS);
    if (raw) {
      const p = JSON.parse(raw);
      // nunca persiste 'on'/'align' ligados (começa sempre desligado)
      return { ...base, ...p, on: false, align: false };
    }
  } catch { /* private mode */ }
  return base;
}

const state: CameraOverlayState = load();
const listeners = new Set<() => void>();

function persist(): void {
  try { localStorage.setItem(LS, JSON.stringify({ ...state, on: false, align: false })); }
  catch { /* ignore */ }
}
function emit(): void { listeners.forEach(fn => fn()); }
function subscribe(fn: () => void): () => void { listeners.add(fn); return () => { listeners.delete(fn); }; }

export function getCameraOverlay(): CameraOverlayState { return state; }

export function setCameraOverlay(patch: Partial<CameraOverlayState>): void {
  Object.assign(state, patch);
  persist();
  emit();
}

export function toggleCameraOverlay(): void {
  state.on = !state.on;
  if (!state.on) state.align = false;
  persist();
  emit();
}

/** Snapshot estável p/ o useSyncExternalStore (evita loop de render). */
let snap = { ...state };
function getSnapshot(): CameraOverlayState {
  // recria o objeto só quando algo muda
  if (snap.on !== state.on || snap.opacity !== state.opacity || snap.scale !== state.scale
      || snap.rotation !== state.rotation || snap.flipX !== state.flipX || snap.x !== state.x
      || snap.y !== state.y || snap.align !== state.align || snap.deviceId !== state.deviceId
      || snap.mode !== state.mode || snap.source !== state.source || snap.pinsOpacity !== state.pinsOpacity) {
    snap = { ...state };
  }
  return snap;
}

export function useCameraOverlay(): CameraOverlayState {
  return useSyncExternalStore(subscribe, getSnapshot, getSnapshot);
}

/** Modo "pinos por cima" ativo? (lido pelo BoardRenderer p/ deixar o fundo transparente) */
export function isPinsOnTop(): boolean { return state.on && state.mode === 'pins'; }

export function subscribeCameraOverlay(fn: () => void): () => void { return subscribe(fn); }

// ---- stream da câmera compartilhado (um só getUserMedia p/ todas as camadas) ----
let stream: MediaStream | null = null;
export function getCameraStream(): MediaStream | null { return stream; }
export function setCameraStream(s: MediaStream | null): void { stream = s; emit(); }

// ---- foto carregada (não persiste: object URL só vale nesta sessão) ----
let photoUrl: string | null = null;
export function getPhotoUrl(): string | null { return photoUrl; }
export function setPhotoFile(file: File | null): void {
  if (photoUrl) URL.revokeObjectURL(photoUrl);
  photoUrl = file ? URL.createObjectURL(file) : null;
  emit();
}
export function usePhotoUrl(): string | null {
  return useSyncExternalStore(subscribe, getPhotoUrl, getPhotoUrl);
}
export function useCameraStream(): MediaStream | null {
  return useSyncExternalStore(subscribe, getCameraStream, getCameraStream);
}
