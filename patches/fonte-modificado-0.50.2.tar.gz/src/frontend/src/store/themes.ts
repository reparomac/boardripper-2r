import { Emitter } from './emitter';
import { log } from './log-store';
import { setThemeOverridesProvider, renderSettingsStore } from './render-settings';
import type { RenderSettings } from './render-settings';
import { hexToInt } from './color-math';
import {
  shadeToward,
  pickAccentFg,
  pickTextColors,
  accentTextColor,
} from './color-math';

// Re-exported for existing call sites that imported these from themes.ts.
export { lightenHex, darkenHex, shadeToward, pickAccentFg, pickTextColors, hexToInt } from './color-math';

/**
 * A theme bundles every color that's currently configurable across the app —
 * UI chrome (CSS custom properties), board canvas (PixiJS scene constants),
 * and selection accents. Two presets ship in v1; adding a third is one entry
 * in THEMES.
 */
export interface Theme {
  id: string;
  label: string;

  /** UI chrome — drives CSS custom properties on document.documentElement. */
  ui: {
    bgPrimary: string;
    bgSecondary: string;
    bgTertiary: string;
    textPrimary: string;
    textSecondary: string;
    accent: string;
    border: string;
    /** Library file-type badge backgrounds — green for boards, red for PDFs,
     *  for at-a-glance type recognition in the file list. */
    iconBoardBg: string;
    iconPdfBg: string;
  };

  /** Board canvas — drives PixiJS scene constants via the BOARD_COLORS getter. */
  board: {
    canvasBackground: string;
    boardFill: string;
    outline: string;
    selection: string;
    butterflySelection: string;
    /** Pin-number labels (drives BOARD_COLORS.labelPin). */
    labelText: string;
    /** Part refdes labels. Default is light gray; monochrome themes set
     *  white for maximum contrast against a black board. */
    labelPart: string;
    /** Net-name labels. Default is light blue; monochrome themes set white. */
    labelNet: string;
    /** Background box behind net-name labels (when the bg toggle is on). Dark
     *  themes use near-black; light themes a light tint of the board fill. */
    netLabelBg: string;
    /** Opacity 0–1 of the net-label background box. */
    netLabelBgOpacity: number;
    /** Primary (clicked) part outline. Absent = white, the Default look. */
    selectedPart?: string;
    /** Colour the dim overlay fades the board toward. Absent = black. */
    dimColor?: string;
    /** Part border, top / underside. Absent = the green / red of Default. */
    partOutlineTop?: string;
    partOutlineBottom?: string;
    /** Highlighter yellow behind the selected net's pins on a light scheme
     *  (see RenderSettings.lightSelectionStyle). Absent = the scheme keeps the
     *  glow in its selection colour (Default, Dark, Landrex). */
    highlighter?: string;
    /** Copper colour of the top / bottom layer. Absent = red / green. */
    copperTop?: string;
    copperBottom?: string;
  };

  /**
   * Role colours for a scheme that owns the whole picture (Dark, Landrex,
   * Light, Atari — docs/specs/2026-10-11-colour-schemes-review.md). Turned into
   * render-setting overrides by `paletteOverrides`, applied over the user's
   * own pin groups and part types so their keywords and prefixes stay theirs
   * and only the colours change. Absent = the theme leaves pin and part
   * colours to the render settings (BoardRipper Default).
   */
  palette?: ThemePalette;

  /**
   * Optional render-settings overrides applied while this theme is active.
   * Lets a theme like Landrex enforce a "monochrome supermode" (no
   * component-type colors, no net colors, white pins regardless of side)
   * without the user having to flip every relevant setting by hand.
   * The user's saved settings are restored when the theme is switched off.
   */
  boardOverrides?: Partial<RenderSettings>;
}

/** What a pin is for, as far as colour goes. Matches the rule ids of
 *  DEFAULT_PIN_GROUPS; `signalTop`/`signalBottom` colour every pin no group
 *  claims, one per side, so the side has its own code and red can mean power. */
export type PinRole = 'signalTop' | 'signalBottom' | 'power' | 'rail' | 'ground' | 'agnd'
  | 'serial' | 'pci' | 'ddr' | 'enable' | 'onoff' | 'nc';

export interface ThemePalette {
  pins: Record<PinRole, string>;
  /** Fill per part-type id; null = parts are outlines with no fill. */
  partTints: Record<string, string> | null;
  componentFillAlpha?: number;
  /** 1 = the board sheet is drawn solid in `board.boardFill`. */
  boardFillAlpha?: number;
  showPin1Marker?: boolean;
  /** Opacity of the copper-pad overlay (Default 0.95). */
  padAlpha?: number;
  /** Fill of a large part fades with its share of the board, so a connector
   *  the size of a third of the board is a tint, not a block. */
  fadeLargeBodies?: boolean;
  /** Connection lines of the lit net, and of the nets reached through 2-pin
   *  parts in chain-adjacent mode. Default's yellow / blue are invisible on
   *  paper, so a scheme names its own. */
  netLine: string;
  adjacentNetLine: string;
}

/** DEFAULT_PIN_GROUPS rule id → role. A rule the user added has no role and
 *  keeps its own colour. */
const RULE_ROLE: Record<string, PinRole> = {
  'power-v': 'power', 'power-pp': 'rail', 'gnd-sep': 'agnd', gnd: 'ground',
  serial: 'serial', pci: 'pci', ddr: 'ddr', enable: 'enable', onoff: 'onoff', nc: 'nc',
};

/** The render-setting overrides a palette theme implies, built on the user's
 *  own settings: pin groups and part types keep every keyword and prefix, only
 *  the colours of the built-in rules and types are swapped. */
export function paletteOverrides(p: ThemePalette, global: RenderSettings): Partial<RenderSettings> {
  const pinGroups = (global.pinGroups ?? []).map(g => ({
    ...g,
    rules: g.rules.map(r => (RULE_ROLE[r.id] ? { ...r, color: p.pins[RULE_ROLE[r.id]] } : r)),
  }));
  const partTypes = (global.partTypes ?? []).map(t => (p.partTints?.[t.id] ? { ...t, color: p.partTints[t.id] } : t));
  const ov: Partial<RenderSettings> = {
    pinGroups,
    defaultPinColorTop: p.pins.signalTop,
    defaultPinColorBottom: p.pins.signalBottom,
    showComponentColors: p.partTints !== null,
    partTypes,
    // The dim appears only with a selection on these schemes; an always-on
    // ambient dim would lay the canvas colour over the whole board.
    ambientDim: false,
    netLineColor: hexToInt(p.netLine),
    adjacentNetLineColor: hexToInt(p.adjacentNetLine),
  };
  if (p.componentFillAlpha !== undefined) ov.componentFillAlpha = p.componentFillAlpha;
  if (p.boardFillAlpha !== undefined) ov.boardFillAlpha = p.boardFillAlpha;
  if (p.showPin1Marker !== undefined) ov.showPin1Marker = p.showPin1Marker;
  return ov;
}

/** Interface chrome shared by the dark schemes (identical to Default's). */
const DARK_UI: Theme['ui'] = {
  bgPrimary: '#08080c', bgSecondary: '#0f0f18', bgTertiary: '#0c1424', textPrimary: '#e0e0e0',
  textSecondary: '#a0a0b0', accent: '#4a9eff', border: '#1a1a28', iconBoardBg: '#44cc44', iconPdfBg: '#cc4444',
};

export const THEMES: Record<string, Theme> = {
  // 2R 18/10/2026 (tema do RastreCurve) e 20/10/2026 (Âmbar = cores do FlexBV, escuro padrão)
    "2r-rastre": {
      id: "2r-rastre",
      label: "2R Tools — RastreCurve",
      ui: {
        bgPrimary: "#0e0f11",
        bgSecondary: "#16171a",
        bgTertiary: "#1c1d21",
        textPrimary: "#e6e6e6",
        textSecondary: "#9a9da5",
        accent: "#4a4d55",
        border: "#2a2c31",
        iconBoardBg: "#3a3d44",
        iconPdfBg: "#3a3d44",
      },
      board: {
        canvasBackground: "#08090A",
        boardFill: "#25282C",
        outline: "#B4B8BE",
        selection: "#ffffff",
        butterflySelection: "#44aaff",
        labelText: "#ffffff",
        labelPart: "#8A8D93",
        labelNet: "#88ccff",
        netLabelBg: "#000000",
        netLabelBgOpacity: 0.6,
      },
      boardOverrides: {
        showSelectionHalo: false,
        hdrFocusGlow: false,
        ambientDim: false,
        boardFillAlpha: 1,
        showComponentColors: false,
        componentFillAlpha: 0,
        partTypes: [
          {
            id: "resistor",
            label: "Resistor",
            prefixes: ["R", "PR", "PH"],
            color: "#25282C",
            padShape: "natural",
            bodyShape: "natural",
            hidden: false,
            hierarchyBridge: false,
          },
          {
            id: "capacitor",
            label: "Capacitor",
            prefixes: ["C", "PC"],
            color: "#25282C",
            padShape: "natural",
            bodyShape: "natural",
            hidden: false,
            hierarchyBridge: false,
          },
          {
            id: "inductor",
            label: "Inductor",
            prefixes: ["L", "PL", "B"],
            color: "#25282C",
            padShape: "natural",
            bodyShape: "natural",
            hidden: false,
            hierarchyBridge: false,
          },
          {
            id: "diode",
            label: "Diode",
            prefixes: ["D", "PD", "Z", "PZ"],
            color: "#25282C",
            padShape: "natural",
            bodyShape: "natural",
            hidden: false,
            hierarchyBridge: false,
          },
          {
            id: "crystal",
            label: "Crystal",
            prefixes: ["Y", "X"],
            color: "#25282C",
            padShape: "natural",
            bodyShape: "natural",
            hidden: false,
            hierarchyBridge: false,
          },
          {
            id: "transistor",
            label: "Transistor",
            prefixes: ["Q", "PQ"],
            color: "#25282C",
            padShape: "natural",
            bodyShape: "natural",
            hidden: false,
            hierarchyBridge: false,
          },
          {
            id: "ic",
            label: "IC",
            prefixes: ["U", "PU"],
            color: "#25282C",
            padShape: "natural",
            bodyShape: "natural",
            hidden: false,
            hierarchyBridge: false,
          },
          {
            id: "connector",
            label: "Connector",
            prefixes: ["J", "SW"],
            color: "#25282C",
            padShape: "natural",
            bodyShape: "natural",
            hidden: false,
            hierarchyBridge: false,
          },
          {
            id: "fuse",
            label: "Fuse",
            prefixes: ["F"],
            color: "#25282C",
            padShape: "natural",
            bodyShape: "natural",
            hidden: false,
            hierarchyBridge: false,
          },
          {
            id: "testpoint",
            label: "Test Point",
            prefixes: ["TP"],
            color: "#25282C",
            padShape: "natural",
            bodyShape: "natural",
            hidden: false,
            hierarchyBridge: false,
          },
          {
            id: "shield",
            label: "Shield",
            prefixes: ["SH", "MEC"],
            color: "#25282C",
            padShape: "natural",
            bodyShape: "natural",
            hidden: false,
            hierarchyBridge: false,
          },
        ],
        pinGroups: [{ id: "misc", label: "Misc", outlineOnly: false, rules: [] }],
        netColorRules: [],
        defaultPinColorTop: "#8A8D93",
        defaultPinColorBottom: "#8A8D93",
        netLineAlpha: 0,
        showPin1Marker: false,
        showDiodeValues: false,
        showNetNames: false,
        showPinNumbers: false,
        showPartLabels: true,
        partLabelScale: 1.15,
        labelMinScreenPx: 3,
        labelHideThreshold: 1,
        partLabelShadow: true,
        outlineWidth: 1.2,
        outlineAlpha: 0.95,
        partBorderAlpha: 0,
        partBorderWidth: 1,
        pinAlpha: 0.5,
      },
    },
    "2r-ambar": {
      id: "2r-ambar",
      label: "2R Tools — Âmbar",
      ui: {
        bgPrimary: "#0e0f11",
        bgSecondary: "#16171a",
        bgTertiary: "#1c1d21",
        textPrimary: "#e6e6e6",
        textSecondary: "#9a9da5",
        accent: "#4a4d55",
        border: "#2a2c31",
        iconBoardBg: "#3a3d44",
        iconPdfBg: "#3a3d44",
      },
      board: {
        canvasBackground: "#151412",
        boardFill: "#211F1B",
        outline: "#4a463f",
        selection: "#ffffff",
        butterflySelection: "#44aaff",
        labelText: "#ffffff",
        labelPart: "#CB9347",
        labelNet: "#88ccff",
        netLabelBg: "#000000",
        netLabelBgOpacity: 0.6,
      },
      boardOverrides: {
        showSelectionHalo: false,
        hdrFocusGlow: false,
        ambientDim: false,
        boardFillAlpha: 1,
        showComponentColors: true,
        componentFillAlpha: 1,
        partTypes: [
          {
            id: "resistor",
            label: "Resistor",
            prefixes: ["R", "PR", "PH"],
            color: "#1F1F1F",
            padShape: "natural",
            bodyShape: "natural",
            hidden: false,
            hierarchyBridge: true,
          },
          {
            id: "capacitor",
            label: "Capacitor",
            prefixes: ["C", "PC"],
            color: "#5C4A3F",
            padShape: "natural",
            bodyShape: "natural",
            hidden: false,
            hierarchyBridge: false,
          },
          {
            id: "inductor",
            label: "Inductor",
            prefixes: ["L", "PL", "B"],
            color: "#2D2D2D",
            padShape: "natural",
            bodyShape: "square",
            hidden: false,
            hierarchyBridge: true,
          },
          {
            id: "diode",
            label: "Diode",
            prefixes: ["D", "PD", "Z", "PZ"],
            color: "#2D2D2D",
            padShape: "natural",
            bodyShape: "natural",
            hidden: false,
            hierarchyBridge: true,
          },
          {
            id: "crystal",
            label: "Crystal",
            prefixes: ["Y", "X"],
            color: "#2D2D2D",
            padShape: "natural",
            bodyShape: "natural",
            hidden: false,
            hierarchyBridge: false,
          },
          {
            id: "transistor",
            label: "Transistor",
            prefixes: ["Q", "PQ"],
            color: "#2D2D2D",
            padShape: "natural",
            bodyShape: "natural",
            hidden: false,
            hierarchyBridge: false,
          },
          {
            id: "ic",
            label: "IC",
            prefixes: ["U", "PU"],
            color: "#2D2D2D",
            padShape: "natural",
            bodyShape: "natural",
            hidden: false,
            hierarchyBridge: false,
          },
          {
            id: "connector",
            label: "Connector",
            prefixes: ["J", "SW"],
            color: "#2D2D2D",
            padShape: "natural",
            bodyShape: "natural",
            hidden: false,
            hierarchyBridge: false,
          },
          {
            id: "fuse",
            label: "Fuse",
            prefixes: ["F"],
            color: "#2D2D2D",
            padShape: "natural",
            bodyShape: "natural",
            hidden: false,
            hierarchyBridge: false,
          },
          {
            id: "testpoint",
            label: "Test Point",
            prefixes: ["TP"],
            color: "#8B7334",
            padShape: "round",
            bodyShape: "natural",
            hidden: false,
            hierarchyBridge: false,
          },
          {
            id: "shield",
            label: "Shield",
            prefixes: ["SH", "MEC"],
            color: "#2D2D2D",
            padShape: "natural",
            bodyShape: "natural",
            hidden: false,
            hierarchyBridge: false,
          },
        ],
        partBorderAlpha: 0.9,
      },
    },
  // 2R Tools (Roger, 10/10/2026): «tudo neutro, com cara de programa profissional».
  // Cinza grafite na interface, placa em preto e branco, sem cor de componente
  // nem de net. A seleção fica branca (o padrão da casa: selecionado = branco).
  '2r-clean': {
    id: '2r-clean',
    label: '2R Tools — Neutro',
    ui: {
      bgPrimary:     '#0e0f11',
      bgSecondary:   '#16171a',
      bgTertiary:    '#1c1d21',
      textPrimary:   '#e6e6e6',
      textSecondary: '#9a9da5',
      accent:        '#4a4d55',
      border:        '#2a2c31',
      iconBoardBg:   '#3a3d44',
      iconPdfBg:     '#3a3d44',
    },
    // placa com as cores de verdade (Roger 10/10/2026: «no BDV tem que deixar a cor
    // da placa, sem efeito de luz») — só a interface fica neutra
    // 2R 18/10/2026: placa escura (o anterior virou «2r-clean-antigo»)
    board: {
      canvasBackground:   '#000000',
      boardFill:          '#2a2a2a',
      outline:            '#45484a',
      selection:          '#ffffff',
      butterflySelection: '#44aaff',
      labelText:          '#ffffff',
      labelPart:          '#cccccc',
      labelNet:           '#88ccff',
      netLabelBg:         '#000000',
      netLabelBgOpacity:  0.6,
    },
    boardOverrides: { showSelectionHalo: false, hdrFocusGlow: false, ambientDim: false, boardFillAlpha: 1 },
  },
  '2r-clean-antigo': {
    id: '2r-clean-antigo',
    label: '2R Tools — Neutro (anterior)',
    ui: {
      bgPrimary:     '#0e0f11',
      bgSecondary:   '#16171a',
      bgTertiary:    '#1c1d21',
      textPrimary:   '#e6e6e6',
      textSecondary: '#9a9da5',
      accent:        '#4a4d55',
      border:        '#2a2c31',
      iconBoardBg:   '#3a3d44',
      iconPdfBg:     '#3a3d44',
    },
    board: {
      canvasBackground:   '#050508',
      boardFill:          '#ffffff',
      outline:            '#9a9da5',
      selection:          '#ffff44',
      butterflySelection: '#44aaff',
      labelText:          '#ffffff',
      labelPart:          '#cccccc',
      labelNet:           '#88ccff',
      netLabelBg:         '#000000',
      netLabelBgOpacity:  0.6,
    },
    boardOverrides: { showSelectionHalo: false, hdrFocusGlow: false, ambientDim: false },
  },
  // 2R Tools — variantes do tema padrão (Roger, 10/10/2026 23:13): «um pouco mais claro,
  // placa puxando para o verde oliva; outro com a placa mais para o marrom; outro cinza/grafite…
  // nada gritante… as cores padrões das nets não mudam em nada».
  '2r-oliva': {
    id: '2r-oliva',
    label: '2R Tools — Oliva (mais claro)',
    ui: {
      bgPrimary:     '#17181b',
      bgSecondary:   '#1f2024',
      bgTertiary:    '#26272c',
      textPrimary:   '#ececec',
      textSecondary: '#a6a9b0',
      accent:        '#5a5d66',
      border:        '#34363c',
      iconBoardBg:   '#464950',
      iconPdfBg:     '#464950',
    },
    board: {
      // 2R (Roger, 11/10/2026): fundo claro também nos temas médios — «está preto»
      canvasBackground:   '#bfc2b4',
      boardFill:          '#6f7d3e',
      outline:            '#4f5638',
      selection:          '#1f2023',
      butterflySelection: '#44aaff',
      labelText:          '#1c1f24',
      labelPart:          '#2a2e34',
      labelNet:           '#1f3f63',
      netLabelBg:         '#eef0f2',
      netLabelBgOpacity:  0.75,
    },
    // cores das nets/pinos não mudam (vêm das regras de cor, não do tema)
    boardOverrides: {
      showSelectionHalo: false,
      hdrFocusGlow:      false,
      ambientDim:        false,
      boardFillAlpha:    0.3,
    },
  },
  '2r-marrom': {
    id: '2r-marrom',
    label: '2R Tools — Marrom',
    ui: {
      bgPrimary:     '#0e0f11',
      bgSecondary:   '#16171a',
      bgTertiary:    '#1c1d21',
      textPrimary:   '#e6e6e6',
      textSecondary: '#9a9da5',
      accent:        '#4a4d55',
      border:        '#2a2c31',
      iconBoardBg:   '#3a3d44',
      iconPdfBg:     '#3a3d44',
    },
    board: {
      // 2R (Roger, 11/10/2026): fundo claro também nos temas médios — «está preto»
      canvasBackground:   '#c6bcae',
      boardFill:          '#7a5b3d',
      outline:            '#5e4c38',
      selection:          '#1f2023',
      butterflySelection: '#44aaff',
      labelText:          '#1c1f24',
      labelPart:          '#2a2e34',
      labelNet:           '#1f3f63',
      netLabelBg:         '#eef0f2',
      netLabelBgOpacity:  0.75,
    },
    // cores das nets/pinos não mudam (vêm das regras de cor, não do tema)
    boardOverrides: {
      showSelectionHalo: false,
      hdrFocusGlow:      false,
      ambientDim:        false,
      boardFillAlpha:    0.3,
    },
  },
  '2r-grafite': {
    id: '2r-grafite',
    label: '2R Tools — Grafite',
    ui: {
      bgPrimary:     '#121315',
      bgSecondary:   '#1a1b1e',
      bgTertiary:    '#212226',
      textPrimary:   '#e8e8e8',
      textSecondary: '#a0a3aa',
      accent:        '#52555d',
      border:        '#2f3136',
      iconBoardBg:   '#40434a',
      iconPdfBg:     '#40434a',
    },
    board: {
      // 2R (Roger, 11/10/2026): fundo claro também nos temas médios — «está preto»
      canvasBackground:   '#1b1d21', // 2R: fundo escuro no Grafite
      boardFill:          '#8a8f96',
      outline:            '#4a4f56',
      selection:          '#1f2023',
      butterflySelection: '#44aaff',
      labelText:          '#1c1f24',
      labelPart:          '#2a2e34',
      labelNet:           '#1f3f63',
      netLabelBg:         '#eef0f2',
      netLabelBgOpacity:  0.75,
    },
    // cores das nets/pinos não mudam (vêm das regras de cor, não do tema)
    boardOverrides: {
      showSelectionHalo: false,
      hdrFocusGlow:      false,
      ambientDim:        false,
      boardFillAlpha:    0.26,
    },
  },
  // 2R Tools — variantes CLARAS (Roger, 10/10/2026 23:16–23:17: «mais 3 variantes para o tema
  // claro, sem esse fundo escuro… grafite para o cinza ou gelo»). Cores das nets iguais.
  '2r-claro-oliva': {
    id: '2r-claro-oliva',
    label: '2R Tools — Claro Oliva',
    ui: {
      bgPrimary:     '#eceee6',
      bgSecondary:   '#e2e5da',
      bgTertiary:    '#dcdfd2',
      textPrimary:   '#1c1f24',
      textSecondary: '#5b616b',
      accent:        '#8a8f97',
      border:        '#c6cab9',
      iconBoardBg:   '#9aa0a8',
      iconPdfBg:     '#9aa0a8',
    },
    board: {
      canvasBackground:   '#e6e8df',
      boardFill:          '#a7b27a',
      outline:            '#6b7350',
      selection:          '#1f2023',
      butterflySelection: '#3c5a78',
      labelText:          '#1c1f24',
      labelPart:          '#3a3f47',
      labelNet:           '#2d4a66',
      netLabelBg:         '#f4f5f6',
      netLabelBgOpacity:  0.75,
    },
    boardOverrides: {
      showSelectionHalo: false,
      hdrFocusGlow:      false,
      ambientDim:        false,
      boardFillAlpha:    0.42,
    },
  },
  '2r-claro-areia': {
    id: '2r-claro-areia',
    label: '2R Tools — Claro Areia (marrom)',
    ui: {
      bgPrimary:     '#efebe4',
      bgSecondary:   '#e6e0d6',
      bgTertiary:    '#dfd8cc',
      textPrimary:   '#1c1f24',
      textSecondary: '#5b616b',
      accent:        '#8a8f97',
      border:        '#cbc2b3',
      iconBoardBg:   '#9aa0a8',
      iconPdfBg:     '#9aa0a8',
    },
    board: {
      canvasBackground:   '#e9e4dc',
      boardFill:          '#c2a57f',
      outline:            '#7a6650',
      selection:          '#1f2023',
      butterflySelection: '#3c5a78',
      labelText:          '#1c1f24',
      labelPart:          '#3a3f47',
      labelNet:           '#2d4a66',
      netLabelBg:         '#f4f5f6',
      netLabelBgOpacity:  0.75,
    },
    boardOverrides: {
      showSelectionHalo: false,
      hdrFocusGlow:      false,
      ambientDim:        false,
      boardFillAlpha:    0.42,
    },
  },
  '2r-claro-gelo': {
    id: '2r-claro-gelo',
    label: '2R Tools — Claro Gelo (cinza)',
    ui: {
      bgPrimary:     '#eef0f2',
      bgSecondary:   '#e3e6e9',
      bgTertiary:    '#dce0e4',
      textPrimary:   '#1c1f24',
      textSecondary: '#5b616b',
      accent:        '#8a8f97',
      border:        '#c4c9cf',
      iconBoardBg:   '#9aa0a8',
      iconPdfBg:     '#9aa0a8',
    },
    board: {
      canvasBackground:   '#e6e9ec',
      boardFill:          '#b9c0c8',
      outline:            '#5f6873',
      selection:          '#1f2023',
      butterflySelection: '#3c5a78',
      labelText:          '#1c1f24',
      labelPart:          '#3a3f47',
      labelNet:           '#2d4a66',
      netLabelBg:         '#f4f5f6',
      netLabelBgOpacity:  0.75,
    },
    boardOverrides: {
      showSelectionHalo: false,
      hdrFocusGlow:      false,
      ambientDim:        false,
      boardFillAlpha:    0.45,
    },
  },
  default: {
    id: 'default',
    label: 'BoardRipper Default',
    // Note for future palette work: avoid AI-cliché colour schemes —
    // saturated cyan-blue dashboards and warm amber/orange "cyberpunk"
    // accents are both visually generic now. When picking a new default
    // accent, explore: magenta/hot-pink, acid lime, deep violet,
    // teal-not-cyan, classic ATARI red/orange/gold, or muted neutrals.
    // Keep ui.* values mirrored to :root in src/frontend/src/index.css
    // so the first paint (before themeStore.init()) doesn't flash.
    ui: {
      bgPrimary:     '#08080c',
      bgSecondary:   '#0f0f18',
      bgTertiary:    '#0c1424',
      textPrimary:   '#e0e0e0',
      textSecondary: '#a0a0b0',
      accent:        '#4a9eff',
      border:        '#1a1a28',
      iconBoardBg:   '#44cc44',
      iconPdfBg:     '#cc4444',
    },
    board: {
      canvasBackground:   '#050508',
      boardFill:          '#ffffff',
      outline:            '#4a9eff',
      selection:          '#ffff44',
      butterflySelection: '#44aaff',
      labelText:          '#ffffff',
      labelPart:          '#cccccc',
      labelNet:           '#88ccff',
      netLabelBg:         '#000000',
      netLabelBgOpacity:  0.6,
    },
    // Default theme = no overrides. Whatever the user has configured wins.
  },
  // ──────────────────────────────────────────────────────────────────────
  // Palette schemes (2026-10-11 review, docs/specs/2026-10-11-colour-schemes-review.md).
  // Each owns every colour on the board: pins by role and side, part bodies,
  // outlines, selection, dim and copper. All four pass the contrast checks in
  // themes.test.ts (labels ≥ 4.5:1 on the board and on every part body, pins
  // and selection ≥ 3:1). Mockup: claude.ai/artifact/9SzQM5xQaWsoEab6CPNgPX.
  dark: {
    id: 'dark',
    label: 'Dark',
    // Near-monochrome on NexusBV's principle: parts are grey outlines, every
    // pin one quiet grey, power a step brighter, ground a dark teal. Colour is
    // kept for the selection (yellow net, red part).
    ui: DARK_UI,
    board: {
      canvasBackground: '#08090b', boardFill: '#0f1114', outline: '#4a5260',
      selection: '#fff033', butterflySelection: '#44aaff', selectedPart: '#ff2b2b',
      labelText: '#e6e9ec', labelPart: '#d4d8dd', labelNet: '#b8c2cc',
      netLabelBg: '#000000', netLabelBgOpacity: 0.6, dimColor: '#08090b',
      partOutlineTop: '#5a606a', partOutlineBottom: '#6f6550',
      copperTop: '#39a9ff', copperBottom: '#f0a94a',
    },
    palette: {
      pins: {
        signalTop: '#6e7681', signalBottom: '#9c8a6a', power: '#a7afb9', rail: '#959da7',
        ground: '#5b7676', agnd: '#6b8686', serial: '#6e7681', pci: '#6e7681', ddr: '#6e7681',
        enable: '#6e7681', onoff: '#6e7681', nc: '#5e6570',
      },
      partTints: null, boardFillAlpha: 1, padAlpha: 0.6,
      netLine: '#fff033', adjacentNetLine: '#44aaff',
    },
  },
  landrex: {
    id: 'landrex',
    label: 'Landrex Classic',
    // As Landrex Test Link drew a board: black, an olive board edge,
    // lavender-grey part outlines, every pin the same blue, nothing filled.
    // The only additions: ground set apart, an amber underside, a yellow
    // selected net and a red selected part. Editing any colour forks the theme
    // into the custom slot like every other theme.
    ui: DARK_UI,
    board: {
      canvasBackground: '#000000', boardFill: '#000000', outline: '#9c9a4e',
      selection: '#fff033', butterflySelection: '#44aaff', selectedPart: '#ff2b2b',
      labelText: '#ffffff', labelPart: '#d8d8e8', labelNet: '#c8c8e0',
      netLabelBg: '#000000', netLabelBgOpacity: 0.55, dimColor: '#000000',
      partOutlineTop: '#8f8fc8', partOutlineBottom: '#a08850',
      copperTop: '#3b5bff', copperBottom: '#e0a040',
    },
    palette: {
      pins: {
        signalTop: '#3b5bff', signalBottom: '#e0a040', power: '#3b5bff', rail: '#3b5bff',
        ground: '#5a5f9a', agnd: '#5a5f9a', serial: '#3b5bff', pci: '#3b5bff', ddr: '#3b5bff',
        enable: '#3b5bff', onoff: '#3b5bff', nc: '#55558f',
      },
      partTints: null, boardFillAlpha: 1, showPin1Marker: false, padAlpha: 0.5,
      netLine: '#fff033', adjacentNetLine: '#44aaff',
    },
  },
  light: {
    id: 'light',
    label: 'Light',
    // Paper-white sheet, dark ink. Part tints reuse the pin hues (rail 29,
    // crystal 48, logic 174, data 213, on/off 262, one green), so parts and
    // pins are one family. Red means power only; the underside is warm brown
    // (violet is taken by the on/off pins).
    ui: {
      bgPrimary: '#eceef1', bgSecondary: '#dee0e3', bgTertiary: '#dde0e4', textPrimary: '#1c1f24',
      textSecondary: '#5b616b', accent: '#2f6db5', border: '#c2c5c9', iconBoardBg: '#3f9142', iconPdfBg: '#c0392b',
    },
    board: {
      canvasBackground: '#e6e8eb', boardFill: '#ffffff', outline: '#5d6672',
      selection: '#c26f00', butterflySelection: '#2f6db5', selectedPart: '#15191e',
      labelText: '#15191e', labelPart: '#15191e', labelNet: '#1f4f8f',
      netLabelBg: '#ffffff', netLabelBgOpacity: 0.72, dimColor: '#e6e8eb', highlighter: '#ffd400',
      partOutlineTop: '#5d6672', partOutlineBottom: '#8a6440',
      copperTop: '#1f63d6', copperBottom: '#d95f0e',
    },
    palette: {
      pins: {
        signalTop: '#5d6672', signalBottom: '#8a6440', power: '#d7261e', rail: '#d95f0e',
        ground: '#8c939c', agnd: '#8c939c', serial: '#b8338f', pci: '#1f63d6', ddr: '#3d82d8',
        enable: '#0e8f84', onoff: '#7a4fd6', nc: '#878e97',
      },
      partTints: {
        resistor: '#eae5e1', capacitor: '#f0ecdb', inductor: '#e3e5e8', diode: '#dae4f1', crystal: '#f4eed7',
        transistor: '#dbf0ee', ic: '#e3ddee', connector: '#dfe5ec', fuse: '#e6e6e6', testpoint: '#deedde', shield: '#e6e6e6',
      },
      componentFillAlpha: 0.95, boardFillAlpha: 1, fadeLargeBodies: true, padAlpha: 0.4,
      // The lines in the selection orange and the butterfly blue: yellow on
      // white paper is not a line.
      netLine: '#c26f00', adjacentNetLine: '#2f6db5',
    },
  },
  atari: {
    id: 'atari',
    label: 'Atari (light)',
    // The 2600's silver label and black ink. Every colour is one of the five
    // rainbow-stripe hues (green #4faf4a, yellow #f4e325, orange #fe8b1f,
    // red #ed3823, blue #2a3192) at a set lightness: pale tints for parts,
    // deep shades for pins (red power, orange rails, blue data, green logic),
    // muted orange for the woodgrain underside. Six neutrals.
    ui: {
      bgPrimary: '#ececea', bgSecondary: '#dcdcd8', bgTertiary: '#e0e0dc', textPrimary: '#111111',
      textSecondary: '#4a4a48', accent: '#2a3192', border: '#b8b8b4', iconBoardBg: '#3d883a', iconPdfBg: '#c62310',
    },
    board: {
      canvasBackground: '#b8b8b4', boardFill: '#ececea', outline: '#111111',
      selection: '#cb6301', butterflySelection: '#2a3192', selectedPart: '#111111',
      labelText: '#111111', labelPart: '#111111', labelNet: '#2a3192',
      netLabelBg: '#ececea', netLabelBgOpacity: 0.72, dimColor: '#ececea', highlighter: '#f4e325',
      partOutlineTop: '#111111', partOutlineBottom: '#6f4b2a',
      copperTop: '#2a3192', copperBottom: '#cb6301',
    },
    palette: {
      pins: {
        signalTop: '#4a4a48', signalBottom: '#6f4b2a', power: '#c62310', rail: '#cb6301',
        ground: '#86867f', agnd: '#86867f', serial: '#2a3192', pci: '#2a3192', ddr: '#414ac8',
        enable: '#3d883a', onoff: '#316c2d', nc: '#6c6c68',
      },
      partTints: {
        resistor: '#f8ddc4', capacitor: '#f6f2c6', inductor: '#d4e9d3', diode: '#cfd1ed', crystal: '#f6f2c6',
        transistor: '#d4e9d3', ic: '#cfd1ed', connector: '#d4d4d0', fuse: '#f8ddc4', testpoint: '#d4e9d3', shield: '#d4d4d0',
      },
      componentFillAlpha: 1, boardFillAlpha: 1, fadeLargeBodies: true, padAlpha: 0.4,
      netLine: '#cb6301', adjacentNetLine: '#2a3192',
    },
  },
};

const STORAGE_KEY = 'boardripper-theme';
const ACCENT_OVERRIDE_KEY = 'boardripper-accent-override';
const BACKGROUND_OVERRIDE_KEY = 'boardripper-background-override';
const CHROME_OVERRIDE_KEY = 'boardripper-chrome-override';
const UI_SCALE_KEY = 'boardripper-ui-scale';
const CUSTOM_THEME_KEY = 'boardripper-custom-theme';
const DEFAULT_ID = 'default';
/** Reserved id for the single user-editable theme (the custom theme editor).
 *  Unlike the built-in THEMES entries it is persisted as user data, not a
 *  constant, and is the only theme whose colours can be edited in the UI. */
export const CUSTOM_ID = 'custom';

/** Interface scaling factor — multiplies the visual size of all chrome
 *  (toolbars, panels, dialogs, sidebar, start page). The BoardViewer and
 *  PDF canvases are counter-zoomed via CSS so their rendered pixel
 *  resolution is unaffected. */
export const UI_SCALE_MIN = 0.50;
export const UI_SCALE_MAX = 1.50;
export const UI_SCALE_STEP = 0.05;
export const UI_SCALE_DEFAULT = 1.00;

function clampScale(n: number): number {
  if (!Number.isFinite(n)) return UI_SCALE_DEFAULT;
  const clamped = Math.max(UI_SCALE_MIN, Math.min(UI_SCALE_MAX, n));
  return Math.round(clamped / UI_SCALE_STEP) * UI_SCALE_STEP;
}

function loadScale(): number {
  try {
    // 2R Tools: letra um pouco maior por padrão (Roger, 10/10/2026: «difícil de ler»).
    // Aplicado uma vez; depois vale o que o técnico escolher na escala da interface.
    if ((window as unknown as { __2rAcervo?: unknown }).__2rAcervo && localStorage.getItem('2r-ui-scale-set') !== '1') {
      localStorage.setItem('2r-ui-scale-set', '1');
      localStorage.setItem(UI_SCALE_KEY, '1.15');
      return 1.15;
    }
    const raw = localStorage.getItem(UI_SCALE_KEY);
    if (!raw) return UI_SCALE_DEFAULT;
    const n = parseFloat(raw);
    if (!Number.isFinite(n)) return UI_SCALE_DEFAULT;
    return clampScale(n);
  } catch {
    return UI_SCALE_DEFAULT;
  }
}

function saveScale(n: number | null) {
  try {
    if (n == null || n === UI_SCALE_DEFAULT) localStorage.removeItem(UI_SCALE_KEY);
    else localStorage.setItem(UI_SCALE_KEY, String(n));
  } catch { /* quota — ignore */ }
}

/** Apply --ui-scale CSS var. Read by the body { zoom: var(--ui-scale) }
 *  rule in index.css; canvas containers counter-zoom via the same var. */
export function applyUiScaleToDOM(scale: number) {
  document.documentElement.style.setProperty('--ui-scale', String(scale));
}

/**
 * Architecture note — themes vs interface knobs.
 *
 * The `THEMES` registry was originally a kitchen-sink theme: UI chrome
 * + board canvas + render-settings overrides bundled per id. The user
 * has clarified that **themes should be for boards**, not the interface.
 * Going forward:
 *
 *   - Theme  — board-side concerns: canvas background, board fill,
 *              outline / selection / butterfly / labelText, plus any
 *              `boardOverrides` (settings overlays like Landrex super-
 *              monochrome). Selectable via setTheme().
 *   - Knobs  — interface-side: 3 simple colours the user picks freely.
 *              `accent` (signal indicators), `background` (canvas + the
 *              interactive surface tier), `chrome` (toolbar / status /
 *              tab strips). Each cascades into the related CSS vars.
 *
 * Right now `theme.ui.*` still ships per theme as a *fallback default*
 * for the knobs — when no override is set, the active theme's UI tokens
 * paint chrome. The end-state is to retire `theme.ui.*` and have a
 * single neutral baseline; the override knobs become the only path to
 * change interface chrome. Tracked separately from this registry edit.
 */

/**
 * Curated accent presets used by both the SettingsPanel and the home
 * dashboard picker. Adding a preset = one append; both surfaces pick it up.
 *
 * Deep-research notes on the Atari palette
 * (after a request to verify rather than guess):
 *
 *   - The classical Atari Fuji logo (designed by George Opperman, first
 *     used 1972–73) was MONOCHROME — black on white — for ~30 years.
 *     There is no "classical Atari red".
 *   - The official red was introduced in 2002 in a corporate refresh.
 *     Documented spec: Pantone Bright Red C, #E5141E, RGB 229/20/30,
 *     CMYK 0/91/87/10. (Some secondary sources cite #E01E2B as a slightly
 *     different web rendering of the same Pantone.)
 *   - The "Atari rainbow" — five vertical stripes of green / yellow /
 *     orange / red / blue — lives on the 1983 Atari 2600 silver-label
 *     cartridges and the "long/short rainbow" 2600 console variants. This
 *     is packaging / industrial-design art, NOT the Fuji logo itself, but
 *     is widely associated with the brand and is a useful era-evocative
 *     palette for an interface accent.
 *   - The arcade marquee gradient (red→orange→gold inside the Fuji on
 *     Asteroids / Centipede / Tempest cabinets) was a separate marketing
 *     treatment — dropped here because the rainbow stripe is the
 *     better-documented Atari heritage palette.
 *
 * Sources: fabrikbrands.com (explicit hex/Pantone for Fuji red),
 * 1000logos.net, logodesignlove.com, AtariAge forums (rainbow cartridge
 * variants), Wikipedia (Atari, Inc. + Atari 2600 articles).
 */
export const ACCENT_PRESETS: ReadonlyArray<{ hex: string; label: string }> = [
  { hex: '#4a9eff', label: 'BoardRipper default' },
  // Pantone Bright Red C — the canonical post-2002 Atari Fuji red.
  { hex: '#e5141e', label: 'ATARI Red (Pantone Bright Red C)' },
  // Atari 2600 silver-label rainbow stripe (1983) — five-bar packaging
  // palette also used on "long/short rainbow" 2600 consoles. Sampled from
  // the cartridge label artwork; values are commonly-cited reproductions.
  { hex: '#4faf4a', label: 'Atari rainbow — green' },
  { hex: '#f4e325', label: 'Atari rainbow — yellow' },
  { hex: '#fe8b1f', label: 'Atari rainbow — orange' },
  { hex: '#ed3823', label: 'Atari rainbow — red' },
  { hex: '#2a3192', label: 'Atari rainbow — blue' },
  // Non-Atari, non-cliché alternates.
  { hex: '#ff3aa1', label: 'Hot magenta' },
  { hex: '#b8ff2b', label: 'Acid lime' },
  { hex: '#9c6bff', label: 'Deep violet' },
  { hex: '#00c7b7', label: 'Teal' },
];

interface PersistedTheme {
  activeId: string;
}

/** Schemes retired in the 2026-10-11 review; an install that had one picked
 *  moves to its replacement instead of falling back to Default. */
const RETIRED_THEMES: Record<string, string> = { 'drafting-paper': 'light', daylight: 'light', 'blueprint-light': 'light' };

function loadFromStorage(): string {
  // 2R Tools: dentro do app 2R o tema neutro é o padrão (aplicado uma vez;
  // depois vale o que o técnico escolher em Ajustes) — 10/10/2026
  try {
    // 2R (23:17): o BoardRipper segue o tema do SDS — app claro (Aço, Dourado, Claro…) usa a
    // variante clara escolhida; app escuro, a escura. Cada lado lembra a última escolha.
    const w2 = window as unknown as { __2rAcervo?: unknown; __2rTheme?: string };
    // último tema escolhido pelo técnico vale sempre (Roger, 11/10/2026)
    if (w2.__2rAcervo) {
      const last = localStorage.getItem('2r-theme-last');
      if (last && (THEMES[last] || last === CUSTOM_ID)) {
        localStorage.setItem('2r-clean-theme-v2', '1'); localStorage.setItem('2r-clean-theme', '1');
        localStorage.setItem(STORAGE_KEY, JSON.stringify({ activeId: last } as PersistedTheme));
        return last;
      }
    }
    if (w2.__2rAcervo && w2.__2rTheme) {
      const light = w2.__2rTheme !== 'dark';
      const def = light ? (w2.__2rTheme === 'gold' || w2.__2rTheme === 'light' ? '2r-claro-areia' : '2r-claro-gelo') : '2r-ambar'; // 2R 20/10/2026: Âmbar é o escuro padrão
      const pick = localStorage.getItem(light ? '2r-theme-light' : '2r-theme-dark') || def;
      if (THEMES[pick]) {
        localStorage.setItem('2r-clean-theme-v2', '1'); localStorage.setItem('2r-clean-theme', '1');
        localStorage.setItem(STORAGE_KEY, JSON.stringify({ activeId: pick } as PersistedTheme));
        return pick;
      }
    }
    // v2 (22:58, Roger: «remover essas cores azuis, gostei do padrão que estava antes»):
    // a v1 aplicava o tema neutro só numa abertura e não gravava — na seguinte voltava o azul.
    if ((window as unknown as { __2rAcervo?: unknown }).__2rAcervo && localStorage.getItem('2r-clean-theme-v2') !== '1') {
      localStorage.setItem('2r-clean-theme-v2', '1');
      localStorage.setItem('2r-clean-theme', '1');
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ activeId: '2r-ambar' } as PersistedTheme));
      return '2r-ambar';
    }
  } catch { /* sem armazenamento */ }
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_ID;
    const parsed = JSON.parse(raw) as PersistedTheme;
    if (parsed?.activeId && RETIRED_THEMES[parsed.activeId]) return RETIRED_THEMES[parsed.activeId];
    // CUSTOM_ID is valid even though it isn't in THEMES — activeTheme() falls
    // back to default if the custom theme blob is missing.
    if (parsed?.activeId && (THEMES[parsed.activeId] || parsed.activeId === CUSTOM_ID)) return parsed.activeId;
    log.ui.warn(`themes: unknown activeId in localStorage: ${parsed?.activeId} — falling back to '${DEFAULT_ID}'`);
    return DEFAULT_ID;
  } catch {
    return DEFAULT_ID;
  }
}

function saveToStorage(activeId: string) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ activeId } as PersistedTheme));
  } catch { /* quota — ignore */ }
}

const HEX_RE = /^#[0-9a-fA-F]{6}$/;

function loadHexOverride(key: string): string | null {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return null;
    return HEX_RE.test(raw) ? raw : null;
  } catch {
    return null;
  }
}

function saveHexOverride(key: string, hex: string | null) {
  try {
    if (hex == null) localStorage.removeItem(key);
    else localStorage.setItem(key, hex);
  } catch { /* quota — ignore */ }
}

/** A clone of `src` re-stamped as the editable custom theme. Used to seed the
 *  custom theme from whatever theme is active when the user first edits it, so
 *  they start from a familiar palette rather than a blank slate. */
function seedCustomFrom(src: Theme): Theme {
  return {
    id: CUSTOM_ID,
    label: 'Custom',
    ui: { ...src.ui },
    board: { ...src.board },
    // boardOverrides start empty: the custom theme only overrides global
    // render-settings (pin / net colours) once the user explicitly opts in.
    boardOverrides: src.boardOverrides ? structuredClone(src.boardOverrides) : undefined,
    palette: src.palette ? structuredClone(src.palette) : undefined,
  };
}

function loadCustomTheme(): Theme | null {
  try {
    const raw = localStorage.getItem(CUSTOM_THEME_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Theme;
    // Minimal shape validation — a corrupt blob shouldn't brick the app.
    if (!parsed?.ui?.bgPrimary || !parsed?.board?.canvasBackground) return null;
    parsed.id = CUSTOM_ID;
    if (!parsed.label) parsed.label = 'Custom';
    return parsed;
  } catch {
    return null;
  }
}

function saveCustomTheme(theme: Theme | null) {
  try {
    if (theme == null) localStorage.removeItem(CUSTOM_THEME_KEY);
    else localStorage.setItem(CUSTOM_THEME_KEY, JSON.stringify(theme));
  } catch { /* quota — ignore */ }
}

interface UiOverrides {
  accent: string | null;
  background: string | null;
  chrome: string | null;
}

/** Apply a theme's UI + canvas colors to CSS custom properties on <html>.
 *  Each override replaces the corresponding theme token and cascades into
 *  related siblings (siblings shade *away* from the base's luminance pole —
 *  lighten on dark, darken on light — via shadeToward):
 *    - background  → --bg-primary; --bg-secondary derived; text auto-flips
 *    - chrome      → --bg-tertiary; --border derived
 *    - accent      → --accent; --accent-fg auto-flips; --accent-hover in CSS
 */
export function isLightHex(h: string): boolean {
  const m = /^#?([0-9a-f]{6})$/i.exec(h || ''); if (!m) return false;
  const n = parseInt(m[1], 16); const r = n >> 16, g = (n >> 8) & 255, b = n & 255;
  return (0.299 * r + 0.587 * g + 0.114 * b) > 150;
}

export function applyThemeToDOM(theme: Theme, overrides: Partial<UiOverrides> = {}) {
  const root = document.documentElement;
  // 2R Tools: painéis 2R (sequência, medições, curvas…) trocam de cor junto (index.css html.r2-light)
  root.classList.toggle('r2-light', isLightHex(theme.ui.bgPrimary));
  const { accent, background, chrome } = overrides;

  // Tier siblings are derived with shadeToward (not plain lightenHex) so a
  // light background/chrome produces a darker — therefore visible — sibling
  // instead of running into white. The non-override path now also derives
  // the sibling rather than trusting theme.ui.bg{Secondary,border}; this lets
  // a theme declare just bgPrimary/bgTertiary and get a correct tier for free,
  // and keeps knob and theme paths consistent.
  const effBg = background ?? theme.ui.bgPrimary;
  root.style.setProperty('--bg-primary',   effBg);
  root.style.setProperty('--bg-secondary', background ? shadeToward(effBg, 0.06) : theme.ui.bgSecondary);

  const effChrome = chrome ?? theme.ui.bgTertiary;
  root.style.setProperty('--bg-tertiary', effChrome);
  root.style.setProperty('--border',      chrome ? shadeToward(effChrome, 0.12) : theme.ui.border);

  // Body text is derived from the effective background's luminance so it
  // stays readable when the background knob (or a light theme) flips the base
  // from dark to light. Dark backgrounds reproduce the historical pair, so
  // existing dark themes are unchanged.
  const text = pickTextColors(effBg);
  root.style.setProperty('--text-primary',   text.primary);
  root.style.setProperty('--text-secondary', text.secondary);
  const effAccent = accent ?? theme.ui.accent;
  root.style.setProperty('--accent', effAccent);
  // --accent-fg = the text colour that reads on top of an accent-tinted
  // surface. Auto-flipped to dark when the accent is bright enough that
  // white text would blend in (yellow / gold / lime / pale teal). Replaces
  // the previously hardcoded `color: #fff` paired with accent backgrounds.
  root.style.setProperty('--accent-fg', pickAccentFg(effAccent));
  // --accent-text = the accent shaded (only when needed) to stay legible as
  // *text* on the effective background. Bright accents (Atari yellow, acid
  // lime) plus a light theme would otherwise render near-invisible accent
  // text; foreground `color:` sites in index.css read --accent-text, while
  // accent-as-background / border / glow sites keep the pure --accent hue.
  root.style.setProperty('--accent-text', accentTextColor(effAccent, effBg));
  // --accent-hover is derived from --accent in index.css via color-mix.
  root.style.setProperty('--canvas-bg',      theme.board.canvasBackground);
  root.style.setProperty('--icon-board-bg',  theme.ui.iconBoardBg);
  root.style.setProperty('--icon-pdf-bg',    theme.ui.iconPdfBg);

  // Board-side colours mirrored as CSS vars. The PixiJS scene reads these
  // through BOARD_COLORS (JS), not CSS — but exposing them on :root gives the
  // visibility test harness a single DOM source of truth for every theme
  // colour, and is the hook the upcoming custom-theme editor reads/writes.
  root.style.setProperty('--board-fill',         theme.board.boardFill);
  root.style.setProperty('--board-outline',      theme.board.outline);
  root.style.setProperty('--board-selection',    theme.board.selection);
  root.style.setProperty('--board-butterfly',    theme.board.butterflySelection);
  root.style.setProperty('--board-label-text',   theme.board.labelText);
  root.style.setProperty('--board-label-part',   theme.board.labelPart);
  root.style.setProperty('--board-label-net',    theme.board.labelNet);
}

class ThemeStore extends Emitter {
  private _activeId: string = DEFAULT_ID;
  private _accentOverride: string | null = null;
  private _backgroundOverride: string | null = null;
  private _chromeOverride: string | null = null;
  private _scale: number = UI_SCALE_DEFAULT;
  private _customTheme: Theme | null = null;
  private _initialized = false;
  private _switch: { seq: number; prev: Theme } = { seq: 0, prev: THEMES[DEFAULT_ID] };

  /** The last explicit scheme switch: a counter and the scheme left behind.
   *  Knob changes (accent, background, chrome) notify too but never move it. */
  get lastSwitch(): { seq: number; prev: Theme } { return this._switch; }

  /** Call once at app startup. Idempotent — second call no-ops. */
  init(): void {
    if (this._initialized) return;
    this._customTheme = loadCustomTheme();
    this._activeId = loadFromStorage();
    this._accentOverride = loadHexOverride(ACCENT_OVERRIDE_KEY);
    this._backgroundOverride = loadHexOverride(BACKGROUND_OVERRIDE_KEY);
    this._chromeOverride = loadHexOverride(CHROME_OVERRIDE_KEY);
    this._scale = loadScale();
    this.applyAll();
    applyUiScaleToDOM(this._scale);
    this._initialized = true;
    // init() does not notify, so the subscriber below never sees the stored
    // scheme: re-merge here, or a palette scheme's colours wait for the first
    // board to activate (the Theme-tab editors read Default's meanwhile).
    renderSettingsStore.refreshEffective();
  }

  get activeId(): string {
    return this._activeId;
  }

  /** User's accent override, or null if the theme's default is in use. */
  get accentOverride(): string | null {
    return this._accentOverride;
  }
  /** User's background (canvas + surface tier) override, or null. */
  get backgroundOverride(): string | null {
    return this._backgroundOverride;
  }
  /** User's chrome (toolbar / status / tabs / border tier) override, or null. */
  get chromeOverride(): string | null {
    return this._chromeOverride;
  }

  /** The accent currently driving --accent (override if set, else theme default). */
  get effectiveAccent(): string {
    return this._accentOverride ?? this.activeTheme().ui.accent;
  }
  /** Effective canvas background — drives --bg-primary. */
  get effectiveBackground(): string {
    return this._backgroundOverride ?? this.activeTheme().ui.bgPrimary;
  }
  /** Effective chrome colour — drives --bg-tertiary. */
  get effectiveChrome(): string {
    return this._chromeOverride ?? this.activeTheme().ui.bgTertiary;
  }

  /** Current interface scaling factor (1.0 = 100%). */
  get scale(): number {
    return this._scale;
  }

  activeTheme(): Theme {
    if (this._activeId === CUSTOM_ID && this._customTheme) return this._customTheme;
    return THEMES[this._activeId] ?? THEMES[DEFAULT_ID];
  }

  /** The editable custom theme, or null if the user hasn't created one yet. */
  get customTheme(): Theme | null {
    return this._customTheme;
  }
  /** True when the custom theme is the active one. */
  get isCustomActive(): boolean {
    return this._activeId === CUSTOM_ID && this._customTheme != null;
  }

  private applyAll(): void {
    applyThemeToDOM(this.activeTheme(), {
      accent: this._accentOverride,
      background: this._backgroundOverride,
      chrome: this._chromeOverride,
    });
  }

  setTheme(id: string): void {
    // 2R: lembra a escolha separada para quando o SDS está escuro ou claro
    try {
      if ((window as unknown as { __2rAcervo?: unknown }).__2rAcervo && (THEMES[id] || id === CUSTOM_ID)) {
        if (THEMES[id]) localStorage.setItem(isLightHex(THEMES[id].ui.bgPrimary) ? '2r-theme-light' : '2r-theme-dark', id);
        // Roger (11/10/2026): «quando abrir um tema, manter ele como padrão… lembrar sempre do último»
        localStorage.setItem('2r-theme-last', id);
      }
    } catch { /* */ }
    if (id === CUSTOM_ID) {
      // Selecting Custom seeds it from the current theme on first use so the
      // user starts from a familiar palette rather than an empty one.
      this.ensureCustom();
    } else if (!THEMES[id]) {
      log.ui.warn(`themes: setTheme called with unknown id '${id}' — ignored`);
      return;
    }
    if (id === this._activeId) return;
    this._switch = { seq: this._switch.seq + 1, prev: this.activeTheme() };
    this._activeId = id;
    saveToStorage(id);
    this.applyAll();
    this.notify();
  }

  /** Create the custom theme (seeded from the currently-active theme) if it
   *  doesn't exist yet. Returns the custom theme. Does not switch to it. */
  ensureCustom(): Theme {
    if (!this._customTheme) {
      this._customTheme = seedCustomFrom(this.activeTheme());
      saveCustomTheme(this._customTheme);
    }
    return this._customTheme;
  }

  /**
   * Patch the custom theme's colours. Accepts partial `ui` / `board` colour
   * maps and a `boardOverrides` patch (pin / net colours that override the
   * GLOBAL render settings while the custom theme is active — the same
   * mechanism Landrex uses). Creates the custom theme first if needed.
   * Re-applies + notifies immediately if the custom theme is active.
   */
  updateCustom(patch: {
    ui?: Partial<Theme['ui']>;
    board?: Partial<Theme['board']>;
    boardOverrides?: Partial<RenderSettings> | null;
  }): void {
    const base = this.ensureCustom();
    const next: Theme = {
      ...base,
      ui: { ...base.ui, ...(patch.ui ?? {}) },
      board: { ...base.board, ...(patch.board ?? {}) },
    };
    if (patch.boardOverrides !== undefined) {
      // null clears overrides entirely; an object merges into existing ones.
      next.boardOverrides = patch.boardOverrides == null
        ? undefined
        : { ...(base.boardOverrides ?? {}), ...patch.boardOverrides };
    }
    this._customTheme = next;
    saveCustomTheme(next);
    if (this._activeId === CUSTOM_ID) this.applyAll();
    // Always notify: the editor UI re-renders even when previewing while the
    // custom theme isn't the active one. The boardOverrides re-merge is gated
    // by the subscriber at the bottom of this module.
    this.notify();
  }

  /**
   * Set or clear a single board-override key on the custom theme (the "pin
   * colours act as overrides over the global render settings" model). Passing
   * null removes the key so that field falls back to the global setting; the
   * `boardOverrides` object is dropped entirely once it's empty.
   */
  setCustomOverride<K extends keyof RenderSettings>(key: K, value: RenderSettings[K] | null): void {
    const base = this.ensureCustom();
    const ov: Partial<RenderSettings> = { ...(base.boardOverrides ?? {}) };
    if (value == null) delete ov[key];
    else ov[key] = value;
    const next: Theme = { ...base, boardOverrides: Object.keys(ov).length ? ov : undefined };
    this._customTheme = next;
    saveCustomTheme(next);
    if (this._activeId === CUSTOM_ID) this.applyAll();
    this.notify();
  }

  /**
   * Overwrite the custom slot with a clone of the currently-active theme and
   * switch to it. The copy-to-custom-on-edit entry point: lets the colour
   * editors fork whatever built-in theme is active (preserving its palette)
   * into the single editable slot, rather than seeding from default.
   */
  forkToCustom(): void {
    this._customTheme = seedCustomFrom(this.activeTheme());
    saveCustomTheme(this._customTheme);
    if (this._activeId !== CUSTOM_ID) {
      this._activeId = CUSTOM_ID;
      saveToStorage(CUSTOM_ID);
    }
    this.applyAll();
    this.notify();
  }

  /** Delete the custom theme and, if it was active, fall back to default. */
  resetCustom(): void {
    const prev = this.activeTheme();
    this._customTheme = null;
    saveCustomTheme(null);
    if (this._activeId === CUSTOM_ID) {
      // A scheme switch like setTheme's: board-store's applyThemeChange reads it.
      this._switch = { seq: this._switch.seq + 1, prev };
      this._activeId = DEFAULT_ID;
      saveToStorage(DEFAULT_ID);
      this.applyAll();
    }
    this.notify();
  }

  /** Override the active theme's accent. Pass null to revert to the theme's
   *  built-in accent. Persisted independently of the active theme. */
  setAccent(hex: string | null): void {
    if (hex != null && !HEX_RE.test(hex)) {
      log.ui.warn(`themes: setAccent called with invalid hex '${hex}' — ignored`);
      return;
    }
    if (hex === this._accentOverride) return;
    this._accentOverride = hex;
    saveHexOverride(ACCENT_OVERRIDE_KEY, hex);
    this.applyAll();
    this.notify();
  }

  /** Override the canvas + surface background. Drives --bg-primary directly
   *  and --bg-secondary as a lightened sibling. Pass null to revert. */
  setBackground(hex: string | null): void {
    if (hex != null && !HEX_RE.test(hex)) {
      log.ui.warn(`themes: setBackground called with invalid hex '${hex}' — ignored`);
      return;
    }
    if (hex === this._backgroundOverride) return;
    this._backgroundOverride = hex;
    saveHexOverride(BACKGROUND_OVERRIDE_KEY, hex);
    this.applyAll();
    this.notify();
  }

  /** Override the chrome / passive-element tier. Drives --bg-tertiary
   *  directly and --border as a lifted sibling. Pass null to revert. */
  setChrome(hex: string | null): void {
    if (hex != null && !HEX_RE.test(hex)) {
      log.ui.warn(`themes: setChrome called with invalid hex '${hex}' — ignored`);
      return;
    }
    if (hex === this._chromeOverride) return;
    this._chromeOverride = hex;
    saveHexOverride(CHROME_OVERRIDE_KEY, hex);
    this.applyAll();
    this.notify();
  }

  /** Set the global interface scaling factor. Pass null to reset to 100%.
   *  Out-of-range values are clamped to [UI_SCALE_MIN, UI_SCALE_MAX] and
   *  snapped to UI_SCALE_STEP. The slider commits this on pointer-up only;
   *  there's no ephemeral path because mid-drag rescaling resizes the
   *  slider control itself, breaking the drag. */
  setScale(n: number | null): void {
    const next = n == null ? UI_SCALE_DEFAULT : clampScale(n);
    if (next === this._scale) {
      saveScale(n == null ? null : next);
      return;
    }
    this._scale = next;
    applyUiScaleToDOM(next);
    saveScale(n == null ? null : next);
    this.notify();
  }

  /** All available themes, sorted by label for UI display. The custom theme
   *  (when it exists) is appended last so it sits below the built-ins. */
  list(): Theme[] {
    const builtins = Object.values(THEMES).sort((a, b) => a.label.localeCompare(b.label));
    return this._customTheme ? [...builtins, this._customTheme] : builtins;
  }
}

export const themeStore = new ThemeStore();

// Wire theme overrides into render-settings. The provider is read by
// renderSettingsStore whenever it re-merges; `base` is global⊕active board
// overrides, so a palette keeps the board's own keywords and prefixes.
setThemeOverridesProvider((base) => {
  const t = themeStore.activeTheme();
  if (!t.palette) return t.boardOverrides;
  // A palette theme's colours, then the custom theme's own edits on top.
  return { ...paletteOverrides(t.palette, base), ...(t.boardOverrides ?? {}) };
});
renderSettingsStore.refreshEffective();

// On theme change, force render-settings to re-merge so the new theme's
// overlay takes effect (or a left scheme's overlay goes).
//
// themeStore.notify() fires on EVERY interface knob change too — accent /
// background / chrome picks, which carry no board colours. refreshEffective
// compares the merged result and notifies only when it changed, so those cost
// one merge and no scene rebuild. There used to be a gate here on "had / has
// an overlay", but its baseline was taken at module load, before init() read
// the stored scheme, so leaving a palette scheme stored from the last session
// was never re-merged.
themeStore.subscribe(() => {
  renderSettingsStore.refreshEffective();
});
