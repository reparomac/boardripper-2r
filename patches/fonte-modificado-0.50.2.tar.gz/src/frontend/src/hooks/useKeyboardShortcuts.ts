import { useEffect } from 'react';
import { shortcuts, matchesShortcut, getShortcut } from '../store/keyboard-shortcuts';
import { boardStore } from '../store/board-store';
import { pdfStore } from '../store/pdf-store';
import { viewCommands } from '../store/view-commands';
import { fileInputRefs } from '../store/file-inputs';
import { ensurePdfPanel, getDockviewApi } from '../store/dockview-api';
import { openBoardSearch } from '../panels/board-viewer-bridge';
import { focusBoardSearchInput } from '../components/BoardSidebar.utils';
import { toggleLibrarySidebar } from '../components/Sidebar.utils';
import { copyText } from '../clipboard';
import { peekHintStore } from '../store/peek-hint-store';
import { historyBack, historyForward } from '../store/nav-history-actions';
import { focusRibbonFind } from '../components/overlay/ribbon-find';
import { log } from '../store/log-store';
import { stepPin } from '../r2/probe-seq';

/**
 * Global keyboard shortcut handler — attach once in App.
 * Uses shared fileInputRefs set by Toolbar.
 */
function activePanelKind(): 'board' | 'pdf' | null {
  const id = getDockviewApi()?.activePanel?.id ?? '';
  if (id.startsWith('board-')) return 'board';
  if (id.startsWith('pdf-')) return 'pdf';
  return null;
}

// Track last known cursor position for context-sensitive shortcuts
/* 2R 24/10/2026 (Roger: «os atalhos do BDV e PDF agem onde estiver o foco» — deck Ulanzi): expõe o foco (board|pdf) */
{
  const w = window as unknown as Record<string, unknown>;
  w.__r2Td = activePanelKind;
  w.__r2Me = pdfStore;
  w.__r2ed = viewCommands;
}
let _lastMouseX = 0;
let _lastMouseY = 0;

/**
 * Hold-to-peek state for Space-flip:
 *   - keydown records the original side + a timestamp, flips immediately,
 *     and arms a timer that triggers the peek-hint chip after the threshold.
 *   - keyup checks the duration: under SPACE_HOLD_PEEK_MS = tap (keep
 *     flipped, no hint); at or over = hold (revert to original + dismiss
 *     hint).
 *
 * 500 ms: a slow, controlled tap runs 200–300 ms, and 350 still caught some
 * (2026-10-05, "peek interval should be a bit longer"); a deliberate hold is
 * past it anyway.
 *
 * The press is timed with the EVENTS' own timestamps, never with the clock
 * when the handlers run. The first flip after a board renders does heavy
 * synchronous work, so the keyup sits in the queue behind it; timed at
 * handler time, a quick tap measured as a long hold and peeked back.
 */
const SPACE_HOLD_PEEK_MS = 500;
/** How long the hint chip stays visible after it first appears. Auto-hides
 *  even if the user keeps holding Space, so a long peek doesn't leave a
 *  permanent label cluttering the canvas. */
const PEEK_HINT_LIFESPAN_MS = 3000;
interface SpaceFlipPress {
  wasUiTopVisible: boolean;
  pressedAt: number;
  hintTimer: ReturnType<typeof setTimeout> | null;
  hintHideTimer: ReturnType<typeof setTimeout> | null;
}
let _spaceFlipPress: SpaceFlipPress | null = null;

/** Text to copy for the active board tab's current selection, mirroring the
 *  Cmd/Ctrl+F prefill priority: a selected pin yields its net (or, when the
 *  pin carries no net, a `part-pin` reference); a part-only selection yields
 *  the component name; a net-only selection yields the net name. Returns null
 *  when nothing is selected. */
function copySelectionText(): string | null {
  const sel = boardStore.selection;
  const part = boardStore.selectedPart;
  const pin = boardStore.selectedPin;
  if (sel.pinIndex != null && sel.pinIndex >= 0 && pin) {
    if (pin.net) return pin.net;
    const label = pin.number || pin.name;
    if (part && label) return `${part.name}-${label}`;
    return label || part?.name || null;
  }
  if (part) return part.name;
  if (sel.highlightedNet) return sel.highlightedNet;
  return null;
}

/** The find-field prefill for a board tab's selection: a selected pin stands
 *  for its net, otherwise the part's name, otherwise the lit net. Null when
 *  nothing is selected. */
function boardSelectionText(tab: typeof boardStore.activeTab): string | null {
  const sel = tab?.selection;
  if (!sel || !tab?.board) return null;
  if (sel.pinIndex != null && sel.pinIndex >= 0 && sel.highlightedNet) return sel.highlightedNet;
  if (sel.partIndex != null) return tab.board.parts[sel.partIndex]?.name ?? null;
  return sel.highlightedNet ?? null;
}

/** The find field of the panel showing `fileName` — every PDF find field
 *  carries `data-pdf-file`, so this needs no registration to have happened. */
function pdfSearchInputFor(fileName: string): HTMLInputElement | null {
  for (const el of document.querySelectorAll<HTMLInputElement>('.pdf-search-input')) {
    if (el.dataset.pdfFile === fileName) return el;
  }
  return null;
}

export function useKeyboardShortcuts() {
  useEffect(() => {
    const trackMouse = (e: MouseEvent) => { _lastMouseX = e.clientX; _lastMouseY = e.clientY; };
    document.addEventListener('mousemove', trackMouse, { passive: true });

    const handler = (e: KeyboardEvent) => {
      // Cmd/Ctrl+F — routing:
      //   1. A PDF find field is focused with text → step to the next match.
      //   2. A board panel is active → its sidebar search, prefilled with the
      //      selection (pin → net, part → name, net → name).
      //   3. A PDF panel is active → its find field: a word clicked since the
      //      last ⌘F becomes the query; an existing query is only focused.
      //   4. Otherwise → the active board's linked PDF with the selection,
      //      then the registered PDF field, then the top-bar global search.
      const focusSearch = getShortcut('focusSearch');
      // Match focusSearch with OR without shift — the block below routes
      // shift to prevMatch and unshifted to nextMatch. The matcher's
      // symmetric shift-guard otherwise rejects Shift+Cmd+F outright.
      const focusSearchMatch = focusSearch && (
        matchesShortcut(e, focusSearch) ||
        matchesShortcut(e, { ...focusSearch, shift: true }) ||
        // 2R 24/10/2026 (Roger: «Control+F = busca, tanto no PDF quanto no BDV»): no Mac o Control+F também vale
        (e.ctrlKey && !e.metaKey && !e.altKey && (e.key === 'f' || e.key === 'F'))
      );
      if (focusSearch && focusSearchMatch) {
        // Standard behavior: if the PDF search field is already focused with a
        // query, repeat Cmd+F steps to the next match (Shift reverses direction).
        // Any focused PDF find field counts, not only the one registered in
        // fileInputRefs (that ref follows Dockview's *active* panel, which a
        // focused field in another panel need not be) — otherwise ⌘F fell
        // through to the fresh-search path and reset the view.
        const focused = document.activeElement as HTMLInputElement | null;
        if (focused?.classList?.contains('pdf-search-input') && focused.value.trim()) {
          e.preventDefault();
          const file = focused.dataset.pdfFile;
          if (file) pdfStore.switchTo(file);
          if (e.shiftKey) pdfStore.prevMatch();
          else pdfStore.nextMatch();
          return;
        }

        const tab = boardStore.activeTab;
        const linkedPdf = tab?.pdfFileNames?.[0];
        // Priority: pin-selected (→ net name) > part-only (→ component name) > net-only
        const selectionText = boardSelectionText(tab);

        const api = getDockviewApi();
        const activePanelId = api?.activePanel?.id ?? '';

        // Board panel: ⌘F is the ribbon's find field — Find net for a lit
        // net or a selected pin, Find part otherwise — prefilled with the
        // selection; the sidebar search follows the ribbon. A ribbon without
        // that slot falls back to the sidebar search. It used to hand a
        // selection to the linked PDF instead, so finding the selected part
        // on the *board* took a detour through the schematic (2026-10-20).
        if (activePanelId.startsWith('board-')) {
          e.preventDefault();
          const boardTabId = parseInt(activePanelId.slice('board-'.length), 10);
          const sel = tab?.selection;
          const kind = sel?.highlightedNet && (sel.partIndex == null || (sel.pinIndex != null && sel.pinIndex >= 0))
            ? 'nets' : 'parts';
          const text = selectionText ?? '';
          if (!isNaN(boardTabId) && focusRibbonFind(boardTabId, kind, text)) {
            log.ui.log(`find: board ribbon ${kind} field`, { text });
            return;
          }
          log.ui.log('find: board sidebar search (no ribbon field)', { text });
          openBoardSearch(text, isNaN(boardTabId) ? undefined : boardTabId);
          focusBoardSearchInput();
          return;
        }

        const activePdfFile: string | null = activePanelId.startsWith('pdf-')
          ? (api?.activePanel?.params as { pdfFileName?: string } | undefined)?.pdfFileName ?? null
          : null;

        let prefillText: string | null = selectionText;
        if (activePdfFile) {
          // A word clicked since the last ⌘F is a new request and replaces
          // the query. Anything else leaves the field alone: the user panned
          // to another page and pressed ⌘F again to get back to the find
          // field, not to have its text replaced with a stale word — or with
          // the board's selection — and not to have the view jump to another
          // occurrence by re-running the same search.
          const clicked = pdfStore.takeClickedWordForFind();
          const current = pdfStore.getDocSearchQuery(activePdfFile).trim();
          if (clicked && clicked.trim().toLowerCase() !== current.toLowerCase()) {
            prefillText = clicked;
            log.ui.log('find: pdf field takes the clicked word', { file: activePdfFile, text: clicked, was: current });
          } else if (current) {
            prefillText = null;
            log.ui.log('find: pdf field kept', { file: activePdfFile, text: current, clicked });
          } else {
            log.ui.log('find: pdf field prefilled from the board selection', { file: activePdfFile, text: prefillText });
          }
        }

        // Route target PDF: if a PDF panel is the active dockview panel, use
        // THAT panel's PDF — even if the board tab has a different linked PDF.
        // Cmd+F must always focus the search field of the tab the user is in.
        const targetPdf = activePdfFile ?? linkedPdf ?? null;

        if (targetPdf) {
          e.preventDefault();
          ensurePdfPanel(targetPdf);
          pdfStore.switchTo(targetPdf);
          if (prefillText) {
            pdfStore.searchText(prefillText, 'lookup');
          }
          // Wait a tick for the PDF panel's onDidActiveChange effect to register
          // searchInputRef.current into fileInputRefs.pdfSearch. The field also
          // carries its file name, which is the surer way to the right one.
          setTimeout(() => {
            const input = pdfSearchInputFor(targetPdf) ?? fileInputRefs.pdfSearch;
            if (!input) return;
            if (prefillText) input.value = prefillText;
            input.focus();
            input.select();
          }, 0);
          return;
        }

        if (fileInputRefs.pdfSearch) {
          e.preventDefault();
          fileInputRefs.pdfSearch.focus();
          fileInputRefs.pdfSearch.select();
          return;
        }
        if (fileInputRefs.search) {
          e.preventDefault();
          fileInputRefs.search.focus();
          fileInputRefs.search.select();
          return;
        }
      }

      // ⌘[ / ⌘] — navigation history, Preview's Go ▸ Back / Forward. Handled
      // before the input bailout: neither key edits text and Preview's Back
      // works with the find field focused. preventDefault unconditionally —
      // ⌘[ is the browser's own Back in Chrome and Safari on macOS, and in the
      // hosted PWA that would leave the app even when there is nothing to go
      // back to.
      {
        const hb = getShortcut('historyBack');
        const hf = getShortcut('historyForward');
        if (hb && matchesShortcut(e, hb)) { e.preventDefault(); historyBack(); return; }
        if (hf && matchesShortcut(e, hf)) { e.preventDefault(); historyForward(); return; }
      }

      // Don't intercept when typing in inputs/textareas
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
      if ((e.target as HTMLElement)?.isContentEditable) return;

      // Tab — jump between active board panel and its linked PDF (both directions).
      if (e.key === 'Tab' && !e.ctrlKey && !e.metaKey && !e.altKey && !e.shiftKey) {
        const api = getDockviewApi();
        const activeId = api?.activePanel?.id ?? '';
        if (activeId.startsWith('board-')) {
          const linked = boardStore.activeTab?.pdfFileNames?.[0];
          if (linked) {
            e.preventDefault();
            ensurePdfPanel(linked);
            pdfStore.switchTo(linked);
          }
          return;
        }
        if (activeId.startsWith('pdf-')) {
          const activeTabId = boardStore.activeTabId;
          if (activeTabId != null) {
            const boardPanel = api?.getPanel('board-' + activeTabId);
            if (boardPanel) {
              e.preventDefault();
              boardPanel.api.setActive();
            }
          }
          return;
        }
      }

      // 2R 18/10/2026: Ctrl+←/→ gira a placa (no PDF também gira a placa — o PDF não gira)
      if (e.ctrlKey && !e.metaKey && !e.altKey && !e.shiftKey && (e.key === 'ArrowLeft' || e.key === 'ArrowRight')) {
        const x = activePanelKind();
        if (x === 'board' || x === 'pdf') {
          e.preventDefault();
          const w = e.key === 'ArrowLeft' ? 'cw' : 'ccw';
          if (x === 'pdf') pdfStore.rotateActive(w); else if (w === 'ccw') boardStore.rotateCCW(); else boardStore.rotateCW();
          return;
        }
      }
      // 2R 24/10/2026 (Roger: «a tecla N (next) serve para saltar para o próximo resultado localizado no PDF e no BDV;
      // em ponto a ponto salta para a próxima leitura»): N = próximo, Shift+N = anterior
      const r2k = window as unknown as { __r2TeclaN?: boolean; __r2NBusca?: string; __r2seq?: { on: boolean; next(): void; prev(): void } };
      if (!e.ctrlKey && !e.metaKey && !e.altKey && (e.key === 'n' || e.key === 'N') && r2k.__r2TeclaN !== false) {
        const vo = e.shiftKey;
        try {
          const sq = r2k.__r2seq;
          if (sq && sq.on && r2k.__r2NBusca !== 'pdf') { e.preventDefault(); if (vo) sq.prev(); else sq.next(); return; }
        } catch { /* */ }
        if (pdfStore.matches.length > 0) { e.preventDefault(); if (vo) pdfStore.prevMatch(); else pdfStore.nextMatch(); return; }
        try { if (stepPin(vo ? -1 : 1)) { e.preventDefault(); return; } } catch { /* */ }
      }

      // Arrow keys in PDF context: navigate matches if they exist, otherwise scroll pages
      if (!e.ctrlKey && !e.metaKey && !e.altKey && !e.shiftKey) {
        if (pdfStore.matches.length > 0) {
          if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
            e.preventDefault();
            pdfStore.nextMatch();
            return;
          }
          if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
            e.preventDefault();
            pdfStore.prevMatch();
            return;
          }
        } else if (fileInputRefs.pdfSearch) {
          // No search matches — arrow up/down scroll PDF pages
          if (e.key === 'ArrowDown') {
            e.preventDefault();
            pdfStore.goToPage(pdfStore.currentPage + 1);
            return;
          }
          if (e.key === 'ArrowUp') {
            e.preventDefault();
            pdfStore.goToPage(pdfStore.currentPage - 1);
            return;
          }
        }
      }

      for (const shortcut of shortcuts) {
        if (shortcut.displayOnly) continue; // cheat-sheet-only; handled ad-hoc above
        if (!matchesShortcut(e, shortcut)) continue;

        switch (shortcut.id) {
          case 'openBoard':
            e.preventDefault();
            fileInputRefs.board?.click();
            return;

          case 'openPdf':
            e.preventDefault();
            fileInputRefs.pdf?.click();
            return;

          case 'flipBoard': {
            // Cursor over a PDF panel → fit-to-width; otherwise → flip board.
            // The PDF path is tap-only — no peek/hold semantics for fit-width.
            const hovered = document.elementFromPoint(_lastMouseX, _lastMouseY);
            if (hovered?.closest('.pdf-viewer')) {
              e.preventDefault();
              window.dispatchEvent(new Event('pdf-fit-width'));
              return;
            }
            e.preventDefault();
            // Autorepeat or second-keydown-without-keyup → already flipped on
            // the first keydown, ignore subsequent firings until keyup. Without
            // this gate, holding Space would re-flip every autorepeat tick.
            if (e.repeat || _spaceFlipPress) return;
            const { showTop, showBottom, butterfly, board } = boardStore;
            if (butterfly || (showTop && showBottom)) return;
            // selectTop/selectBottom already swap raw flags for primarySide='bottom'
            // files. Read state in UI perspective (what the user sees as "Top") so
            // the toggle flips both kinds of files identically.
            const swap = board?.primarySide === 'bottom';
            const uiTopVisible = swap ? showBottom : showTop;
            // Hint chip shows up only AFTER the tap-vs-hold threshold trips,
            // and self-dismisses PEEK_HINT_LIFESPAN_MS after that — a quick
            // tap never sees the chip at all, and a long peek doesn't leave
            // it permanently parked on the canvas. The hide-timer ref lives
            // on the press record so keyup/blur can cancel it cleanly.
            const press: SpaceFlipPress = {
              wasUiTopVisible: uiTopVisible,
              pressedAt: e.timeStamp,
              hintTimer: null,
              hintHideTimer: null,
            };
            press.hintTimer = setTimeout(() => {
              // A timer can fire late, after the main thread was busy; only
              // show the hint if the key is really still down by now.
              if (_spaceFlipPress !== press) return;
              peekHintStore.show();
              press.hintHideTimer = setTimeout(() => {
                peekHintStore.hide();
              }, PEEK_HINT_LIFESPAN_MS);
            }, SPACE_HOLD_PEEK_MS);
            _spaceFlipPress = press;
            if (uiTopVisible) boardStore.selectBottom();
            else boardStore.selectTop();
            return;
          }

          case 'pdfFitWidth':
            // Handled via flipBoard case above (same key, context-dependent)
            break;

          case 'rotateCW': {
            const kind = activePanelKind();
            if (kind === null) return;
            e.preventDefault();
            if (kind === 'pdf') pdfStore.rotateActive('cw');
            else boardStore.rotateCW();
            return;
          }
          case 'rotateCCW': {
            const kind = activePanelKind();
            if (kind === null) return;
            e.preventDefault();
            if (kind === 'pdf') pdfStore.rotateActive('ccw');
            else boardStore.rotateCCW();
            return;
          }
          case 'mirrorBoard': {
            const kind = activePanelKind();
            if (kind === null) return;
            e.preventDefault();
            if (kind === 'pdf') pdfStore.mirrorActive();
            else boardStore.flipHorizontal();
            return;
          }

          case 'panLeft':
            if (activePanelKind() === null) return;
            e.preventDefault();
            viewCommands.pan('left');
            return;
          case 'panRight':
            if (activePanelKind() === null) return;
            e.preventDefault();
            viewCommands.pan('right');
            return;
          case 'panUp':
            if (activePanelKind() === null) return;
            e.preventDefault();
            viewCommands.pan('up');
            return;
          case 'panDown':
            if (activePanelKind() === null) return;
            e.preventDefault();
            viewCommands.pan('down');
            return;

          case 'pageDown':
            e.preventDefault();
            pdfStore.goToPage(pdfStore.currentPage + 1);
            return;
          case 'pageUp':
            e.preventDefault();
            pdfStore.goToPage(pdfStore.currentPage - 1);
            return;
          case 'pageFirst':
            e.preventDefault();
            pdfStore.goToPage(1);
            return;
          case 'pageLast':
            e.preventDefault();
            pdfStore.goToPage(pdfStore.pageCount);
            return;

          case 'panBoardLeft':
          case 'panBoardRight':
          case 'panBoardUp':
          case 'panBoardDown': {
            const kind = activePanelKind();
            if (kind === null) return;
            e.preventDefault();
            const dir = shortcut.id === 'panBoardLeft'  ? 'left'
                      : shortcut.id === 'panBoardRight' ? 'right'
                      : shortcut.id === 'panBoardUp'    ? 'up'
                      : 'down';
            if (kind === 'board') {
              viewCommands.pan(dir);
            } else {
              window.dispatchEvent(new CustomEvent('pdf-pan', { detail: { direction: dir } }));
            }
            return;
          }

          case 'rotateBoardCCW':
          case 'rotateBoardCW': {
            const kind = activePanelKind();
            if (kind === null) return;
            e.preventDefault();
            const dir = shortcut.id === 'rotateBoardCCW' ? 'ccw' : 'cw';
            if (kind === 'pdf') {
              if (dir === 'ccw') pdfStore.rotateActive('ccw');
              else pdfStore.rotateActive('cw');
            } else {
              if (dir === 'ccw') boardStore.rotateCCW();
              else boardStore.rotateCW();
            }
            return;
          }

          case 'zoomBoardIn':
          case 'zoomBoardOut': {
            const kind = activePanelKind();
            if (kind === null) return;
            e.preventDefault();
            const dir = shortcut.id === 'zoomBoardIn' ? 'in' : 'out';
            if (kind === 'board') {
              viewCommands.zoom(dir);
            } else {
              window.dispatchEvent(new CustomEvent('pdf-zoom', { detail: { direction: dir } }));
            }
            return;
          }

          case 'toggleLibrary': {
            const kind = activePanelKind();
            if (kind === null) return;
            e.preventDefault();
            toggleLibrarySidebar();
            return;
          }

          case 'copySelection': {
            // Only act when a board panel is active. Anywhere else, let the
            // browser's native copy proceed (we never preventDefault).
            if (activePanelKind() !== 'board') return;
            // If the user has highlighted text (e.g. in the NetList or Info
            // panel), don't hijack — let the native copy take it verbatim.
            if ((window.getSelection?.()?.toString() ?? '').trim()) return;
            const text = copySelectionText();
            if (!text) return;
            e.preventDefault();
            copyText(text).then(
              () => boardStore.addToast(`Copied '${text}'`, 'info'),
              (err) => boardStore.addToast(
                `Copy failed: ${err instanceof Error ? err.message : String(err)}`, 'error'),
            );
            return;
          }
        }
      }
    };

    // Block browser page zoom (Ctrl+wheel on Win/Linux, Cmd+wheel / pinch on Mac).
    // The board viewport (pixi-viewport) and PDF panel handle their own zoom already;
    // we just need to stop the browser from scaling the entire page.
    // Only block browser zoom when pointer is over a canvas (board or PDF viewer).
    // This preserves Ctrl+wheel page zoom in settings, debug, and other non-canvas panels.
    const blockBrowserZoom = (e: WheelEvent) => {
      if ((e.ctrlKey || e.metaKey) && (e.target instanceof HTMLCanvasElement)) {
        e.preventDefault();
      }
    };

    // Block Ctrl+Plus/Minus/0 keyboard zoom only when a canvas-based panel is focused
    // The browser's own chords never reach the browser: page zoom, find
    // (⌘F / ⌘G / ⌘E), save, bookmark, print, open, downloads. Capture phase on
    // the window, ahead of any element that stops propagation — the slide
    // sheet's text boxes do, and ⌘F typed there opened the browser's find bar
    // (2026-10-22, "sometimes ⌘F causes the browser's search").
    const BROWSER_CHORD_KEYS = new Set(['=', '+', '-', '0', 'f', 'g', 'e', 's', 'd', 'p', 'o', 'j']);
    // The browser's context menu never opens either — a right-click on a tab
    // strip or any other chrome showed it (2026-10-22). Text fields keep it:
    // paste and spell-check live there.
    const blockNativeContextMenu = (e: MouseEvent) => {
      const t = e.target as Element | null;
      if (t?.closest?.('input, textarea, [contenteditable="true"], [data-native-menu]')) return;
      e.preventDefault();
    };
    const blockKeyboardZoom = (e: KeyboardEvent) => {
      const mod = e.ctrlKey || e.metaKey;
      if (mod && !e.altKey && BROWSER_CHORD_KEYS.has(e.key.toLowerCase())) {
        e.preventDefault();
      }
    };

    // Space-flip release: tap → keep flipped, hold → revert to original side.
    // Mirrors the keydown side of the flipBoard case above; lives outside it
    // so it can fire on the same document(s) regardless of which one received
    // the keydown (popout windows share the same module-level press state).
    const spaceKeyupHandler = (e: KeyboardEvent) => {
      if (e.key !== ' ' && e.code !== 'Space') return;
      const press = _spaceFlipPress;
      if (!press) return;
      _spaceFlipPress = null;
      if (press.hintTimer) clearTimeout(press.hintTimer);
      if (press.hintHideTimer) clearTimeout(press.hintHideTimer);
      peekHintStore.hide();
      // Event time, not handler time: a keyup that waited behind the flip's
      // own work is still a tap.
      const heldMs = e.timeStamp - press.pressedAt;
      if (heldMs < SPACE_HOLD_PEEK_MS) return; // tap: keep flipped state
      // Hold: restore the side that was visible before the press.
      if (press.wasUiTopVisible) boardStore.selectTop();
      else boardStore.selectBottom();
    };
    // Window blur safety net: if focus leaves the page mid-hold (e.g. the
    // user alt-tabs), we'll never get keyup. Discard the press state so the
    // next tap isn't ignored as "autorepeat". Don't revert — the user may
    // come back and release Space normally; reverting now would surprise
    // them.
    const spaceBlurHandler = () => {
      if (_spaceFlipPress?.hintTimer) clearTimeout(_spaceFlipPress.hintTimer);
      if (_spaceFlipPress?.hintHideTimer) clearTimeout(_spaceFlipPress.hintHideTimer);
      _spaceFlipPress = null;
      peekHintStore.hide();
    };

    document.addEventListener('keydown', handler);
    document.addEventListener('keyup', spaceKeyupHandler);
    window.addEventListener('keydown', blockKeyboardZoom, true);
    window.addEventListener('contextmenu', blockNativeContextMenu, true);
    document.addEventListener('wheel', blockBrowserZoom, { passive: false });
    window.addEventListener('blur', spaceBlurHandler);

    // Also attach to every Dockview popout window's document so shortcuts
    // fire when focus is inside the detached PDF window. (2-window mode.)
    // Popouts share the parent's JS context, so the same `handler` closure
    // works — we just need it bound to the popout's document.
    const popoutDocs = new Set<Document>();
    const attachToPopout = (doc: Document) => {
      if (popoutDocs.has(doc)) return;
      doc.addEventListener('keydown', handler);
      doc.addEventListener('keyup', spaceKeyupHandler);
      doc.defaultView?.addEventListener('keydown', blockKeyboardZoom, true);
      doc.defaultView?.addEventListener('contextmenu', blockNativeContextMenu, true);
      doc.addEventListener('mousemove', trackMouse, { passive: true });
      popoutDocs.add(doc);
    };
    const detachFromPopout = (doc: Document) => {
      doc.removeEventListener('keydown', handler);
      doc.removeEventListener('keyup', spaceKeyupHandler);
      doc.defaultView?.removeEventListener('keydown', blockKeyboardZoom, true);
      doc.defaultView?.removeEventListener('contextmenu', blockNativeContextMenu, true);
      doc.removeEventListener('mousemove', trackMouse);
      popoutDocs.delete(doc);
    };
    const scanPopouts = () => {
      const api = getDockviewApi();
      if (!api) return;
      for (const group of api.groups) {
        if (group.api.location.type === 'popout') {
          attachToPopout(group.api.location.getWindow().document);
        }
      }
    };
    scanPopouts();
    const scanInterval = setInterval(scanPopouts, 500);

    return () => {
      document.removeEventListener('mousemove', trackMouse);
      document.removeEventListener('keydown', handler);
      document.removeEventListener('keyup', spaceKeyupHandler);
      window.removeEventListener('keydown', blockKeyboardZoom, true);
      window.removeEventListener('contextmenu', blockNativeContextMenu, true);
      document.removeEventListener('wheel', blockBrowserZoom);
      window.removeEventListener('blur', spaceBlurHandler);
      clearInterval(scanInterval);
      for (const doc of Array.from(popoutDocs)) detachFromPopout(doc);
    };
  }, []);
}
