import { IS_2R } from '../r2/env';
import { useState, useCallback, useRef, useMemo, useEffect, useSyncExternalStore, createContext, useContext } from 'react';
import { setWatermarkTerms } from '../store/pdf-filter-actions';
import { IconPalette, IconLayoutBoardSplit, IconKeyboard, IconBooks, IconSettings, IconPlug, IconClick, IconGauge } from '@tabler/icons-react';
import { themeStore, THEMES, ACCENT_PRESETS } from '../store/themes';
import { isHdrCapable, onHdrCapabilityChange } from '../renderer/hdr-selection-outline';
import { resizeModeStore } from '../store/resize-mode-store';
import type { Theme } from '../store/themes';
import { renderSettingsStore, DEFAULTS, computeOverrides } from '../store/render-settings';
import { colorToHex, hexToColor } from '../store/layer-store';
import { StandaloneCollapsibleSection } from './settings/StandaloneCollapsibleSection';
import {
  SettingsSearchProvider,
  SettingsSearchBar,
  useFieldSearchState,
  useSectionSearchState,
  useSettingsSearch,
  recordRenderedField,
} from './settings/SettingsSearch';
import type { RenderSettings, PartType, PadShape, BodyShape, PinGroup, PinGroupRule, LightSelectionStyle } from '../store/render-settings';
import { SettingsMockup } from './SettingsMockup';
import { QualityPresetCard } from '../components/QualityPresetCard';
import { resetLocalSettings } from '../store/reset-local-settings';
import { InterfaceScaleSlider } from '../components/InterfaceScaleSlider';
import { SidebarNavSwitch } from '../components/SidebarNavSwitch';
import type { MockupSectionId } from './SettingsMockup';
import { shortcuts, formatShortcut, CATEGORY_LABELS, CATEGORY_ORDER } from '../store/keyboard-shortcuts';
import { boardStore } from '../store/board-store';
import { startMcpBridge, stopMcpBridge, getMcpClientIdentity, setMcpClientLabel } from '../store/mcp-bridge';
import { copyText } from '../clipboard';
import { useDatabank } from '../hooks/useDatabank';
import { databankStore } from '../store/databank-store';
import { PDF_INERTIA_KEY, loadPdfInertia } from './PdfViewerPanel';
import { PDF_QUALITY_LABELS, PDF_RENDER_QUALITY_OPTIONS, getPdfQualityConfig, pdfQualityDescription, setPdfQuality } from '../store/pdf-quality';
import { usePdfQuality } from '../components/PdfQualityCard';
import {
  ACTION_COLOR, ACTION_LABEL, SLOT_LABEL, SHIFT_SCROLL_NOTE, SCROLL_ACTIONS, SCROLL_SLOTS, SCROLL_BINDINGS_EVENT,
  DEFAULT_SCROLL_BINDINGS, DEFAULT_BOARD_SCROLL_BINDINGS, BOARD_SCROLL_ACTIONS, isMacPlatform,
  loadScrollBindings, saveScrollBindings, sameScrollBindings, nextAction, boardScrollBindings, boardScrollSettings,
  type ScrollAction, type ScrollBindings, type ScrollSlot, type BoardScrollSettings,
} from '../store/scroll-bindings';
import { ensureDatabaseEditorPanel } from '../store/dockview-api';
import { useObdForBoard } from '../store/obd-store';
import { LibrarySyncSection, SoftwareUpdateSection } from './LibrarySyncSection';
import { welcomeStore } from '../store/welcome-store';
import { OverlayCustomizer } from './settings/OverlayCustomizer';
import { RangeControl } from '../components/RangeControl';
import { AutoBindSection } from './settings/AutoBindSection';
import { firstRunStore } from '../store/first-run-store';
import { pdfIndexClient } from '../pdf/pdf-index-client';
import { fmtIndexEta } from './LibraryPanel';
import { isElectron, hasBackend } from '../store/databank-store';
import { isLiteBuild } from '../store/build-mode';

const subscribeBoardName = (cb: () => void) => boardStore.subscribe(cb);
const getBoardFileName = () => boardStore.fileName;

/** Silently disable the SettingsMockup render preview without removing
 *  it from the tree. Flip to true to bring the preview back in one line. */
const SHOW_MOCKUP_PREVIEW = false;

/** Context that provides per-field override info to Slider/Toggle children */
interface OverrideCtx {
  isBoardMode: boolean;
  globalSettings: RenderSettings;
  draft: RenderSettings;
}
const OverrideContext = createContext<OverrideCtx | null>(null);

function useOverride(field: keyof RenderSettings) {
  const ctx = useContext(OverrideContext);
  if (!ctx || !ctx.isBoardMode) return { isOverride: false, resetValue: undefined };
  const gv = ctx.globalSettings[field];
  const dv = ctx.draft[field];
  const isOverride = typeof gv === 'object'
    ? JSON.stringify(gv) !== JSON.stringify(dv)
    : gv !== dv;
  return { isOverride, resetValue: gv as number & boolean };
}

type SectionId = MockupSectionId | 'zoomLod' | 'netLines' | 'navigation' | 'performance' | 'shortcuts' | 'partTypeOverrides' | 'server' | 'dbinfo' | 'pdf' | 'boardOverlay';

export type SettingsTabId = 'theme' | 'board' | 'rendering' | 'input' | 'library' | 'system' | 'integrations';

// 2R Tools (Roger, 10/10/2026): integração MCP (IA na placa) fica oculta por enquanto — o
// código continua aqui, pronto; liga com window.__2rBeta.mcp = true quando a ponte existir.
const MCP_2R = typeof window !== 'undefined' && !!(window as unknown as { __2rBeta?: Record<string, boolean> }).__2rBeta?.mcp;
const TAB_ORDER: SettingsTabId[] = (['theme', 'board', 'rendering', 'input', 'library', 'system', 'integrations'] as SettingsTabId[])
  .filter(t => !(isLiteBuild() && (t === 'library' || t === 'integrations')))
  .filter(t => !(IS_2R && t === 'integrations' && !MCP_2R));

const TAB_ICONS: Record<SettingsTabId, typeof IconPalette> = {
  theme:        IconPalette,
  board:        IconLayoutBoardSplit,
  rendering:    IconGauge,
  input:        IconKeyboard,
  library:      IconBooks,
  system:       IconSettings,
  integrations: IconPlug,
};

const TAB_LABELS: Record<SettingsTabId, string> = {
  theme:        'Theme',
  board:        'Board',
  rendering:    'Rendering',
  input:        'Input',
  library:      'Library',
  system:       'System',
  integrations: 'Integrations',
};

/** Maps each section id to the tab that owns it. Used by focusSection deep-links. */
export const SECTION_TO_TAB: Record<SectionId, SettingsTabId> = {
  // Board tab
  outline:           'board',
  parts:             'board',
  pins:              'board',
  partTypeOverrides: 'board',
  netColors:         'board',
  selection:         'board',
  netLines:          'board',
  boardOverlay:      'board',
  // Input tab
  zoomLod:    'input',
  navigation: 'input',
  shortcuts:  'input',
  // Rendering tab (2026-10-10): board and PDF quality, text renderer,
  // diagnostics — it was two levels down as System ▸ Performance & Debug.
  // The section id stays `performance` for deep links and saved open state.
  performance: 'rendering',
  // System tab
  pdf:         'system',
  // Library folder + auto-scan + scan/index controls live on the Library tab.
  // The internal section id is still `server` for localStorage continuity
  // (`boardripper-settings-open-sections-*`) and focus refs. `dbinfo` is the
  // split-out database stats / dedup / reset block.
  server:      'library',
  dbinfo:      'library',
};

const ACTIVE_TAB_KEY = 'boardripper-settings-active-tab';

function loadActiveTab(): SettingsTabId {
  try {
    const raw = localStorage.getItem(ACTIVE_TAB_KEY);
    if (raw && TAB_ORDER.includes(raw as SettingsTabId)) return raw as SettingsTabId;
  } catch { /* ignore */ }
  return 'board';
}

function saveActiveTab(id: SettingsTabId) {
  try { localStorage.setItem(ACTIVE_TAB_KEY, id); } catch { /* ignore */ }
}

function openSectionsKey(tab: SettingsTabId): string {
  return `boardripper-settings-open-sections-${tab}`;
}

function loadOpenSections(tab: SettingsTabId): Set<SectionId> {
  // First visit to the Library tab: the everyday section (Scanning & Indexing)
  // starts open instead of a wall of collapsed headers.
  const fallback = (): Set<SectionId> =>
    tab === 'library' ? new Set<SectionId>(['server'])
      : tab === 'rendering' ? new Set<SectionId>(['performance'])   // its only section
      : new Set();
  try {
    const raw = localStorage.getItem(openSectionsKey(tab));
    if (!raw) return fallback();
    const parsed = JSON.parse(raw) as SectionId[];
    return new Set(parsed);
  } catch {
    return fallback();
  }
}

function saveOpenSections(tab: SettingsTabId, sections: Set<SectionId>) {
  try {
    localStorage.setItem(openSectionsKey(tab), JSON.stringify(Array.from(sections)));
  } catch { /* ignore */ }
}

type DraftUpdater = (partial: Partial<RenderSettings>) => void;

// ---- Collapsible section ----

function CollapsibleSection({
  id, title, children, isOpen, onToggle, sectionRef, isFocused,
}: {
  id: SectionId;
  title: string;
  children: React.ReactNode;
  isOpen: boolean;
  onToggle: (id: SectionId) => void;
  sectionRef: React.RefObject<HTMLDivElement | null>;
  isFocused: boolean;
}) {
  // Section IDs are typed as SectionId but the search index uses the same
  // string set (plus a few extras for non-main-tab sections). Cast is safe
  // because the section ids are the same strings.
  const { hidden, forceOpen } = useSectionSearchState(id as Parameters<typeof useSectionSearchState>[0]);
  if (hidden) return null;
  const effectiveOpen = forceOpen || isOpen;
  return (
    <div
      ref={sectionRef}
      className={`settings-section${isFocused ? ' settings-section-focused' : ''}`}
    >
      <button className="settings-section-header" onClick={() => onToggle(id)}>
        <span className="settings-section-title">{title}</span>
        <span className="settings-section-chevron">{effectiveOpen ? '▾' : '▸'}</span>
      </button>
      {effectiveOpen && <div className="settings-section-body">{children}</div>}
    </div>
  );
}

// ---- Primitive controls ----

interface SliderProps {
  label: string; value: number; min: number; max: number; step: number;
  field: keyof RenderSettings; onUpdate: DraftUpdater; title?: string;
  /** Boolean setting this slider also switches: the thumb toggles on click,
   *  the row name toggles on click, and the row greys out while off. One
   *  row for "show it" and "how big" (RangeControl in on/off mode). */
  toggleField?: keyof RenderSettings;
  unit?: string;
}

function Slider({ label, value, min, max, step, field, onUpdate, title, toggleField, unit }: SliderProps) {
  const [dragging, setDragging] = useState(false);
  const { isOverride, resetValue: ovReset } = useOverride(field);
  const ctx = useContext(OverrideContext);
  const defaultValue = ovReset ?? DEFAULTS[field] as number;
  const pct = ((value - min) / (max - min)) * 100;
  const isModified = Math.abs(value - defaultValue) > step * 0.5;
  useEffect(() => { recordRenderedField(field); if (toggleField) recordRenderedField(toggleField); }, [field, toggleField]);
  const fs = useFieldSearchState(field);
  const ts = useFieldSearchState(toggleField ?? field);
  const hidden = fs.hidden && ts.hidden, matched = fs.matched || ts.matched;
  const on = toggleField ? (ctx?.draft[toggleField] as boolean | undefined ?? true) : true;
  if (hidden) return null;
  const readout = <span className="settings-value">{Number(value.toFixed(2))}{unit ? ` ${unit}` : ''}</span>;
  return (
    <div className={`settings-row${isOverride ? ' settings-override' : ''}${matched ? ' settings-search-match' : ''}${toggleField && !on ? ' settings-row-off' : ''}`} title={title} data-field={field}>
      {toggleField ? (
        <button type="button" className="settings-label settings-label-btn" aria-pressed={on}
          onClick={() => onUpdate({ [toggleField]: !on })}>
          {label}{readout}
        </button>
      ) : (
        <label className="settings-label">{label}{readout}</label>
      )}
      <div className="settings-slider-wrap">
        <RangeControl
          value={value} min={min} max={max} step={step}
          onChange={(v) => onUpdate({ [field]: v })}
          on={toggleField ? on : undefined}
          onToggle={toggleField ? (next) => onUpdate({ [toggleField]: next }) : undefined}
          defaultValue={defaultValue}
          ariaLabel={label}
          onDragChange={setDragging}
          className={isOverride ? 'slider-override' : undefined}
          testId={`range-${field}`}
        />
        <div className={`settings-slider-tooltip${dragging ? ' is-visible' : ''}`} style={{ left: `${pct}%` }}>
          {dragging
            ? <span className="settings-slider-reset-hint">dbl-click track to reset{isModified ? ` (${Number(defaultValue.toFixed(2))})` : ''}</span>
            : <>{Number(value.toFixed(2))}{toggleField ? <span className="settings-slider-reset-hint"> · click thumb or name: {on ? 'off' : 'on'}</span> : null}</>
          }
        </div>
      </div>
    </div>
  );
}

interface ToggleProps {
  label: string; value: boolean; field: keyof RenderSettings; onUpdate: DraftUpdater; title?: string;
}

function Toggle({ label, value, field, onUpdate, title }: ToggleProps) {
  const { isOverride, resetValue: ovReset } = useOverride(field);
  useEffect(() => { recordRenderedField(field); }, [field]);
  const { hidden, matched } = useFieldSearchState(field);
  if (hidden) return null;
  return (
    <div className={`settings-row settings-toggle-row${isOverride ? ' settings-override' : ''}${matched ? ' settings-search-match' : ''}`} title={title}>
      <label className="settings-label">{label}</label>
      <input type="checkbox" checked={value}
        onChange={(e) => onUpdate({ [field]: e.target.checked })}
        onDoubleClick={() => { const rv = ovReset ?? DEFAULTS[field] as boolean; onUpdate({ [field]: rv }); }}
      />
    </div>
  );
}


// ---- Part types (grouped component categories, issue #10) ----

type PartTypeActions = {
  update: (id: string, patch: Partial<PartType>) => void;
};

const PAD_SHAPES: PadShape[]  = ['natural', 'round', 'square'];
const BODY_SHAPES: BodyShape[] = ['natural', 'rect', 'square'];

function PartTypeRow({ type: t, actions, hideShapes }: { type: PartType; actions: PartTypeActions; hideShapes?: boolean }) {
  // Track the prefix text locally so the user can type commas/spaces freely.
  const [editPrefixes, setEditPrefixes] = useState(t.prefixes.join(', '));

  // Keep local text in sync if the parent list changes (e.g. reset). This is
  // the "Storing information from previous renders" pattern from the React
  // docs (https://react.dev/reference/react/useState#storing-information-from-previous-renders):
  // calling setState during render with a different value is allowed and
  // causes React to discard this render before commit — strictly better than
  // either an effect (cascading render) or a ref read (forbidden by R19).
  const joined = t.prefixes.join(', ');
  const [prevJoined, setPrevJoined] = useState(joined);
  if (prevJoined !== joined) {
    setPrevJoined(joined);
    setEditPrefixes(joined);
  }

  const commitPrefixes = () => {
    const parsed = editPrefixes
      .split(/[\s,]+/)
      .map(p => p.trim().toUpperCase())
      .filter(p => p.length > 0);
    // Deduplicate while preserving order.
    const seen = new Set<string>();
    const unique = parsed.filter(p => seen.has(p) ? false : (seen.add(p), true));
    if (unique.join(',') !== t.prefixes.join(',')) {
      actions.update(t.id, { prefixes: unique });
    }
    setEditPrefixes(unique.join(', '));
  };

  return (
    <div className="part-type-row">
      <span className="pt-label" title={t.id}>{t.label}</span>
      <input
        className="pt-prefixes-input"
        value={editPrefixes}
        onChange={e => setEditPrefixes(e.target.value)}
        onBlur={commitPrefixes}
        onKeyDown={e => { if (e.key === 'Enter') (e.target as HTMLInputElement).blur(); }}
        title="Comma-separated prefixes (e.g. R, PR, PH)"
        placeholder="R, PR, PH"
      />
      {!hideShapes && (
      <div className="pt-col-pad settings-btn-group">
        {PAD_SHAPES.map(shape => (
          <button key={shape}
            className={`settings-btn-option${t.padShape === shape ? ' active' : ''}`}
            onClick={() => actions.update(t.id, { padShape: shape })}
            title={shape}
          >
            {shape === 'natural' ? '~' : shape === 'round' ? '●' : '■'}
          </button>
        ))}
      </div>
      )}
      {!hideShapes && (
      <div className="pt-col-body settings-btn-group">
        {BODY_SHAPES.map(shape => (
          <button key={shape}
            className={`settings-btn-option${t.bodyShape === shape ? ' active' : ''}`}
            onClick={() => actions.update(t.id, { bodyShape: shape })}
            title={shape}
          >
            {shape === 'natural' ? '~' : shape === 'rect' ? '▭' : '□'}
          </button>
        ))}
      </div>
      )}
      <span className="pt-col-color">
        <input type="color" className="pto-color-input"
          value={t.color || '#000000'}
          onChange={e => actions.update(t.id, { color: e.target.value })}
        />
      </span>
      <span className="pt-col-hide">
        <input type="checkbox" checked={t.hidden}
          onChange={e => actions.update(t.id, { hidden: e.target.checked })}
        />
      </span>
      <span className="pt-col-bridge" title="Bridge nets through this type in hierarchical (chain + adjacent) net lines, even with more than 2 pins — e.g. 4-pin current-sense resistors, transistors.">
        <input type="checkbox" checked={t.hierarchyBridge}
          onChange={e => actions.update(t.id, { hierarchyBridge: e.target.checked })}
        />
      </span>
    </div>
  );
}

function PartTypesSection({ types, actions, hideShapes }: { types: PartType[]; actions: PartTypeActions; hideShapes?: boolean }) {
  return (
    <div className={`part-types${hideShapes ? ' compact' : ''}`}>
      <div className="part-types-header">
        <span>Type</span>
        <span>Prefixes</span>
        {!hideShapes && <span>Pads</span>}
        {!hideShapes && <span>Body</span>}
        <span>Fill</span>
        <span>Hide</span>
        <span title="Bridge nets through this type in hierarchical net lines, even with >2 pins.">Bridge</span>
      </div>
      {types.map(t => (
        <PartTypeRow key={t.id} type={t} actions={actions} hideShapes={hideShapes} />
      ))}
      <div className="color-rule-hint">Longest prefix wins across all types (e.g. FB beats F for FB1).</div>
      <div className="color-rule-hint">Bridge: carry hierarchical (chain + adjacent) net lines through &gt;2-pin parts of this type (e.g. current-sense resistors, transistors).</div>
    </div>
  );
}


// ---- Library folder setting (Docker mode) ----

function LibraryFolderSetting() {
  const { libraryPath, backendAvailable } = useDatabank();
  const [editing, setEditing] = useState(false);
  const [inputVal, setInputVal] = useState(libraryPath ?? '');
  const [saving, setSaving] = useState(false);

  // Don't show on desktop — it has its own native folder picker (LibraryPanel).
  if (isElectron()) return null;

  const handleSave = async () => {
    setSaving(true);
    const ok = await databankStore.setLibraryDir(inputVal.trim());
    setSaving(false);
    if (ok) {
      setEditing(false);
      // Trigger rescan with new library dir
      databankStore.triggerFileScan();
    }
  };

  if (!backendAvailable) {
    return (
      <div className="color-rule-hint">Backend not available. Start the Docker container to configure the library folder.</div>
    );
  }

  return (
    <div className="settings-library-folder">
      <div className="color-rule-hint" style={{ marginBottom: 6 }}>
        Path inside the container to scan for board/PDF files. Mount a NAS folder with <code>docker -v /host/path:/library</code>.
      </div>
      {editing ? (
        <div className="settings-library-edit">
          <input
            type="text"
            className="settings-library-input"
            value={inputVal}
            onChange={e => setInputVal(e.target.value)}
            placeholder="/library"
            autoFocus
            onKeyDown={e => { if (e.key === 'Enter') handleSave(); if (e.key === 'Escape') setEditing(false); }}
          />
          <button className="settings-action-btn settings-apply-btn" onClick={handleSave} disabled={saving}>
            {saving ? '...' : 'Save'}
          </button>
          <button className="settings-action-btn" onClick={() => setEditing(false)}>Cancel</button>
        </div>
      ) : (
        <div className="settings-row settings-toggle-row">
          <label className="settings-label">Library Folder</label>
          <span
            className="settings-library-path"
            onClick={() => { setInputVal(libraryPath ?? '/library'); setEditing(true); }}
            title="Click to edit"
          >
            {libraryPath || <em>Not configured</em>}
          </span>
        </div>
      )}
    </div>
  );
}

// ---- Auto-scan toggle ----

interface McpActivity { last_tool: string; last_tool_at_ms: number; total_calls: number; }
interface McpStatus { enabled: boolean; drive_ui: boolean; clients: number; activity?: McpActivity; auth_mode?: string; }

type McpClientId = 'claude-code' | 'claude-desktop' | 'cursor' | 'other';
const MCP_CLIENTS: { id: McpClientId; label: string; paste: string }[] = [
  { id: 'claude-code', label: 'Claude Code', paste: 'Run this in your terminal.' },
  { id: 'claude-desktop', label: 'Claude Desktop', paste: 'Add to claude_desktop_config.json, then restart Claude Desktop.' },
  { id: 'cursor', label: 'Cursor', paste: 'Add to ~/.cursor/mcp.json (or .cursor/mcp.json in your project).' },
  { id: 'other', label: 'Other', paste: 'Any MCP client over Streamable HTTP.' },
];

// oauth=true drops the bearer header — the client discovers the auth server and
// the user approves in the browser the first time (no token to copy).
function mcpSnippet(client: McpClientId, url: string, token: string, oauth: boolean): string {
  const t = token || '<enable the server to reveal the token>';
  switch (client) {
    case 'claude-code':
      return oauth
        ? `claude mcp add --transport http boardripper ${url}`
        : `claude mcp add --transport http boardripper ${url} --header "Authorization: Bearer ${t}"`;
    case 'claude-desktop':
      return JSON.stringify({
        mcpServers: {
          boardripper: oauth
            ? { command: 'npx', args: ['-y', 'mcp-remote', url] }
            : { command: 'npx', args: ['-y', 'mcp-remote', url, '--header', `Authorization: Bearer ${t}`] },
        },
      }, null, 2);
    case 'cursor':
      return JSON.stringify({
        mcpServers: { boardripper: oauth ? { url } : { url, headers: { Authorization: `Bearer ${t}` } } },
      }, null, 2);
    case 'other':
      return oauth
        ? `URL: ${url}\nAuth: OAuth 2.1 (the client discovers the auth server; approve in browser)`
        : `URL:    ${url}\nHeader: Authorization: Bearer ${t}`;
  }
}

function CopyButton({ text, disabled }: { text: string; disabled?: boolean }) {
  const [copied, setCopied] = useState(false);
  return (
    <button type="button" className="library-tab" disabled={disabled}
      style={{ padding: '3px 10px', fontSize: 11 }}
      onClick={async () => {
        try { await copyText(text); setCopied(true); setTimeout(() => setCopied(false), 1500); }
        catch { /* clipboard blocked */ }
      }}>
      {copied ? 'Copied ✓' : 'Copy'}
    </button>
  );
}

function McpLiveStatus({ status }: { status: McpStatus }) {
  const [test, setTest] = useState<{ ok: boolean; count?: number; error?: string } | null>(null);
  const [testing, setTesting] = useState(false);
  const act = status.activity;
  const ago = act && act.last_tool_at_ms
    ? `${Math.max(0, Math.round((Date.now() - act.last_tool_at_ms) / 1000))}s ago`
    : null;
  return (
    <div style={{ marginTop: 8 }}>
      <div className="settings-row">
        <span className="settings-label">Connected pages</span>
        <span>{status.clients}</span>
      </div>
      <div className="settings-row">
        <span className="settings-label">Tool calls</span>
        <span>{act?.total_calls ?? 0}{act?.last_tool ? ` · last: ${act.last_tool}${ago ? ` (${ago})` : ''}` : ''}</span>
      </div>
      <div className="settings-row settings-toggle-row">
        <button type="button" className="library-tab" disabled={testing}
          onClick={async () => {
            setTesting(true);
            try {
              const r = await fetch('/api/mcp/selftest', { method: 'POST' });
              setTest(await r.json());
            } catch (e: any) { setTest({ ok: false, error: String(e?.message ?? e) }); }
            setTesting(false);
          }}>
          {testing ? 'Testing…' : 'Test connection'}
        </button>
        {test && (
          <span style={{ fontSize: 12, color: test.ok ? 'var(--accent, #4ade80)' : '#f87171' }}>
            {test.ok ? `✓ responding · ${test.count} tools` : `✗ ${test.error ?? 'failed'}`}
          </span>
        )}
      </div>
    </div>
  );
}

/** Desktop-only master MCP switch. Drives the Electron `mcpEnabled` setting,
 *  which spawns/kills the backend sidecar and reloads the page. On success the
 *  window navigates (loadURL/loadFile) and this component unmounts. On a failed
 *  enable (backend never became healthy) it stays mounted and reflects the
 *  revert. */
function ElectronMcpToggle() {
  const [enabled, setEnabled] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [pending, setPending] = useState(false);

  useEffect(() => {
    window.electronAPI!.getMcpEnabled().then(v => { setEnabled(v); setLoaded(true); });
  }, []);

  const toggle = async (on: boolean) => {
    setPending(true);
    setEnabled(on);
    const result = await window.electronAPI!.setMcpEnabled(on);
    // Reachable only if the page did NOT navigate (i.e. a failed enable).
    setEnabled(result);
    setPending(false);
  };

  return (
    <div className="settings-row settings-toggle-row">
      <label className="settings-label">Enable MCP server</label>
      <input type="checkbox" checked={enabled} disabled={!loaded || pending}
        onChange={e => toggle(e.target.checked)} />
    </div>
  );
}

function IntegrationsSection() {
  const [status, setStatus] = useState<McpStatus | null>(null);
  const [token, setToken] = useState('');
  const [client, setClient] = useState<McpClientId>('claude-code');
  // Per-browser pairing: which token feeds the connect snippet, this browser's
  // pairing token, and its user-editable label.
  const [tokenSource, setTokenSource] = useState<'browser' | 'shared'>('browser');
  const [pairToken, setPairToken] = useState('');
  const [pairLabel, setPairLabel] = useState(() => getMcpClientIdentity().label);

  const pair = useCallback((label?: string) => {
    const ident = getMcpClientIdentity();
    fetch('/api/mcp/pair', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ client_id: ident.id, label: label ?? ident.label }),
    })
      .then(r => r.ok ? r.json() : null)
      .then((d: { token?: string; label?: string } | null) => {
        if (d?.token) setPairToken(d.token);
        if (d?.label) { setPairLabel(d.label); setMcpClientLabel(d.label); }
      })
      .catch(() => setPairToken(''));
  }, []);

  const rotatePair = useCallback(() => {
    fetch('/api/mcp/pair/rotate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ client_id: getMcpClientIdentity().id }),
    })
      .then(r => r.ok ? r.json() : null)
      .then((d: { token?: string } | null) => { if (d?.token) setPairToken(d.token); })
      .catch(() => { /* keep the old token visible */ });
  }, []);

  // Ends every OAuth grant at once. Switching auth mode deliberately does NOT
  // do this (agents mid-session would drop), so revoking is an explicit act.
  const resetOAuth = useCallback(() => {
    fetch('/api/mcp/oauth/reset', { method: 'POST' })
      .then(r => r.ok ? r.json() : null)
      .then((d: { revoked?: number } | null) => {
        const n = d?.revoked ?? 0;
        boardStore.addToast(
          n > 0
            ? `Disconnected ${n} OAuth agent${n === 1 ? '' : 's'} — they must approve access again.`
            : 'No OAuth agents were connected.',
          'info');
      })
      .catch(() => boardStore.addToast('Could not reset OAuth — check backend connection.', 'error'));
  }, []);

  const refresh = useCallback(() => {
    fetch('/api/mcp/status')
      .then(r => r.ok ? r.json() : null)
      .then((s: McpStatus | null) => setStatus(s))
      .catch(() => setStatus(null));
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  useEffect(() => {
    if (!status?.enabled) { setToken(''); setPairToken(''); return; }
    fetch('/api/mcp/token')
      .then(r => r.ok ? r.json() : { token: '' })
      .then((d: { token?: string }) => setToken(d.token ?? ''))
      .catch(() => setToken(''));
    pair();
  }, [status?.enabled, pair]);

  // Poll status while enabled so connected pages + tool activity update live.
  useEffect(() => {
    if (!status?.enabled) return;
    const t = setInterval(refresh, 3000);
    return () => clearInterval(t);
  }, [status?.enabled, refresh]);

  const setFlag = async (key: 'mcp_enabled' | 'mcp_drive_ui', on: boolean) => {
    setStatus(s => s ? { ...s, [key === 'mcp_enabled' ? 'enabled' : 'drive_ui']: on } : s);
    try {
      await fetch('/api/config', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key, value: on ? 'true' : '' }),
      });
    } catch { /* ignore */ }
    if (key === 'mcp_enabled') {
      if (on) startMcpBridge();
      else stopMcpBridge(); // tear the bridge down immediately; don't reconnect
    }
    refresh();
  };

  const setAuthMode = async (mode: 'token' | 'oauth') => {
    setStatus(s => s ? { ...s, auth_mode: mode } : s);
    try {
      await fetch('/api/config', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key: 'mcp_auth_mode', value: mode }),
      });
    } catch { /* ignore */ }
    refresh();
  };

  const enabled = !!status?.enabled;
  const oauth = status?.auth_mode === 'oauth';
  const url = `${location.protocol}//${location.host}/api/mcp`;
  const snippet = mcpSnippet(client, url, tokenSource === 'browser' && !oauth ? pairToken : token, oauth);
  const activeClient = MCP_CLIENTS.find(c => c.id === client)!;

  return (
    <div className="settings-tab-body">
      <StandaloneCollapsibleSection title="MCP server (AI agents)" defaultOpen storageKey="mcp">
        <p className="settings-hint">
          Let an AI agent (Claude Code, Claude Desktop, Cursor, or any MCP client) query
          this BoardRipper — PDF full-text search, OpenBoardData readings, the board
          reference DB, and the live connectivity of whatever board you have open — and
          drive the view. Off by default.
        </p>
        {isElectron()
          ? <ElectronMcpToggle />
          : (
            <div className="settings-row settings-toggle-row">
              <label className="settings-label">Enable MCP server</label>
              <input type="checkbox" checked={enabled}
                onChange={e => setFlag('mcp_enabled', e.target.checked)} />
            </div>
          )}
        <div className="settings-row settings-toggle-row">
          <label className="settings-label" title="Lets agents highlight nets, select parts, change side, and navigate PDFs on the open board">
            Allow agents to control the UI
          </label>
          <input type="checkbox" checked={!!status?.drive_ui} disabled={!enabled}
            onChange={e => setFlag('mcp_drive_ui', e.target.checked)} />
        </div>

        {(enabled || (isElectron() && hasBackend())) && status && (
          <>
            <McpLiveStatus status={status!} />

            <p className="settings-hint" style={{ margin: '12px 0 4px' }}>Authentication:</p>
            <div style={{ display: 'flex', gap: 4, marginBottom: 4 }}>
              <button type="button" className={`library-tab ${!oauth ? 'active' : ''}`}
                onClick={() => setAuthMode('token')}>Token</button>
              <button type="button" className={`library-tab ${oauth ? 'active' : ''}`}
                onClick={() => setAuthMode('oauth')}>OAuth (no token)</button>
            </div>
            <p className="settings-hint" style={{ margin: '0 0 8px' }}>
              {oauth
                ? 'Clients can connect with just the URL and approve access in the browser the first time — no token to copy. Bearer tokens keep working too, so users can mix both.'
                : 'New clients authenticate with the bearer token below. Agents that already approved access over OAuth stay connected — switching modes never logs anyone out.'}
            </p>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, margin: '0 0 8px' }}>
              <button type="button" className="settings-action-btn" data-testid="mcp-oauth-reset"
                onClick={resetOAuth}>Disconnect all OAuth agents</button>
              <span className="settings-hint" style={{ margin: 0 }}>
                Revokes every approved OAuth session. They can reconnect by approving again.
              </span>
            </div>

            {!oauth && (
              <>
                <p className="settings-hint" style={{ margin: '12px 0 4px', opacity: 0.9 }}>
                  ⚠ MCP tokens were <strong>reset</strong> by the multi-user session-separation
                  update — resetting the shared credential was the only way to migrate properly.
                  Agents connected before this update are logged out and must reconnect with a
                  token from below.
                </p>
                <p className="settings-hint" style={{ margin: '12px 0 4px' }}>Token:</p>
                <div style={{ display: 'flex', gap: 4, marginBottom: 4 }}>
                  <button type="button" className={`library-tab ${tokenSource === 'browser' ? 'active' : ''}`}
                    onClick={() => setTokenSource('browser')}>This browser&#39;s agent</button>
                  <button type="button" className={`library-tab ${tokenSource === 'shared' ? 'active' : ''}`}
                    onClick={() => setTokenSource('shared')}>Shared (all sessions)</button>
                </div>
                <p className="settings-hint" style={{ margin: '0 0 8px' }}>
                  {tokenSource === 'browser'
                    ? 'Scoped to boards open in this browser — your agent never sees or drives other users’ sessions. Recommended.'
                    : 'Sees and can drive every connected session on this install. Use deliberately, e.g. to analyze other users’ sessions; pass an explicit session from board_sessions.'}
                </p>
                {tokenSource === 'browser' && (
                  <div className="settings-row" style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8 }}>
                    <label className="settings-label" title="Shown to agents in board_sessions so your pages are recognizable">Browser label</label>
                    <input type="text" data-testid="mcp-pair-label" value={pairLabel}
                      style={{ flex: 1, minWidth: 0 }}
                      onChange={e => setPairLabel(e.target.value)}
                      onBlur={e => { const v = e.target.value.trim(); if (v) { setMcpClientLabel(v); pair(v); } }} />
                    <button type="button" className="library-tab" title="Mint a new token for this browser; the old one stops working"
                      onClick={rotatePair}>Rotate</button>
                  </div>
                )}
              </>
            )}
            <p className="settings-hint" style={{ margin: '12px 0 4px' }}>Connect a client:</p>
            <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap', marginBottom: 6 }}>
              {MCP_CLIENTS.map(c => (
                <button key={c.id} type="button"
                  className={`library-tab ${client === c.id ? 'active' : ''}`}
                  onClick={() => setClient(c.id)}>{c.label}</button>
              ))}
            </div>
            <p className="settings-hint" style={{ margin: '0 0 4px' }}>{activeClient.paste}</p>
            <div style={{ display: 'flex', alignItems: 'flex-start', gap: 6 }}>
              <pre className="mcp-connect-cmd" style={{
                whiteSpace: 'pre-wrap', wordBreak: 'break-all', userSelect: 'all',
                fontSize: 11, padding: '8px 10px', borderRadius: 6, margin: 0, flex: 1,
                background: 'var(--panel-alt, rgba(0,0,0,0.25))',
              }}>{snippet}</pre>
              <CopyButton text={snippet} />
            </div>
          </>
        )}
      </StandaloneCollapsibleSection>
    </div>
  );
}

function AutoScanToggle() {
  const { backendAvailable, electronMode } = useDatabank();
  const [autoScan, setAutoScan] = useState(false);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    if (electronMode || !backendAvailable) return;
    fetch('/api/config')
      .then(r => r.ok ? r.json() : null)
      .then(cfg => {
        if (cfg && typeof cfg.auto_scan === 'string') {
          setAutoScan(cfg.auto_scan === 'true');
        }
        setLoaded(true);
      })
      .catch(() => setLoaded(true));
  }, [backendAvailable, electronMode]);

  if (electronMode || !loaded) return null;

  const handleToggle = async (checked: boolean) => {
    setAutoScan(checked);
    try {
      await fetch('/api/config', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key: 'auto_scan', value: checked ? 'true' : '' }),
      });
    } catch { /* ignore */ }
  };

  return (
    <div className="settings-row settings-toggle-row">
      <label className="settings-label">Auto-scan on startup</label>
      <input type="checkbox" checked={autoScan} onChange={e => handleToggle(e.target.checked)} />
    </div>
  );
}

// ---- Database info section ----

function DatabaseInfoSection() {
  const { stats, scanStatus, backendAvailable, electronMode, pdfIndexStats, pdfIndexProgress, dedupProgress, dedupStats } = useDatabank();
  const [resetting, setResetting] = useState(false);
  const [optimizing, setOptimizing] = useState(false);
  const reclaimable = stats?.reclaimable_bytes ?? 0;
  // Nudge Optimize only when there's a meaningful amount to reclaim (≥64 MiB),
  // matching the backend's boot auto-compaction gate.
  const worthOptimizing = reclaimable >= 64 * 1024 * 1024;

  useEffect(() => {
    if (!electronMode && backendAvailable) {
      databankStore.fetchStats();
      // Refresh PDF-index stats + progress on open (one-shot stats at boot go
      // stale otherwise). fetchPdfIndexStats also starts the 1.5s poll if a
      // bulk index is currently running, so the indicator stays live.
      databankStore.fetchPdfIndexStats();
      // Same for dedup: refresh stats on open and resume polling if a pass is
      // already running so the panel re-attaches to live progress.
      databankStore.fetchDedupStats();
    }
  }, [backendAvailable, electronMode]);

  if (electronMode || !backendAvailable) return null;

  const isRunning = scanStatus?.running;

  const formatDate = (ts: number) => {
    if (!ts) return 'Never';
    return new Date(ts * 1000).toLocaleString();
  };

  const formatBytes = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  const handleResetPdf = async () => {
    if (!confirm('Reset all extracted PDF text? You will need to re-run PDF extraction.')) return;
    setResetting(true);
    await databankStore.resetPdf();
    setResetting(false);
  };

  const handleResetAll = async () => {
    if (!confirm('Wipe ALL scan data (files, bindings, PDF text)? This cannot be undone.')) return;
    setResetting(true);
    await databankStore.resetAll();
    setResetting(false);
  };

  const handleOptimize = async () => {
    if (optimizing) return;
    setOptimizing(true);
    try {
      const r = await databankStore.optimizeDatabase();
      if (r) {
        boardStore.addToast(`Database compacted — reclaimed ${formatBytes(r.reclaimed_bytes)}`, 'info');
      }
    } finally {
      setOptimizing(false);
    }
  };

  return (
    <div className="settings-db-info">
      {stats && (
        <>
          <div className="settings-row settings-toggle-row">
            <label className="settings-label">Board files</label>
            <span>{stats.boards}</span>
          </div>
          <div className="settings-row settings-toggle-row">
            <label className="settings-label">PDF files</label>
            <span>{stats.pdfs}</span>
          </div>
          <div className="settings-row settings-toggle-row">
            <label className="settings-label">Bindings</label>
            <span>{stats.bindings}</span>
          </div>
          <div className="settings-row settings-toggle-row">
            <label className="settings-label">PDF pages indexed</label>
            <span>{pdfIndexStats?.pages ?? 0}</span>
          </div>
          <div className="settings-row settings-toggle-row">
            <label className="settings-label">PDF index status</label>
            <span>
              {pdfIndexProgress?.running
                ? `Indexing ${pdfIndexProgress.done}/${pdfIndexProgress.total}`
                  + (pdfIndexProgress.workers > 0 ? ` · ${pdfIndexProgress.active_workers}/${pdfIndexProgress.workers} threads` : '')
                  + (pdfIndexProgress.errors > 0 ? ` (${pdfIndexProgress.errors} err)` : '')
                  + (fmtIndexEta(pdfIndexProgress) ? ` · ${fmtIndexEta(pdfIndexProgress)}` : '')
                : pdfIndexStats
                  ? `Idle — ${pdfIndexStats.indexed} indexed, ${pdfIndexStats.pending} pending`
                  : '—'}
            </span>
          </div>
          {pdfIndexProgress?.running && pdfIndexProgress.current_file && (
            <div className="settings-row settings-toggle-row">
              <label className="settings-label">Current file</label>
              <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: '60%', direction: 'rtl' }} title={pdfIndexProgress.current_file}>
                {pdfIndexProgress.current_file}
              </span>
            </div>
          )}
          {(pdfIndexStats?.failed ?? 0) > 0 && (
            <div className="settings-row settings-toggle-row">
              <label className="settings-label">PDF index errors</label>
              <span>{pdfIndexStats!.failed}</span>
            </div>
          )}
          <div className="settings-row settings-toggle-row">
            <label className="settings-label">Duplicate content</label>
            <span>
              {dedupProgress?.running
                ? `Finding duplicates ${dedupProgress.done}/${dedupProgress.total}`
                  + (dedupProgress.errors > 0 ? ` (${dedupProgress.errors} err)` : '')
                : dedupStats
                  ? `${dedupStats.groups} duplicate group${dedupStats.groups === 1 ? '' : 's'} · ${dedupStats.duplicate_files} redundant cop${dedupStats.duplicate_files === 1 ? 'y' : 'ies'}`
                  : '—'}
            </span>
          </div>
          <div className="settings-row settings-toggle-row">
            <label className="settings-label">Database size</label>
            <span>
              {formatBytes(stats.db_size_bytes)}
              {worthOptimizing && (
                <span style={{ color: 'var(--warn, #b8730a)' }}>
                  {' '}· {formatBytes(reclaimable)} reclaimable
                </span>
              )}
            </span>
          </div>
          <div className="settings-row settings-toggle-row">
            <label className="settings-label">Last file scan</label>
            <span>{formatDate(stats.last_file_scan_at)}</span>
          </div>
        </>
      )}
      <div className="settings-db-actions" style={{ marginTop: 8, display: 'flex', gap: 8, flexWrap: 'wrap' }}>
        <button
          className="settings-action-btn"
          onClick={ensureDatabaseEditorPanel}
          title="Open the read-only Database Editor in a Dockview panel"
        >
          Open Database Editor
        </button>
        {dedupProgress?.running ? (
          <button
            className="settings-action-btn"
            onClick={() => databankStore.stopDedup()}
            title="Stop the duplicate-finding pass"
          >
            Stop ({dedupProgress.done}/{dedupProgress.total})
          </button>
        ) : (
          <button
            className="settings-action-btn"
            onClick={() => databankStore.runDedup()}
            disabled={!!isRunning}
            title="Hash size-colliding files and group byte-identical duplicates"
          >
            Find duplicates
          </button>
        )}
        <button
          className={`settings-action-btn${worthOptimizing ? ' active' : ''}`}
          onClick={handleOptimize}
          disabled={optimizing || !!isRunning}
          title="Compact the database (VACUUM) to reclaim free pages left by past scans and index changes. Runs automatically at boot when badly bloated; safe to run any time."
        >
          {optimizing ? 'Optimizing…' : worthOptimizing ? `Optimize (reclaim ${formatBytes(reclaimable)})` : 'Optimize database'}
        </button>
        <button
          className="settings-action-btn"
          onClick={handleResetPdf}
          disabled={resetting}
          title="Wipe extracted PDF text — keeps file index and bindings. Independent of the file scan; the backend stops the indexer before wiping."
        >
          Reset PDF Text
        </button>
        <button
          className="settings-action-btn"
          onClick={handleResetAll}
          disabled={!!isRunning || resetting}
          title="Wipe ALL scan data"
          style={{ color: '#e55' }}
        >
          Reset Database
        </button>
      </div>
    </div>
  );
}

// ---- Library settings (auto-pdf, history depth, clear history) ----

function LibrarySettingsSection() {
  const { autoPdf, historyDepth, recentItems, scanStatus, pdfIndexProgress, pdfIndexStats, libraryLoadMode } = useDatabank();
  const [depthDraft, setDepthDraft] = useState<string>(String(historyDepth));
  const scanRunning = scanStatus?.running ?? false;
  const pdfIndexRunning = pdfIndexProgress?.running ?? false;
  const hasPending = (pdfIndexStats?.pending ?? 0) > 0;
  const [forcing, setForcing] = useState(false);

  // Background auto-resume toggle (default ON server-side; null while loading).
  const [autoResume, setAutoResumeState] = useState<boolean | null>(null);
  useEffect(() => {
    let alive = true;
    void pdfIndexClient.getAutoResume().then((r) => { if (alive && r) setAutoResumeState(r.enabled); });
    return () => { alive = false; };
  }, []);
  const toggleAutoResume = useCallback(async (next: boolean) => {
    setAutoResumeState(next); // optimistic
    const r = await pdfIndexClient.setAutoResume(next);
    if (r) {
      setAutoResumeState(r.enabled);
      if (r.enabled) databankStore.startPdfIndexPolling();
    }
  }, []);

  const handleRestart = useCallback(async () => {
    await pdfIndexClient.restart();
    databankStore.startPdfIndexPolling();
  }, []);

  // Live indexer numbers. `pdfIndexProgress` is the running snapshot
  // (done/total/active workers/current file/started_at); `pdfIndexStats`
  // is the steady-state aggregate (indexed/pages/failed/pending). Show
  // both depending on running state.
  const indexPct = pdfIndexProgress && pdfIndexProgress.total > 0
    ? Math.round((pdfIndexProgress.done / pdfIndexProgress.total) * 100)
    : 0;
  const indexEta = pdfIndexProgress ? fmtIndexEta(pdfIndexProgress) : '';

  const handleForceReindex = useCallback(async () => {
    if (forcing) return;
    if (!confirm(
      'Force re-index ALL PDFs?\n\n' +
      'This resets every status row (indexed / empty / failed) back to "pending" and re-extracts text from scratch. ' +
      'Use this only after changing the watermark term list or upgrading the indexer. ' +
      'It takes hours on a large library and is NOT what you want for a regular rescan — for that, "Index all PDFs" is already additive.',
    )) return;
    setForcing(true);
    try {
      await pdfIndexClient.reindex('all');
      databankStore.startPdfIndexPolling();
    } finally {
      setForcing(false);
    }
  }, [forcing]);

  // Keep local draft in sync when the stored value changes externally
  useEffect(() => {
    setDepthDraft(String(historyDepth));
  }, [historyDepth]);

  const commitDepth = () => {
    const n = Math.floor(Number(depthDraft));
    if (!Number.isFinite(n) || n < 1) { setDepthDraft(String(historyDepth)); return; }
    databankStore.setHistoryDepth(n);
  };

  return (
    <div className="settings-subsection">
      <div className="settings-subsection-label">Library</div>

      {/* Scan / index actions — moved from the Library panel statsbar so the
       *  panel chrome stays focused on browsing. */}
      <div className="settings-row-field">
        <span>Scan boards & PDFs</span>
        {scanRunning ? (
          <button
            className="settings-action-btn"
            onClick={() => databankStore.stopScan()}
          >
            Stop scan
          </button>
        ) : (
          <button
            className="settings-action-btn"
            onClick={() => databankStore.triggerFileScan()}
          >
            Scan now
          </button>
        )}
      </div>

      {/* Library load transport. Streaming = progressive gzipped NDJSON (rows
       *  appear as they arrive). Bulk API = one gzipped JSON download — often
       *  faster on slow connections, no progressive rows. Switching reloads. */}
      <div className="settings-row-field">
        <span title="How the full library list is fetched. Streaming shows rows as they arrive; Bulk API downloads one compressed file (often faster on slow links). The stream also auto-falls-back to Bulk on failure. Changing this reloads the library.">
          Library load mode
        </span>
        <span className="settings-pdfindex-actions">
          <button
            className={`settings-action-btn${libraryLoadMode === 'stream' ? ' active' : ''}`}
            onClick={() => databankStore.setLibraryLoadMode('stream')}
          >
            Streaming
          </button>
          <button
            className={`settings-action-btn${libraryLoadMode === 'bulk' ? ' active' : ''}`}
            onClick={() => databankStore.setLibraryLoadMode('bulk')}
          >
            Bulk API
          </button>
        </span>
      </div>

      {/* PDF text indexing — verbose status when running, summary when idle.
       *  The "Index all PDFs" trigger is additive (processes only `pending`
       *  rows); the separate Force row below resets every row first. */}
      <div className="settings-pdfindex-card">
        <div className="settings-pdfindex-header">
          <span className="settings-pdfindex-label">PDF text indexing</span>
          <span className="settings-pdfindex-actions">
            {pdfIndexRunning ? (
              <button
                className="settings-action-btn settings-pdfindex-stop"
                onClick={() => pdfIndexClient.stop()}
                title="Stop the indexer. Files already in progress finish their current page; the rest stay pending and resume when you continue."
              >
                Stop
              </button>
            ) : (
              <button
                className="settings-action-btn"
                onClick={() => { void pdfIndexClient.run(); databankStore.startPdfIndexPolling(); }}
                title={hasPending
                  ? 'Continue indexing the remaining pending PDFs from where it left off.'
                  : 'Index all PDFs (extract searchable text).'}
              >
                {hasPending ? 'Continue' : 'Index all PDFs'}
              </button>
            )}
            <button
              className="settings-action-btn"
              onClick={handleRestart}
              title="Stop the current sweep and start a fresh pass over all pending PDFs. Keeps already-indexed files (not a reset)."
            >
              Restart
            </button>
          </span>
        </div>

        {pdfIndexRunning && pdfIndexProgress ? (
          <>
            <div className="settings-pdfindex-bar">
              <div className="settings-pdfindex-fill" style={{ width: `${indexPct}%` }} />
            </div>
            <div className="settings-pdfindex-stats">
              <span>{pdfIndexProgress.done.toLocaleString()} / {pdfIndexProgress.total.toLocaleString()} ({indexPct}%)</span>
              {pdfIndexProgress.workers > 0 && (
                <span> · {pdfIndexProgress.active_workers}/{pdfIndexProgress.workers} threads</span>
              )}
              {pdfIndexProgress.errors > 0 && (
                <span className="settings-pdfindex-err"> · {pdfIndexProgress.errors} err</span>
              )}
              {indexEta && <span> · {indexEta}</span>}
            </div>
            {pdfIndexProgress.current_file && (
              <div className="settings-pdfindex-file" title={pdfIndexProgress.current_file}>
                {pdfIndexProgress.current_file}
              </div>
            )}
          </>
        ) : pdfIndexStats ? (
          <div className="settings-pdfindex-stats">
            <span>{pdfIndexStats.indexed.toLocaleString()} indexed</span>
            <span> · {pdfIndexStats.pages.toLocaleString()} pages</span>
            {pdfIndexStats.pending > 0 && <span> · {pdfIndexStats.pending.toLocaleString()} pending</span>}
            {pdfIndexStats.failed > 0 && (
              <span className="settings-pdfindex-err"> · {pdfIndexStats.failed} failed</span>
            )}
          </div>
        ) : null}
      </div>

      <div className="settings-row-field">
        <span title="Resets every PDF status row back to pending and re-extracts text from scratch. Hours on a large library — use only after changing the watermark term list or upgrading the indexer.">
          Force re-index everything
        </span>
        <button
          className="settings-action-btn settings-action-danger"
          disabled={forcing || pdfIndexRunning}
          onClick={handleForceReindex}
        >
          {forcing ? '…' : 'Force re-index'}
        </button>
      </div>

      <label className="settings-row-toggle">
        <input
          type="checkbox"
          checked={autoResume ?? true}
          disabled={autoResume === null}
          onChange={(e) => void toggleAutoResume(e.target.checked)}
        />
        <span title="When on, the indexer continues any pending PDFs automatically — on server start and after a scan finds new PDFs — without pressing anything.">
          Auto-index PDFs in the background
        </span>
      </label>

      <label className="settings-row-toggle">
        <input
          type="checkbox"
          checked={autoPdf}
          onChange={(e) => databankStore.setAutoPdf(e.target.checked)}
        />
        <span>Auto-load bound PDFs when opening a board</span>
      </label>

      <label className="settings-row-field">
        <span>Recent history depth</span>
        <input
          type="number"
          min={1}
          max={100}
          step={1}
          value={depthDraft}
          onChange={(e) => setDepthDraft(e.target.value)}
          onBlur={commitDepth}
          onKeyDown={(e) => { if (e.key === 'Enter') (e.target as HTMLInputElement).blur(); }}
        />
      </label>

      <div className="settings-row-field">
        <span>Recent history ({recentItems.length} item{recentItems.length === 1 ? '' : 's'})</span>
        <button
          className="settings-action-btn"
          disabled={recentItems.length === 0}
          onClick={() => databankStore.clearHistory()}
        >
          Clear
        </button>
      </div>
    </div>
  );
}

// ---- Scroll bindings editor (click a pill to cycle its action) ----
//
// One editor for both surfaces. Slots are independent — two of them may hold
// the same action — so this is a per-slot picker, not the old drag-to-swap
// permutation (which is what forced Shift+Scroll onto zoom whenever bare
// scroll panned, issue #40). Mirrored on the home dashboard in
// components/home/HomeBackdrop.tsx; labels and colours come from
// store/scroll-bindings.ts so the two cannot drift.

function SlotBindingsEditor<A extends ScrollAction>({ surface, slots, actions, value, onChange, onReset }: {
  surface: 'board' | 'pdf';
  slots: readonly ScrollSlot[];
  actions: readonly A[];
  value: Record<ScrollSlot, A>;
  onChange: (slot: ScrollSlot, action: A) => void;
  /** Present while the layout differs from the default. */
  onReset?: () => void;
}) {
  return (
    <div className="scroll-bindings-editor" data-testid={`scroll-bindings-${surface}`}>
      <div className="scroll-bindings-grid">
        {slots.map(slot => {
          const action = value[slot];
          return (
            <div key={slot} className="scroll-binding-slot">
              <span className="scroll-binding-modifier">{SLOT_LABEL[slot]}</span>
              <button
                type="button"
                className="scroll-binding-pill"
                style={{ '--pill-color': ACTION_COLOR[action] } as React.CSSProperties}
                data-testid={`scroll-slot-${surface}-${slot}`}
                data-action={action}
                title={`${SLOT_LABEL[slot]}: ${ACTION_LABEL[action]} — click to change`}
                onClick={() => onChange(slot, nextAction(actions, action))}
              >
                {ACTION_LABEL[action]}
              </button>
            </div>
          );
        })}
      </div>
      {value.shift !== 'pan' && (
        <p className="settings-hint scroll-bindings-note" data-testid={`scroll-note-${surface}`}>{SHIFT_SCROLL_NOTE}</p>
      )}
      {onReset && (
        <button className="scroll-bindings-reset" onClick={onReset}>Reset to default</button>
      )}
    </div>
  );
}

function ScrollBindingsEditor() {
  const [bindings, setBindings] = useState<ScrollBindings>(loadScrollBindings);

  // Re-sync when any other surface (HomeBackdrop, WelcomeSetup, DebugPanel,
  // PDF toolbar swap) changes the bindings while this editor is mounted.
  useEffect(() => {
    const onChange = () => setBindings(loadScrollBindings());
    window.addEventListener(SCROLL_BINDINGS_EVENT, onChange);
    return () => window.removeEventListener(SCROLL_BINDINGS_EVENT, onChange);
  }, []);

  const save = useCallback((next: ScrollBindings) => {
    setBindings(next);
    saveScrollBindings(next);
  }, []);

  const isDefault = sameScrollBindings(bindings, DEFAULT_SCROLL_BINDINGS);
  return (
    <SlotBindingsEditor
      surface="pdf"
      slots={SCROLL_SLOTS}
      actions={SCROLL_ACTIONS}
      value={bindings}
      onChange={(slot, action) => save({ ...bindings, [slot]: action })}
      onReset={isDefault ? undefined : () => save(DEFAULT_SCROLL_BINDINGS)}
    />
  );
}

// ---- PDF render quality selector ----
// The same four presets as the start page's PDF card (store/pdf-quality.ts).

function PdfQualitySelector() {
  const quality = usePdfQuality();
  const cfg = getPdfQualityConfig(quality);
  return (
    <div className="pdf-quality-selector">
      <div className="settings-btn-group">
        {PDF_RENDER_QUALITY_OPTIONS.map(q => (
          <button
            key={q}
            className={`settings-btn-option${quality === q ? ' active' : ''}`}
            onClick={() => setPdfQuality(q)}
            title={pdfQualityDescription(q)}
            data-testid={`settings-pdf-quality-${q}`}
          >
            {PDF_QUALITY_LABELS[q]}
          </button>
        ))}
      </div>
      <p className="settings-hint">{pdfQualityDescription(quality)}</p>
      <div className="pdf-quality-details" translate="no">
        <span>{`Page up to ${cfg.maxMainTier}× · neighbours ${cfg.maxAdjTier}× near, ${cfg.neighbourFarTier}× far · cache ${cfg.cacheMaxEntries} pages / ${Math.round(cfg.cacheMaxPixels / 1_000_000)} MP`}</span>
      </div>
    </div>
  );
}

// ---- Selected pins on the light schemes ----

const LIGHT_SELECTION_OPTIONS: { id: LightSelectionStyle; label: string; title: string }[] = [
  { id: 'highlighter', label: 'Highlighter', title: 'A yellow halo behind each pin, the pin in its own colour, a thin ink ring' },
  { id: 'ink', label: 'Ink pins', title: 'Each pin filled solid ink with a white rim' },
  { id: 'inkHighlighter', label: 'Ink on highlighter', title: 'Each pin filled solid ink on a yellow halo' },
];

/** How the selected net's pins are marked on Light and Atari, where a coloured
 *  glow does not show on paper. Other schemes keep their glow. */
function LightSelectionStyleRow({ value, onUpdate }: { value: LightSelectionStyle; onUpdate: DraftUpdater }) {
  useEffect(() => { recordRenderedField('lightSelectionStyle'); }, []);
  const { hidden, matched } = useFieldSearchState('lightSelectionStyle');
  if (hidden) return null;
  return (
    <div className={`settings-row${matched ? ' settings-search-match' : ''}`}
      title="How the pins of the selected net are marked on the light schemes (Light, Atari)">
      <label className="settings-label">Selected pins on light schemes</label>
      <div className="settings-btn-group">
        {LIGHT_SELECTION_OPTIONS.map(o => (
          <button key={o.id} type="button" title={o.title}
            className={`settings-btn-option${value === o.id ? ' active' : ''}`}
            data-testid={`settings-light-sel-${o.id}`}
            onClick={() => onUpdate({ lightSelectionStyle: o.id })}>
            {o.label}
          </button>
        ))}
      </div>
    </div>
  );
}

// ---- PDF render mode selector ----

const RENDER_MODE_LABELS: Record<'auto' | 'standard' | 'always-tile', string> = {
  auto: 'Auto',
  standard: 'Standard',
  'always-tile': 'Always tile',
};

const RENDER_MODE_DESCRIPTIONS: Record<'auto' | 'standard' | 'always-tile', string> = {
  auto: 'Tile above 1.05× zoom for crisp text at deep zoom. Full page below.',
  standard: 'Always render the full page into one canvas (Firefox-style). Smoother during pinch/zoom; pixels go soft past ~5–6× zoom on A4. Default.',
  'always-tile': 'Always tile. Mostly an escape hatch for debugging — rarely useful.',
};

function PdfRenderModeSelector() {
  const mode = useSyncExternalStore(
    cb => renderSettingsStore.subscribe(cb),
    () => renderSettingsStore.settings.pdfRenderMode,
  );

  const handleChange = useCallback((next: 'auto' | 'standard' | 'always-tile') => {
    renderSettingsStore.setPdfRenderMode(next);
  }, []);

  return (
    <div className="pdf-quality-selector">
      <div className="settings-btn-group">
        {(['auto', 'standard', 'always-tile'] as const).map(m => (
          <button
            key={m}
            className={`settings-btn-option${mode === m ? ' active' : ''}`}
            onClick={() => handleChange(m)}
            title={RENDER_MODE_DESCRIPTIONS[m]}
          >
            {RENDER_MODE_LABELS[m]}
          </button>
        ))}
      </div>
      <p className="settings-hint">{RENDER_MODE_DESCRIPTIONS[mode]}</p>
    </div>
  );
}

/** Format the stored filter array into a textarea-friendly string (one term per line). */
function formatWatermarkFilter(terms: string[]): string {
  return terms.join('\n');
}

/** Parse a textarea value into normalised filter terms (split on newline OR comma). */
function parseWatermarkFilter(raw: string): string[] {
  return raw.split(/[\n,]/).map(t => t.trim()).filter(t => t.length > 0);
}

function PdfWatermarkFilterEditor() {
  const storedTerms = renderSettingsStore.globalSettings.pdfWatermarkFilter;
  const [value, setValue] = useState(() => formatWatermarkFilter(storedTerms));
  // Track the terms that were committed while this editor instance was mounted.
  // Used to detect when the list changed so we can surface the reindex prompt.
  const committedRef = useRef<string[]>(storedTerms);
  const [showReindex, setShowReindex] = useState(false);
  const [reindexing, setReindexing] = useState(false);

  // Dirty when the textarea would commit to a different terms list than what's stored.
  const pendingTerms = parseWatermarkFilter(value);
  const dirty =
    pendingTerms.length !== storedTerms.length ||
    pendingTerms.some((t, i) => t !== storedTerms[i]);

  const commit = useCallback(() => {
    const next = parseWatermarkFilter(value);
    // Also pushes the list to the backend so the pdfium indexer uses it.
    setWatermarkTerms(next);
    // Normalise the textarea to the canonical form so the dirty flag clears.
    setValue(formatWatermarkFilter(next));

    // Detect whether the committed terms changed vs the last commit.
    const prev = committedRef.current;
    const changed = next.length !== prev.length || next.some((t, i) => t !== prev[i]);
    committedRef.current = next;
    if (changed) setShowReindex(true);
  }, [value]);

  const revert = useCallback(() => {
    setValue(formatWatermarkFilter(storedTerms));
  }, [storedTerms]);

  const handleReindex = useCallback(async () => {
    setReindexing(true);
    try {
      await pdfIndexClient.reindexWatermark();
      databankStore.startPdfIndexPolling();
      boardStore.addToast('Re-indexing PDFs with updated watermark terms…', 'info');
    } catch {
      boardStore.addToast('Failed to start reindex — check backend connection.', 'error');
    } finally {
      setReindexing(false);
      setShowReindex(false);
    }
  }, []);

  return (
    <div className="pdf-watermark-filter">
      <textarea
        className="settings-text-input pdf-watermark-textarea"
        rows={4}
        value={value}
        onChange={e => setValue(e.target.value)}
        onKeyDown={e => {
          // Ctrl / Cmd + Enter = save (plain Enter inserts a newline)
          if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
            e.preventDefault();
            commit();
          }
        }}
        placeholder={'One term per line\n(commas also accepted)'}
        spellCheck={false}
      />
      <div className="pdf-watermark-actions">
        <button
          type="button"
          className="settings-btn-option pdf-watermark-save"
          onClick={commit}
          disabled={!dirty}
          title={dirty ? 'Save watermark filter (Ctrl/Cmd + Enter)' : 'No unsaved changes'}
        >
          {dirty ? 'Save' : 'Saved'}
        </button>
        {dirty && (
          <button
            type="button"
            className="settings-btn-option pdf-watermark-revert"
            onClick={revert}
            title="Discard changes"
          >
            Revert
          </button>
        )}
      </div>
      {showReindex && hasBackend() && (
        <div className="pdf-watermark-reindex-prompt">
          <span className="pdf-watermark-reindex-hint">
            Watermark terms changed — reindex PDFs to apply?
          </span>
          <button
            type="button"
            className="settings-btn-option pdf-watermark-reindex-btn"
            onClick={handleReindex}
            disabled={reindexing}
            title="Reset and re-run PDF text indexing with the new watermark terms"
          >
            {reindexing ? 'Starting…' : 'Reindex PDFs'}
          </button>
          <button
            type="button"
            className="settings-btn-option pdf-watermark-reindex-dismiss"
            onClick={() => setShowReindex(false)}
            title="Dismiss — reindex later"
          >
            Dismiss
          </button>
        </div>
      )}
      <p className="settings-hint">
        One term per line (or comma-separated). Matches ignore case and whitespace,
        so "www.chinafix.com" catches "w w w . c h i n a f i x . c o m". Matching
        text is erased before rendering. Press Ctrl/Cmd + Enter to save.
      </p>
    </div>
  );
}

// ---- Board scroll bindings editor ----
//
// The board's slots live in three render-settings keys (twoFingerPan is the
// bare slot). The ⌘ slot is shown on macOS only: elsewhere `metaKey` is the
// Windows key, and Ctrl is the pinch/fast-zoom path that cannot be
// reassigned.

const BOARD_SLOTS: readonly ScrollSlot[] = isMacPlatform ? ['bare', 'shift', 'meta'] : ['bare', 'shift'];

function BoardScrollBindingsEditor({ draft, onUpdate }: { draft: BoardScrollSettings; onUpdate: DraftUpdater }) {
  const bindings = boardScrollBindings(draft);
  const isDefault = bindings.bare === DEFAULT_BOARD_SCROLL_BINDINGS.bare
    && bindings.shift === DEFAULT_BOARD_SCROLL_BINDINGS.shift
    && bindings.meta === DEFAULT_BOARD_SCROLL_BINDINGS.meta;
  return (
    <SlotBindingsEditor
      surface="board"
      slots={BOARD_SLOTS}
      actions={BOARD_SCROLL_ACTIONS}
      value={bindings}
      onChange={(slot, action) => onUpdate(boardScrollSettings({ ...bindings, [slot]: action }))}
      onReset={isDefault ? undefined : () => onUpdate(boardScrollSettings(DEFAULT_BOARD_SCROLL_BINDINGS))}
    />
  );
}

// ---- Board drag bindings editor ----

type BoardDragAction = 'pan' | 'zoom';
const BOARD_DRAG_ACTIONS: BoardDragAction[] = ['pan', 'zoom'];

const BOARD_DRAG_MODIFIER_KEYS = ['bare', 'shift'] as const;
type BoardDragModifier = typeof BOARD_DRAG_MODIFIER_KEYS[number];
const BOARD_DRAG_MODIFIER_LABELS: Record<BoardDragModifier, React.ReactNode> = {
  bare: 'Left-drag',
  shift: 'Shift + Left-drag',
};

function BoardDragBindingsEditor({ dragToZoom, onUpdate }: { dragToZoom: boolean; onUpdate: DraftUpdater }) {
  // Derive bindings: bare=zoom when dragToZoom, else bare=pan
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const bindings: Record<BoardDragModifier, BoardDragAction> = {
    bare: dragToZoom ? 'zoom' : 'pan',
    shift: dragToZoom ? 'pan' : 'zoom',
  };

  const [dragging, setDragging] = useState<BoardDragAction | null>(null);
  const [dragOver, setDragOver] = useState<BoardDragModifier | null>(null);

  const handleDragStart = useCallback((e: React.DragEvent, action: BoardDragAction) => {
    setDragging(action);
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', action);
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent, slot: BoardDragModifier) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    setDragOver(slot);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent, targetSlot: BoardDragModifier) => {
    e.preventDefault();
    setDragOver(null);
    setDragging(null);
    const action = e.dataTransfer.getData('text/plain') as BoardDragAction;
    if (!BOARD_DRAG_ACTIONS.includes(action)) return;
    const sourceSlot = BOARD_DRAG_MODIFIER_KEYS.find(k => bindings[k] === action);
    if (!sourceSlot || sourceSlot === targetSlot) return;
    // Swapping bare and shift means toggling dragToZoom
    onUpdate({ dragToZoom: targetSlot === 'bare' && action === 'zoom' });
  }, [bindings, onUpdate]);

  const handleDragEnd = useCallback(() => { setDragging(null); setDragOver(null); }, []);

  return (
    <div className="scroll-bindings-editor">
      <div className="scroll-bindings-grid">
        {BOARD_DRAG_MODIFIER_KEYS.map(slot => {
          const action = bindings[slot];
          const isOver = dragOver === slot;
          return (
            <div key={slot} className={`scroll-binding-slot${isOver ? ' drag-over' : ''}`}
              onDragOver={e => handleDragOver(e, slot)}
              onDragLeave={() => setDragOver(null)}
              onDrop={e => handleDrop(e, slot)}>
              <span className="scroll-binding-modifier">{BOARD_DRAG_MODIFIER_LABELS[slot]}</span>
              <span
                className={`scroll-binding-pill${dragging === action ? ' dragging' : ''}`}
                style={{ '--pill-color': ACTION_COLOR[action] } as React.CSSProperties}
                draggable onDragStart={e => handleDragStart(e, action)} onDragEnd={handleDragEnd}>
                {ACTION_LABEL[action]}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ---- PDF inertia toggle ----

function PdfInertiaToggle() {
  const [enabled, setEnabled] = useState(loadPdfInertia);
  const toggle = useCallback(() => {
    const next = !enabled;
    setEnabled(next);
    try { localStorage.setItem(PDF_INERTIA_KEY, String(next)); } catch { /* ignore */ }
    window.dispatchEvent(new CustomEvent('pdf-inertia-changed'));
  }, [enabled]);
  return (
    <div className="settings-row settings-toggle-row" title="Continue panning with momentum after releasing the drag. When disabled, panning stops immediately on release. Note: trackpad scroll momentum is controlled by your OS settings and cannot be disabled by the app">
      <label className="settings-label">Inertia</label>
      <input type="checkbox" checked={enabled} onChange={toggle} />
    </div>
  );
}

// ---- Main panel ----

type SettingsMode = 'global' | 'board';

/**
 * Prominent cache-control bar at the top of the Settings panel. Three
 * scoped actions so the user doesn't have to wipe the whole database to
 * see the effect of a parser fix or a stale render.
 */
function CacheControlBar({ hasBoard }: { hasBoard: boolean }) {
  const [busy, setBusy] = useState<null | 'reparse' | 'boards' | 'pdf'>(null);

  const run = async (tag: 'reparse' | 'boards' | 'pdf', fn: () => Promise<unknown>) => {
    if (busy) return;
    setBusy(tag);
    try { await fn(); } finally { setBusy(null); }
  };

  return (
    <div className="settings-cache-bar" role="group" aria-label="Cache control">
      <div className="settings-cache-bar-title">Cache</div>
      <div className="settings-cache-bar-buttons">
        <button
          className="settings-cache-btn"
          onClick={() => run('reparse', () => boardStore.reparseActiveBoard())}
          disabled={!hasBoard || busy !== null}
          title="Delete the cache entry for the current board and re-run the parser on it. Fastest way to pick up a parser fix on the file you're looking at."
        >
          {busy === 'reparse' ? 'Re-parsing…' : 'Re-parse current'}
        </button>
        <button
          className="settings-cache-btn"
          onClick={() => run('boards', () => boardStore.resetBoardCaches())}
          disabled={busy !== null}
          title="Clear all cached parsed boards from IndexedDB and re-parse every open tab. PDF caches are left alone."
        >
          {busy === 'boards' ? 'Clearing…' : 'Reset board caches'}
        </button>
        <button
          className="settings-cache-btn"
          onClick={() => run('pdf', () => boardStore.resetPdfCaches())}
          disabled={busy !== null}
          title="Clear cached PDF text, tile bitmaps, font glyphs, and watermark skip sets. Board parses are left alone."
        >
          {busy === 'pdf' ? 'Clearing…' : 'Reset PDF caches'}
        </button>
      </div>
    </div>
  );
}

/**
 * Wipes every preference this browser stored and reloads — the way back from
 * a setting that broke the board, without clearing site data by hand. Two
 * clicks: the first arms it, the second (within 5 s) runs it.
 */
function LocalSettingsResetBar() {
  const [armed, setArmed] = useState(false);
  useEffect(() => {
    if (!armed) return;
    const t = setTimeout(() => setArmed(false), 5000);
    return () => clearTimeout(t);
  }, [armed]);
  return (
    <div className="settings-cache-bar" role="group" aria-label="Local settings">
      <div className="settings-cache-bar-title">Local settings</div>
      <div className="settings-cache-hint">
        Every setting this browser saved — view, theme, layout, panels — back to its default, then the page reloads.
        Recent files, favourites, history, worklists, bookmarks and cached boards are kept.
      </div>
      <div className="settings-cache-bar-buttons">
        <button
          className={`settings-cache-btn${armed ? ' settings-cache-btn-danger' : ''}`}
          data-testid="reset-local-settings"
          onClick={() => { if (armed) resetLocalSettings(); else setArmed(true); }}
        >
          {armed ? 'Click again to reset and reload' : 'Reset all local settings'}
        </button>
      </div>
    </div>
  );
}

export function SettingsPanel() {
  // The active file name only, not the whole board snapshot.
  const activeFileName = useSyncExternalStore(subscribeBoardName, getBoardFileName);
  const hasBoard = !!activeFileName;

  // Mode: global settings vs per-board overrides
  const [mode, setMode] = useState<SettingsMode>('global');
  // Force mode to global when no board is open
  const effectiveMode = hasBoard ? mode : 'global';
  const isBoardMode = effectiveMode === 'board';

  const baselineRef = useRef<RenderSettings>(
    isBoardMode ? renderSettingsStore.boardSnapshot() : renderSettingsStore.globalSnapshot()
  );
  const [draft, setDraft] = useState<RenderSettings>(() =>
    isBoardMode ? renderSettingsStore.boardSnapshot() : renderSettingsStore.globalSnapshot()
  );
  const [previewing, setPreviewing] = useState(false);
  const [dirty, setDirty] = useState(false);
  // 2R Tools (Roger, 10/10/2026): «alterar em tempo real cada barra dessa, para saber de
  // onde é» — no 2R cada mudança aparece na placa na hora (Apply grava, Cancelar volta).
  useEffect(() => {
    if (!IS_2R || !dirty) return;
    // 0.50.2: applySettings virou previewSettings(settings, camada) — o tema fica por cima, sem gravar a paleta
    renderSettingsStore.previewSettings(draft, isBoardMode ? 'board' : 'global');
    setPreviewing(true);
  }, [draft, dirty]); // eslint-disable-line react-hooks/exhaustive-deps
  const previewingRef = useRef(previewing);
  previewingRef.current = previewing;
  // What the draft stands for: global⊕board in board mode, global otherwise.
  // The store layers board overrides / the theme on top accordingly.
  const previewLayer = isBoardMode ? 'board' as const : 'global' as const;
  const previewLayerRef = useRef(previewLayer);
  previewLayerRef.current = previewLayer;

  // Reset draft/baseline when mode changes
  useEffect(() => {
    const snap = isBoardMode ? renderSettingsStore.boardSnapshot() : renderSettingsStore.globalSnapshot();
    baselineRef.current = structuredClone(snap);
    setDraft(structuredClone(snap));
    setDirty(false);
    if (previewing) { renderSettingsStore.endPreview(); setPreviewing(false); }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [effectiveMode, activeFileName]);

  // Tabs + collapsible sections
  const [activeTab, setActiveTabState] = useState<SettingsTabId>(() => loadActiveTab());
  const [openSections, setOpenSections] = useState<Set<SectionId>>(() => loadOpenSections(loadActiveTab()));

  // Persist open sections per tab whenever they change.
  useEffect(() => {
    saveOpenSections(activeTab, openSections);
  }, [activeTab, openSections]);

  const setActiveTab = useCallback((id: SettingsTabId) => {
    setActiveTabState(id);
    saveActiveTab(id);
    setOpenSections(loadOpenSections(id));
  }, []);

  const [focusedSection, setFocusedSection] = useState<SectionId | null>(null);
  const focusTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Section scroll refs
  const outlineRef = useRef<HTMLDivElement>(null);
  const partsRef = useRef<HTMLDivElement>(null);
  const pinsRef = useRef<HTMLDivElement>(null);
  const netColorsRef = useRef<HTMLDivElement>(null);
  const selectionRef = useRef<HTMLDivElement>(null);
  const netLinesRef = useRef<HTMLDivElement>(null);
  const navigationRef = useRef<HTMLDivElement>(null);
  const performanceRef = useRef<HTMLDivElement>(null);
  const shortcutsRef = useRef<HTMLDivElement>(null);
  const partTypeOverridesRef = useRef<HTMLDivElement>(null);
  const zoomLodRef = useRef<HTMLDivElement>(null);
  const serverRef = useRef<HTMLDivElement>(null);
  const dbinfoRef = useRef<HTMLDivElement>(null);
  const pdfRef = useRef<HTMLDivElement>(null);
  const boardOverlayRef = useRef<HTMLDivElement>(null);

  const sectionRefsMapRef = useRef<Record<SectionId, React.RefObject<HTMLDivElement | null>>>({
    outline: outlineRef, parts: partsRef, pins: pinsRef,
    netColors: netColorsRef, selection: selectionRef, zoomLod: zoomLodRef, netLines: netLinesRef, navigation: navigationRef,
    performance: performanceRef, shortcuts: shortcutsRef,
    partTypeOverrides: partTypeOverridesRef, server: serverRef, dbinfo: dbinfoRef, pdf: pdfRef,
    boardOverlay: boardOverlayRef,
  });

  const toggleSection = useCallback((id: SectionId) => {
    setOpenSections(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }, []);

  const focusSection = useCallback((id: SectionId) => {
    const targetTab = SECTION_TO_TAB[id];
    if (targetTab && targetTab !== activeTab) {
      setActiveTab(targetTab);
    }
    setOpenSections(prev => { const next = new Set(prev); next.add(id); return next; });
    requestAnimationFrame(() => {
      sectionRefsMapRef.current[id]?.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    });
    if (focusTimerRef.current) clearTimeout(focusTimerRef.current);
    setFocusedSection(id);
    focusTimerRef.current = setTimeout(() => setFocusedSection(null), 1400);
  }, [activeTab, setActiveTab]);

  // External deep-link: other panels dispatch 'settings-focus-section' with a
  // SectionId (e.g. the Library empty state pointing at the scan controls).
  // The sidebar tab itself is switched by the caller via showSidebarTab.
  useEffect(() => {
    const onFocus = (e: Event) => {
      const id = (e as CustomEvent<SectionId>).detail;
      if (id && SECTION_TO_TAB[id]) focusSection(id);
    };
    window.addEventListener('settings-focus-section', onFocus);
    return () => window.removeEventListener('settings-focus-section', onFocus);
  }, [focusSection]);
  // 2R Tools: o menu de cima abre uma aba dos Ajustes (ex.: Tema)
  useEffect(() => {
    const onTab = (e: Event) => {
      const t = (e as CustomEvent<string>).detail as SettingsTabId;
      if (TAB_ORDER.includes(t)) setActiveTab(t);
    };
    window.addEventListener('settings-open-tab', onTab);
    return () => window.removeEventListener('settings-open-tab', onTab);
  }, [setActiveTab]);

  const updateDraft: DraftUpdater = useCallback((partial) => {
    setDraft(prev => {
      const next = { ...prev, ...partial };
      if (previewingRef.current) renderSettingsStore.previewSettings(next, previewLayerRef.current);
      return next;
    });
    setDirty(true);
  }, []);

  // Immediate global commit for input-behavior / system fields (Input +
  // System tabs). No draft, no Apply — matches what QuickSettings on the
  // home screen already does for the same fields. The draft + Apply
  // pipeline is reserved for the Board tab (visual render settings +
  // per-board overrides). Baseline is advanced too so these edits never
  // show up in the board-tab dirty diff.
  // applyGlobal notifies synchronously, which fires the re-sync subscriber
  // below. In Board mode that subscriber would rebuild the draft from the
  // *effective* (global+override) snapshot and corrupt the baselines of
  // other override-carrying global-only fields. Guard against our own notify.
  const selfUpdateRef = useRef(false);
  const updateGlobal: DraftUpdater = useCallback((partial) => {
    selfUpdateRef.current = true;
    try {
      renderSettingsStore.applyGlobal({ ...renderSettingsStore.globalSettings, ...partial });
    } finally {
      selfUpdateRef.current = false;
    }
    baselineRef.current = { ...baselineRef.current, ...partial };
    setDraft(prev => ({ ...prev, ...partial }));
  }, []);

  // HDR capability drives only the *hint text* on the glow toggle — the control
  // stays visible and usable either way, so docking to an SDR monitor explains
  // itself instead of silently doing nothing.
  const [hdrCapable, setHdrCapable] = useState(isHdrCapable);
  useEffect(() => onHdrCapabilityChange(setHdrCapable), []);

  // Re-sync draft + baseline when the store changes underneath us (e.g.
  // QuickSettings on the home screen, theme poke) while nothing is being
  // edited here — otherwise a later Apply would clobber those changes with
  // a stale snapshot. Skipped while dirty, previewing, or for our own
  // updateGlobal-originated notifies.
  const dirtyRef = useRef(dirty);
  dirtyRef.current = dirty;
  useEffect(() => {
    return renderSettingsStore.subscribe(() => {
      if (selfUpdateRef.current || dirtyRef.current || previewingRef.current) return;
      const snap = isBoardMode ? renderSettingsStore.boardSnapshot() : renderSettingsStore.globalSnapshot();
      baselineRef.current = structuredClone(snap);
      setDraft(structuredClone(snap));
    });
  }, [isBoardMode]);

  // Pin-colour rules, NC patterns and component fills moved to the Theme tab
  // (carried by the theme), so their Board-tab edit handlers were removed.

  const handleApply = () => {
    if (isBoardMode) {
      // Compute sparse diff against global and store as board overrides
      const global = renderSettingsStore.globalSettings;
      const overrides = computeOverrides(global, draft);
      renderSettingsStore.setBoardOverrides(activeFileName, overrides);
    } else {
      // Surgical apply: merge only the fields the user actually edited
      // (diff vs baseline) onto the CURRENT global settings, so changes
      // made elsewhere while this panel was open are never clobbered.
      const changed = computeOverrides(baselineRef.current, draft);
      renderSettingsStore.applyGlobal({ ...renderSettingsStore.globalSettings, ...changed });
    }
    baselineRef.current = structuredClone(draft);
    setDirty(false); setPreviewing(false);
  };
  const handleCancel = () => {
    if (previewing) renderSettingsStore.endPreview();
    setDraft(structuredClone(baselineRef.current));
    setDirty(false); setPreviewing(false);
  };
  const handlePreview = () => {
    if (previewing) {
      renderSettingsStore.endPreview();
      setPreviewing(false);
    } else {
      renderSettingsStore.previewSettings(draft, previewLayer);
      setPreviewing(true);
    }
  };
  const handleReset = () => {
    if (isBoardMode) {
      // Reset to global (clear all board overrides)
      const global = renderSettingsStore.globalSnapshot();
      setDraft(global);
      setDirty(true);
      if (previewing) renderSettingsStore.previewSettings(global, 'board');
    } else {
      const defaults = structuredClone(DEFAULTS);
      setDraft(defaults);
      setDirty(true);
      if (previewing) renderSettingsStore.previewSettings(defaults, 'global');
    }
  };

  const overrideCtx = useMemo<OverrideCtx>(() => ({
    isBoardMode,
    globalSettings: renderSettingsStore.globalSettings,
    draft,
  }), [isBoardMode, draft]);

  const panelRef = useRef<HTMLDivElement>(null);

  return (
    <SettingsSearchProvider>
    <div className="panel-content settings-panel" data-testid="settings-panel" ref={panelRef}>
      <div className="settings-top">
        {/* Tab strip — fixed-width icon cells so icons never shift; the open
            tab's name sits underneath its icon, centred. Same library-tab
            base styling as the Library panel's strip. */}
        <div className="library-tabs-row settings-tabs-row">
          <div className="library-tabs" style={{ flex: '1 1 auto', minWidth: 0 }}>
            {TAB_ORDER.map(tab => (
              <TabPill key={tab} tab={tab} activeTab={activeTab} setActiveTab={setActiveTab} />
            ))}
          </div>
        </div>

        {/* ── Search bar (under the tabs) — type or press / to focus, Esc to clear ── */}
        <SettingsSearchBar />

        {/* Mode switch + draft footer govern ONLY the Board tab — every other
            tab commits immediately (updateGlobal / own stores), so rendering
            Apply/Cancel there would act on invisible state. */}
        {activeTab === 'board' && (
          <>
            <InteractiveModeToggle />

            {/* ── Mode switch: Global vs Board ── */}
            <div className="settings-mode-switch">
              <button
                className={`settings-mode-btn${effectiveMode === 'global' ? ' active' : ''}`}
                onClick={() => setMode('global')}
              >Global</button>
              <button
                className={`settings-mode-btn${effectiveMode === 'board' ? ' active' : ''}`}
                onClick={() => setMode('board')}
                disabled={!hasBoard}
                title={hasBoard ? `Board overrides for ${activeFileName}` : 'Open a board to edit per-board settings'}
              >Board</button>
            </div>
            <div className="settings-mode-hint">
              {isBoardMode
                ? <>Overrides for <strong>{activeFileName}</strong> &middot; <span className="settings-override-legend">yellow</span> = overridden</>
                : 'Changes apply to all boards'}
            </div>

            {/* Render preview (SettingsMockup) is silently disabled for now —
                kept in the tree via the import so we can flip it back quickly
                by toggling SHOW_MOCKUP_PREVIEW to true. */}
            {SHOW_MOCKUP_PREVIEW && <SettingsMockup settings={draft} onElementClick={focusSection} />}
            <div className="settings-footer">
              {IS_2R ? <span className="r2-live-hint">{dirty ? '● ao vivo na placa' : 'mexa: muda na placa na hora'}</span> : <button
                className={`settings-action-btn ${previewing ? 'active' : ''}`}
                onClick={handlePreview} disabled={!dirty}
                title={previewing ? 'Stop preview, revert board to saved' : 'Preview changes on the board'}
              >
                {previewing ? 'Stop Preview' : 'Preview'}
              </button>}
              <button className="settings-action-btn settings-apply-btn" onClick={handleApply} disabled={!dirty}>Apply</button>
              <button className="settings-action-btn" onClick={handleCancel} disabled={!dirty}>Cancel</button>
            </div>
          </>
        )}
      </div>
      <OverrideContext.Provider value={overrideCtx}>
      <div className="settings-scroll">

      <SearchEmptyState activeTab={activeTab} goTab={setActiveTab} />

      {activeTab === 'theme' && (
        <ThemeTab />
      )}

      {activeTab === SECTION_TO_TAB.outline && (
      <CollapsibleSection id="outline" title="Board Outline" isOpen={openSections.has('outline')}
        onToggle={toggleSection} sectionRef={outlineRef} isFocused={focusedSection === 'outline'}>
        <Slider label="Stroke Width" value={draft.outlineWidth} min={0.5} max={20} step={0.5} field="outlineWidth" onUpdate={updateDraft}
          title="Thickness of the PCB board outline stroke (mils)" />
        <Slider label="Stroke Opacity" value={draft.outlineAlpha} min={0} max={1} step={0.05} field="outlineAlpha" onUpdate={updateDraft}
          title="Transparency of the board outline. 0 = invisible, 1 = fully opaque" />
        <Slider label="Board Fill" value={draft.boardFillAlpha} min={0} max={0.5} step={0.01} field="boardFillAlpha" onUpdate={updateDraft}
          title="Semi-transparent fill inside the board outline. Helps distinguish the PCB area from the background" />
        <Toggle label="Use board metadata color" value={draft.useMetadataBoardColor} field="useMetadataBoardColor" onUpdate={updateDraft}
          title="When on, boards with a known PCB color (Apple → black, Dell → blue, etc.) render with that tint instead of the theme default. Boards without a metadata match silently fall back to the theme default. Intensity is the Board Fill slider above." />
      </CollapsibleSection>
      )}

      {activeTab === SECTION_TO_TAB.parts && (
      <CollapsibleSection id="parts" title="Parts / Components" isOpen={openSections.has('parts')}
        onToggle={toggleSection} sectionRef={partsRef} isFocused={focusedSection === 'parts'}>
        <Slider label="Border Width" value={draft.partBorderWidth} min={0.1} max={10} step={0.1} field="partBorderWidth" onUpdate={updateDraft}
          title="Thickness of component border outlines (mils). Always at least 1px on screen regardless of zoom" />
        <Slider label="Border Opacity" value={draft.partBorderAlpha} min={0} max={1} step={0.05} field="partBorderAlpha" onUpdate={updateDraft}
          title="Transparency of component border outlines. 0 = invisible, 1 = fully opaque" />
        <Slider label="Padding" value={draft.partPadding} min={0} max={30} step={1} field="partPadding" onUpdate={updateDraft}
          title="Extra space (mils) between component pins and the part border. Larger = more room around the IC/chip outline" />
        <Slider label="2-Pin Body Ratio" value={draft.partMinBodyRatio} min={0} max={1} step={0.01} field="partMinBodyRatio" onUpdate={updateDraft}
          title="Short-axis to pin-distance ratio for 2-pin parts (resistors, capacitors). 0.333 = 1:3 proportion. 0 = use file data as-is" />
        {/* Type colours: name/thumb toggle showComponentColors, drag sets the fill opacity. */}
        <Slider label="Type colours" value={draft.componentFillAlpha} min={0} max={1} step={0.05} field="componentFillAlpha" toggleField="showComponentColors" onUpdate={updateDraft}
          title="Transparency of the component type color fills. 0 = invisible, 1 = fully opaque" />
        <Slider label="Part names" value={draft.partLabelScale ?? 1} min={0.3} max={4} step={0.1} field="partLabelScale" toggleField="showPartLabels" unit="×" onUpdate={updateDraft}
          title="Show component designators (U1, R100…); the slider scales the auto-fit size. Click the name or the thumb to turn them off." />
        <Toggle label="Label Drop Shadow" value={draft.partLabelShadow} field="partLabelShadow" onUpdate={updateDraft}
          title="Add a dark shadow halo behind part labels for better readability against colored or busy backgrounds" />
        <Toggle label="Pin Label Shadow" value={draft.pinLabelShadow} field="pinLabelShadow" onUpdate={updateDraft}
          title="Add a dark shadow halo behind on-pin labels (pin numbers and net names) for readability. Net names were previously always shadowed; turn this off for crisp, shadow-free pin text." />
        <Toggle label="Hide Mechanical Fills" value={draft.autoMarkMechanical} field="autoMarkMechanical" onUpdate={updateDraft}
          title="Auto-detect EMI shields, heatsink frames and oversized through-hole connector shadows (footprint contains ≥5 other component origins, or description contains SHIELD/HEATSINK/FRAME, or trailing-dot duplicates). Detected parts render without a body fill — border outline and pins still draw — so smaller components beneath stay visible. Right-click any part for a per-component override." />
        <Slider label="Min Label Size" value={draft.labelMinSize} min={1} max={30} step={1} field="labelMinSize" onUpdate={updateDraft}
          title="Minimum font size (board mils) for part / pin / net-name labels. Acts as a floor on the auto-computed size, so tiny components still get a readable label. Labels smaller than the Zoom LOD thresholds are still hidden." />
      </CollapsibleSection>
      )}

      {activeTab === SECTION_TO_TAB.pins && (
      <CollapsibleSection id="pins" title="Pins / Pads" isOpen={openSections.has('pins')}
        onToggle={toggleSection} sectionRef={pinsRef} isFocused={focusedSection === 'pins'}>
        <Slider label="Min Radius" value={draft.pinMinRadius} min={1} max={20} step={0.5} field="pinMinRadius" onUpdate={updateDraft}
          title="Minimum pin circle radius (mils). All pins are rendered at least this size. Also the base size when Scale Factor = 0" />
        <Slider label="Max Radius" value={draft.pinMaxRadius} min={5} max={100} step={1} field="pinMaxRadius" onUpdate={updateDraft}
          title="Maximum pin circle radius (mils). Caps the visual size of large pins. On dense parts (BGA), pins are auto-clamped smaller to avoid overlap" />
        <Slider label="Scale Factor" value={draft.pinScaleFactor} min={0} max={3} step={0.1} field="pinScaleFactor" onUpdate={updateDraft}
          title="How much the file-specified pin radius affects rendered size. 0 = all pins identical (Min Radius). 1 = proportional to file data. >1 = exaggerated differences" />
        <Slider label="Fill Opacity" value={draft.pinAlpha} min={0} max={1} step={0.05} field="pinAlpha" onUpdate={updateDraft}
          title="Fill transparency of pin circles and rectangular pads. 0 = invisible, 1 = fully opaque" />
        <Slider label="Pin numbers" value={draft.pinNumberScale ?? 1} min={0.3} max={4} step={0.1} field="pinNumberScale" toggleField="showPinNumbers" unit="×" onUpdate={updateDraft}
          title="Show pin numbers on ICs and connectors; the slider scales them. Click the name or the thumb to turn them off." />
        <Slider label="Net names" value={draft.netLabelScale ?? 1} min={0.3} max={4} step={0.1} field="netLabelScale" toggleField="showNetNames" unit="×" onUpdate={updateDraft}
          title="Show net names on pins (GND and NC are excluded — already colour-coded); the slider scales them." />
        <Slider label="Diode values" value={draft.diodeValueScale ?? 1} min={0.3} max={4} step={0.1} field="diodeValueScale" toggleField="showDiodeValues" unit="×" onUpdate={updateDraft}
          title="Draw diode-mode readings on pins (from the file or OpenBoardData); the slider scales them." />
        <Toggle label="Diode Values Only" value={draft.diodeValuesOnly} field="diodeValuesOnly" onUpdate={updateDraft}
          title="While diode values are shown, hide pin numbers and net names board-wide so a pin carries nothing but its reading. Your Show Pin Numbers / Show Net Names settings are left untouched and come back when this is off. Same as the third state of the diode button on the board overlay" />
        <Toggle label="Pin 1 Marker" value={draft.showPin1Marker} field="showPin1Marker" onUpdate={updateDraft}
          title="Highlight pin 1 with red color and a triangle indicator on multi-pin parts" />
        <Toggle label="Pin Label Background" value={draft.pinNetLabelBg} field="pinNetLabelBg" onUpdate={updateDraft}
          title="Draw a dark background plate behind net name labels on circle pins. Improves readability when labels overflow beyond the pin area" />
        <Toggle label="2-Pin Label Background" value={draft.twoPinNetLabelBg} field="twoPinNetLabelBg" onUpdate={updateDraft}
          title="Draw a dark background plate behind net name labels on 2-pin rectangular pads" />
        <Slider label="BGA Label Gap" value={draft.bgaLabelGapFactor} min={0} max={1} step={0.05} field="bgaLabelGapFactor" onUpdate={updateDraft}
          title="Visible vertical gap between pin number and net name labels on dense BGA parts, as a fraction of pin radius. On BGAs, pin numbers and net names alternate above/below the pin center to avoid overlap. 0 = labels meet at the pin center; larger = more visible separation" />
      </CollapsibleSection>
      )}

      {/* Navigation first — gesture/scroll setup is the most important thing a
          new user configures, so it leads the Input tab. */}
      {activeTab === SECTION_TO_TAB.navigation && (
      <CollapsibleSection id="navigation" title="Navigation" isOpen={openSections.has('navigation')}
        onToggle={toggleSection} sectionRef={navigationRef} isFocused={focusedSection === 'navigation'}>
        <div className="settings-row settings-toggle-row" title="Re-open the first-run gesture wizard: do the gesture you want for each pan/zoom action and it configures the bindings for you.">
          <label className="settings-label">Interactive gesture setup</label>
          <button
            className="settings-action-btn"
            style={{ marginLeft: 'auto' }}
            onClick={() => welcomeStore.show()}
          >
            Re-run setup…
          </button>
        </div>
        <div className="settings-subsection-label">Scroll wheel behavior</div>
        <p className="settings-hint">Click a pill to change what that scroll does. Pinch and Ctrl+Scroll always zoom, dragging always pans.</p>
        <BoardScrollBindingsEditor draft={draft} onUpdate={updateGlobal} />
        <Toggle
          label="Mouse wheel detection"
          value={draft.wheelDetection}
          field="wheelDetection"
          onUpdate={updateGlobal}
          title="When scroll is set to pan, classic mouse-wheel events override to zoom instead — avoids jerky pan with a physical scroll wheel. Trackpads and fine-grained wheels are unaffected."
        />

        <div className="settings-subsection-label">Trackpad/Mouse drag behavior</div>
        <p className="settings-hint">Drag pills between slots to swap left-drag and Shift+left-drag actions.</p>
        <BoardDragBindingsEditor dragToZoom={draft.dragToZoom} onUpdate={updateGlobal} />

        <div className="settings-subsection-label">Keyboard pan / zoom</div>
        <div className="settings-row" title="Fraction of screen dimension panned per WSAD or Alt+Arrow keypress. Default: 10% of screen width/height per press.">
          <label className="settings-label">
            Keyboard Pan Step
            <span className="settings-value">{Math.round(draft.keyboardPanFraction * 100)}%</span>
          </label>
          <div className="settings-slider-wrap">
            <input
              type="range" className="settings-slider"
              min={2} max={30} step={1}
              value={Math.round(draft.keyboardPanFraction * 100)}
              onChange={(e) => updateGlobal({ keyboardPanFraction: parseFloat(e.target.value) / 100 })}
              onDoubleClick={() => updateGlobal({ keyboardPanFraction: DEFAULTS.keyboardPanFraction })}
            />
          </div>
        </div>
        <Slider
          label="Keyboard Zoom Step"
          value={draft.keyboardZoomDelta}
          min={50} max={400} step={10}
          field="keyboardZoomDelta" onUpdate={updateGlobal}
          title={`Raw zoom delta per Shift+W / Shift+S keypress. Applies to both board and PDF. Current: ×${Math.pow(2, 1.3 * (draft.keyboardZoomDelta / 500)).toFixed(2)} per press. Default: 100 (≈×1.32).`}
        />

        <div className="settings-subsection-label">Zoom</div>
        <Slider label="Wheel Smoothing" value={draft.wheelSmooth} min={1} max={20} step={1} field="wheelSmooth" onUpdate={updateGlobal}
          title="Mouse wheel zoom smoothness. 1 = instant snap, higher = smoother animated zoom. Default: 5" />
        <Slider label="Fit Padding" value={draft.fitPadding} min={0} max={200} step={10} field="fitPadding" onUpdate={updateGlobal}
          title="Extra padding (screen pixels) added when fitting the board to the viewport (Fit to Screen, double-click zoom). Prevents the board from touching viewport edges" />

        <div className="settings-subsection-label">Navigate-to-component</div>
        <Slider label="Component Size" value={draft.navTargetSize} min={0.05} max={0.90} step={0.05} field="navTargetSize" onUpdate={updateGlobal}
          title="Target on-screen size of a component after navigating to it from search / NetList / Worklist. Expressed as a fraction of the smaller viewport dimension. Default 0.25 (~25%)." />
        <div className="settings-row" data-test="nav-zoom-mode" title="How navigation should treat zoom level.">
          <label className="settings-label">Zoom Mode</label>
          <div className="settings-btn-group" style={{ marginLeft: 'auto' }}>
            <button
              className={`settings-btn-option${draft.navZoomMode === 'auto' ? ' active' : ''}`}
              onClick={() => updateGlobal({ navZoomMode: 'auto' })}
              title="Auto — keep current zoom when the part is in the comfortable band (1.5%–70% of screen). Snap to Component Size only when extreme."
              data-test="nav-zoom-auto"
            >Auto</button>
            <button
              className={`settings-btn-option${draft.navZoomMode === 'keep' ? ' active' : ''}`}
              onClick={() => updateGlobal({ navZoomMode: 'keep' })}
              title="Keep — never change zoom, just pan to the part. Component Size is ignored."
              data-test="nav-zoom-keep"
            >Keep</button>
            <button
              className={`settings-btn-option${draft.navZoomMode === 'always' ? ' active' : ''}`}
              onClick={() => updateGlobal({ navZoomMode: 'always' })}
              title="Always — every navigation snaps to Component Size. Pre-v0.31.4 behavior."
              data-test="nav-zoom-always"
            >Always</button>
          </div>
        </div>

        <div className="settings-subsection-label">Pan</div>
        <div className="settings-row settings-toggle-row" title="Continue panning with momentum after releasing a drag gesture. When disabled, panning stops immediately on release. Note: trackpad scroll momentum is controlled by your OS settings and cannot be disabled by the app">
          <label className="settings-label">Inertia</label>
          <input type="checkbox" checked={!draft.disableInertia}
            onChange={(e) => updateGlobal({ disableInertia: !e.target.checked })} />
        </div>

        <div className="settings-subsection-label">Zoom and rotation</div>
        <Toggle label="Smooth wheel zoom" value={draft.smoothZoom} field="smoothZoom" onUpdate={updateGlobal}
          title="Animated cursor-anchored zoom" />
        <Toggle label="Two-finger rotation" value={draft.twoFingerRotate} field="twoFingerRotate" onUpdate={updateGlobal}
          title="On a touch screen, turning two fingers turns the board about the point between them. Starts locked: a turn past the unlock angle unlocks it, a two-finger double-tap locks it again and squares the board. The angle is kept when the fingers lift, snapped to the nearest right angle when within the snap window. Off: two fingers only zoom and pan." />
        <Slider label="Rotation unlock angle" value={draft.rotateUnlockDeg} min={4} max={45} step={1} field="rotateUnlockDeg" onUpdate={updateGlobal} unit="°"
          title="While rotation is locked, two fingers must turn this far before it unlocks. Every pinch turns a little; too low and zooming starts rotating, too high and unlocking takes a deliberate twist. Default 24°." />
        <Slider label="Rotation snap window" value={draft.rotateSnapDeg} min={0} max={45} step={1} field="rotateSnapDeg" onUpdate={updateGlobal} unit="°"
          title="When the fingers lift within this many degrees of 0°, 90°, 180° or 270°, the board snaps to that right angle. 0 never snaps. Default 10°." />
        <div className="settings-subsection-label">Click</div>
        <Slider label="Pin Click Radius" value={draft.clickThreshold} min={5} max={100} step={5} field="clickThreshold" onUpdate={updateGlobal}
          title="Maximum distance (screen pixels) from a pin center that counts as a click on that pin. Larger = easier to click small or densely packed pins" />
      </CollapsibleSection>
      )}

      {activeTab === SECTION_TO_TAB.zoomLod && (
      <CollapsibleSection id="zoomLod" title="Zoom Level of Detail" isOpen={openSections.has('zoomLod')}
        onToggle={toggleSection} sectionRef={zoomLodRef} isFocused={focusedSection === 'zoomLod'}>
        <div className="color-rule-hint" style={{ marginBottom: 6 }}>Controls when text labels appear/disappear as you zoom. Higher = must zoom in more. At 100% zoom: 1 mil = 1 screen pixel.</div>
        <Slider label="Part Labels" value={draft.labelMinScreenPx} min={0} max={50} step={1} field="labelMinScreenPx" onUpdate={updateGlobal}
          title="Part name labels (R1, U1, C42) appear when they reach this many screen pixels. At 100% zoom a medium (8 mil) label = 8px. Set to 10 to hide them below 125% zoom." />
        <Slider label="Pin Numbers" value={draft.pinNumberMinScreenPx ?? 5} min={0} max={50} step={1} field="pinNumberMinScreenPx" onUpdate={updateGlobal}
          title="Pin numbers on ICs/BGAs appear when they reach this many screen pixels. They sit inside the pin and cannot overlap, so this can be lower than the net-name floor; until the net name shows, the number is drawn centred in the pin." />
        <Slider label="Net Names on Pins" value={draft.circleLabelMinScreenPx} min={0} max={50} step={1} field="circleLabelMinScreenPx" onUpdate={updateGlobal}
          title="Net names on IC/BGA pins appear when they reach this many screen pixels. At 100% zoom a 6-mil label = 6px. When they appear, the pin numbers move out of the pin centre to make room." />
        <Slider label="2-Pin Net Names" value={draft.twoPinLabelMinScreenPx} min={0} max={50} step={1} field="twoPinLabelMinScreenPx" onUpdate={updateGlobal}
          title="Net names on resistors/capacitors (2-pin parts) appear when they reach this many screen pixels." />
        <Slider label="Label Cull (mils)" value={draft.labelHideThreshold} min={0} max={20} step={0.5} field="labelHideThreshold" onUpdate={updateGlobal}
          title="Labels smaller than this (in board mils) are permanently removed from the scene — never drawn at any zoom. Saves GPU memory on dense boards." />
        <Slider label="Global Zoom Floor" value={draft.labelZoomHide} min={0} max={10} step={0.01} field="labelZoomHide" onUpdate={updateGlobal}
          title="Hard minimum zoom level to show ANY text. 0 = disabled. All labels vanish below this zoom level." />
        <Slider label="Selected Part Labels" value={draft.selectedLabelMinPx} min={0} max={30} step={1} field="selectedLabelMinPx" onUpdate={updateGlobal}
          title="The selected part's labels never render smaller than this many screen pixels — they stay readable while you unzoom (Text fast mode). 0 = scale naturally with zoom." />
        <div className="settings-row settings-toggle-row"
          title="Cap pin numbers and net names on ICs/BGAs at the size that fits between the part's pin centres, so a selected chip's labels cannot overlap. A label that would have to go below its appear-floor to fit is hidden. The pin you point at is exempt.">
          <label className="settings-label">Fit pin labels to pitch</label>
          <input type="checkbox" checked={draft.labelFitToPitch ?? true} onChange={e => updateGlobal({ labelFitToPitch: e.target.checked })} />
        </div>
        <Slider label="Label Fade-In" value={draft.labelFadeRange ?? 0.5} min={0} max={1.5} step={0.05} field="labelFadeRange" onUpdate={updateGlobal}
          title="Labels fade in as they grow past their appear-floor instead of popping in at full strength — fully opaque at floor × (1 + this). 0 = instant. Like the part-name fade, but at the small end." />
        <Slider label="Other Pins of Selected Part" value={draft.selectedLabelOtherScale ?? 0.8} min={0.3} max={1} step={0.05} field="selectedLabelOtherScale" onUpdate={updateGlobal}
          title="Fraction of the size above for the selected part's pin labels that are not the selected or hovered pin. The pin you point at, the selected pin and the part name keep the full size; the rest stay smaller so a dense part's labels don't overlap." />
      </CollapsibleSection>
      )}

      {activeTab === SECTION_TO_TAB.partTypeOverrides && (
      <CollapsibleSection id="partTypeOverrides" title="Part properties" isOpen={openSections.has('partTypeOverrides')}
        onToggle={toggleSection} sectionRef={partTypeOverridesRef} isFocused={focusedSection === 'partTypeOverrides'}>
        <Slider label="Hierarchy Depth" value={draft.hierarchyDepth} min={1} max={4} step={1} field="hierarchyDepth" onUpdate={updateDraft}
          title="How many hops the hierarchical (chain + adjacent) net-line mode follows through bridging parts. 1 = immediate neighbours; up to 4 follows longer series chains." />
        <div className="color-rule-hint" style={{ padding: '4px 0' }}>
          Component fill colours &amp; prefixes are carried by the theme — edit
          them under <strong>Settings ▸ Theme ▸ Board &amp; pin colours</strong>.
        </div>
      </CollapsibleSection>
      )}

      {activeTab === SECTION_TO_TAB.netColors && (
      <CollapsibleSection id="netColors" title="Pin Color Rules" isOpen={openSections.has('netColors')}
        onToggle={toggleSection} sectionRef={netColorsRef} isFocused={focusedSection === 'netColors'}>
        <div className="color-rule-hint" style={{ padding: '4px 0' }}>
          Pin colours are now grouped by net class (Power / Ground / Datalines /
          Logical / Misc) and carried by the theme. Edit them under{' '}
          <strong>Settings ▸ Theme ▸ Board &amp; pin colours</strong>.
        </div>
      </CollapsibleSection>
      )}

      {activeTab === SECTION_TO_TAB.selection && (
      <CollapsibleSection id="selection" title="Selection & Highlight" isOpen={openSections.has('selection')}
        onToggle={toggleSection} sectionRef={selectionRef} isFocused={focusedSection === 'selection'}>
        <Slider label="Selection Border" value={draft.selectionWidth} min={0.5} max={10} step={0.5} field="selectionWidth" onUpdate={updateDraft}
          title="Thickness of the selection outline in screen pixels — the same at every zoom level" />
        <Slider label="Selection Min Size" value={draft.selectionMinScreenPx} min={0} max={64} step={2} field="selectionMinScreenPx" onUpdate={updateDraft}
          title="A selected part is never drawn smaller than this on screen (px): zoomed out, the outline is padded to this size so a tiny part stays findable; zoomed in, the padding drops to zero and the outline sits exactly on the component border" />
        <Slider label="Selection Fill" value={draft.selectionFillAlpha} min={0} max={0.5} step={0.01} field="selectionFillAlpha" onUpdate={updateDraft}
          title="Brightness of the semi-transparent fill inside the selected component outline. 0 = no fill, higher = brighter" />
        <Slider label="Selection Padding" value={draft.selectionPadding} min={0} max={30} step={1} field="selectionPadding" onUpdate={updateDraft}
          title="Extra gap (mils) between the component border and the selection outline. 0 = the outline is the border. Added on top of the dynamic minimum size" />
        <Slider label="Net Highlight Ring" value={draft.netHighlightGrow} min={0} max={20} step={0.5} field="netHighlightGrow" onUpdate={updateDraft}
          title="How much larger (mils) the yellow net highlight circle is compared to the pin circle. Creates a visible ring around each pin in the selected net" />
        <Slider label="Highlight Ring Opacity" value={draft.netHighlightAlpha} min={0} max={1} step={0.05} field="netHighlightAlpha" onUpdate={updateDraft}
          title="Opacity of the yellow highlight ring around pins in the selected net. Higher = more visible ring" />
        <LightSelectionStyleRow value={draft.lightSelectionStyle} onUpdate={updateDraft} />
        <Slider label="Dim Overlay Strength" value={draft.dimOverlayAlpha} min={0} max={0.8} step={0.05} field="dimOverlayAlpha" onUpdate={updateDraft}
          title="Opacity of the black overlay that dims unselected areas when a net is highlighted. 0 = no dimming, higher = darker" />
        <Toggle label="Ambient Dim" value={draft.ambientDim} field="ambientDim" onUpdate={updateDraft}
          title="Always dim the board even when nothing is selected. Hovering over a pin punches through the overlay to reveal its net. Useful for high-contrast inspection" />
        <Toggle label="Floating Part Label" value={draft.showElevatedPartLabel} field="showElevatedPartLabel" onUpdate={updateDraft}
          title="Show a large background-backed label above the selected component with its reference designator (e.g. U1)" />
        <Toggle label="Floating Pin Label" value={draft.showElevatedPinLabel} field="showElevatedPinLabel" onUpdate={updateDraft}
          title="Show a background-backed label above the selected pin with its pin number and net name" />
        <Slider label="HDR outline (experimental)" value={draft.hdrGlowIntensity} min={1} max={10} step={1} field="hdrGlowIntensity" toggleField="hdrFocusGlow" onUpdate={updateGlobal}
          title={hdrCapable
            ? "On an HDR display, burn the selected outline brighter than white for as long as it stays selected. The slider is the brightness: if the rest of the UI visibly dims while a part is selected, lower it. Click the name or the thumb to turn it off."
            : "No HDR display detected. Needs an HDR-capable screen in HDR mode; automatic on macOS, must be enabled system-wide on Windows."} />
      </CollapsibleSection>
      )}

      {activeTab === SECTION_TO_TAB.boardOverlay && (
      <CollapsibleSection id="boardOverlay" title="Board overlay" isOpen={openSections.has('boardOverlay')}
        onToggle={toggleSection} sectionRef={boardOverlayRef} isFocused={focusedSection === 'boardOverlay'}>
        <OverlayCustomizer />
      </CollapsibleSection>
      )}

      {activeTab === SECTION_TO_TAB.netLines && (
      <CollapsibleSection id="netLines" title="Net Lines" isOpen={openSections.has('netLines')}
        onToggle={toggleSection} sectionRef={netLinesRef} isFocused={focusedSection === 'netLines'}>
        <div className="settings-row" title="Colour of net connection lines. Left: the selected net (primary). Right: chain-adjacent nets reached through 2-pin bridge components in hierarchical highlight mode.">
          <label className="settings-label">Line colours</label>
          <div className="net-line-color-chain">
            <input
              type="color"
              className="color-rule-color"
              value={colorToHex(draft.netLineColor)}
              onChange={(e) => updateDraft({ netLineColor: hexToColor(e.target.value) })}
              title="Primary net line colour (the selected net)"
            />
            <span className="net-line-color-chain-link" aria-hidden="true">→</span>
            <input
              type="color"
              className="color-rule-color"
              value={colorToHex(draft.adjacentNetLineColor)}
              onChange={(e) => updateDraft({ adjacentNetLineColor: hexToColor(e.target.value) })}
              title="Adjacent (chain-propagated) net line colour, used when Hierarchy Depth > 1"
            />
          </div>
        </div>
        {themeStore.activeTheme().palette && (
          <p className="settings-hint">
            The {themeStore.activeTheme().label} scheme sets the line colours; these apply on BoardRipper Default.
          </p>
        )}
        <Slider label="Line Width" value={draft.netLineWidth} min={0.5} max={5} step={0.5} field="netLineWidth" onUpdate={updateDraft}
          title="Thickness of the connection lines drawn between pins of the same net when a net is selected" />
        <Slider label="Line Opacity" value={draft.netLineAlpha} min={0} max={1} step={0.05} field="netLineAlpha" onUpdate={updateDraft}
          title="Transparency of net connection lines. 0 = invisible, 1 = fully opaque" />
        <Slider label="Dashed" value={draft.netLineDashLength} min={2} max={20} step={1} field="netLineDashLength" toggleField="netLineDashed" unit="px" onUpdate={updateDraft}
          title="Length of each dash segment (screen pixels) in the dashed net line pattern" />
        <Toggle label="Pulse Animation" value={draft.netLinePulse} field="netLinePulse" onUpdate={updateDraft}
          title="Animate net lines with a red traveling pulse effect, making the connection path easier to follow across the board" />
      </CollapsibleSection>
      )}

      {activeTab === SECTION_TO_TAB.performance && (
      <CollapsibleSection id="performance" title="Rendering" isOpen={openSections.has('performance')}
        onToggle={toggleSection} sectionRef={performanceRef} isFocused={focusedSection === 'performance'}>
        <div className="settings-subsection-label">Board</div>
        <div className="settings-quality-preset"><QualityPresetCard /></div>
        <details className="settings-fine-tune" data-testid="settings-board-fine-tune">
          <summary>Fine-tune — the settings the preset sets</summary>
          <Toggle label="Cap to 60 FPS" value={draft.cap60Fps} field="cap60Fps" onUpdate={updateGlobal}
          title="Limit the renderer to 60 frames per second. Disable to let the ticker run at the display refresh rate (120/144/240 Hz) — smoother but more CPU/GPU work" />
          <Toggle label="Touch device performance mode" value={draft.touchPerformanceMode} field="touchPerformanceMode" onUpdate={updateGlobal}
          title="On a tablet (finger as the primary pointer): cap the board to 60 FPS instead of the panel's 120 and cap the render resolution at 1.5×. Edge smoothing stays on. Board text keeps full resolution. No effect on a mouse or trackpad machine. Takes effect when a board panel is next opened." />
          <Slider label="Render resolution limit" value={draft.boardResolutionCap} min={0} max={2} step={0.25} field="boardResolutionCap" onUpdate={updateGlobal} unit="×"
          title="Ceiling on the board's render resolution in device pixels per CSS pixel. 0 = no limit of its own (a tablet still gets the touch profile's 1.5×). 1 draws 44 % of the pixels 1.5 does. Board text is unaffected." />
          <Toggle label="Edge smoothing (MSAA)" value={draft.boardAntialiasing} field="boardAntialiasing" onUpdate={updateGlobal}
          title="Multisampled rendering for the board. Keep it on: thin lines such as the board outline are thinner than a pixel when zoomed out and break into jaggies without it. Turning it off saves GPU work on a machine that cannot afford it. Takes effect when a board panel is next opened." />
          <Toggle label="Simple trace corners" value={draft.traceCorners === 'simple'} field="traceCorners"
          onUpdate={(p) => { const v: unknown = p.traceCorners; updateGlobal({ traceCorners: (v === true || v === 'simple') ? 'simple' : 'round' }); }}
          title="Bevelled bends and square ends instead of rounded ones: about half the trace geometry. Invisible when zoomed out; corners look square deep in." />
        </details>
        <div className="settings-subsection-label">PDF</div>
        <PdfQualitySelector />
        <details className="settings-fine-tune" data-testid="settings-pdf-render-mode">
          <summary>Render mode</summary>
          <PdfRenderModeSelector />
        </details>
        <div className="settings-subsection-label">Board text</div>
        <Toggle label="Board text on an overlay (recommended)" value={draft.textFastMode} field="textFastMode" onUpdate={updateGlobal}
          title="Draw board text on a 2D overlay instead of as in-scene text objects — much faster on dense boards, and the default since 2026-07. Off falls back to the legacy in-scene text." />
        {!draft.textFastMode && <>
          <Slider label="Label Atlas Resolution" value={draft.labelAtlasResolution} min={4} max={24} step={1} field="labelAtlasResolution" onUpdate={updateGlobal}
          title="Pixel multiplier for the BitmapFont atlases used by pin/net/part labels. Higher = sharper labels at deep zoom; texture memory grows ~quadratically. Default 8. Triggers a scene rebuild." />
          <Toggle label="Hide Text During Zoom" value={draft.hideTextDuringZoom} field="hideTextDuringZoom" onUpdate={updateGlobal}
          title="Temporarily hide all text labels while zooming or panning for smoother performance. Labels reappear when interaction stops" />
        </>}
        <div className="settings-subsection-label">Diagnostics</div>
        <Toggle label="Show Perf Overlay" value={draft.showPerfOverlay} field="showPerfOverlay" onUpdate={updateGlobal}
          title="Show per-phase frame-time stats (frame / lod / sel / net / gpu) on each board panel. Same toggle as the small 'i' button at the bottom-left of a panel" />
        <Toggle label="[Debug] Pad Vertex Crosshairs" value={draft.showPadVertices} field="showPadVertices" onUpdate={updateGlobal}
          title="Draw magenta crosshair markers at each pin's exact coordinate from the board file. Useful for verifying parser accuracy" />
        <Toggle label="[Debug] Outline Vertex Numbers" value={draft.showVertexNumbers} field="showVertexNumbers" onUpdate={updateGlobal}
          title="Show numbered markers at each board outline vertex. Yellow = unique, orange = duplicate coordinates. Works for all board formats" />
      </CollapsibleSection>
      )}

      {activeTab === SECTION_TO_TAB.pdf && (
      <CollapsibleSection id="pdf" title="PDF Viewer" isOpen={openSections.has('pdf')}
        onToggle={toggleSection} sectionRef={pdfRef} isFocused={focusedSection === 'pdf'}>
        <p className="settings-hint">Quality and render mode are under Settings ▸ Rendering.</p>
        <div className="settings-subsection-label">Watermark filter</div>
        <PdfWatermarkFilterEditor />
        <div className="settings-subsection-label">Navigation</div>
        <PdfInertiaToggle />
        <Toggle label="Pan Boundaries" value={draft.pdfEnableBoundaries} field="pdfEnableBoundaries" onUpdate={updateGlobal}
          title="Clamp PDF pan to page edges: prevents scrolling off the document at the first/last page and centers horizontally when the page fits the viewport. Page-flip thresholds still fire as you cross them either way. Zoom range stays at 0.5×–10× regardless." />
        <div className="settings-subsection-label">Shortcuts (when PDF panel is active)</div>
        <div className="pdf-shortcuts-list">
          {shortcuts.filter(s => s.category === 'pdf').map(s => (
            <div key={s.id} className="shortcuts-row">
              <span className="shortcuts-label" title={s.description}>{s.label}</span>
              <kbd className="shortcuts-key">{formatShortcut(s.id)}</kbd>
            </div>
          ))}
        </div>
        <div className="settings-subsection-label">Scroll wheel behavior</div>
        <p className="settings-hint">Click a pill to change what that scroll does. Pinch always zooms, dragging always pans; Page flips one page per notch.</p>
        <ScrollBindingsEditor />
      </CollapsibleSection>
      )}

      {activeTab === 'system' && (
        <>
          {!isLiteBuild() && <SoftwareUpdateSection />}
          {/* Cache/render resets are troubleshooting tools, not everyday
              controls — demoted from the panel header into their own block. */}
          <StandaloneCollapsibleSection title="Troubleshooting" defaultOpen={false}
            storageKey="troubleshooting" searchSectionId="troubleshooting">
            <CacheControlBar hasBoard={hasBoard} />
            <LocalSettingsResetBar />
          </StandaloneCollapsibleSection>
        </>
      )}

      {activeTab === SECTION_TO_TAB.server && (
      <>
      {/* The everyday section first (scan/index controls); database stats,
          dedup and the destructive resets live in their own block below. */}
      <CollapsibleSection id="server" title="Scanning & Indexing" isOpen={openSections.has('server')}
        onToggle={toggleSection} sectionRef={serverRef} isFocused={focusedSection === 'server'}>
        <LibraryFolderSetting />
        <AutoScanToggle />
        <AutoBindSection />
        <LibrarySettingsSection />
      </CollapsibleSection>
      <CollapsibleSection id="dbinfo" title="Database info" isOpen={openSections.has('dbinfo')}
        onToggle={toggleSection} sectionRef={dbinfoRef} isFocused={focusedSection === 'dbinfo'}>
        <DatabaseInfoSection />
      </CollapsibleSection>
      </>
      )}

      {activeTab === SECTION_TO_TAB.shortcuts && (
      <CollapsibleSection id="shortcuts" title="Keyboard Shortcuts" isOpen={openSections.has('shortcuts')}
        onToggle={toggleSection} sectionRef={shortcutsRef} isFocused={focusedSection === 'shortcuts'}>
        {CATEGORY_ORDER.map(cat => (
          <div key={cat} className="shortcuts-category">
            <div className="shortcuts-category-title">{CATEGORY_LABELS[cat]}</div>
            {shortcuts.filter(s => s.category === cat && !s.hideInList).map(s => (
              <div key={s.id} className="shortcuts-row">
                <span className="shortcuts-label" title={s.description}>{s.label}</span>
                <kbd className="shortcuts-key">{formatShortcut(s.id)}</kbd>
              </div>
            ))}
          </div>
        ))}
      </CollapsibleSection>
      )}

      {activeTab === 'library' && (
        <LibraryTab />
      )}

      {activeTab === 'integrations' && (
        <IntegrationsSection />
      )}

      {activeTab === 'board' && (
        <button className="settings-reset-btn" onClick={handleReset}
          title={isBoardMode ? 'Clear all board overrides — revert to global settings' : 'Reset all settings to defaults (board render + input behavior)'}>
          {isBoardMode ? 'Reset to Global' : 'Reset to Defaults'}
        </button>
      )}
      </div>
      </OverrideContext.Provider>
    </div>
    </SettingsSearchProvider>
  );
}

// ---- Tab pill with match-count badge + search-clear-on-switch helpers ----

/** Board-tab toggle for Interactive (Resize) Mode. Clicking board elements
 *  while ON opens a resize popup for the clicked element class. Prominent
 *  top-of-list card with a description and an attention bump while off. */
function InteractiveModeToggle() {
  const enabled = useSyncExternalStore(
    (cb) => resizeModeStore.subscribe(cb),
    () => resizeModeStore.enabled,
  );
  return (
    <button
      type="button"
      className={`interactive-mode-toggle${enabled ? ' active' : ''}`}
      onClick={() => resizeModeStore.toggle()}
      title="Click a pin, component, label, or empty board to resize it directly. The whole board updates live."
    >
      <IconClick size={22} className="interactive-mode-icon" />
      <span className="interactive-mode-text">
        <strong>Interactive mode{enabled ? ' · ON' : ''}</strong>
        <span className="interactive-mode-desc">
          {enabled
            ? 'Click a pin, component, label, or empty board to resize it live.'
            : 'Resize board elements by clicking them — sizes update live.'}
        </span>
      </span>
    </button>
  );
}

function TabPill({ tab, activeTab, setActiveTab }: {
  tab: SettingsTabId;
  activeTab: SettingsTabId;
  setActiveTab: (t: SettingsTabId) => void;
}) {
  const { active, matches } = useSettingsSearch();
  const count = matches.perTabCount.get(tab) ?? 0;
  const isActive = activeTab === tab;
  const Icon = TAB_ICONS[tab];
  // Every tab is a fixed-width cell with the icon at a fixed spot, so
  // switching tabs never moves any icon. The open tab's name is drawn
  // underneath its icon (absolutely positioned, so it doesn't widen the
  // cell either). The label is always the hover tooltip.
  return (
    <button
      type="button"
      className={`library-tab icon-tab settings-tab-iconed ${isActive ? 'active' : ''}${active && count > 0 ? ' settings-tab-has-match' : ''}`}
      onClick={() => setActiveTab(tab)}
      data-title={TAB_LABELS[tab]}
      aria-label={TAB_LABELS[tab]}
      data-settings-tab={tab}
    >
      <Icon size={14} />
      {isActive && <span className="icon-tab-caption">{TAB_LABELS[tab]}</span>}
      {active && count > 0 && <span className="settings-tab-match-badge">{count}</span>}
    </button>
  );
}

/** Inline note when a search has zero matches on the ACTIVE tab — names the
 *  tabs that do match instead of leaving the body silently empty. Deliberately
 *  does NOT auto-switch tabs; moving the user without asking is worse. */
function SearchEmptyState({ activeTab, goTab }: {
  activeTab: SettingsTabId;
  goTab: (t: SettingsTabId) => void;
}) {
  const { active, matches } = useSettingsSearch();
  if (!active) return null;
  if ((matches.perTabCount.get(activeTab) ?? 0) > 0) return null;
  const others = TAB_ORDER.filter(t => t !== activeTab && (matches.perTabCount.get(t) ?? 0) > 0);
  return (
    <div className="settings-search-empty">
      {others.length === 0 ? (
        'No settings match this search.'
      ) : (
        <>
          No matches on this tab —{' '}
          {others.map((t, i) => (
            <span key={t}>
              {i > 0 && ', '}
              <button type="button" className="settings-search-empty-link" onClick={() => goTab(t)}>
                {matches.perTabCount.get(t)} on {TAB_LABELS[t]}
              </button>
            </span>
          ))}
        </>
      )}
    </div>
  );
}


function useThemeId(): string {
  return useSyncExternalStore(
    (cb) => themeStore.subscribe(cb),
    () => themeStore.activeId,
  );
}

// Module-level cache so the snapshot reference stays stable across calls
// within the same render pass — useSyncExternalStore requires this. The
// cache is invalidated on every themeStore notify so reads after a mutation
// pick up fresh values. Same pattern as in components/home/HomeBackdrop.tsx.
let _themeOverridesCache: { accent: string | null; background: string | null; chrome: string | null } | null = null;
themeStore.subscribe(() => { _themeOverridesCache = null; });
function _getThemeOverridesSnapshot() {
  if (!_themeOverridesCache) {
    _themeOverridesCache = {
      accent: themeStore.accentOverride,
      background: themeStore.backgroundOverride,
      chrome: themeStore.chromeOverride,
    };
  }
  return _themeOverridesCache;
}

function useThemeOverrides() {
  return useSyncExternalStore(
    (cb) => themeStore.subscribe(cb),
    _getThemeOverridesSnapshot,
  );
}

interface TokenPickerBlockProps {
  /** Section heading (uppercase). */
  title: string;
  /** Tooltip / description shown beneath the picker. */
  hint: React.ReactNode;
  /** Currently effective hex (override if set, else theme default). */
  effective: string;
  /** Override hex if user has set one, else null. */
  override: string | null;
  /** Called when the user picks a colour. */
  onChange: (hex: string) => void;
  /** Called when the user clicks "Reset". */
  onReset: () => void;
  /** Optional preset swatches. */
  presets?: ReadonlyArray<{ hex: string; label: string }>;
}

/** A single row block in the ThemeTab: title (with Reset button on the
 *  right when an override is active) → colour input + hex readout →
 *  optional preset swatches → hint text. */
function TokenPickerBlock({
  title,
  hint,
  effective,
  override,
  onChange,
  onReset,
  presets,
}: TokenPickerBlockProps) {
  const eff = effective.toLowerCase();
  return (
    <div>
      <div style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5, color: 'var(--text-secondary)', marginBottom: 6, display: 'flex', alignItems: 'center', gap: 8 }}>
        <span>{title}</span>
        {override && (
          <button
            type="button"
            onClick={onReset}
            style={{
              marginLeft: 'auto',
              background: 'none',
              border: '1px solid var(--border)',
              color: 'var(--text-secondary)',
              fontSize: 10,
              padding: '2px 8px',
              borderRadius: 3,
              cursor: 'pointer',
              textTransform: 'none',
              letterSpacing: 0,
            }}
            title="Revert to the active theme's default"
          >
            Reset
          </button>
        )}
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '4px 8px 8px' }}>
        <input
          type="color"
          value={eff}
          onChange={(e) => onChange(e.target.value.toLowerCase())}
          title={`Pick a ${title.toLowerCase()} colour`}
          style={{
            width: 36,
            height: 24,
            padding: 0,
            border: '1px solid var(--border)',
            borderRadius: 3,
            background: 'transparent',
            cursor: 'pointer',
          }}
        />
        <code style={{ fontSize: 11, color: 'var(--text-secondary)', fontFamily: 'ui-monospace, Menlo, Consolas, monospace' }}>
          {eff.toUpperCase()}
          {override == null && <span style={{ opacity: 0.6, marginLeft: 6 }}>(theme default)</span>}
        </code>
      </div>
      {presets && presets.length > 0 && (
        <div role="listbox" aria-label={`${title} presets`} style={{ display: 'flex', flexWrap: 'wrap', gap: 6, padding: '0 8px' }}>
          {presets.map((p) => {
            const active = p.hex.toLowerCase() === eff;
            return (
              <button
                key={p.hex}
                type="button"
                onClick={() => onChange(p.hex)}
                title={`${p.label} · ${p.hex.toUpperCase()}`}
                aria-label={p.label}
                aria-pressed={active}
                style={{
                  width: 22,
                  height: 22,
                  borderRadius: 4,
                  background: p.hex,
                  border: active ? '2px solid var(--text-primary)' : '1px solid var(--border)',
                  cursor: 'pointer',
                  padding: 0,
                  outline: 'none',
                }}
              />
            );
          })}
        </div>
      )}
      <div style={{ fontSize: 11, color: 'var(--text-secondary)', padding: '6px 8px 0' }}>
        {hint}
      </div>
    </div>
  );
}

const MONO = 'ui-monospace, Menlo, Consolas, monospace';

/** Compact one-line colour control: label, swatch input, hex readout, and an
 *  optional clear (×) button when the value is an active override. */
function MiniColorRow({
  label,
  value,
  onChange,
  onClear,
  note,
}: {
  label: string;
  value: string;
  onChange: (hex: string) => void;
  onClear?: () => void;
  note?: React.ReactNode;
}) {
  const v = (value || '#000000').toLowerCase();
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '3px 0' }}>
      <span style={{ fontSize: 11, color: 'var(--text-secondary)', minWidth: 104 }}>{label}</span>
      <input
        type="color"
        value={v}
        onChange={(e) => onChange(e.target.value.toLowerCase())}
        title={`Pick ${label.toLowerCase()}`}
        style={{ width: 30, height: 22, padding: 0, border: '1px solid var(--border)', borderRadius: 3, background: 'transparent', cursor: 'pointer' }}
      />
      <code style={{ fontSize: 10.5, color: 'var(--text-secondary)', fontFamily: MONO }}>{v.toUpperCase()}</code>
      {note && <span style={{ fontSize: 10, color: 'var(--text-secondary)', opacity: 0.7 }}>{note}</span>}
      {onClear && (
        <button
          type="button"
          onClick={onClear}
          title="Clear this override — fall back to the global setting"
          style={{ marginLeft: 'auto', background: 'none', border: '1px solid var(--border)', color: 'var(--text-secondary)', fontSize: 10, lineHeight: 1, padding: '2px 6px', borderRadius: 3, cursor: 'pointer' }}
        >
          ×
        </button>
      )}
    </div>
  );
}

const GROUP_LABEL: React.CSSProperties = { fontSize: 10.5, textTransform: 'uppercase', letterSpacing: 0.5, color: 'var(--text-secondary)', margin: '8px 0 2px' };

/**
 * Custom theme editor — the single user-editable theme. Edits its interface
 * baseline (ui) + board palette directly, and exposes pin colours as
 * *overrides* over the global render settings (set = override, × = inherit),
 * exactly the "global settings + overrides if set" model. Lives at the bottom
 * of the Theme tab; creating it adds a "Custom" entry to the board-theme list.
 */
/** Board-canvas colour editor (Theme tab). Reads the active theme's board
 *  palette; edits route through the copy-to-custom gate. */
function ThemeBoardColorsEditor() {
  useThemeId();
  const board = themeStore.activeTheme().board;
  const setBoard = (k: keyof Theme['board'], hex: string) => {
    if (gateThemeEdit()) themeStore.updateCustom({ board: { [k]: hex } });
  };
  return (
    <div>
      <div style={GROUP_LABEL}>Board canvas</div>
      <MiniColorRow label="Canvas" value={board.canvasBackground} onChange={(h) => setBoard('canvasBackground', h)} />
      <MiniColorRow label="Board fill" value={board.boardFill} onChange={(h) => setBoard('boardFill', h)} />
      <MiniColorRow label="Outline" value={board.outline} onChange={(h) => setBoard('outline', h)} />
      <MiniColorRow label="Selection" value={board.selection} onChange={(h) => setBoard('selection', h)} />
      <MiniColorRow label="Butterfly" value={board.butterflySelection} onChange={(h) => setBoard('butterflySelection', h)} />
      <MiniColorRow label="Pin labels" value={board.labelText} onChange={(h) => setBoard('labelText', h)} />
      <MiniColorRow label="Part labels" value={board.labelPart} onChange={(h) => setBoard('labelPart', h)} />
      <div style={{ fontSize: 10.5, color: 'var(--text-secondary)', opacity: 0.7, padding: '2px 0' }}>
        Net-label colours are under “Net labels” below. Body text and the
        secondary surface/border tiers are derived automatically for contrast.
      </div>
    </div>
  );
}

/** Component fill-colour editor (Theme tab) — the part-type list with
 *  per-type fill colour, carried by the theme. Pad/Body shape columns are
 *  hidden (rarely used; data + code retained). Edits route through the gate. */
function ThemeComponentFillsEditor() {
  useThemeId();
  const settings = useEffectiveSettings();
  const types = settings.partTypes;
  // PartTypeActions only exposes update — the theme editor retints / re-prefixes
  // the standard type set; add/remove of types isn't offered here.
  const actions: PartTypeActions = {
    update: (id, patch) => {
      if (!gateThemeEdit()) return;
      themeStore.setCustomOverride('partTypes', renderSettingsStore.settings.partTypes.map(t => t.id === id ? { ...t, ...patch } : t));
    },
  };
  return (
    <div>
      <div style={GROUP_LABEL}>Component fills</div>
      <PartTypesSection types={types} actions={actions} hideShapes />
    </div>
  );
}

/** Custom-theme management strip — delete the single custom slot. Shown only
 *  when a custom theme exists. Creation happens implicitly on first edit. */
function CustomThemeStrip() {
  useThemeId();
  if (!themeStore.customTheme) return null;
  return (
    <div style={{ ...GROUP_LABEL, display: 'flex', alignItems: 'center', gap: 8 }}>
      <span>Custom theme {themeStore.isCustomActive ? '(active)' : ''}</span>
      <button
        type="button"
        onClick={() => { if (confirm('Delete the custom theme? This reverts to BoardRipper Default.')) themeStore.resetCustom(); }}
        style={{ marginLeft: 'auto', background: 'none', border: '1px solid var(--border)', color: 'var(--danger)', fontSize: 10, padding: '2px 8px', borderRadius: 3, cursor: 'pointer', textTransform: 'none', letterSpacing: 0 }}
        title="Delete the custom theme"
      >
        Delete custom
      </button>
    </div>
  );
}

/** Live effective render settings (global ⊕ board ⊕ theme overrides). */
function useEffectiveSettings(): RenderSettings {
  return useSyncExternalStore(
    (cb) => renderSettingsStore.subscribe(cb),
    () => renderSettingsStore.settings,
  );
}

/**
 * Gate a theme-colour edit. If the custom theme is already active, runs the
 * edit directly. Otherwise asks once to fork the current theme into the
 * single custom slot (overwriting it if one exists) and switches to it, then
 * runs the edit. Returns true if the edit should proceed. Editing built-in
 * themes is never destructive — it always forks to custom first.
 */
function gateThemeEdit(): boolean {
  if (themeStore.isCustomActive) return true;
  const had = !!themeStore.customTheme;
  const ok = confirm(
    had
      ? 'Editing colours here will overwrite your existing custom theme with the current theme + this change, and switch to it. Continue?'
      : 'Editing colours here will create a custom theme from the current one and switch to it. Continue?',
  );
  if (!ok) return false;
  // Fork the currently-active theme (preserving its palette) into the custom
  // slot and switch to it.
  themeStore.forkToCustom();
  return true;
}

/** Pin-group colour editor (Theme tab). Reads the effective pinGroups and
 *  writes the whole array to the active theme via the copy-to-custom gate. */
function ThemePinGroupsEditor() {
  useThemeId(); // re-render on theme switch
  const settings = useEffectiveSettings();
  const groups = settings.pinGroups ?? [];

  // Commit a transformed copy of the groups through the gate.
  const commit = (next: PinGroup[]) => {
    if (!gateThemeEdit()) return;
    themeStore.setCustomOverride('pinGroups', next);
  };
  const editRule = (gi: number, ri: number, patch: Partial<PinGroupRule>) =>
    commit(groups.map((g, i) => i !== gi ? g : { ...g, rules: g.rules.map((r, j) => j !== ri ? r : { ...r, ...patch }) }));
  const removeRule = (gi: number, ri: number) =>
    commit(groups.map((g, i) => i !== gi ? g : { ...g, rules: g.rules.filter((_, j) => j !== ri) }));
  const addRule = (gi: number) =>
    commit(groups.map((g, i) => i !== gi ? g : { ...g, rules: [...g.rules, { id: `r${Date.now()}`, keywords: '', color: '#888888' }] }));
  const setOutline = (gi: number, on: boolean) =>
    commit(groups.map((g, i) => i !== gi ? g : { ...g, outlineOnly: on }));

  return (
    <div>
      <div style={GROUP_LABEL}>Pin colours (by net group)</div>
      <div style={{ fontSize: 10.5, color: 'var(--text-secondary)', opacity: 0.75, padding: '0 0 6px' }}>
        Keywords are comma-separated, matched case-insensitively (substring; <code style={{ fontFamily: MONO }}>*</code> = wildcard, <code style={{ fontFamily: MONO }}>#</code> = digits). First match across groups wins, in order.
      </div>
      {groups.map((g, gi) => (
        <div key={g.id} style={{ marginBottom: 8, border: '1px solid var(--border)', borderRadius: 5, padding: '6px 8px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <span style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-primary)' }}>{g.label}</span>
            <label style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 4, fontSize: 10, color: 'var(--text-secondary)', cursor: 'pointer' }}
              title="Render matching pins as outline-only circles (no fill / no labels) — e.g. no-connect pins.">
              <input type="checkbox" checked={g.outlineOnly} onChange={(e) => setOutline(gi, e.target.checked)} />
              outline-only
            </label>
          </div>
          {g.rules.map((r, ri) => (
            <PinGroupRuleRow key={r.id} rule={r}
              onKeywords={(kw) => editRule(gi, ri, { keywords: kw })}
              onColor={(c) => editRule(gi, ri, { color: c })}
              onRemove={() => removeRule(gi, ri)} />
          ))}
          <button type="button" className="color-rule-add-btn" style={{ marginTop: 2 }} onClick={() => addRule(gi)} title="Add a keyword→colour rule to this group">+ rule</button>
        </div>
      ))}
      <div style={GROUP_LABEL}>Default pin colour (no group matched)</div>
      <MiniColorRow label="Top side" value={settings.defaultPinColorTop}
        onChange={(h) => { if (gateThemeEdit()) themeStore.setCustomOverride('defaultPinColorTop', h); }} />
      <MiniColorRow label="Bottom side" value={settings.defaultPinColorBottom}
        onChange={(h) => { if (gateThemeEdit()) themeStore.setCustomOverride('defaultPinColorBottom', h); }} />

      <ThemeNetLabelEditor />
    </div>
  );
}

/** Net-name label styling — font colour + background colour & opacity. Lives
 *  with the net colours (Pin colours section). Font is theme.board.labelNet;
 *  the background box (shown when the per-side bg toggle is on) is
 *  theme.board.netLabelBg / netLabelBgOpacity. All route through the gate. */
function ThemeNetLabelEditor() {
  useThemeId();
  const board = themeStore.activeTheme().board;
  const opacity = board.netLabelBgOpacity ?? 0.6;
  return (
    <div>
      <div style={GROUP_LABEL}>Net labels</div>
      <MiniColorRow label="Font" value={board.labelNet}
        onChange={(h) => { if (gateThemeEdit()) themeStore.updateCustom({ board: { labelNet: h } }); }} />
      <MiniColorRow label="Background" value={board.netLabelBg ?? '#000000'}
        onChange={(h) => { if (gateThemeEdit()) themeStore.updateCustom({ board: { netLabelBg: h } }); }} />
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '3px 0' }}>
        <span style={{ fontSize: 11, color: 'var(--text-secondary)', minWidth: 104 }}>Bg opacity</span>
        <input type="range" min={0} max={1} step={0.05} value={opacity}
          onChange={(e) => { if (gateThemeEdit()) themeStore.updateCustom({ board: { netLabelBgOpacity: parseFloat(e.target.value) } }); }}
          style={{ flex: 1, accentColor: 'var(--accent)' }} />
        <code style={{ fontSize: 10.5, color: 'var(--text-secondary)', fontFamily: MONO, minWidth: 28, textAlign: 'right' }}>{Math.round(opacity * 100)}%</code>
      </div>
      <div style={{ fontSize: 10.5, color: 'var(--text-secondary)', opacity: 0.7, padding: '2px 0' }}>
        The background box appears when net-label backgrounds are enabled (Board ▸ Labels).
      </div>
    </div>
  );
}

/** One pin-group rule row: keywords (commit on blur) + colour (live) + remove. */
function PinGroupRuleRow({ rule, onKeywords, onColor, onRemove }: {
  rule: PinGroupRule;
  onKeywords: (kw: string) => void;
  onColor: (c: string) => void;
  onRemove: () => void;
}) {
  const [text, setText] = useState(rule.keywords);
  const [prev, setPrev] = useState(rule.keywords);
  if (prev !== rule.keywords) { setPrev(rule.keywords); setText(rule.keywords); }
  const commit = () => { if (text !== rule.keywords) onKeywords(text); };
  return (
    <div className="color-rule-row">
      <input type="text" className="color-rule-pattern" value={text}
        onChange={(e) => setText(e.target.value)} onBlur={commit}
        onKeyDown={(e) => { if (e.key === 'Enter') (e.target as HTMLInputElement).blur(); }}
        placeholder="VCC, 3V3, …" title="Comma-separated keywords" />
      <input type="color" className="color-rule-color" value={rule.color} onChange={(e) => onColor(e.target.value)} />
      <button className="color-rule-remove" onClick={onRemove} title="Remove rule">×</button>
    </div>
  );
}

function ThemeTab() {
  const activeId = useThemeId();
  const themes: Theme[] = themeStore.list();
  const overrides = useThemeOverrides();
  const activeTheme = themes.find((t) => t.id === activeId);
  const effectiveAccent = overrides.accent ?? activeTheme?.ui.accent ?? '#4a9eff';
  const effectiveBackground = overrides.background ?? activeTheme?.ui.bgPrimary ?? '#08080c';
  const effectiveChrome = overrides.chrome ?? activeTheme?.ui.bgTertiary ?? '#0c1424';

  return (
    <div className="settings-section-body" style={{ padding: 12, display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div>
        <div style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5, color: 'var(--text-secondary)', marginBottom: 6 }}>
          Board theme
        </div>
        <div style={{ fontSize: 11, color: 'var(--text-secondary)', padding: '0 8px 6px' }}>
          Picks the canvas / board-side colour set (background, fill, outline,
          selection accent) and any per-theme settings overlays. Light themes
          also set a light interface baseline; text auto-adjusts for contrast.
          The colour pickers below override the chosen theme's chrome.
        </div>
        <div role="radiogroup" aria-label="Board theme" style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
          {themes.map(t => (
            <label
              key={t.id}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 8,
                padding: '6px 8px',
                borderRadius: 4,
                cursor: 'pointer',
                background: activeId === t.id ? 'var(--bg-secondary)' : 'transparent',
              }}
            >
              <input
                type="radio"
                name="theme-picker"
                value={t.id}
                checked={activeId === t.id}
                onChange={() => themeStore.setTheme(t.id)}
              />
              <span>{t.label}</span>
              <span
                style={{
                  marginLeft: 'auto',
                  width: 14,
                  height: 14,
                  borderRadius: 3,
                  background: t.board.canvasBackground,
                  border: `1px solid ${t.ui.border}`,
                  boxShadow: `inset 0 0 0 1px ${t.board.boardFill}`,
                }}
                aria-hidden="true"
              />
            </label>
          ))}
        </div>
      </div>

      <div style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5, color: 'var(--text-secondary)' }}>
        Interface colours
      </div>

      <TokenPickerBlock
        title="Accent"
        effective={effectiveAccent}
        override={overrides.accent}
        onChange={(h) => themeStore.setAccent(h)}
        onReset={() => themeStore.setAccent(null)}
        presets={ACCENT_PRESETS}
        hint={
          <>
            Drives <code style={{ fontFamily: 'ui-monospace, Menlo, Consolas, monospace' }}>--accent</code>{' '}
            (focus, active states, links) and{' '}
            <code style={{ fontFamily: 'ui-monospace, Menlo, Consolas, monospace' }}>--accent-hover</code>{' '}
            (derived in CSS via <code style={{ fontFamily: 'ui-monospace, Menlo, Consolas, monospace' }}>color-mix</code>).
            Pill colours and selection (yellow) are independent.
          </>
        }
      />

      <TokenPickerBlock
        title="Background"
        effective={effectiveBackground}
        override={overrides.background}
        onChange={(h) => themeStore.setBackground(h)}
        onReset={() => themeStore.setBackground(null)}
        hint={
          <>
            The canvas + interactive surface tier. Drives{' '}
            <code style={{ fontFamily: 'ui-monospace, Menlo, Consolas, monospace' }}>--bg-primary</code>;{' '}
            <code style={{ fontFamily: 'ui-monospace, Menlo, Consolas, monospace' }}>--bg-secondary</code>{' '}
            (cards, button surfaces) cascades 6% lighter.
          </>
        }
      />

      <TokenPickerBlock
        title="Chrome"
        effective={effectiveChrome}
        override={overrides.chrome}
        onChange={(h) => themeStore.setChrome(h)}
        onReset={() => themeStore.setChrome(null)}
        hint={
          <>
            Toolbar, status bar, and tab strip surfaces. Drives{' '}
            <code style={{ fontFamily: 'ui-monospace, Menlo, Consolas, monospace' }}>--bg-tertiary</code>;{' '}
            <code style={{ fontFamily: 'ui-monospace, Menlo, Consolas, monospace' }}>--border</code>{' '}
            (panel boundaries) cascades 12% lighter.
          </>
        }
      />

      <div style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5, color: 'var(--text-secondary)' }}>
        Interface scale
      </div>
      <InterfaceScaleSlider />

      <div style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5, color: 'var(--text-secondary)', paddingTop: 4 }}>
        Sidebar navigation
      </div>
      <SidebarNavSwitch />

      <div style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5, color: 'var(--text-secondary)', borderTop: '1px solid var(--border)', paddingTop: 12 }}>
        Board & pin colours
      </div>
      <div style={{ fontSize: 11, color: 'var(--text-secondary)', padding: '0 0 2px' }}>
        These are carried by the theme. Editing any of them copies the current
        theme into your custom theme (one slot) and switches to it.
      </div>
      <CustomThemeStrip />
      <ThemeBoardColorsEditor />
      <ThemePinGroupsEditor />
      <ThemeComponentFillsEditor />

    </div>
  );
}

// Suppress unused-warning when THEMES is only referenced indirectly via themeStore.list().
void THEMES;

function LibraryTab() {
  const obd = useObdForBoard(undefined);
  const [confirming, setConfirming] = useState(false);

  // Cold-start: when the user opens this tab, refresh the index status
  // from disk so "Last synced: ..." reflects index.json without waiting
  // for the user to view a board first.
  useEffect(() => { obd.refreshStatus(); obd.refreshFetchAll(); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  const fa = obd.fetchAllProgress;
  const downloading = !!fa?.running;

  return (
    <div className="settings-tab-body" data-testid="settings-library-tab">
      <div className="settings-row settings-toggle-row">
        <label className="settings-label">First-run library setup</label>
        <button className="settings-action-btn" onClick={() => firstRunStore.show()} data-testid="firstrun-show-btn">
          Show again
        </button>
      </div>
      <LibrarySyncSection />

      <StandaloneCollapsibleSection title="OpenBoardData" storageKey="obd" searchSectionId="obd">
        <p style={{ fontSize: 12, color: 'var(--text-secondary)', lineHeight: 1.4, margin: '0 0 12px' }}>
          Per-net diagnostic measurements (diode / voltage / resistance) and repair notes from{' '}
          <a href="https://openboarddata.org" target="_blank" rel="noopener noreferrer">openboarddata.org</a>.
          Data is community-contributed under the <strong>ODbL 1.0</strong> license. BoardRipper does not bundle this data;
          you fetch it on demand. Re-distribution requires keeping the same license — see{' '}
          <a href="https://opendatacommons.org/licenses/odbl/1-0/" target="_blank" rel="noopener noreferrer">
            the license terms
          </a>.
        </p>

        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 8 }}>
          <button
            onClick={() => obd.syncIndex()}
            disabled={obd.syncing}
            data-testid="obd-sync-btn"
          >
            {obd.syncing ? 'Syncing…' : 'Sync OBD index'}
          </button>
          <span style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
            {obd.indexSynced
              ? `Last synced: ${obd.indexSyncedAt} · ${obd.indexBoardCount} boards`
              : 'Never synced'}
          </span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 8 }}>
          {downloading ? (
            <button onClick={() => obd.stopFetchAll()} data-testid="obd-fetch-all-stop">Stop</button>
          ) : (
            <button onClick={() => obd.fetchAll()} data-testid="obd-fetch-all-btn"
              title="Fetch every board in the index that is not cached yet (~1 request per second)">
              Download all boards
            </button>
          )}
          <span style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
            {downloading && fa
              ? `${fa.done} of ${fa.total} · ${fa.fetched} fetched · ${fa.skipped} cached${fa.failed ? ` · ${fa.failed} failed` : ''}${fa.current ? ` · ${fa.current}` : ''}`
              : obd.indexSynced
                ? `${obd.indexCached} of ${obd.indexBoardCount} boards cached${fa && !fa.running && fa.total > 0 ? ` · last run: ${fa.fetched} fetched, ${fa.failed} failed` : ''}`
                : 'Sync the index first, or click Download all — it syncs on its own.'}
          </span>
        </div>
        {downloading && fa && fa.total > 0 && (
          <div className="obd-fetchall-bar" aria-hidden="true">
            <div className="obd-fetchall-fill" style={{ width: `${Math.round((fa.done / fa.total) * 100)}%` }} />
          </div>
        )}
        {obd.error && (
          <div style={{ color: '#c33', fontSize: 12, marginBottom: 8 }}>{obd.error}</div>
        )}

        <div style={{ marginTop: 12 }}>
          {!confirming ? (
            <button onClick={() => setConfirming(true)}>Delete all OBD data</button>
          ) : (
            <span>
              <strong>Are you sure?</strong>{' '}
              <button onClick={async () => { await obd.clearCache(); setConfirming(false); }}>
                Yes, delete
              </button>{' '}
              <button onClick={() => setConfirming(false)}>Cancel</button>
            </span>
          )}
        </div>
      </StandaloneCollapsibleSection>
    </div>
  );
}
