import { useEffect, useRef, useState, useSyncExternalStore } from 'react';
import { IconWaveSine, IconCamera, IconPhotoUp, IconRefresh, IconX, IconCheck } from '@tabler/icons-react';
import { useBoardStore } from '../hooks/useBoardStore';
import { curvesStore, DEVICE_LABEL, PROFILE_LABEL, RANGE, similarity, sameCond, type Curve, type Device, type Profile } from '../r2/curves-store';

/** 2R Tools: aba «Curvas» — assinatura V×I de cada pino (RastreCurve / Smart Curve), Beta. */

function useCurves() { return useSyncExternalStore(curvesStore.subscribe, () => curvesStore.rev); }

const fmt = (t: number) => {
  const d = new Date(t);
  return d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: '2-digit' }) + ' ' + d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
};

/** Tela do traçador: tensão na horizontal, corrente na vertical. */
function Plot({ lines, dev, small }: { lines: { pts: [number, number][]; kind: 'oficial' | 'minha' | 'live' | 'outra' }[]; dev: Device; small?: boolean }) {
  const W = small ? 120 : 320, H = small ? 84 : 230, P = small ? 4 : 26;
  const r = RANGE[dev];
  const x = (v: number) => P + ((v + r.v) / (2 * r.v)) * (W - 2 * P);
  const y = (i: number) => H - P - ((i + r.ma) / (2 * r.ma)) * (H - 2 * P);
  const path = (pts: [number, number][]) => pts.map((p, k) => `${k ? 'L' : 'M'}${x(p[0]).toFixed(1)},${y(p[1]).toFixed(1)}`).join(' ');
  return (
    <svg className={`r2cv-plot ${small ? 'small' : ''}`} viewBox={`0 0 ${W} ${H}`} width="100%">
      <rect x="0" y="0" width={W} height={H} className="r2cv-bg" />
      {[-1, -0.5, 0.5, 1].map(f => <line key={'v' + f} x1={x(f * r.v)} x2={x(f * r.v)} y1={P} y2={H - P} className="r2cv-grid" />)}
      {[-1, -0.5, 0.5, 1].map(f => <line key={'i' + f} y1={y(f * r.ma)} y2={y(f * r.ma)} x1={P} x2={W - P} className="r2cv-grid" />)}
      <line x1={x(0)} x2={x(0)} y1={P} y2={H - P} className="r2cv-axis" />
      <line y1={y(0)} y2={y(0)} x1={P} x2={W - P} className="r2cv-axis" />
      {!small && <>
        <text x={W - P} y={y(0) - 4} className="r2cv-lbl" textAnchor="end">+{r.v} V</text>
        <text x={P} y={y(0) - 4} className="r2cv-lbl">−{r.v} V</text>
        <text x={x(0) + 4} y={P + 9} className="r2cv-lbl">+{r.ma} mA</text>
        <text x={x(0) + 4} y={H - P - 3} className="r2cv-lbl">−{r.ma} mA</text>
      </>}
      {lines.map((l, k) => <path key={k} d={path(l.pts)} className={`r2cv-line ${l.kind}`} />)}
    </svg>
  );
}

const STATUS: Record<Curve['status'], string> = { oficial: 'OFICIAL', pendente: 'PENDENTE', recusada: 'RECUSADA', minha: 'MINHA' };

export function CurvesPanel() {
  useCurves();
  const snap = useBoardStore();
  const tab = snap.tabs.find(t => t.id === snap.activeTabId) ?? null;
  const sel = tab?.selection;
  const part = tab?.board && sel?.partIndex != null ? tab.board.parts[sel.partIndex] : null;
  const pin = part && sel?.pinIndex != null && sel.pinIndex >= 0 ? part.pins[sel.pinIndex] : null;
  const c = curvesStore.cond;
  const [msg, setMsg] = useState('');
  const [auto, setAuto] = useState(() => { try { return localStorage.getItem('2r-curvas-auto') !== '0'; } catch { return true; } });
  const [showOther, setShowOther] = useState(false);
  const [redoId, setRedoId] = useState<string | null>(null);
  const done = useRef(false);
  const fileRef = useRef<HTMLInputElement | null>(null);

  // captura sozinha quando a curva firma (uma vez por toque da ponta)
  useEffect(() => {
    const s = curvesStore.stable;
    if (s < 0.3) done.current = false;
    if (auto && s >= 1 && !done.current && pin && curvesStore.live) {
      done.current = true;
      curvesStore.capture(undefined, undefined, '', redoId || undefined).then(m => { setMsg(m); setRedoId(null); });
    }
  });

  const pinNo = pin ? (pin.number || pin.name) : '';
  const all = pin ? curvesStore.forPin(pinNo) : [];
  const same = all.filter(x => sameCond(x.cond, c));
  const other = all.filter(x => !sameCond(x.cond, c));
  const official = same.find(x => x.status === 'oficial' && x.points.length);
  const live = curvesStore.live;
  const sim = official && live ? similarity(official.points, live, c.device) : null;
  const st = curvesStore.stable;

  const importImage = (f: File) => {
    const rd = new FileReader();
    rd.onload = () => curvesStore.capture([], String(rd.result), 'foto da tela do aparelho', redoId || undefined).then(m => { setMsg(m); setRedoId(null); });
    rd.readAsDataURL(f);
  };

  return (
    <div className="r2acv r2cv">
      <div className="r2acv-title"><IconWaveSine size={16} /> Curvas 
        <span className="r2acv-sub">{curvesStore.capacitado ? 'técnico capacitado' : 'contribuição'}</span></div>

      <div className="r2acv-section">
        <div className="r2meter-kinds">
          {(['rastre', 'smart'] as Device[]).map(d => (
            <button key={d} className={`r2meter-kind ${c.device === d ? 'sel' : ''}`} onClick={() => curvesStore.setCond({ device: d })}>{DEVICE_LABEL[d]}</button>
          ))}
        </div>
        <div className="r2acv-two">
          <label className="r2meter-field">Perfil
            <select value={c.profile} onChange={e => curvesStore.setCond({ profile: e.target.value as Profile })}>
              {(Object.keys(PROFILE_LABEL) as Profile[]).map(p => <option key={p} value={p}>{PROFILE_LABEL[p]}</option>)}
            </select>
          </label>
          <label className="r2meter-field">Ponta preta (referência)
            <input value={c.ref} onChange={e => curvesStore.setCond({ ref: e.target.value.toUpperCase() })} placeholder="GND" />
          </label>
        </div>
        <label className="r2acv-check"><input type="checkbox" checked={c.battery === 'desligada'} onChange={e => curvesStore.setCond({ battery: e.target.checked ? 'desligada' : 'ligada' })} /> Bateria e carregador desligados</label>
        <label className="r2acv-check"><input type="checkbox" checked={c.caps === 'descarregados'} onChange={e => curvesStore.setCond({ caps: e.target.checked ? 'descarregados' : 'carregando' })} /> Placa descansada (capacitores descarregados)</label>
      </div>

      {!pin ? (
        <div className="r2acv-section"><div className="r2acv-note">Clique num pino na placa para ver a curva oficial e gravar a sua.</div></div>
      ) : (
        <div className="r2acv-section">
          <div className="r2cv-pinhead"><b>{part!.name}.{pinNo}</b> <span className="r2hist-sub" style={{ display: 'inline' }}>{pin.net || 'sem net'}</span></div>
          <Plot dev={c.device} lines={[
            ...(official ? [{ pts: official.points, kind: 'oficial' as const }] : []),
            ...(live ? [{ pts: live, kind: 'live' as const }] : []),
          ]} />
          <div className="r2cv-legend">
            <span><i className="oficial" /> oficial 2R</span>
            <span><i className="live" /> ao vivo</span>
            {sim !== null && <span className={`r2cv-sim ${sim >= 90 ? 'ok' : sim >= 75 ? 'mid' : 'bad'}`}>
              {sim >= 90 ? 'Igual à oficial' : sim >= 75 ? 'Parecida' : 'Diferente da oficial'} · {sim}%</span>}
            {!official && <span className="r2acv-note">Ainda sem curva oficial nestas condições.</span>}
          </div>

          <div className="r2cv-stab">
            <div className="r2cv-stab-bar"><div style={{ width: `${Math.round(st * 100)}%` }} className={st >= 1 ? 'ok' : ''} /></div>
            <span>{!live ? 'Aguardando o aparelho…' : st >= 1 ? 'Curva firme — pode capturar' : 'Esperando a curva firmar (capacitores carregando)…'}</span>
          </div>
          <label className="r2acv-check"><input type="checkbox" checked={auto} onChange={e => { setAuto(e.target.checked); try { localStorage.setItem('2r-curvas-auto', e.target.checked ? '1' : '0'); } catch { /* */ } }} /> Capturar sozinho quando a curva firmar</label>
          <div className="r2meter-actions">
            <button className="r2acv-send r2meter-btn" disabled={!live} onClick={() => curvesStore.capture(undefined, undefined, '', redoId || undefined).then(m => { setMsg(m); setRedoId(null); })}>
              <IconCamera size={14} /> {redoId ? 'Capturar de novo' : 'Capturar curva'}</button>
            <button className="r2meter-btn r2meter-off" onClick={() => fileRef.current?.click()}><IconPhotoUp size={14} /> Foto da tela</button>
            <input ref={fileRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={e => { const f = e.target.files?.[0]; if (f) importImage(f); e.target.value = ''; }} />
          </div>
          {redoId && <div className="r2acv-note">A próxima captura substitui a curva escolhida. <button className="r2cv-link" onClick={() => setRedoId(null)}>cancelar</button></div>}
          {msg && <div className="r2acv-note">{msg}</div>}

          <div className="r2cv-listhead"><b>Curvas deste pino ({same.length})</b></div>
          {same.length === 0 && <div className="r2acv-note">Nenhuma curva gravada nestas condições.</div>}
          {same.map(cv => (
            <div key={cv.id} className={`r2cv-item ${cv.status} ${redoId === cv.id ? 'redo' : ''}`}>
              {cv.points.length ? <Plot small dev={cv.cond.device} lines={[{ pts: cv.points, kind: cv.status === 'oficial' ? 'oficial' : 'minha' }]} />
                : cv.image ? <img className="r2cv-thumb" src={cv.image} alt="" /> : null}
              <div className="r2cv-meta">
                <span className={`r2cv-chip ${cv.status}`}>{STATUS[cv.status]}</span>
                <span className="r2hist-sub">{cv.by || '—'} · {fmt(cv.created)}</span>
                <span className="r2hist-sub">{PROFILE_LABEL[cv.cond.profile]} · ref {cv.cond.ref}</span>
                {cv.reviewer && <span className="r2hist-sub">aprovada por {cv.reviewer}</span>}
                {live && cv.points.length > 0 && <span className="r2hist-sub">parecença com o ao vivo: {similarity(cv.points, live, c.device)}%</span>}
              </div>
              <div className="r2hist-act r2cv-act">
                <button title="Capturar de novo (substitui esta)" onClick={() => setRedoId(cv.id)}><IconRefresh size={14} /></button>
                <button title="Apagar" onClick={() => curvesStore.remove(cv.id)}><IconX size={14} /></button>
              </div>
            </div>
          ))}
          {other.length > 0 && (
            <button className="r2cv-link" onClick={() => setShowOther(!showOther)}>
              {showOther ? '▾' : '▸'} {other.length} curva(s) em outras condições (outro aparelho/perfil/referência)</button>
          )}
          {showOther && other.map(cv => (
            <div key={cv.id} className="r2cv-item outra">
              {cv.points.length ? <Plot small dev={cv.cond.device} lines={[{ pts: cv.points, kind: 'outra' }]} /> : null}
              <div className="r2cv-meta">
                <span className={`r2cv-chip ${cv.status}`}>{STATUS[cv.status]}</span>
                <span className="r2hist-sub">{DEVICE_LABEL[cv.cond.device]} · {PROFILE_LABEL[cv.cond.profile]} · ref {cv.cond.ref}</span>
                <span className="r2hist-sub">{cv.by} · {fmt(cv.created)}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {curvesStore.capacitado && curvesStore.pending.length > 0 && (
        <div className="r2acv-section">
          <div className="r2cv-listhead"><b>Aguardando aprovação ({curvesStore.pending.length})</b></div>
          {curvesStore.pending.map(cv => (
            <div key={cv.id} className="r2cv-item pendente">
              {cv.points.length ? <Plot small dev={cv.cond.device} lines={[{ pts: cv.points, kind: 'minha' }]} /> : cv.image ? <img className="r2cv-thumb" src={cv.image} alt="" /> : null}
              <div className="r2cv-meta">
                <b>{cv.board.replace(/\.[^.]+$/, '')} · {cv.part}.{cv.pin}</b>
                <span className="r2hist-sub">{cv.net} · {DEVICE_LABEL[cv.cond.device]} · {PROFILE_LABEL[cv.cond.profile]}</span>
                <span className="r2hist-sub">{cv.by} · {fmt(cv.created)}</span>
              </div>
              <div className="r2cv-act r2cv-review">
                <button className="r2meter-btn" onClick={() => curvesStore.review(cv.id, 'aprovar')}><IconCheck size={13} /> Aprovar</button>
                <button className="r2meter-btn r2meter-off" onClick={() => curvesStore.review(cv.id, 'recusar')}>Recusar</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
