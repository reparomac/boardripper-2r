import { useEffect, useState, useSyncExternalStore } from 'react';
import { IconGauge, IconPlugConnected, IconPlugConnectedX, IconDownload, IconTrash } from '@tabler/icons-react';
import { meterStore, meterApi, type Mode } from '../r2/meter-store';
import { useBoardStore } from '../hooks/useBoardStore';
import { boardStore } from '../store/board-store';
import { pinOrder, probePoints, ruleFor, setRuleFor, seqPrefs, stepPin, SEQ_LABEL, type SeqRule } from '../r2/probe-seq';

/** 2R Tools: aba «Medições» — liga o multímetro e guarda as leituras por pino (10/10/2026). */
const MODE_LABEL: Record<Mode, string> = { diodo: 'Diodo', tensao: 'Tensão', resistencia: 'Resistência' };

function useMeter() {
  return useSyncExternalStore(meterStore.subscribe, () => meterStore.rev);
}

const HOLDS = [500, 800, 1000, 1500, 2000, 3000];
const keyName = (k: string) => k === ' ' || k === 'Space' ? 'Espaço' : k.replace(/^Key/, '').replace(/^Digit/, '').replace(/^Numpad/, 'Num ');

/** Como a leitura entra: sozinha (tempo parado ajustável) ou por tecla; e os avisos sonoros. */
function CaptureSection() {
  const c = meterStore.capture;
  const [waitKey, setWaitKey] = useState(false);
  useEffect(() => {
    if (!waitKey) return;
    const fn = (e: KeyboardEvent) => {
      e.preventDefault(); e.stopPropagation();
      if (e.key !== 'Escape') meterStore.setCapture({ key: e.code || e.key });
      setWaitKey(false);
    };
    window.addEventListener('keydown', fn, true);
    return () => window.removeEventListener('keydown', fn, true);
  }, [waitKey]);
  return (
    <div className="r2acv-section r2cap">
      <div className="r2meter-kinds">
        <button className={`r2meter-kind ${c.auto ? 'sel' : ''}`} onClick={() => meterStore.setCapture({ auto: true })}>Captura automática</button>
        <button className={`r2meter-kind ${!c.auto ? 'sel' : ''}`} onClick={() => meterStore.setCapture({ auto: false })}>Captura manual</button>
      </div>
      {c.auto ? (
        <label className="r2meter-field">Grava quando a leitura fica parada por
          <select value={c.holdMs} onChange={e => meterStore.setCapture({ holdMs: Number(e.target.value) })}>
            {HOLDS.map(h => <option key={h} value={h}>{(h / 1000).toLocaleString('pt-BR')} s</option>)}
          </select>
        </label>
      ) : (
        <div className="r2meter-actions">
          <span className="r2cap-lbl">Tecla para gravar:</span>
          <button className={`r2meter-btn r2meter-off r2cap-key ${waitKey ? 'wait' : ''}`} onClick={() => setWaitKey(true)}
                  title="Clique e aperte a tecla que você quer usar">{waitKey ? 'Aperte a tecla…' : keyName(c.key)}</button>
          <button className="r2acv-send r2meter-btn" onClick={() => meterStore.captureNow()} disabled={meterStore.status.state !== 'on'}>Gravar agora</button>
        </div>
      )}
      <div className="r2cap-sound">
        <label className="r2acv-check"><input type="checkbox" checked={c.sound} onChange={e => meterStore.setCapture({ sound: e.target.checked })} /> Som da leitura (quando a leitura firma)</label>
        <div className="r2meter-actions r2cap-tests">
          <button className="r2meter-icon r2cap-test" title="Ouvir" onClick={() => meterStore.testSound('ok')}>♪ dentro da margem</button>
          <button className="r2meter-icon r2cap-test" title="Ouvir" onClick={() => meterStore.testSound('warn')}>♪ um pouco fora</button>
          <button className="r2meter-icon r2cap-test" title="Ouvir" onClick={() => meterStore.testSound('bad')}>♪ muito fora</button>
        </div>
        <label className="r2acv-check"><input type="checkbox" checked={c.soundSave} onChange={e => meterStore.setCapture({ soundSave: e.target.checked })} /> Som da gravação</label>
        <div className="r2meter-actions r2cap-tests">
          <button className="r2meter-icon r2cap-test" title="Ouvir" onClick={() => meterStore.testSound('saved')}>♪ gravou</button>
          <button className="r2meter-icon r2cap-test" title="Ouvir" onClick={() => meterStore.testSound('notsaved')}>♪ não gravou</button>
        </div>
      </div>
      {meterStore.who && <div className="r2acv-note">Medições gravadas em nome de <b>{meterStore.who}</b>.</div>}
    </div>
  );
}

function fmtWhen(t: number): string {
  const d = new Date(t);
  return d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: '2-digit' }) + ' ' + d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
}

/** Valor editável no próprio histórico. */
function EditValue({ t, value, onDone }: { t: number; value: number; onDone: () => void }) {
  const [v, setV] = useState(value.toFixed(3));
  const ok = () => { const n = parseFloat(v.replace(',', '.')); if (!isNaN(n)) meterStore.edit(t, n); onDone(); };
  return <input className="r2hist-edit" autoFocus value={v} onChange={e => setV(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter') ok(); else if (e.key === 'Escape') onDone(); }} onBlur={ok} />;
}

/** Mapear componente: sequência dos pinos e ponto de medição mais próximo (Roger, 10/10/2026). */
function MapSection() {
  const { board, fileName, selection } = useBoardStore();
  const [, force] = useState(0);
  const redraw = () => force(n => n + 1);
  const part = board && selection.partIndex != null ? board.parts[selection.partIndex] : null;
  if (!board || !part) {
    return (
      <div className="r2acv-section">
        <b>Mapear componente</b>
        <div className="r2acv-note">Clique num componente na placa para ver a sequência dos pinos e o ponto de medição mais próximo.</div>
      </div>
    );
  }
  const rule = ruleFor(fileName, part.name);
  const order = pinOrder(board, part, rule, seqPrefs.skipGnd);
  const done = new Set(meterStore.list.filter(m => m.board === fileName && m.part === part.name).map(m => m.pin));
  const probe = probePoints();
  const via = meterStore.via;
  const curPin = selection.pinIndex != null && selection.pinIndex >= 0 ? part.pins[selection.pinIndex] : null;
  const curName = curPin ? `${part.name}.${curPin.number || curPin.name}` : '';
  return (
    <div className="r2acv-section r2map">
      <div className="r2map-head">
        <b>Mapear {part.name}</b>
        <span className="r2map-count">{order.filter(i => done.has(part.pins[i].number || part.pins[i].name)).length}/{order.length} medidos</span>
      </div>
      <label className="r2meter-field">Sequência dos pinos
        <select value={rule} onChange={e => { setRuleFor(fileName, part.name, e.target.value as SeqRule); redraw(); }}>
          {(Object.keys(SEQ_LABEL) as SeqRule[]).map(r => <option key={r} value={r}>{SEQ_LABEL[r]}</option>)}
        </select>
      </label>
      <div className="r2map-opts">
        <label className="r2acv-check"><input type="checkbox" defaultChecked={seqPrefs.auto} onChange={e => { seqPrefs.auto = e.target.checked; }} /> Ir sozinho para o próximo pino depois de medir</label>
        <label className="r2acv-check"><input type="checkbox" defaultChecked={seqPrefs.skipGnd} onChange={e => { seqPrefs.skipGnd = e.target.checked; redraw(); }} /> Pular pinos de GND</label>
      </div>
      <div className="r2map-nav">
        <button className="r2meter-btn r2meter-off" onClick={() => stepPin(-1)}>◀ Anterior</button>
        <button className="r2meter-btn r2meter-off" onClick={() => stepPin(1)}>Próximo ▶</button>
      </div>
      <div className="r2map-pins">
        {order.map((i, k) => {
          const p = part.pins[i];
          const label = p.number || p.name;
          return (
            <button key={i} title={`${k + 1}º · ${p.net || 'sem net'}`}
                    className={`r2map-pin ${selection.pinIndex === i ? 'cur' : ''} ${done.has(label) ? 'done' : ''}`}
                    onClick={() => boardStore.selectPin(selection.partIndex!, i)}>{label}</button>
          );
        })}
      </div>
      {probe && (
        <div className="r2map-probe">
          <div className="r2map-sub">Sem acesso ao pad de {probe.from}? Meça a mesma net ({probe.net || 'sem net'}) em:</div>
          {probe.points.length === 0 && <div className="r2acv-note">Nenhum ponto de teste ou passivo nessa net.</div>}
          {probe.points.map(pt => {
            const at = `${pt.part}.${pt.pin}`;
            const on = via?.pin === curName && via.at === at;
            return (
              <div key={pt.partIndex} className={`r2map-pt ${on ? 'sel' : ''}`}>
                <button className="r2map-pt-name" title="Mostrar na placa" onClick={() => boardStore.previewPart(pt.part)}>
                  {at}<span className="r2map-pt-info">{pt.mm.toFixed(1)} mm · {pt.kind === 'teste' ? 'ponto de teste' : 'passivo'}{pt.side !== part.side ? ' · outro lado' : ''}</span>
                </button>
                <button className="r2meter-btn r2meter-off" onClick={() => { meterStore.setVia(on ? null : { pin: curName, at }); if (!on) boardStore.previewPart(pt.part); }}>
                  {on ? 'Medindo aqui ✓' : 'Medir aqui'}
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

export function MeterPanel() {
  useMeter();
  const [editing, setEditing] = useState<number | null>(null);
  const [sure, setSure] = useState(false);
  const api = meterApi();
  // 2R 23/10/2026: i2C C09 removido daqui (tem painel próprio no SDS) — só Rigol
  const [kind, setKind] = useState<'rigol' | 'i2c'>('rigol');
  const [host, setHost] = useState('');
  const [ports, setPorts] = useState<{ port: string; desc: string }[]>([]);
  const [port, setPort] = useState('');
  const [baud, setBaud] = useState('9600');
  const [msg, setMsg] = useState('');
  useEffect(() => {
    api?.ports().then(r => { setPorts(r.ports); if (!host && r.rigol_host) setHost(r.rigol_host); if (!port && r.ports[0]) setPort(r.ports[0].port); }).catch(() => {});
  }, [api]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!api) return null;
  const st = meterStore.status;
  const on = st.state === 'on' || st.state === 'connecting';
  const live = meterStore.live;
  const tol = meterStore.tolerance();
  const connect = () => {
    try { localStorage.setItem('2r-meter-kind', kind); } catch { /* */ }
    setMsg('');
    api.connect(kind === 'rigol' ? { kind, host, port: '5555' } : { kind, port, baud });
  };
  const csv = () => {
    const head = 'data;quem mediu;placa;componente;pino;net;modo;medido;unidade;esperado;resultado;aparelho;medido_em;editado\n';
    const rows = meterStore.shown.map(m => [new Date(m.t).toLocaleString('pt-BR'), m.by || '', m.board, m.part, m.pin, m.net, MODE_LABEL[m.mode],
      (m.value == null ? 'OL' : Number(m.value).toFixed(4)).replace('.', ','), m.unit, m.expected, m.status, m.source, m.via || '',
      m.edited ? 'sim (era ' + (m.orig ?? 0).toFixed(4).replace('.', ',') + ')' : ''].join(';')).join('\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([head + rows], { type: 'text/csv' }));
    a.download = 'medicoes.csv'; a.click();
  };
  return (
    <div className="r2acv r2meter">
      <div className="r2acv-title"><IconGauge size={16} /> Medições <span className="r2acv-sub">{st.state === 'on' ? 'ligado' : 'desligado'}</span></div>
      <div className="r2acv-section r2meter-conn">
        <div className="r2meter-kinds">
          <button className={`r2meter-kind ${kind === 'rigol' ? 'sel' : ''}`} onClick={() => setKind('rigol')} disabled={on}>Rigol DM858E (rede)</button>
        </div>
        {kind === 'rigol' ? (
          <label className="r2meter-field">IP do Rigol (Utility › I/O › LAN)
            <input value={host} onChange={e => setHost(e.target.value)} placeholder="ex.: 192.168.0.50" disabled={on} />
          </label>
        ) : (
          <div className="r2acv-two">
            <label className="r2meter-field">Porta USB
              <select value={port} onChange={e => setPort(e.target.value)} disabled={on}>
                {ports.length === 0 && <option value="">(nenhuma porta)</option>}
                {ports.map(p => <option key={p.port} value={p.port}>{p.port.replace('/dev/', '')}{p.desc ? ' — ' + p.desc : ''}</option>)}
              </select>
            </label>
            <label className="r2meter-field">Velocidade
              <select value={baud} onChange={e => setBaud(e.target.value)} disabled={on}>
                {['2400', '9600', '19200', '38400', '115200'].map(b => <option key={b} value={b}>{b}</option>)}
              </select>
            </label>
          </div>
        )}
        <div className="r2meter-actions">
          {!on
            ? <button className="r2acv-send r2meter-btn" onClick={connect} disabled={kind === 'rigol' ? !host.trim() : !port}><IconPlugConnected size={14} /> Ligar</button>
            : <button className="r2meter-btn r2meter-off" onClick={() => api.disconnect()}><IconPlugConnectedX size={14} /> Desligar</button>}
        </div>
        <div className={`r2acv-note ${st.state === 'error' ? 'r2acv-msg err' : ''}`}>{st.text}</div>
        {msg && <div className="r2acv-note">{msg}</div>}
        {st.state === 'on' && (
          <div className="r2meter-live">
            <span className="r2meter-val">{live?.value == null ? 'OL' : live.value.toFixed(4)}</span>
            <span className="r2meter-unit">{live?.unit || ''}</span>
          </div>
        )}
        <div className="r2acv-note">{meterStore.capture.auto
          ? 'Clique no pino na placa e encoste a ponta: quando a leitura firma, ela entra sozinha na lista abaixo.'
          : `Clique no pino na placa, encoste a ponta e aperte ${keyName(meterStore.capture.key)} para gravar.`}</div>
      </div>
      <CaptureSection />
      <MapSection />
      <div className="r2acv-section">
        <div className="r2meter-tolrow">
          <span>Tolerância:</span>
          {(['diodo', 'tensao', 'resistencia'] as Mode[]).map(m => (
            <label key={m} className="r2meter-tol">{MODE_LABEL[m]}
              <input type="number" min={0} max={100} value={tol[m]} onChange={e => meterStore.setTolerance(m, Number(e.target.value) || 0)} />%
            </label>
          ))}
        </div>
      </div>
      <div className="r2acv-section">
        <div className="r2meter-histhead">
          <b>Histórico ({meterStore.shown.length})</b>
          <button className="r2meter-icon" title="Salvar em planilha (CSV)" onClick={csv} disabled={!meterStore.shown.length}><IconDownload size={14} /></button>
          {sure
            ? <button className="r2meter-icon r2hist-sure" onClick={() => { meterStore.clear(); setSure(false); }} onBlur={() => setSure(false)} autoFocus>Apagar as desta placa?</button>
            : <button className="r2meter-icon" title="Limpar o histórico" onClick={() => setSure(true)} disabled={!meterStore.shown.length}><IconTrash size={14} /></button>}
        </div>
        <div className="r2acv-note r2hist-where">{meterStore.where === 'placa'
          ? 'Salvo junto do boardview (pasta da placa): abre junto com ela em qualquer computador.'
          : meterStore.where === 'loja'
          ? 'Salvo na pasta da loja: todos os computadores veem estas medições.'
          : meterStore.where === 'local' ? 'Salvo só neste computador (a pasta da loja não está ligada).' : ''}
          {meterStore.pending > 0 && ` Aguardando enviar: ${meterStore.pending}.`}</div>
        <table className="r2acv-table r2meter-table">
          <thead><tr><th>Pino</th><th>Medido</th><th>Esperado</th><th></th><th></th></tr></thead>
          <tbody>
            {meterStore.shown.slice(0, 300).map(m => (
              <tr key={m.t} className={`r2meter-${m.status} ${meterStore.redo?.t === m.t ? 'r2hist-redo' : ''}`}
                  title={`${MODE_LABEL[m.mode]} · ${m.source} · ${m.board}${m.edited ? ` · corrigido à mão (era ${(m.orig ?? 0).toFixed(3)})` : ''}`}>
                <td className="r2acv-td-board">
                  {m.part}.{m.pin}{m.via && <span className="r2map-via"> · em {m.via}</span>}
                  <span className="r2hist-sub">{m.net}</span>
                  <span className="r2hist-sub">{fmtWhen(m.t)}{m.by ? ' · ' + m.by : ''}</span>
                </td>
                <td>{editing === m.t ? <EditValue t={m.t} value={m.value} onDone={() => setEditing(null)} />
                  : <>{m.value == null ? 'OL' : Number(m.value).toFixed(3)}{m.edited && <span className="r2hist-ed" title="Corrigido à mão">*</span>}</>}</td>
                <td>{m.expected || '—'}</td>
                <td>{m.status === 'ok' ? '✓' : m.status === 'fora' ? '✕' : ''}</td>
                <td className="r2hist-act">
                  <button title={meterStore.redo?.t === m.t ? 'Cancelar: não medir de novo' : 'Medir de novo (a próxima leitura desse pino substitui esta)'}
                          onClick={() => (meterStore.redo?.t === m.t ? meterStore.cancelRedo() : meterStore.remeasure(m.t))}>↻</button>
                  <button title="Corrigir o valor" onClick={() => setEditing(m.t)}>✎</button>
                  <button title="Apagar esta medição" onClick={() => meterStore.remove(m.t)}>×</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
