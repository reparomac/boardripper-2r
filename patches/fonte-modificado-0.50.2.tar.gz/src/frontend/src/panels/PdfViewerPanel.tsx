import { IS_2R } from '../r2/env';
import { mirrorToBoard, searchSyncOn } from '../r2/search-sync';
import { createPortal } from 'react-dom';
import { useRef, useEffect, useCallback, useState, useMemo, useSyncExternalStore, useId } from 'react';
import type { IDockviewPanelProps } from 'dockview-react';
import { usePdfDoc } from '../hooks/usePdfStore';
import { pdfStore, pdfFontSize, PDF_LOAD_PHASE_TEXT } from '../store/pdf-store';
import { boardStore } from '../store/board-store';
import { boardPanelId, activateLinkedPanel, isAutoSwitchLinked } from '../store/dockview-api';
import { pickLinkedBoardTab } from '../store/linked-panel';
import { openBoardSearch } from './board-viewer-bridge';
import { navHistoryStore, type PdfCameraProvider } from '../store/nav-history-store';
import { useNavHistory } from '../hooks/useNavHistory';
import { IconHistory } from '@tabler/icons-react';
import { fileInputRefs } from '../store/file-inputs';
import { contextMenuStore } from '../store/context-menu-store';
import { log } from '../store/log-store';
import { PdfFilterMenu } from '../components/PdfFilterMenu';
import { PdfNightMenu } from '../components/PdfNightMenu';
import { usePdfNight, nightPipeline } from '../store/pdf-night-store';
import type { GlyphDebugState, PageGlyphData } from '../pdf/glyph-types';
import { DEFAULT_GLYPH_DEBUG_STATE } from '../pdf/glyph-types';
import { extractPageGlyphs, clearFontCache } from '../pdf/glyph-extractor';
import { drawGlyphBoxes, drawGlyphOutlines, drawTextItems } from '../pdf/glyph-overlay';
import { drawSimplifiedGlyphs } from '../pdf/glyph-simplifier';
import type { SimplifyStats } from '../pdf/glyph-simplifier';
import { drawMonospaceReplacement } from '../pdf/glyph-replacer';
import { IconArrowAutofitWidth, IconBookmarkPlus, IconHandMove, IconZoomIn, IconZoomOut, IconFileStack, IconFile, IconSwitchHorizontal } from '@tabler/icons-react';
import { pointerMode, mouseZoomSpeed, trackpadDirect } from '../renderer/BoardRenderer';
import { r2LadoPeca } from '../r2/guide-store';
/* eslint-disable @typescript-eslint/no-explicit-any */
const r2w = window as any;
import {
  TILE_SIZE, computeTileGrid, tileRenderRequest,
  getTileCached, putTileCached, invalidateTileCache,
  setTileCacheLimit,
} from '../pdf/tile-manager';
import type { TileGridInfo } from '../pdf/tile-manager';
import { renderSettingsStore, isPdfWatermarkText, getActiveWatermarkFilter } from '../store/render-settings';
import { invertScrollBindings, scrollSwapTooltip, useBareScrollAction } from '../store/scroll-mode';
import { databankStore } from '../store/databank-store';
import { showSidebarTab } from '../components/Sidebar.utils';

const DRAG_THRESHOLD = 3;
const TOUCH_PINCH_FACTOR = 1;       // 1:1 with the fingers — see note below
// A factor above 1 makes the page run ahead of the pinch and snap back when
// the fingers stop, which reads as the view jumping. The board had the same
// bug as pixi-viewport's `pinch({percent: 2})`. Keep both at 1.
const TRACKPAD_PINCH_SPEED = 0.01;  // trackpad pinch sensitivity (10× faster than mouse wheel)
const MOUSE_WHEEL_SPEED = 0.001;    // mouse wheel zoom sensitivity
/** Largest |deltaY| one ctrlKey wheel event may zoom by. A trackpad pinch
 *  step stays well under it; a mouse notch (100–200) does not. See the note at
 *  the use site. */
const PINCH_STEP_CAP = 90;
const LINE_HEIGHT_RATIO = 1.2;
const CLEAN_CONTRAST_KEY = 'boardripper-pdf-clean-contrast';
const DEFAULT_CLEAN_CONTRAST = 3;

// Scroll bindings live in store/scroll-bindings.ts (shared with the board);
// re-exported here because the older importers reach them through this panel.
import { loadScrollBindings, type ScrollAction, type ScrollBindings } from '../store/scroll-bindings';
export {
  SCROLL_ACTIONS, SCROLL_BINDINGS_KEY, DEFAULT_SCROLL_BINDINGS, loadScrollBindings,
} from '../store/scroll-bindings';
export type { ScrollAction, ScrollBindings } from '../store/scroll-bindings';

export const PDF_INERTIA_KEY = 'boardripper-pdf-inertia';
export function loadPdfInertia(): boolean {
  try { return localStorage.getItem(PDF_INERTIA_KEY) !== 'false'; } catch { return true; }
}

// PDF render quality presets live in store/pdf-quality.ts (shared with the
// start page and Settings, which must not import this panel).
export { PDF_QUALITY_KEY, PDF_RENDER_QUALITY_OPTIONS, loadPdfQuality, getPdfQualityConfig } from '../store/pdf-quality';
export type { PdfRenderQuality, PdfQualityConfig } from '../store/pdf-quality';
import { getPdfQualityConfig, loadPdfQuality, type PdfRenderQuality } from '../store/pdf-quality';

// The full-page bitmap cache and the tile cache are used in mutually-exclusive
// zoom regimes (full-page when zoomed out, tiles when zoomed in), so giving each
// the entire cacheMaxPixels budget doubled the worst-case native/GPU footprint
// (e.g. at 'high': 2×120 MP ≈ 960 MB of ImageBitmaps). Cap the tile cache at a
// fraction so the combined ceiling is ~1.6× rather than 2× cacheMaxPixels. This
// is pure eviction frequency — evicted tiles re-render on demand, and the √clamp
// on a single bitmap's dimensions still uses the full cacheMaxPixels, so render
// sharpness is unchanged.
const TILE_CACHE_BUDGET_FRACTION = 0.6;

/** Detect WebKit/Safari (including iOS Safari, iPad Safari, and macOS Safari).
 *  Used as a belt-and-suspenders cap in case the canvas-area probe doesn't
 *  catch every Safari silent-clamp variant. WebKit-only `GestureEvent` is
 *  the most reliable feature-detect — Chromium and Firefox don't ship it. */
function isWebKit(): boolean {
  if (typeof window === 'undefined') return false;
  return typeof (window as { GestureEvent?: unknown }).GestureEvent !== 'undefined';
}

/** Probe the browser's actual maximum canvas dimension. WebKit/Safari
 *  silently caps the backing store while still reporting the requested
 *  width/height — so width-readback alone doesn't catch the truth.
 *  We draw a sentinel pixel at the far corner and read it back; if the
 *  backing store was clamped, the pixel write/read fails or returns 0.
 *  In addition, WebKit gets a hard ceiling at 4096 because some macOS
 *  Safari builds report a successful draw at 8192² but produce blurry
 *  output downstream — likely an internal `createImageBitmap` cap. */
function probeMaxCanvasDim(): number {
  if (typeof document === 'undefined') return 4096; // SSR / test
  const ceiling = isWebKit() ? 4096 : 16384;
  const c = document.createElement('canvas');
  for (const dim of [16384, 8192, 4096, 2048]) {
    if (dim > ceiling) continue;
    try {
      c.width = dim;
      c.height = dim;
      const ctx = c.getContext('2d');
      if (!ctx) continue;
      // Draw a sentinel at the bottom-right corner. Safari's silent clamp
      // means the corner pixel either won't be written (write succeeds
      // silently but no backing) or readback returns 0/throws.
      ctx.fillStyle = '#ff00ff';
      ctx.fillRect(dim - 2, dim - 2, 2, 2);
      const px = ctx.getImageData(dim - 1, dim - 1, 1, 1).data;
      if (px[0] === 0xff && px[2] === 0xff) return dim;
    } catch { /* taint / out-of-bounds / OOM — try next smaller */ }
  }
  return 2048;
}
const PROBED_MAX_CANVAS_DIM = probeMaxCanvasDim();
log.pdf.log(`probed canvas-dim = ${PROBED_MAX_CANVAS_DIM}px (WebKit:${isWebKit()}; full-page path only)`);

/** Clamp scale for the full-page render path (one giant canvas). Uses the
 *  smaller of the preset's nominal maxCanvasDim and the browser's actually-
 *  achievable canvas dim. Safari silently shrinks oversize canvases, so
 *  trusting the preset alone produces blurry output above the real limit. */
function clampFullPageScale(pageW: number, pageH: number, scale: number, presetMaxDim: number): number {
  return clampCanvasScale(pageW, pageH, scale, Math.min(presetMaxDim, PROBED_MAX_CANVAS_DIM));
}


const TIER_DEBOUNCE_MS = 60; // trailing debounce — guarantees final crisp frame after zoom

/** Compute main-page render tier from zoom, capped by quality config. */
function mainTierFromZoom(zoom: number, maxTier: number): number {
  return Math.max(1, Math.min(zoom, maxTier));
}
/** Quantise tier to half-integer steps to reduce cache key thrashing. */
function quantiseTier(tier: number): number {
  return Math.round(tier * 2) / 2;
}

/**
 * Zoom hysteresis: prevent tier thrashing at quantisation boundaries.
 * Upgrade eagerly (users notice blur), downgrade lazily (over-res is invisible).
 * Returns the new tier, or the current tier if within the hysteresis band.
 */
const TIER_UP_THRESHOLD = 1.05;   // must exceed boundary by 5% to upgrade
const TIER_DOWN_THRESHOLD = 0.90; // must drop 10% below boundary to downgrade
let _lastCommittedTier = 1;
function hysteresisFilter(rawTier: number): number {
  if (rawTier > _lastCommittedTier * TIER_UP_THRESHOLD) {
    _lastCommittedTier = rawTier;
  } else if (rawTier < _lastCommittedTier * TIER_DOWN_THRESHOLD) {
    _lastCommittedTier = rawTier;
  }
  // else: stay at _lastCommittedTier (within hysteresis band)
  return _lastCommittedTier;
}

// --- Offscreen canvas pool (avoids GC churn during fast zoom/page navigation) ---
const CANVAS_POOL_CAP = 8;
const _canvasPool: HTMLCanvasElement[] = [];
function acquireCanvas(w: number, h: number): HTMLCanvasElement {
  const c = _canvasPool.pop() ?? document.createElement('canvas');
  c.width = w;
  c.height = h;
  return c;
}
function releaseCanvas(c: HTMLCanvasElement): void {
  c.width = 1;
  c.height = 1;
  if (_canvasPool.length < CANVAS_POOL_CAP) _canvasPool.push(c);
}

/** Clamp a pdf.js render scale so the resulting canvas stays within GPU limits. */
/** Per-(pageW:pageH:maxDim) throttle so we log each distinct clamp once per
 *  session rather than on every tile/render. */
const _clampLogged = new Set<string>();

function clampCanvasScale(pageW: number, pageH: number, scale: number, maxDim: number): number {
  const maxArea = maxDim * maxDim;
  const requested = scale;
  let w = pageW * scale;
  let h = pageH * scale;
  if (w > maxDim || h > maxDim) {
    scale *= Math.min(maxDim / w, maxDim / h);
    w = pageW * scale;
    h = pageH * scale;
  }
  if (w * h > maxArea) {
    scale *= Math.sqrt(maxArea / (w * h));
  }
  if (scale < requested) {
    const key = `${Math.round(pageW)}:${Math.round(pageH)}:${maxDim}`;
    if (!_clampLogged.has(key)) {
      _clampLogged.add(key);
      log.perf.warn(
        `clampCanvasScale: ${Math.round(pageW)}×${Math.round(pageH)} pt @ requested=${requested.toFixed(2)} ` +
        `clamped=${scale.toFixed(2)} (${Math.round((scale / requested) * 100)}%, maxDim=${maxDim}). ` +
        `Page too large for target tier — visible result will be softer than quality preset implies.`
      );
    }
  }
  return scale;
}

// --- Page render cache (LRU, module-level shared across all PDF panels) ---
interface CachedRender {
  bitmap: ImageBitmap;
  width: number;
  height: number;
  cssW: number;
  cssH: number;
  baseScale: number;
  hiresScale: number;
  vpHeight: number;
  vpTransform: number[];
}
// Cache limits are set dynamically from quality config via _pageCacheLimits
let _pageCacheMaxEntries = 10;
let _pageCacheMaxPixels = 80_000_000;
/** Update cache limits from quality config (called when quality changes) */
export function setPageCacheLimits(maxEntries: number, maxPixels: number): void {
  _pageCacheMaxEntries = maxEntries;
  _pageCacheMaxPixels = maxPixels;
}
const _pageCache = new Map<string, CachedRender>();
let _pageCacheTotalPixels = 0;

function pageCacheKey(file: string, page: number, tier: number, clean: boolean): string {
  return `${file}:${page}:${tier}:${clean ? 1 : 0}`;
}

function putPageCache(key: string, entry: CachedRender): void {
  const entryPixels = entry.width * entry.height;
  // LRU eviction: enforce both entry count and total pixel area
  while (
    _pageCache.size > 0 &&
    (_pageCache.size >= _pageCacheMaxEntries || _pageCacheTotalPixels + entryPixels > _pageCacheMaxPixels)
  ) {
    const oldest = _pageCache.keys().next().value!;
    const old = _pageCache.get(oldest)!;
    _pageCacheTotalPixels -= old.width * old.height;
    old.bitmap.close();
    _pageCache.delete(oldest);
  }
  // Replace existing entry for same key — the key omits containerWidth, so a
  // post-resize re-render lands on the same key with a new bitmap. Close the
  // old bitmap + subtract its pixels first, or it leaks and inflates the
  // running pixel total (mirrors putTileCached / putPreviewCache).
  const existing = _pageCache.get(key);
  if (existing) {
    _pageCacheTotalPixels -= existing.width * existing.height;
    existing.bitmap.close();
  }
  _pageCacheTotalPixels += entryPixels;
  _pageCache.set(key, entry);
}

function getPageCache(key: string): CachedRender | undefined {
  const entry = _pageCache.get(key);
  if (entry) {
    // Move to end (most recently used)
    _pageCache.delete(key);
    _pageCache.set(key, entry);
  }
  return entry;
}

/** Nominal page-cache key → the key its bitmap is stored under. Past the
 *  canvas clamp (`maxCanvasDim`) every tier produces the same pixels — at DPR 2
 *  on the `high` preset, tiers 4 to 10 are one 8192-px bitmap — so a bitmap is
 *  stored once under its *effective* tier and every nominal tier that clamps to
 *  it points here. Keyed by the nominal tier, each half-tier zoom step was a
 *  fresh 63 MP render of identical output (review 2026-10-03, 3.2). */
const _tierAlias = new Map<string, string>();

/** The tier a render actually has once the canvas clamp has been applied. */
function effectiveTier(hiresScale: number, baseScale: number, dpr: number): number {
  return Math.round((hiresScale / (baseScale * dpr)) * 1000) / 1000;
}

function getPageCacheAliased(key: string): CachedRender | undefined {
  const hit = getPageCache(key);
  if (hit) return hit;
  const alias = _tierAlias.get(key);
  return alias ? getPageCache(alias) : undefined;
}

/** Neighbour-page renders in flight, by page-cache key. The adjacent-page
 *  effect and the idle prefetch ask for the same neighbours; without this the
 *  same page was rendered twice at once. */
const _neighbourInflight = new Map<string, Promise<CachedRender>>();


/** Find the best (highest-tier) cached render for a page, regardless of tier. */
function getBestPageCache(file: string, page: number, clean: boolean): CachedRender | undefined {
  let best: { key: string; entry: CachedRender; tier: number } | undefined;
  for (const [key, entry] of _pageCache) {
    if (key.startsWith(`${file}:${page}:`) && key.endsWith(`:${clean ? 1 : 0}`)) {
      const tier = parseFloat(key.split(':')[2]);
      if (!best || tier > best.tier) {
        best = { key, entry, tier };
      }
    }
  }
  if (best) {
    _pageCache.delete(best.key);
    _pageCache.set(best.key, best.entry);
  }
  return best?.entry;
}

/**
 * Detach a display canvas (tile or adjacent-page blit target) and shrink its
 * backing store to 1×1 first, so the browser releases the (up to ~4 MB for a
 * 1024² RGBA tile) pixel buffer deterministically instead of only when GC
 * finally collects the detached element. Mirrors releaseCanvas() in the canvas
 * pool, which already shrinks before pooling. Safe here: these are our own blit
 * targets being discarded — never reused — so this is the recommended "abandon"
 * pattern, not a pool reuse.
 */
function detachCanvas(canvas: HTMLCanvasElement): void {
  canvas.width = 1;
  canvas.height = 1;
  canvas.remove();
}

// --- Preview cache: always-available tier-1 renders (never evicted by hi-res) ---
const PREVIEW_CACHE_MAX = 6;
const _previewCache = new Map<string, CachedRender>();
function previewCacheKey(file: string, page: number, clean: boolean): string {
  return `${file}:${page}:${clean ? 1 : 0}`;
}
function putPreviewCache(key: string, entry: CachedRender): void {
  if (_previewCache.size >= PREVIEW_CACHE_MAX && !_previewCache.has(key)) {
    const oldest = _previewCache.keys().next().value!;
    _previewCache.get(oldest)!.bitmap.close();
    _previewCache.delete(oldest);
  }
  const existing = _previewCache.get(key);
  if (existing) existing.bitmap.close();
  _previewCache.set(key, entry);
}
function getPreviewCache(key: string): CachedRender | undefined {
  const entry = _previewCache.get(key);
  if (entry) { _previewCache.delete(key); _previewCache.set(key, entry); }
  return entry;
}

/** Invalidate all cache entries for a given file (e.g. on clean mode toggle) */
export function invalidatePageCache(file?: string): void {
  if (!file) {
    _tierAlias.clear();
    for (const e of _pageCache.values()) e.bitmap.close();
    _pageCache.clear();
    _pageCacheTotalPixels = 0;
    for (const e of _previewCache.values()) e.bitmap.close();
    _previewCache.clear();
    return;
  }
  for (const k of [..._tierAlias.keys()]) if (k.startsWith(file + ':')) _tierAlias.delete(k);
  for (const [k, v] of _pageCache) {
    if (k.startsWith(file + ':')) {
      _pageCacheTotalPixels -= v.width * v.height;
      v.bitmap.close();
      _pageCache.delete(k);
    }
  }
  for (const [k, v] of _previewCache) {
    if (k.startsWith(file + ':')) { v.bitmap.close(); _previewCache.delete(k); }
  }
}

/** Transform a PDF-space point to canvas-pixel-space */
function toCanvas(px: number, py: number, vpT: number[], scale: number): [number, number] {
  return [
    (vpT[0] * px + vpT[2] * py + vpT[4]) * scale,
    (vpT[1] * px + vpT[3] * py + vpT[5]) * scale,
  ];
}

/** Compute a text item's axis-aligned bounding rect in canvas-space.
 *  Handles rotated/skewed text by projecting all 4 corners of the oriented
 *  text rectangle through the viewport transform and taking the AABB.
 *  Baseline at (e,f): ascent = 1.0×fontSize up, descent = 0.2×fontSize down. */
function textItemRect(
  transform: number[], width: number, vpT: number[], scale: number,
): { x: number; y: number; w: number; h: number } {
  const t = transform;
  const fsx = Math.sqrt(t[0] * t[0] + t[1] * t[1]);
  const fsy = Math.sqrt(t[2] * t[2] + t[3] * t[3]);
  const fontSize = fsy;
  const ascent = fontSize;                                // 1.0× up from baseline
  const descent = (LINE_HEIGHT_RATIO - 1.0) * fontSize;  // 0.2× down from baseline

  const dx = fsx > 0 ? t[0] / fsx : 1;
  const dy = fsx > 0 ? t[1] / fsx : 0;
  const ux = fsy > 0 ? t[2] / fsy : 0;
  const uy = fsy > 0 ? t[3] / fsy : 1;

  const ex = t[4], ey = t[5];
  const c0 = toCanvas(ex - descent * ux,          ey - descent * uy,          vpT, scale);
  const c1 = toCanvas(ex + width * dx - descent * ux, ey + width * dy - descent * uy, vpT, scale);
  const c2 = toCanvas(ex + ascent * ux,            ey + ascent * uy,            vpT, scale);
  const c3 = toCanvas(ex + width * dx + ascent * ux, ey + width * dy + ascent * uy, vpT, scale);

  const minX = Math.min(c0[0], c1[0], c2[0], c3[0]);
  const minY = Math.min(c0[1], c1[1], c2[1], c3[1]);
  const maxX = Math.max(c0[0], c1[0], c2[0], c3[0]);
  const maxY = Math.max(c0[1], c1[1], c2[1], c3[1]);

  return { x: minX, y: minY, w: maxX - minX, h: maxY - minY };
}

/** Watermark filtering happens at the pdf.js worker / parser level via a
 *  patch in `src/frontend/patches/pdfjs-dist+<version>.patch` (applied by
 *  `npm run postinstall`). The worker examines each `showText` op's
 *  reconstructed glyph string against the filter terms forwarded through
 *  the custom `watermarkFilter` render option and drops matching ops before
 *  they enter the operator list. No client-side filter callback is needed.
 *
 *  Returns the spreadable options blob (cast through `unknown` because the
 *  upstream pdf.js types don't declare our patched-in field). Pass `[]` /
 *  empty to disable on a given render. */
function wmFilterOptions(filter: readonly string[] | undefined): Record<string, readonly string[] | null> {
  return { watermarkFilter: (filter && filter.length > 0 ? filter : null) } as Record<string, readonly string[] | null>;
}

/** Compute zoom & pan to center a group of text items in the viewport */
function zoomToItemGroup(
  items: { transform: number[]; width: number }[],
  vpT: number[], baseScale: number,
  cw: number, ch: number,
  targetFraction: number,
  floorZoom: number = 0.5,
): { zoom: number; pan: { x: number; y: number } } {
  let gx1 = Infinity, gy1 = Infinity, gx2 = -Infinity, gy2 = -Infinity;
  for (const item of items) {
    const r = textItemRect(item.transform, item.width, vpT, baseScale);
    if (r.x < gx1) gx1 = r.x;
    if (r.y < gy1) gy1 = r.y;
    if (r.x + r.w > gx2) gx2 = r.x + r.w;
    if (r.y + r.h > gy2) gy2 = r.y + r.h;
  }
  const mcx = (gx1 + gx2) / 2;
  const mcy = (gy1 + gy2) / 2;
  const groupW = Math.max(gx2 - gx1, 1);
  const groupH = Math.max(gy2 - gy1, 1);
  const zoomByW = (cw * targetFraction) / groupW;
  const zoomByH = (ch * targetFraction) / groupH;
  const fit = Math.min(zoomByW, zoomByH);
  // Cap fit at 300% so we don't over-zoom tiny matches; then enforce a floor so
  // the caller can guarantee "at least floorZoom" (e.g. keep current zoom when
  // navigating matches).
  const zoom = Math.max(floorZoom, Math.min(fit, 3));
  return { zoom, pan: { x: cw / 2 - mcx * zoom, y: ch / 2 - mcy * zoom } };
}

/** Apply CSS transform directly to a DOM element — bypasses React for smooth 60fps pan/zoom.
 *
 *  Safari rasterizes a `transform: scale(z)` element to a Core Animation
 *  layer at the wrapper's *intrinsic* CSS size, then GPU-upscales the
 *  cached layer — at high zoom the user sees a blurry low-res copy on
 *  idle. The PDF panel works around this by sizing every wrapper child
 *  at *committed-zoom CSS pixels* (see committedZoomRef + the
 *  zCommit multipliers in renderTiledPage / blitToCanvas), then calling
 *  applyTransform with `s = currentZoom / committedZoom` — equal to 1 on
 *  idle. With s = 1 the wrapper has no scale, its intrinsic CSS size
 *  matches displayed size, and Safari rasterizes the GPU layer at full
 *  resolution. During gestures s briefly diverges; a 60ms-debounced
 *  render commits the new sizes and resets s to 1. */
function applyTransform(el: HTMLElement | null, x: number, y: number, s: number, mirrorW = 0) {
  if (!el) return;
  // mirrorW > 0 flips the whole wrapper (page + tiles + highlight + overlays)
  // horizontally around the page's local content width. Applied innermost so
  // it mirrors in pre-scale content space; pan/zoom math is unaffected because
  // the flipped page occupies the same on-screen box. Geometry consumers that
  // read X (click hit-test, match centering) mirror their own coordinate.
  const flip = mirrorW > 0 ? ` translateX(${mirrorW}px) scaleX(-1)` : '';
  el.style.transform = `translate(${x}px,${y}px) scale(${s})${flip}`;
}

// --- Page Scrubber Rail ---
function PageScrubber({ currentPage, pageCount, onGoToPage, scrubberRef }: {
  currentPage: number;
  pageCount: number;
  onGoToPage: (page: number) => void;
  scrubberRef?: React.MutableRefObject<HTMLDivElement | null>;
}) {
  const railRef = useRef<HTMLDivElement>(null);
  const [hoverPage, setHoverPage] = useState<number | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  const pageFromY = useCallback((clientY: number) => {
    const rail = railRef.current;
    if (!rail) return 1;
    const rect = rail.getBoundingClientRect();
    const ratio = Math.max(0, Math.min(1, (clientY - rect.top) / rect.height));
    return Math.max(1, Math.min(pageCount, Math.round(ratio * (pageCount - 1) + 1)));
  }, [pageCount]);

  const handlePointerDown = useCallback((e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    setIsDragging(true);
    const page = pageFromY(e.clientY);
    setHoverPage(page);
    onGoToPage(page);
  }, [pageFromY, onGoToPage]);

  const handlePointerMove = useCallback((e: React.PointerEvent) => {
    const page = pageFromY(e.clientY);
    setHoverPage(page);
    if (isDragging) onGoToPage(page);
  }, [pageFromY, isDragging, onGoToPage]);

  const handlePointerUp = useCallback((e: React.PointerEvent) => {
    (e.target as HTMLElement).releasePointerCapture(e.pointerId);
    setIsDragging(false);
  }, []);

  // Thumb position as percentage
  const thumbPct = pageCount > 1 ? ((currentPage - 1) / (pageCount - 1)) * 100 : 0;

  return (
    <div
      className={`pdf-scrubber${isDragging ? ' dragging' : ''}`}
      ref={(el) => { (railRef as React.MutableRefObject<HTMLDivElement | null>).current = el; if (scrubberRef) scrubberRef.current = el; }}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={() => setIsDragging(false)}
      onPointerLeave={() => { if (!isDragging) setHoverPage(null); }}
      onPointerEnter={(e) => setHoverPage(pageFromY(e.clientY))}
    >
      <div className="pdf-scrubber-track">
        <div className="pdf-scrubber-thumb" style={{ top: `${thumbPct}%` }} />
      </div>
      {hoverPage !== null && (
        <div className="pdf-scrubber-tooltip" style={{ top: `${((hoverPage - 1) / Math.max(1, pageCount - 1)) * 100}%` }}>
          {hoverPage}
        </div>
      )}
    </div>
  );
}

const subscribePdfStore = (cb: () => void) => pdfStore.subscribe(cb);

export function PdfViewerPanel(props: IDockviewPanelProps<{ pdfFileName?: string }>) {
  // 2R Tools (Roger, 10/10/2026): «subir os comandos uma barra e deixar todos do lado
  // direito, assim fica alinhado os nomes dos arquivos e o início de cada item» — a barra
  // do PDF vai para a linha das abas (à direita) e a página começa na altura da placa.
  const viewerRootRef = useRef<HTMLDivElement | null>(null);
  const [hdrSlot, setHdrSlot] = useState<HTMLElement | null>(null);
  const [pdfVisible, setPdfVisible] = useState<boolean>(() => props.api.isVisible);
  useEffect(() => {
    const d = props.api.onDidVisibilityChange(e => setPdfVisible(e.isVisible));
    return () => d.dispose();
  }, [props.api]);
  useEffect(() => {
    if (!IS_2R) return;
    // Roger (22:44): «todos esses itens na mesma barra onde tem o nome do PDF, mas para o
    // lado direito» — nome do PDF à esquerda da aba, a barra do PDF à direita.
    const g = viewerRootRef.current?.closest('.dv-groupview');
    const slot = (g?.querySelector('.dv-right-actions-container') as HTMLElement | null) ?? null;
    if (slot !== hdrSlot) setHdrSlot(slot);
  });
  const placeToolbar = (el: React.ReactElement) =>
    (IS_2R && hdrSlot && pdfVisible ? createPortal(<div className="r2-pdf-hdr">{el}</div>, hdrSlot) : el);
  const pdfFileName = props.params.pdfFileName ?? '';
  // This file's load phase (pdfStore.loads), from the open until the first
  // page is on screen.
  const load = useSyncExternalStore(subscribePdfStore, () => pdfStore.loads.byName[pdfFileName]);
  const { isLoaded, textExtracting, textExtractProgress, pageCount, currentPage, rotation, pageMode, mirror, searchQuery, matches, activeMatchIndex, matchNavSeq, matchGroupCount, activeGroupIndex, isMultiTerm, isAtSyntax, multiTermYGap, multiTermXGap, bookmarks, cleanMode, parseGen, lookupHint, crossProbeHint } = usePdfDoc(pdfFileName);
  /** Effective single-page layout: explicit single mode OR forced while rotated. */
  const singlePageMode = pageMode === 'single' || rotation !== 0;
  /** Current user rotation, read imperatively inside render callbacks. */
  const rotationRef = useRef(rotation);
  rotationRef.current = rotation;
  /** Horizontal mirror, read imperatively inside transform/hit-test callbacks. */
  const mirrorRef = useRef(mirror);
  mirrorRef.current = mirror;

  // Page-number input is draft-based: typing edits a local draft only; the
  // page change commits on Enter/blur (typing "250" must not visit 2 and 25).
  const [pageDraft, setPageDraft] = useState<string | null>(null);
  const pageDraftCancelRef = useRef(false);

  // Switch pdfStore to this panel's document on activation (for mutations)
  useEffect(() => {
    if (!pdfFileName) return;
    // Capture the input node at effect time so the cleanup compares against
    // the node this effect registered, not whatever the ref happens to point
    // at when React tears the panel down (the input may already be detached).
    const searchInputNode = searchInputRef.current;
    // A panel that mounts already active — the first PDF opened, or the one
    // Dockview restores — gets no activation event, so the field was never
    // registered and ⌘F found nothing to focus (2026-10-20). `isLoaded` is in
    // the deps because the field exists only once the document does.
    if (props.api.isActive && searchInputNode) fileInputRefs.pdfSearch = searchInputNode;
    // Also switch when this panel becomes active (focused)
    const disposable = props.api.onDidActiveChange((e) => {
      log.pdf.log(`onDidActiveChange pdf=${pdfFileName} isActive=${e.isActive} storeActive=${boardStore.activeTabId}`);
      if (e.isActive) {
        pdfStore.switchTo(pdfFileName);
        // Register this panel's search input for global Cmd+F routing
        fileInputRefs.pdfSearch = searchInputRef.current;
        // Activate linked board panel so it follows the PDF tab.
        // Gated by auto-switch flag (toggled via BindLink dropdown header).
        // Prefer the currently-active board tab when it's already bound to this
        // PDF: a PDF can be bound to several board tabs (e.g. two revisions
        // sharing one schematic), and a double-click lookup from a non-first
        // bound tab must not yank the board to a sibling tab.
        const linkedTabId = isAutoSwitchLinked()
          ? pickLinkedBoardTab(boardStore.tabs, boardStore.activeTabId, pdfFileName)
          : null;
        log.pdf.log(`linkedTab=${linkedTabId ?? 'none'} autoSwitch=${isAutoSwitchLinked()}`);
        if (linkedTabId != null) {
          const ok = activateLinkedPanel(boardPanelId(linkedTabId), () => boardStore.switchTab(linkedTabId));
          log.pdf.log(`activateLinkedPanel board-${linkedTabId} ok=${ok}`);
        }
      }
    });
    return () => {
      // Cleanup on unmount — only clear the global slot if it still points
      // at the input this effect captured at setup time.
      if (fileInputRefs.pdfSearch === searchInputNode) {
        fileInputRefs.pdfSearch = null;
      }
      disposable.dispose();
    };
  }, [pdfFileName, props.api, isLoaded]);

  // Board/PDF linking lives in the dockview tab (∞) — see components/PdfTab.tsx.

  const canvasRef = useRef<HTMLCanvasElement>(null);
  /** What the main canvas holds right now, so a stand-in is only drawn when it
   *  is sharper (see renderPage). */
  /** Backing size the highlight canvas should have. It is only given that
   *  size while it has matches to draw (drawHighlights); hidden, it is 1×1 —
   *  a page-sized highlight canvas was reallocated on every settle with no
   *  search active (review 2026-10-03, 3.4). */
  const hlSizeRef = useRef({ w: 0, h: 0 });
  const mainContentRef = useRef<{ el: HTMLCanvasElement; file: string; page: number; clean: boolean; rot: number; cssW: number; width: number } | null>(null);
  /** The bitmap each tile canvas was last drawn from (see renderTiledPage). */
  const tileBitmapRef = useRef(new WeakMap<HTMLCanvasElement, ImageBitmap>());
  const highlightRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  /** The one element every pointer event targets — see the JSX comment. */
  const touchSurfaceRef = useRef<HTMLDivElement>(null);
  const wrapperRef = useRef<HTMLDivElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const renderTaskRef = useRef<{ cancel: () => void } | null>(null);
  const scaleRef = useRef(1);
  /** Actual canvas render scale (after clamping) — used for highlight positioning */
  const hiresScaleRef = useRef(1);
  /** Forward-ref to scheduleTierRender — populated below after scheduleTierRender is created.
   *  Lets syncTransform (defined earlier) trigger a debounced tile re-render on pan
   *  without circular-dependency gymnastics in the useCallback chain. */
  const scheduleTierRenderRef = useRef<() => void>(() => {});

  /** Current PDF render mode (auto/standard/always-tile). Ref-backed so the render
   *  router and pan/zoom handlers don't take renderSettingsStore as a dep — a
   *  useEffect (below) keeps it in sync and re-triggers a render on change. */
  const pdfRenderModeRef = useRef<'auto' | 'standard' | 'always-tile'>(
    renderSettingsStore.settings.pdfRenderMode
  );

  /** Should the panel render in tiled mode right now? Function so callers always
   *  read the latest mode AND zoom — both can change between event and render. */
  const shouldUseTilesRef = useRef<() => boolean>(() => false);
  shouldUseTilesRef.current = () => {
    const mode = pdfRenderModeRef.current;
    if (mode === 'always-tile') return true;
    if (mode === 'standard') return false;
    return zoomRef.current > 1.05;
  };

  /** Gesture-active flag: true while the user is actively zooming via wheel/pinch.
   *  Adaptive-throttle renders in scheduleTierRender are suspended when set; the
   *  60 ms trailing debounce still fires after the gesture ends, so the user sees
   *  CSS-scaled transform during interaction and one crisp render at settle. */
  const gestureActiveRef = useRef(false);
  const gestureEndTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const markGestureActive = useCallback(() => {
    gestureActiveRef.current = true;
    if (gestureEndTimerRef.current) clearTimeout(gestureEndTimerRef.current);
    gestureEndTimerRef.current = setTimeout(() => {
      gestureActiveRef.current = false;
      gestureEndTimerRef.current = null;
    }, 150);
  }, []);

  /** Zoom level at which every in-DOM wrapper child's CSS dimensions are
   *  currently committed. See applyTransform docstring for rationale. */
  const committedZoomRef = useRef(1);

  /** Multiply every in-DOM wrapper child's CSS left/top/width/height by
   *  `ratio`. Called when committedZoom changes so old tiles outside the
   *  current viewport-cull range stay positioned correctly relative to
   *  the new committed coords (without this, old tiles end up at stale
   *  positions and appear in the wrong place — the "random tiles"
   *  regression). The same scalar `ratio` works for tiles at every
   *  rendered scale because each tile's CSS = (col × cssTileW) ×
   *  committedZoom: when committedZoom ratios up/down, every tile's
   *  CSS scales by the same factor.
   *
   *  Idempotent for elements that are then overwritten with explicit
   *  zCommit-scaled values later in the same render. */
  const rescaleWrapperChildren = useCallback((ratio: number) => {
    if (ratio === 1 || !Number.isFinite(ratio) || ratio <= 0) return;
    const apply = (s: CSSStyleDeclaration) => {
      const left = parseFloat(s.left);
      const top = parseFloat(s.top);
      const w = parseFloat(s.width);
      const h = parseFloat(s.height);
      if (Number.isFinite(left)) s.left = `${left * ratio}px`;
      if (Number.isFinite(top)) s.top = `${top * ratio}px`;
      if (Number.isFinite(w)) s.width = `${w * ratio}px`;
      if (Number.isFinite(h)) s.height = `${h * ratio}px`;
    };
    for (const tileCanvas of tileContainerRef.current.values()) apply(tileCanvas.style);
    for (const entry of adjCanvasMapRef.current.values()) apply(entry.canvas.style);
    if (canvasRef.current) apply(canvasRef.current.style);
    if (highlightRef.current) apply(highlightRef.current.style);
    if (detailRef.current.canvas) apply(detailRef.current.canvas.style);
  }, []);
  const viewportHeightRef = useRef(0);
  const renderTierRef = useRef(1);
  const viewportTransformRef = useRef<number[]>([1, 0, 0, -1, 0, 0]);
  const [renderEpoch, setRenderEpoch] = useState(0); // bumped after each renderPage to sync overlays
  const [showNavHint, setShowNavHint] = useState(false);

  // Recent queries under the find field — Preview's magnifier menu. Opens on
  // focus and while typing (filtered by the text), never by itself, and it
  // takes ↑↓ / Enter only while it is open, so match stepping after a search
  // is untouched. Fed by the navigation history (searches and lookups whose
  // query ran in a PDF), so the History tab's Clear empties it too.
  const [recentsOpen, setRecentsOpen] = useState(false);
  const [recentHi, setRecentHi] = useState(-1);
  const [recentFilter, setRecentFilter] = useState('');
  const { listed: navListed } = useNavHistory();
  const pdfRecents = useMemo(() => {
    const out: string[] = [];
    const seen = new Set<string>();
    const f = recentFilter.trim().toLowerCase();
    for (const e of navListed) {
      const q = e.query;
      if (!q || q.surface !== 'pdf') continue;
      const key = q.text.toLowerCase();
      if (seen.has(key)) continue;
      if (f && !key.includes(f)) continue;
      seen.add(key);
      out.push(q.text);
      if (out.length >= 8) break;
    }
    return out;
  }, [navListed, recentFilter]);
  const pickRecent = useCallback((text: string) => {
    if (searchInputRef.current) searchInputRef.current.value = text;
    pdfStore.switchTo(pdfFileName);
    pdfStore.setLastClickedLocation(null);
    pdfStore.searchText(text);
    navHintShownRef.current = false;
    setRecentsOpen(false);
    setRecentHi(-1);
    searchInputRef.current?.focus();
  }, [pdfFileName]);
  const navHintTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const navHintShownRef = useRef(false);
  // Click-to-lookup overlay state
  // Click-highlight is managed imperatively (refs + direct DOM writes), NOT React
  // state. It lives inside the CSS-transformed page wrapper, so a state update here
  // would re-render the component and force the browser to recomposite that GPU
  // layer — showing a blurry low-res copy at zoom > 1 until the next committed
  // render re-sharpens it (see the applyTransform comment above). Writing styles
  // directly touches only this one overlay div and never triggers a re-render.
  const clickHighlightElRef = useRef<HTMLDivElement | null>(null);
  const clickTooltipElRef = useRef<HTMLSpanElement | null>(null);
  const clickHighlightTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const showClickHighlight = useCallback(
    (rect: { x: number; y: number; w: number; h: number }, word: string, zoom: number, durationMs = 4000) => {
      const el = clickHighlightElRef.current;
      if (!el) return;
      // Wrapper children are sized at committed-zoom CSS pixels; the captured zoom
      // matches committedZoom at click time. Auto-dismiss bounds any later staleness.
      const z = zoom || 1;
      const padY = 1 / z; // y-only breathing room; x hugs the word so it can't bleed onto the next glyph
      el.style.left = `${rect.x * z}px`;
      el.style.top = `${(rect.y - padY) * z}px`;
      el.style.width = `${rect.w * z}px`;
      el.style.height = `${(rect.h + padY * 2) * z}px`;
      const tip = clickTooltipElRef.current;
      if (tip) tip.textContent = word || 'Double-click to search';
      el.style.display = '';
      // Restart the 4s fade animation on reuse — no remount happens to retrigger it.
      el.style.animation = 'none';
      if (tip) tip.style.animation = 'none';
      void el.offsetWidth; // force reflow so the animation replays
      el.style.animation = '';
      if (tip) tip.style.animation = '';
      if (clickHighlightTimerRef.current) clearTimeout(clickHighlightTimerRef.current);
      clickHighlightTimerRef.current = setTimeout(() => {
        if (clickHighlightElRef.current) clickHighlightElRef.current.style.display = 'none';
      }, durationMs);
    },
    [],
  );

  const hideClickHighlight = useCallback(() => {
    if (clickHighlightTimerRef.current) clearTimeout(clickHighlightTimerRef.current);
    if (clickHighlightElRef.current) clickHighlightElRef.current.style.display = 'none';
  }, []);
  // Tile DOM management
  const tileGridRef = useRef<TileGridInfo | null>(null);
  const tileRenderIdRef = useRef(0);
  const tileContainerRef = useRef<Map<string, HTMLCanvasElement>>(new Map());
  const [error, setError] = useState<string | null>(null);
  const blinkTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const blinkPhaseRef = useRef(0);

  // Pan/zoom live in refs for 60fps DOM updates; React state only for toolbar display
  const zoomRef = useRef(1);
  const panRef = useRef({ x: 0, y: 0 });
  /** The toolbar's zoom readout, written straight to the DOM: as React state
   *  it re-rendered this whole panel on 169 of 170 pinch frames
   *  (review 2026-10-03, 1.1). */
  const zoomInfoRef = useRef<HTMLSpanElement>(null);
  const [tiledMode, setTiledMode] = useState(false);
  const zoomDisplayRafRef = useRef(0);
  const isDraggingRef = useRef(false);
  const dragStartRef = useRef({ x: 0, y: 0 });
  const lastMouseRef = useRef({ x: 0, y: 0 });
  const wasDragRef = useRef(false);
  const velocityRef = useRef({ x: 0, y: 0 });
  const lastDragTimeRef = useRef(0);
  const inertiaRafRef = useRef(0);
  /** Every programmatic jump (match step, board follow, bookmark, history
   *  restore) stops a running drag glide first — otherwise the glide keeps
   *  adding its velocity to the pan the jump just wrote and drags the page
   *  off the target (a lone search hit stepped to again landed hundreds of
   *  px short, 2026-09-29). */
  const stopGlide = () => {
    cancelAnimationFrame(inertiaRafRef.current);
    inertiaRafRef.current = 0;
    velocityRef.current = { x: 0, y: 0 };
  };
  const pdfInertiaRef = useRef(loadPdfInertia());
  const tierDebounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  /** Last zoom level at which highlights were drawn — skip redraw on pan-only changes */
  const lastHighlightZoomRef = useRef('');
  /** Adaptive zoom: exponential moving average of pdf.js render time (ms) */
  const renderTimeEmaRef = useRef(0);
  /** Adaptive zoom: timestamp of last throttled render start */
  const lastThrottleRenderRef = useRef(0);
  /** Delayed full-quality render — fires 500ms after zoom settles */
  const crispTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  /** When true, renderPage ignores quality cap and renders at full zoom tier */
  const forceFullTierRef = useRef(false);
  const CRISP_SETTLE_MS = 500;

  const night = usePdfNight();
  const nightMode = night.on;
  // url(#…) needs a plain id; useId's colons/guillemets are not one.
  const nightFilterId = `pdf-night-${useId().replace(/[^a-zA-Z0-9_-]/g, '')}`;
  const nightFx = nightPipeline(night, nightFilterId);
  const [cleanContrast] = useState(() => {
    try { const v = localStorage.getItem(CLEAN_CONTRAST_KEY); return v ? Number(v) : DEFAULT_CLEAN_CONTRAST; } catch { return DEFAULT_CLEAN_CONTRAST; }
  });
  const cleanContrastRef = useRef(cleanContrast);
  cleanContrastRef.current = cleanContrast;
  const [scrollBindings, setScrollBindings] = useState<ScrollBindings>(loadScrollBindings);
  const scrollBindingsRef = useRef(scrollBindings);
  scrollBindingsRef.current = scrollBindings;
  const bareAction = useBareScrollAction();

  // Sync scroll bindings when changed from Settings panel
  useEffect(() => {
    const handler = (e: Event) => {
      const next = (e as CustomEvent<ScrollBindings>).detail;
      setScrollBindings(next);
      scrollBindingsRef.current = next;
    };
    window.addEventListener('pdf-scroll-bindings-changed', handler);
    const inertiaHandler = () => { pdfInertiaRef.current = loadPdfInertia(); };
    window.addEventListener('pdf-inertia-changed', inertiaHandler);
    return () => {
      window.removeEventListener('pdf-scroll-bindings-changed', handler);
      window.removeEventListener('pdf-inertia-changed', inertiaHandler);
    };
  }, []);

  // PDF render quality — persisted, synced from Settings panel
  const [pdfQuality, setPdfQuality] = useState<PdfRenderQuality>(loadPdfQuality);
  const qcfg = getPdfQualityConfig(pdfQuality);
  const qcfgRef = useRef(qcfg);
  qcfgRef.current = qcfg;

  // Apply cache limits on mount and quality change
  useEffect(() => {
    setPageCacheLimits(qcfg.cacheMaxEntries, qcfg.cacheMaxPixels);
    setTileCacheLimit(Math.round(qcfg.cacheMaxPixels * TILE_CACHE_BUDGET_FRACTION));
  }, [qcfg.cacheMaxEntries, qcfg.cacheMaxPixels]);

  // Sync quality when changed from Settings panel
  useEffect(() => {
    const handler = (e: Event) => {
      const next = (e as CustomEvent<PdfRenderQuality>).detail;
      setPdfQuality(next);
      const cfg = getPdfQualityConfig(next);
      // Update ref immediately so renderPage uses the new config
      // (React state won't commit until next render cycle)
      qcfgRef.current = cfg;
      setPageCacheLimits(cfg.cacheMaxEntries, cfg.cacheMaxPixels);
      invalidatePageCache(pdfFileName); clearDetail();
      setTileCacheLimit(Math.round(cfg.cacheMaxPixels * TILE_CACHE_BUDGET_FRACTION));
      invalidateTileCache(pdfFileName);
      _lastCommittedTier = 1; // reset hysteresis
      renderPageRef.current();
    };
    window.addEventListener('pdf-quality-changed', handler);
    return () => window.removeEventListener('pdf-quality-changed', handler);
  }, [pdfFileName]);

  // Back from the background: a browser may have purged canvas backing
  // stores meanwhile (iOS does), so every tile is drawn again on the next
  // pass instead of being trusted to still hold its bitmap.
  useEffect(() => {
    const onVis = () => { if (document.visibilityState === 'visible') tileBitmapRef.current = new WeakMap(); };
    document.addEventListener('visibilitychange', onVis);
    return () => document.removeEventListener('visibilitychange', onVis);
  }, []);

  // A reparse (filter menu ▸ Reload & re-parse) swapped in new pdf.js
  // documents: every cached bitmap and tile was drawn from the old ones.
  const lastParseGenRef = useRef(parseGen);
  useEffect(() => {
    if (lastParseGenRef.current === parseGen) return;
    lastParseGenRef.current = parseGen;
    invalidatePageCache(pdfFileName); clearDetail();
    invalidateTileCache(pdfFileName);
    renderPageRef.current();
  }, [parseGen, pdfFileName]);

  // Sync caches with the store's watermark filter. Runs on
  // every render-settings change, but reference identity on the list AND the
  // enabled flag's primitive equality act as fast guards — no stringify per
  // notify.
  useEffect(() => {
    let prevFilter = renderSettingsStore.globalSettings.pdfWatermarkFilter;
    let prevEnabled = renderSettingsStore.globalSettings.pdfWatermarkFilterEnabled;
    const unsub = renderSettingsStore.subscribe(() => {
      const curFilter = renderSettingsStore.globalSettings.pdfWatermarkFilter;
      const curEnabled = renderSettingsStore.globalSettings.pdfWatermarkFilterEnabled;
      if (curFilter === prevFilter && curEnabled === prevEnabled) return;
      prevFilter = curFilter;
      prevEnabled = curEnabled;
      // pdf.js keys intentStates only on rendering intent + annotation hash,
      // so a watermark-filter change alone doesn't invalidate the cached
      // operator list. Flush it explicitly so the worker re-parses with the
      // new filter. Then drop our bitmap caches and trigger a fresh render.
      pdfStore.flushOperatorListCache(pdfFileName);
      invalidatePageCache(pdfFileName); clearDetail();
      invalidateTileCache(pdfFileName);
      renderPageRef.current();
    });
    return unsub;
  }, [pdfFileName]);

  // Sync pdfRenderMode ref + re-route on change. shouldUseTilesRef reads the ref
  // on every call, so the next render picks up the new mode automatically. The
  // explicit renderPageRef.current() call handles the case where nothing else
  // would naturally trigger a re-render (e.g. user toggles mode while idle).
  useEffect(() => {
    pdfRenderModeRef.current = renderSettingsStore.settings.pdfRenderMode;
    const unsub = renderSettingsStore.subscribe(() => {
      const cur = renderSettingsStore.settings.pdfRenderMode;
      if (cur === pdfRenderModeRef.current) return;
      pdfRenderModeRef.current = cur;
      log.pdf.log(`render mode → ${cur}`);
      renderPageRef.current();
    });
    return unsub;
  }, []);

  const [editingBookmarkId, setEditingBookmarkId] = useState<string | null>(null);
  const [editingLabel, setEditingLabel] = useState('');
  const [glyphDebug] = useState<GlyphDebugState>(DEFAULT_GLYPH_DEBUG_STATE);

  // glyphMenuOpen/glyphMenuTimerRef removed — legacy glyph-debug menu was
  // rendered inside the now-commented cleaner popup.
  const [fontDataLoaded, setFontDataLoaded] = useState(false);
  const [glyphLoading, setGlyphLoading] = useState(false);
  const glyphCanvasRef = useRef<HTMLCanvasElement>(null);
  const pageGlyphDataRef = useRef<PageGlyphData | null>(null);
  const simplifyStatsRef = useRef<SimplifyStats | null>(null);

  const isTextItemsMode = glyphDebug.overlayMode === 'textItems';
  const isGlyphActive = (glyphDebug.overlayMode !== 'off' && !isTextItemsMode) || glyphDebug.simplifyEnabled || glyphDebug.replaceEnabled;
  const isOverlayActive = isGlyphActive || isTextItemsMode;
  const isGlyphComposite = glyphDebug.simplifyEnabled || glyphDebug.replaceEnabled;

  const bookmarkClickTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const skipResetRef = useRef(false);

  // Scrubber flash: DOM classList toggle to avoid re-rendering the whole panel
  const scrubberFlashTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const scrubberElRef = useRef<HTMLDivElement | null>(null);
  const flashScrubber = useCallback(() => {
    const el = scrubberElRef.current;
    if (!el) return;
    el.classList.add('flash');
    if (scrubberFlashTimerRef.current) clearTimeout(scrubberFlashTimerRef.current);
    scrubberFlashTimerRef.current = setTimeout(() => el.classList.remove('flash'), 800);
  }, []);

  // --- Multi-page rendering (adjacent pages visible when zoomed out / panning) ---
  /** CSS height of the current page at zoom=1 */
  const pageCssHRef = useRef(0);
  /** Imperatively managed canvases for adjacent pages, keyed by page number */
  const adjCanvasMapRef = useRef<Map<number, { canvas: HTMLCanvasElement; tier: number }>>(new Map());
  /** Bumped after zoom settles to trigger adjacent re-render (debounced, not per-render) */
  const [adjTrigger, setAdjTrigger] = useState(0);
  const adjDebounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  /** The tier a neighbour page at `offset` should have now: the full
   *  neighbour tier when it is on screen or within the preset's near margin,
   *  else the preset's far cap. One rule for the adjacent effect and for the
   *  pan check below, so they cannot disagree about what "sharp" means. */
  const neighbourTierFor = useCallback((offset: number): number => {
    const cfg = qcfgRef.current;
    const near = quantiseTier(Math.min(renderTierRef.current, cfg.maxAdjTier));
    const far = quantiseTier(Math.min(near, cfg.neighbourFarTier));
    const container = containerRef.current;
    const pageH = pageCssHRef.current * zoomRef.current;
    if (!container || pageH <= 0) return near;
    const viewH = container.clientHeight;
    const margin = viewH * cfg.neighbourNearMargin;
    const top = panRef.current.y + offset * pageH;
    return top < viewH + margin && top + pageH > -margin ? near : far;
  }, []);

  /** After a pan settles, a neighbour that has come near the viewport is
   *  upgraded to the full tier — a page edge must not stay soft while the
   *  user looks at it. Debounced on the pan, so a fling does not render
   *  every neighbour it passes. */
  const neighbourCheckTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const scheduleNeighbourCheck = useCallback(() => {
    if (neighbourCheckTimerRef.current) clearTimeout(neighbourCheckTimerRef.current);
    neighbourCheckTimerRef.current = setTimeout(() => {
      neighbourCheckTimerRef.current = null;
      // A pan only. While a zoom is waiting for its render (the wrapper still
      // carries a transient scale) the main render's own settle re-runs the
      // neighbours; checking here started renders the next zoom step cancelled.
      if (Math.abs(zoomRef.current / committedZoomRef.current - 1) > 1e-3) return;
      const current = pdfStore.getDocCurrentPage(pdfFileName);
      for (const [pageNum, entry] of adjCanvasMapRef.current) {
        if (entry.tier < neighbourTierFor(pageNum - current)) { setAdjTrigger(t => t + 1); return; }
      }
    }, 150);
  }, [neighbourTierFor, pdfFileName]);
  useEffect(() => () => { if (neighbourCheckTimerRef.current) clearTimeout(neighbourCheckTimerRef.current); }, []);

  // ---- Settled detail render (2026-10-10) ----------------------------------
  // The full-page canvas is the *moving* picture: its size is the preset's
  // (maxCanvasDim), which is what keeps pan and pinch cheap — and what made
  // deep zoom soft on the cheap presets, and on the expensive ones cost
  // ~700 MB per canvas until Chrome ran out of GPU memory and drew black
  // (820-02020.pdf at >500 % on 'max'). Once the view settles, a canvas the
  // size of the visible area plus a margin is rendered at the exact zoom and
  // laid over the page — pdf.js's own PDFPageDetailView design. One op-walk
  // per settle, memory ~ one screen at any zoom, sharp on every preset.
  const detailRef = useRef<{
    canvas: HTMLCanvasElement | null; task: { cancel: () => void } | null; gen: number;
    rect: { x: number; y: number; w: number; h: number } | null; zoom: number; page: number;
  }>({ canvas: null, task: null, gen: 0, rect: null, zoom: 0, page: 0 });
  const detailTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const renderDetailRef = useRef<() => void>(() => {});
  /** Drop the detail canvas (page change, rotation, reparse, filter, resize). */
  const clearDetail = useCallback(() => {
    const d = detailRef.current;
    d.gen++;
    d.task?.cancel();
    d.task = null;
    d.rect = null;
    if (d.canvas) { detachCanvas(d.canvas); d.canvas = null; }
  }, []);
  /** Render the detail once motion has stopped for a moment. */
  const scheduleDetail = useCallback(() => {
    if (detailTimerRef.current) clearTimeout(detailTimerRef.current);
    detailTimerRef.current = setTimeout(() => { detailTimerRef.current = null; renderDetailRef.current(); }, 150);
  }, []);
  useEffect(() => () => { if (detailTimerRef.current) clearTimeout(detailTimerRef.current); }, []);

  /** Clamp pan so the page stays within view boundaries.
   *
   *  Single-page PDFs use *loose* clamps with a margin overshoot on both axes
   *  so the user can pull the page slightly off-screen to zoom-anchor near the
   *  edges. Multi-page first/last keep hard clamps because the page-flip
   *  threshold at `containerH/2` depends on them.
   *
   *  Gated by `pdfEnableBoundaries` (Settings ▸ Performance & Debug). When the
   *  toggle is off (default), the function returns immediately — pan is fully
   *  unrestricted. Page-flip thresholds in the wheel handler still fire as the
   *  user crosses them; this only removes the position clamp that was
   *  occasionally locking users at first/last-page Y or page-fits-X. */
  /** Continuous mode: when the pan has carried the current page far enough off
   *  screen, adopt the neighbour as the current page and rebase the pan by one
   *  page height. Returns the rebased y.
   *
   *  This used to be inline in the wheel handler and nowhere else, so a finger
   *  could pan past the bottom of the current page for ever: the pan kept
   *  growing, the page indicator never moved, and since only `currentPage ± 1`
   *  is rendered, everything past the neighbour was blank paper. Measured on
   *  the 16-page fixture before the fix — fourteen swipes, pan at −11648 px,
   *  page still 1, nothing drawn below page 2.
   *
   *  It loops. One wheel notch can only ever cross one boundary, but a swipe
   *  is most of a screen and a fling is several, so flipping once per gesture
   *  would leave the same hole a page further down.
   */
  const flipPagesForPan = useCallback((y: number): number => {
    const container = containerRef.current;
    const cssH = pageCssHRef.current;
    if (!container || cssH <= 0) return y;
    if (pdfStore.isDocSinglePage(pdfFileName)) return y;

    const pageH = cssH * zoomRef.current;
    if (pageH <= 0) return y;
    const containerH = container.clientHeight;
    const total = pdfStore.getDocPageCount(pdfFileName);

    // Bounded: `total` crossings is the most any pan can need, and a bound
    // means a degenerate pageH can never spin here.
    for (let guard = 0; guard < total; guard++) {
      const curPage = pdfStore.getDocCurrentPage(pdfFileName);
      let next: number;
      if (y + pageH < containerH / 2 && curPage < total) next = curPage + 1;
      else if (y > containerH / 2 && curPage > 1) next = curPage - 1;
      else break;

      skipResetRef.current = true;
      ++tileRenderIdRef.current;
      if (tierDebounceRef.current) { clearTimeout(tierDebounceRef.current); tierDebounceRef.current = null; }
      if (crispTimerRef.current) { clearTimeout(crispTimerRef.current); crispTimerRef.current = null; }
      for (const c of tileContainerRef.current.values()) c.style.display = 'none';
      // Tiled mode: hold the already-rendered neighbour as a backdrop until the
      // new page's tiles arrive. Full-page mode blits from cache instantly.
      if (shouldUseTilesRef.current()) {
        const adj = adjCanvasMapRef.current.get(next);
        if (adj) {
          adj.canvas.style.top = '0px';
          adj.canvas.dataset.transitionBackdrop = '1';
          wrapperRef.current?.querySelectorAll('canvas[data-transition-backdrop]')
            .forEach(c => { if (c !== adj.canvas) c.remove(); });
        }
      }
      pdfStore.goToPage(next);
      y += next > curPage ? pageH : -pageH;
      flashScrubber();
    }
    return y;
  }, [pdfFileName, flashScrubber]);

  const clampPan = useCallback(() => {
    if (!renderSettingsStore.settings.pdfEnableBoundaries) return;

    // Blocking mode locks zoom to ≥ fit-width (100%): a page is never shorter
    // than the viewport width allows, so the scroll-flip threshold keeps a wide
    // dead-zone and can't bounce. Snap up here too so a bookmark restore — or
    // toggling the mode on while already zoomed out — self-corrects on the next
    // sync rather than leaving the page in the bounce-prone sub-100% range.
    if (zoomRef.current < 1) zoomRef.current = 1;

    const container = containerRef.current;
    if (!container) return;
    const containerW = container.clientWidth;
    const containerH = container.clientHeight;
    // Issue #20: Dockview's onlyWhenVisible renderer collapses a hidden panel's
    // container to 0×0, which fires the ResizeObserver → syncTransform → here.
    // With containerW=0 the X branch below would recenter pan.x to 0 (pageW=0 ≤
    // containerW=0), silently losing the horizontal scroll position the moment
    // you switch to another tab. Never clamp against a degenerate viewport —
    // leave pan untouched until the panel is laid out again with a real size.
    if (containerW === 0 || containerH === 0) return;
    const zoom = zoomRef.current;
    const cssH = pageCssHRef.current;
    let { x, y } = panRef.current;

    const total = pdfStore.getDocPageCount(pdfFileName);
    // Treat as single-page when the doc has one page, or single-page layout is
    // active (explicit mode, or forced while rotated) — pan is locked to the
    // current page on both axes rather than flowing into neighbours.
    const singlePage = total === 1 || pdfStore.isDocSinglePage(pdfFileName);
    const SINGLE_PAGE_MARGIN = 80;

    // --- X axis ---
    const pageW = containerW * zoom;
    if (pageW <= containerW) {
      x = (containerW - pageW) / 2; // page fits — centered
    } else {
      // 2R 25/10/2026: folga de meia tela nas bordas para o resultado sempre ficar no centro (window.__r2PdfCentro=false desliga)
      const margin = r2w.__r2PdfCentro !== false ? Math.max(singlePage ? SINGLE_PAGE_MARGIN : 0, containerW / 2) : singlePage ? SINGLE_PAGE_MARGIN : 0;
      x = Math.max(containerW - pageW - margin, Math.min(margin, x));
    }

    // --- Y axis ---
    if (cssH > 0) {
      const pageH = cssH * zoom;
      if (singlePage) {
        if (pageH > containerH) {
          y = Math.max(containerH - pageH - SINGLE_PAGE_MARGIN, Math.min(SINGLE_PAGE_MARGIN, y));
        } else {
          y = (containerH - pageH) / 2; // page fits vertically — centered
        }
      } else {
        const curPage = pdfStore.getDocCurrentPage(pdfFileName);
        if (curPage === 1) y = Math.min(y, 0);
        if (curPage === total) y = Math.max(y, containerH - pageH);
      }
    }

    // Diagnostic, at most one line per gesture (`clampLoggedRef` is cleared on
    // pointerdown). "Panning moves a bit and stops" is what clamping looks
    // like from the outside, and clamping is also the correct behaviour when
    // the page already fits — so the only way to tell a bug from working as
    // designed is to know which axis clamped and against what. Reproducing
    // this needs a real iPad: Playwright's WebKit is the Mac port, reports
    // `maxTouchPoints: 0`, and injects no multi-touch, so the whole pointer
    // stream here is synthetic and pans 1:1 at every UI scale.
    const clamped = x !== panRef.current.x || y !== panRef.current.y;
    if (clamped && !clampLoggedRef.current) {
      clampLoggedRef.current = true;
      log.pdf.log('pan clamped', {
        from: { x: Math.round(panRef.current.x), y: Math.round(panRef.current.y) },
        to: { x: Math.round(x), y: Math.round(y) },
        zoom: +zoom.toFixed(3), containerW, containerH,
        pageW: Math.round(containerW * zoom), pageH: Math.round(cssH * zoom),
        singlePage,
      });
    }
    panRef.current = { x, y };
  }, [pdfFileName]);

  /** Push zoom/pan refs to DOM + throttled React state for toolbar.
   *  Wrapper scale = `currentZoom / committedZoom`. On idle this is 1
   *  (transform: translate-only) — the wrapper layer is at its intrinsic
   *  CSS size which equals displayed size, so Safari rasterizes the GPU
   *  layer at full resolution = sharp. During gestures this briefly
   *  diverges; the next 60ms-debounced render commits the new zoom and
   *  resets it to 1. Also triggers tile re-render on pan in tiled mode. */
  /** Local content width to flip around when mirrored (0 = no mirror). Uses the
   *  committed-zoom content size so the flip matches the wrapper children. */
  const mirrorWidth = useCallback(() =>
    mirrorRef.current ? (containerRef.current?.clientWidth ?? 0) * committedZoomRef.current : 0
  , []);

  const syncTransform = useCallback(() => {
    clampPan();
    const transientScale = zoomRef.current / committedZoomRef.current;
    applyTransform(wrapperRef.current, panRef.current.x, panRef.current.y, transientScale, mirrorWidth());
    if (!zoomDisplayRafRef.current) {
      zoomDisplayRafRef.current = requestAnimationFrame(() => {
        zoomDisplayRafRef.current = 0;
        if (zoomInfoRef.current) zoomInfoRef.current.textContent = `${Math.round(zoomRef.current * 100)}%`;
      });
    }
    if (shouldUseTilesRef.current()) scheduleTierRenderRef.current();
    scheduleNeighbourCheck();
    scheduleDetail();
  }, [clampPan, mirrorWidth, scheduleNeighbourCheck, scheduleDetail]);

  /** Schedule a re-render at exact zoom resolution.
   *  Adaptive throttle: renders at a rate the system can sustain (based on EMA of
   *  recent render times). Fast pages get near-instant crisp zoom; slow pages get
   *  CSS-only zoom with a trailing debounce for the final crisp frame.
   *
   *  Hysteresis invariant: `_lastCommittedTier` is module-global and held through
   *  intermediate renders so mid-zoom re-renders don't thrash tier boundaries.
   *  The trailing debounce below is the single place where we reset it — so the
   *  final settle render always commits to the exact requested tier, not a stale
   *  one. If the debounce is cleared and rescheduled before firing (new zoom
   *  event arrives) the reset is deferred, which is fine: the reset only matters
   *  for the final frame, and there's always a final frame. */
  const scheduleTierRender = useCallback(() => {
    if (tierDebounceRef.current) clearTimeout(tierDebounceRef.current);
    tierDebounceRef.current = setTimeout(() => {
      tierDebounceRef.current = null;
      _lastCommittedTier = 0;
      renderPageRef.current();
    }, TIER_DEBOUNCE_MS);

    // Adaptive throttle: re-render when zooming in (higher tier needed) or
    // when in tiled mode and zoom level changed (new tiles needed for viewport).
    // Suspended during active gesture (wheel-zoom burst, pinch) — the trailing
    // 60 ms debounce above still fires once the gesture stops, so the user
    // sees CSS-transform-only motion during interaction and a crisp render at
    // settle. Same model as Firefox's PDFViewer.
    if (!gestureActiveRef.current) {
      const candidateTier = quantiseTier(mainTierFromZoom(zoomRef.current, qcfgRef.current.maxMainTier));
      if (candidateTier > renderTierRef.current) {
        const ema = renderTimeEmaRef.current;
        const throttleMs = ema > 0 ? Math.max(ema * 1.5, 16) : 0;
        const now = performance.now();
        if (now - lastThrottleRenderRef.current >= throttleMs) {
          lastThrottleRenderRef.current = now;
          renderPageRef.current();
        }
      }
    }

    // Schedule full-quality crisp render after zoom fully settles (500ms).
    // Quality presets only cap the interactive tier; this ensures the final
    // frame is always rendered at full zoom resolution regardless of preset.
    if (crispTimerRef.current) clearTimeout(crispTimerRef.current);
    crispTimerRef.current = setTimeout(() => {
      crispTimerRef.current = null;
      // Only force full tier if zoom exceeds the preset cap — otherwise the
      // interactive render is already at full quality and this would be a no-op.
      const zoom = zoomRef.current;
      const presetMax = qcfgRef.current.maxMainTier;
      if (zoom > presetMax) {
        forceFullTierRef.current = true;
        log.perf.log(`crisp-render zoom=${zoom.toFixed(1)} preset-cap=${presetMax} → full tier`);
        renderPageRef.current();
      }
    }, CRISP_SETTLE_MS);
  }, []);
  // Forward-ref hookup: syncTransform calls scheduleTierRenderRef.current()
  // to trigger debounced re-renders on pan without depending on the
  // scheduleTierRender callback (which is defined after syncTransform).
  scheduleTierRenderRef.current = scheduleTierRender;

  // Reset scale refs when document is unloaded so framing re-runs on next load
  useEffect(() => {
    if (!isLoaded) { scaleRef.current = 0; viewportHeightRef.current = 0; }
  }, [isLoaded]);

  /** Remove all tile canvases from the DOM and clear the tile map */
  const clearTileDom = useCallback(() => {
    for (const canvas of tileContainerRef.current.values()) {
      detachCanvas(canvas);
    }
    tileContainerRef.current.clear();
    clearDetail();
  }, [clearDetail]);

  const prevPageRef = useRef(currentPage);
  useEffect(() => {
    const prevPage = prevPageRef.current;
    prevPageRef.current = currentPage;
    if (prevPage === currentPage) return; // no actual change (StrictMode re-run)
    // Navigation happened — arm a debounced cleanup of pdf.js per-page resources
    // so scrolling a long PDF doesn't accumulate hundreds of parsed pages.
    // Debounced, so it only fires once navigation settles (never mid-scroll).
    pdfStore.scheduleIdleCleanup(pdfFileName);
    clearDetail();   // it shows the page we just left
    if (skipResetRef.current) {
      // Page boundary crossing during pan/zoom — keep tiles, skip reset
      skipResetRef.current = false;
      return;
    }
    // Explicit page change (scrubber, nav) — full reset
    clearTileDom();
    zoomRef.current = 1;
    panRef.current = { x: 0, y: 0 };
    renderTierRef.current = 1;
    syncTransform();
  }, [currentPage, syncTransform, clearTileDom, clearDetail]);

  // Rotation change — every cached bitmap/tile is now wrong-orientation. Drop
  // them all for this doc, tear down adjacent + tile DOM, re-fit (the rotated
  // page has different dimensions), and re-render from scratch. Skips the
  // first run so loading an unrotated doc doesn't redundantly clear caches.
  const prevRotationRef = useRef(rotation);
  useEffect(() => {
    if (prevRotationRef.current === rotation) return;
    prevRotationRef.current = rotation;
    clearTileDom();
    invalidateTileCache(pdfFileName);
    invalidatePageCache(pdfFileName); clearDetail();
    for (const entry of adjCanvasMapRef.current.values()) detachCanvas(entry.canvas);
    adjCanvasMapRef.current.clear();
    zoomRef.current = 1;
    panRef.current = { x: 0, y: 0 };
    renderTierRef.current = 1;
    syncTransform();
    renderPageRef.current();
  }, [rotation, pdfFileName, syncTransform, clearTileDom, clearDetail]);

  // Re-apply the wrapper transform when the layout flips (single↔continuous can
  // leave pan straddling a boundary) or the mirror toggles (the flip lives in
  // the transform, so it needs a fresh syncTransform to take/release effect).
  useEffect(() => { syncTransform(); }, [singlePageMode, mirror, syncTransform]);

  useEffect(() => {
    return () => {
      // Invalidate any in-flight idle prefetch so its .then() doesn't re-insert
      // an ImageBitmap into the (global) caches we're about to clear — that
      // orphan would then linger past close until unrelated LRU pressure evicts
      // it. Every prefetch put is now guarded on this id.
      prefetchIdRef.current++;
      clearTileDom();
      invalidateTileCache(pdfFileName);
      // Also release the full-page / preview ImageBitmap caches for this doc,
      // not just the tile cache — otherwise closed docs leak their decoded
      // page bitmaps for the app's lifetime.
      invalidatePageCache(pdfFileName); clearDetail();
    };
  }, [pdfFileName, clearTileDom, clearDetail]);

  const renderIdRef = useRef(0);
  const prefetchIdRef = useRef(0);
  /** The full-page render in flight: its effective cache key and the token a
   *  later identical request adopts (see renderPage). */
  const mainRenderInflightRef = useRef<{
    key: string; cssW: number; token: { id: number };
    /** What else decides the pixels: the page proxy (a reparse or font
     *  reload swaps it), the rotation and the active watermark terms. A render
     *  is adopted only when all of them match too. */
    page: unknown; rot: number; wm: string;
  } | null>(null);

  /** Render a single page to an ImageBitmap (shared by main render + prefetch) */
  const renderPageToBitmap = useCallback(async (
    pageNum: number, containerWidth: number, tier: number, clean: boolean,
    signal?: AbortSignal,
  ): Promise<CachedRender> => {
    const page = await pdfStore.getPageFor(pdfFileName, pageNum);
    if (signal?.aborted) throw new DOMException('Aborted', 'AbortError');
    const rot = page.rotate + rotationRef.current;
    const unscaledViewport = page.getViewport({ scale: 1, rotation: rot });
    const baseScale = containerWidth / unscaledViewport.width;

    const dpr = window.devicePixelRatio || 1;
    let hiresScale = baseScale * tier * dpr;
    hiresScale = clampFullPageScale(unscaledViewport.width, unscaledViewport.height, hiresScale, qcfgRef.current.maxCanvasDim);
    const viewport = page.getViewport({ scale: hiresScale, rotation: rot });
    const cssW = containerWidth;
    const cssH = unscaledViewport.height * baseScale;

    const offscreen = acquireCanvas(viewport.width, viewport.height);
    const offCtx = offscreen.getContext('2d', { alpha: false });
    if (!offCtx) { releaseCanvas(offscreen); throw new Error(`Canvas too large: ${viewport.width}x${viewport.height}`); }

    // 'display' intent is significantly faster than 'print' for complex schematics
    const task = page.render({
      canvas: offscreen, canvasContext: offCtx, viewport, intent: 'display',
      ...wmFilterOptions(getActiveWatermarkFilter(renderSettingsStore.globalSettings)),
    });
    const onAbort = () => task.cancel();
    signal?.addEventListener('abort', onAbort, { once: true });
    try {
      await task.promise;
    } catch (err) {
      // On cancel/abort: DON'T return canvas to pool — pdf.js worker thread may
      // still queue draw operations that would corrupt a reused canvas. Abandon to GC.
      offscreen.width = 1; offscreen.height = 1; // release backing store
      throw err;
    } finally {
      signal?.removeEventListener('abort', onAbort);
    }

    if (signal?.aborted) { offscreen.width = 1; offscreen.height = 1; throw new DOMException('Aborted', 'AbortError'); }

    // Apply contrast filter for clean mode before creating bitmap
    if (clean) {
      const tmpCanvas = acquireCanvas(offscreen.width, offscreen.height);
      const tmpCtx = tmpCanvas.getContext('2d', { alpha: false });
      if (!tmpCtx) { offscreen.width = 1; offscreen.height = 1; releaseCanvas(tmpCanvas); throw new Error('Canvas context failed for clean mode'); }
      tmpCtx.filter = `contrast(${cleanContrastRef.current})`;
      tmpCtx.drawImage(offscreen, 0, 0);
      const bitmap = await createImageBitmap(tmpCanvas);
      // Abandon pdf.js-rendered canvas (worker may still reference it)
      offscreen.width = 1; offscreen.height = 1;
      releaseCanvas(tmpCanvas); // tmpCanvas is safe to pool (only used for contrast filter)
      return { bitmap, width: viewport.width, height: viewport.height, cssW, cssH, baseScale, hiresScale, vpHeight: unscaledViewport.height, vpTransform: unscaledViewport.transform };
    }

    const bitmap = await createImageBitmap(offscreen);
    // Abandon pdf.js-rendered canvas (worker may still reference it)
    offscreen.width = 1; offscreen.height = 1;
    return { bitmap, width: viewport.width, height: viewport.height, cssW, cssH, baseScale, hiresScale, vpHeight: unscaledViewport.height, vpTransform: unscaledViewport.transform };
  }, [pdfFileName]);

  /** Blit a cached or freshly rendered bitmap to the visible canvas.
   *  CSS sizes are scaled by current zoom so the wrapper layer rasterizes
   *  at displayed size on Safari. Old in-DOM elements are rescaled by the
   *  committed-zoom delta so they keep correct positions when zoom changes. */
  const blitToCanvas = useCallback((entry: CachedRender, page: number) => {
    const canvas = canvasRef.current;
    const highlight = highlightRef.current;
    if (!canvas || !highlight) return;

    const zCommit = zoomRef.current;
    const ratio = zCommit / committedZoomRef.current;
    rescaleWrapperChildren(ratio);
    committedZoomRef.current = zCommit;

    // Only resize if dimensions changed — avoids clearing existing content
    if (canvas.width !== entry.width || canvas.height !== entry.height) {
      canvas.width = entry.width;
      canvas.height = entry.height;
    }
    canvas.style.width = `${entry.cssW * zCommit}px`;
    canvas.style.height = `${entry.cssH * zCommit}px`;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(entry.bitmap, 0, 0);
    mainContentRef.current = { el: canvas, file: pdfFileName, page, clean: cleanMode, rot: rotationRef.current, cssW: entry.cssW, width: entry.width };
    pdfStore.markFirstPaint(pdfFileName);
    scheduleDetail();

    hlSizeRef.current = { w: entry.width, h: entry.height };
    highlight.style.width = `${entry.cssW * zCommit}px`;
    highlight.style.height = `${entry.cssH * zCommit}px`;

    if (wrapperRef.current) {
      // Reset wrapper transient scale so the layer rasterizes at full size.
      applyTransform(wrapperRef.current, panRef.current.x, panRef.current.y, zoomRef.current / zCommit, mirrorWidth());
    }

    scaleRef.current = entry.baseScale;
    hiresScaleRef.current = entry.hiresScale;
    viewportHeightRef.current = entry.vpHeight;
    viewportTransformRef.current = entry.vpTransform;
    pageCssHRef.current = entry.cssH;

    drawHighlightsRef.current();
    setRenderEpoch(e => e + 1);
  }, [rescaleWrapperChildren, mirrorWidth, pdfFileName, cleanMode, scheduleDetail]);


  const renderPage = useCallback(async () => {
    if (!isLoaded) return;

    setError(null);

    const renderId = ++renderIdRef.current;
    // A render whose clamped size turns out to equal the one already in flight
    // adopts it (token.id moves to the newer call) instead of cancelling and
    // restarting identical work — the 8192-px render was started five times
    // and cancelled before it ever finished once. So staleness is read off the
    // token, and the in-flight task is cancelled only once we know it differs.
    const token = { id: renderId };
    const isStale = () => renderIdRef.current !== token.id;
    // forceFullTier (set by the crisp-settle timer) lifts the preset tier cap
    // for exactly one render so the final settled frame is at full zoom
    // resolution. Consume it right after the tier is computed so interactive
    // zoom keeps the cap.
    const maxTier = forceFullTierRef.current ? Infinity : qcfgRef.current.maxMainTier;
    const resTier = hysteresisFilter(quantiseTier(mainTierFromZoom(zoomRef.current, maxTier)));
    renderTierRef.current = resTier;
    forceFullTierRef.current = false;
    const t0 = performance.now();

    try {
      const container = containerRef.current;
      if (!container) return;
      const containerWidth = container.clientWidth;
      if (containerWidth === 0) return;

      const cacheKey = pageCacheKey(pdfFileName, currentPage, resTier, cleanMode);

      // Fast path: cache hit — instant blit, no pdf.js render
      const cached = getPageCacheAliased(cacheKey);
      if (cached && cached.cssW === containerWidth) {
        renderTaskRef.current?.cancel();
        mainRenderInflightRef.current = null;
        blitToCanvas(cached, currentPage);
        const tHit = performance.now() - t0;
        // Cache hits are near-instant — feed EMA so adaptive zoom stays aggressive
        const prev = renderTimeEmaRef.current;
        renderTimeEmaRef.current = prev > 0 ? prev * 0.7 + tHit * 0.3 : tHit;
        log.perf.log(`cache-hit ${cacheKey} ${Math.round(tHit)}ms`);
        return;
      }

      // Stand-in while the exact tier renders: the sharpest copy we have —
      // the highest cached tier, else the tier-1 preview — and only when it is
      // sharper than what the canvas already shows for this page. Both used
      // to be blitted in turn, so the blurry preview landed on top of the
      // sharp copy, and on top of a canvas that was already sharp: the blur
      // blink after a zoom settles (worst in Safari, where the exact-tier
      // render that ends it takes longest).
      const bestCached = getBestPageCache(pdfFileName, currentPage, cleanMode);
      let standIn = bestCached && bestCached.cssW === containerWidth ? bestCached : undefined;
      if (resTier > 1) {
        const preview = getPreviewCache(previewCacheKey(pdfFileName, currentPage, cleanMode));
        if (preview && preview.cssW === containerWidth && (!standIn || preview.width > standIn.width)) standIn = preview;
      }
      const shown = mainContentRef.current;
      const shownWidth = shown && shown.el === canvasRef.current && shown.file === pdfFileName && shown.page === currentPage && shown.clean === cleanMode &&
        shown.rot === rotationRef.current && shown.cssW === containerWidth ? shown.width : 0;
      if (standIn && standIn.width > shownWidth) {
        blitToCanvas(standIn, currentPage);
        log.perf.log(`stand-in page=${currentPage} ${standIn.width}px over ${shownWidth}px`);
      }

      const page = await pdfStore.getPageFor(pdfFileName, currentPage);
      if (isStale()) return;
      const tPage = performance.now();

      const rot = page.rotate + rotationRef.current;
      const unscaledViewport = page.getViewport({ scale: 1, rotation: rot });
      const baseScale = containerWidth / unscaledViewport.width;

      const dpr = window.devicePixelRatio || 1;
      let hiresScale = baseScale * resTier * dpr;
      // Sanity clamp: when the tier cap is lifted (maxTier===Infinity) the
      // requested scale is bounded only by zoom, so also cap the canvas dim by
      // √cacheMaxPixels — a single over-budget page-cache bitmap would keep the
      // LRU permanently "over budget" and disable the cache. The normal capped
      // path is unaffected (maxTier finite → plain maxCanvasDim).
      const fpMaxDim = maxTier === Infinity
        ? Math.min(qcfgRef.current.maxCanvasDim, Math.floor(Math.sqrt(qcfgRef.current.cacheMaxPixels)))
        : qcfgRef.current.maxCanvasDim;
      hiresScale = clampFullPageScale(unscaledViewport.width, unscaledViewport.height, hiresScale, fpMaxDim);
      const viewport = page.getViewport({ scale: hiresScale, rotation: rot });
      const cssW = containerWidth;
      const cssH = unscaledViewport.height * baseScale;

      // Past the clamp, this tier's pixels may already exist under another.
      const effKey = pageCacheKey(pdfFileName, currentPage, effectiveTier(hiresScale, baseScale, dpr), cleanMode);
      _tierAlias.set(cacheKey, effKey);
      const effHit = getPageCache(effKey);
      if (effHit && effHit.cssW === containerWidth) {
        renderTaskRef.current?.cancel();
        mainRenderInflightRef.current = null;
        blitToCanvas(effHit, currentPage);
        log.perf.log(`cache-hit (clamped) ${cacheKey} → ${effKey}`);
        return;
      }
      const wmSig = JSON.stringify(getActiveWatermarkFilter(renderSettingsStore.globalSettings));
      const inflight = mainRenderInflightRef.current;
      if (inflight && inflight.key === effKey && inflight.cssW === containerWidth &&
          inflight.page === page && inflight.rot === rot && inflight.wm === wmSig) {
        inflight.token.id = renderId;           // same pixels already on the way
        log.perf.log(`render adopted ${cacheKey} → ${effKey}`);
        return;
      }
      renderTaskRef.current?.cancel();
      mainRenderInflightRef.current = { key: effKey, cssW: containerWidth, token, page, rot, wm: wmSig };

      // Render to pooled offscreen buffer
      const offscreen = acquireCanvas(viewport.width, viewport.height);
      const offCtx = offscreen.getContext('2d', { alpha: false });
      if (!offCtx) { releaseCanvas(offscreen); throw new Error(`Canvas too large: ${viewport.width}x${viewport.height}`); }

      // 'display' intent is significantly faster than 'print' for complex schematics
      const task = page.render({
        canvas: offscreen, canvasContext: offCtx, viewport, intent: 'display',
        ...wmFilterOptions(getActiveWatermarkFilter(renderSettingsStore.globalSettings)),
      });
      renderTaskRef.current = { cancel: () => task.cancel() };
      try {
        await task.promise;
      } finally {
        if (mainRenderInflightRef.current?.token === token) mainRenderInflightRef.current = null;
      }

      if (isStale()) {
        // Stale render — abandon canvas (don't pool, pdf.js may still draw to it)
        offscreen.width = 1; offscreen.height = 1;
        return;
      }
      const tRender = performance.now();

      // Apply contrast to offscreen buffer before creating bitmap (avoids double-blit)
      let sourceCanvas = offscreen;
      if (cleanMode) {
        const tmpCanvas = acquireCanvas(offscreen.width, offscreen.height);
        const tmpCtx = tmpCanvas.getContext('2d', { alpha: false });
        if (tmpCtx) {
          tmpCtx.filter = `contrast(${cleanContrastRef.current})`;
          tmpCtx.drawImage(offscreen, 0, 0);
          // Abandon offscreen to GC — pdf.js worker may still reference it
          offscreen.width = 1; offscreen.height = 1;
          sourceCanvas = tmpCanvas;
        }
      }

      if (isStale()) { releaseCanvas(sourceCanvas); return; }

      // Blit to visible canvas SYNCHRONOUSLY from sourceCanvas — no async step
      // between render completion and visible blit. This prevents any race with
      // stale pdf.js worker operations or createImageBitmap orientation issues.
      const canvas = canvasRef.current;
      const highlight = highlightRef.current;
      if (!canvas || !highlight) { releaseCanvas(sourceCanvas); return; }

      // Capture committed zoom for this render. Same zCommit used for main
      // canvas, highlight canvas, and the wrapper transform reset below.
      const zCommitFP = zoomRef.current;
      const ratioFP = zCommitFP / committedZoomRef.current;
      rescaleWrapperChildren(ratioFP);
      committedZoomRef.current = zCommitFP;
      // Only a size change needs a reallocation; the page bitmap is opaque and
      // covers the canvas, so drawing over the old content replaces all of it.
      if (canvas.width !== viewport.width || canvas.height !== viewport.height) {
        canvas.width = viewport.width;
        canvas.height = viewport.height;
      }
      canvas.style.width = `${cssW * zCommitFP}px`;
      canvas.style.height = `${cssH * zCommitFP}px`;
      const ctx = canvas.getContext('2d');
      if (ctx) ctx.drawImage(sourceCanvas, 0, 0);
      mainContentRef.current = { el: canvas, file: pdfFileName, page: currentPage, clean: cleanMode, rot: rotationRef.current, cssW, width: viewport.width };
      pdfStore.markFirstPaint(pdfFileName);
      scheduleDetail();

      // Create bitmap AFTER the visible blit for cache storage only.
      // sourceCanvas might get stale pdf.js draws during this await — that's
      // fine because the visible canvas already has the correct content.
      let bitmap: ImageBitmap | null = null;
      try { bitmap = await createImageBitmap(sourceCanvas); } catch { /* skip */ }
      // Don't pool sourceCanvas — abandon to GC (pdf.js worker may still reference it)
      sourceCanvas.width = 1; sourceCanvas.height = 1;
      if (isStale()) { bitmap?.close(); return; }
      const tCopy = performance.now();

      scaleRef.current = baseScale;
      hiresScaleRef.current = hiresScale;
      viewportHeightRef.current = unscaledViewport.height;
      viewportTransformRef.current = unscaledViewport.transform;
      pageCssHRef.current = cssH;

      hlSizeRef.current = { w: viewport.width, h: viewport.height };
      highlight.style.width = `${cssW * zCommitFP}px`;
      highlight.style.height = `${cssH * zCommitFP}px`;
      if (wrapperRef.current) {
        applyTransform(wrapperRef.current, panRef.current.x, panRef.current.y, zoomRef.current / zCommitFP, mirrorWidth());
      }

      drawHighlightsRef.current();
      setRenderEpoch(e => e + 1);

      // Cache the pre-created bitmap for instant reuse
      if (bitmap) {
        putPageCache(effKey, {
          bitmap, width: viewport.width, height: viewport.height,
          cssW, cssH, baseScale, hiresScale, vpHeight: unscaledViewport.height,
          vpTransform: unscaledViewport.transform,
        });
      }

      const totalMs = tCopy - t0;
      const metrics = {
        file: pdfFileName, page: currentPage, tier: resTier, clean: cleanMode,
        canvasW: viewport.width, canvasH: viewport.height,
        getPageMs: Math.round(tPage - t0),
        renderMs: Math.round(tRender - tPage),
        copyMs: Math.round(tCopy - tRender),
        totalMs: Math.round(totalMs),
      };
      log.perf.log(JSON.stringify(metrics));
      window.dispatchEvent(new CustomEvent('pdf-render-perf', { detail: metrics }));

      // Update adaptive zoom EMA (α=0.3 — responsive but not twitchy)
      const prev = renderTimeEmaRef.current;
      renderTimeEmaRef.current = prev > 0 ? prev * 0.7 + totalMs * 0.3 : totalMs;

      // Debounced adjacent page re-render — wait until zoom settles to avoid
      // re-rendering 4+ adjacent pages on every mid-zoom throttle render.
      if (adjDebounceRef.current) clearTimeout(adjDebounceRef.current);
      adjDebounceRef.current = setTimeout(() => {
        adjDebounceRef.current = null;
        setAdjTrigger(t => t + 1);
      }, qcfgRef.current.adjSettleMs);

      // Defer all prefetch work to idle time so the main render doesn't
      // compete with preview/adjacent renders for CPU/GPU. requestIdleCallback
      // fires when the browser is idle (after paint, before next frame deadline).
      const pfId = ++prefetchIdRef.current;
      // Neighbours are prefetched at the tier the adjacent effect will ask for
      // while they are off screen, so the two land on one cache key.
      const adjPfTier = quantiseTier(Math.min(resTier, qcfgRef.current.maxAdjTier, qcfgRef.current.neighbourFarTier));
      const idlePrefetch = () => {
        if (prefetchIdRef.current !== pfId) return; // stale

        // Preview for current page (only if rendered at hi-res)
        const pvKey = previewCacheKey(pdfFileName, currentPage, cleanMode);
        if (resTier > 1 && !getPreviewCache(pvKey)) {
          renderPageToBitmap(currentPage, containerWidth, 1, cleanMode)
            .then(result => {
              // Guard like the hi-res put below: the doc may have closed (unmount
              // bumps prefetchIdRef) while this render was in flight — don't
              // re-insert an orphan bitmap into the global preview cache.
              if (prefetchIdRef.current !== pfId) { result.bitmap.close(); return; }
              putPreviewCache(pvKey, result);
            })
            .catch(() => {});
        }

        // Adjacent pages: preview + hi-res
        const pagesToPrefetch = [currentPage + 1, currentPage - 1].filter(p => p >= 1 && p <= pageCount);
        for (const pNum of pagesToPrefetch) {
          if (prefetchIdRef.current !== pfId) return;
          const adjPvKey = previewCacheKey(pdfFileName, pNum, cleanMode);
          if (!getPreviewCache(adjPvKey)) {
            renderPageToBitmap(pNum, containerWidth, 1, cleanMode)
              .then(result => {
                if (prefetchIdRef.current !== pfId) { result.bitmap.close(); return; }
                putPreviewCache(adjPvKey, result);
              })
              .catch(() => {});
          }
          const pfKey = pageCacheKey(pdfFileName, pNum, adjPfTier, cleanMode);
          if (!getPageCache(pfKey) && !_neighbourInflight.has(pfKey)) {
            const p = renderPageToBitmap(pNum, containerWidth, adjPfTier, cleanMode)
              .then(result => {
                // A newer main render does not make this neighbour bitmap
                // wrong — the adjacent effect may be waiting on it. Only a
                // closed document does.
                if (!pdfStore.hasDocument(pdfFileName)) { result.bitmap.close(); throw new DOMException('closed', 'AbortError'); }
                putPageCache(pfKey, result);
                log.perf.log(`prefetched page ${pNum} tier=${adjPfTier}`);
                return result;
              })
              .finally(() => { if (_neighbourInflight.get(pfKey) === p) _neighbourInflight.delete(pfKey); });
            _neighbourInflight.set(pfKey, p);
            p.catch(() => {});
          }
        }
      };
      if (typeof requestIdleCallback === 'function') {
        requestIdleCallback(idlePrefetch, { timeout: 2000 });
      } else {
        setTimeout(idlePrefetch, 200); // fallback for Safari
      }
    } catch (err) {
      if (err instanceof Error && err.message?.includes('cancel')) {
        return;
      }
      // 2R: painel com tamanho zero (escondido/redimensionando) — tenta de novo depois, sem mostrar erro
      if (/width or height of 0|InvalidStateError/.test(String(err))) { setTimeout(() => window.dispatchEvent(new Event('resize')), 250); return; }
      log.pdf.error('renderPage failed:', err);
      // The panel shows the error; the load indicator must not stay up.
      pdfStore.endLoad(pdfFileName);
      setError(String(err));
    }
  }, [pdfFileName, isLoaded, currentPage, cleanMode, pageCount, renderPageToBitmap, blitToCanvas, rescaleWrapperChildren, mirrorWidth, scheduleDetail]);

  // --- Tiled viewport rendering (zoom > 1) ---
  const renderTiledPage = useCallback(async () => {
    if (!isLoaded) return;
    renderTaskRef.current?.cancel();

    const tileRenderId = ++tileRenderIdRef.current;
    const zoom = zoomRef.current;
    // forceFullTier (crisp-settle timer) lifts the preset tier cap for exactly
    // one render; consume it right after the tier is computed so interactive
    // zoom keeps the cap.
    const maxTier = forceFullTierRef.current ? Infinity : qcfgRef.current.maxMainTier;
    const resTier = hysteresisFilter(quantiseTier(mainTierFromZoom(zoom, maxTier)));
    renderTierRef.current = resTier;
    forceFullTierRef.current = false;

    const container = containerRef.current;
    const wrapper = wrapperRef.current;
    if (!container || !wrapper) return;
    const containerWidth = container.clientWidth;
    if (containerWidth === 0) return;

    try {
      // Guard: don't render if the store's current page doesn't match our closure.
      // This catches stale calls from scheduleTierRender firing before React commits.
      const storePage = pdfStore.getDocCurrentPage(pdfFileName);
      if (storePage !== currentPage) {
        log.pdf.log(`renderTiledPage: stale closure page=${currentPage}, store=${storePage} — skipping`);
        return;
      }

      const page = await pdfStore.getPageFor(pdfFileName, currentPage);
      if (tileRenderIdRef.current !== tileRenderId) return;

      const rot = page.rotate + rotationRef.current;
      const unscaledVp = page.getViewport({ scale: 1, rotation: rot });
      const baseScale = containerWidth / unscaledVp.width;
      const dpr = window.devicePixelRatio || 1;
      // Tile path: each tile renders into its own TILE_SIZE canvas (1024px),
      // so the per-canvas browser dim cap doesn't apply. The previous clamp
      // by `maxCanvasDim` was a memory-budget proxy for the "render all
      // tiles" decision below; with viewport culling we render only ~9
      // visible tiles regardless of zoom, so memory is bounded by viewport
      // size, not by total page-pixel area. Keep renderScale at the
      // tier-requested value so Safari users get full Retina sharpness on
      // oversize schematic PDFs.
      const renderScale = baseScale * resTier * dpr;

      const cssW = containerWidth;
      const cssH = unscaledVp.height * baseScale;
      // Capture zoom for this render, rescale all old in-DOM children to
      // match (so tiles outside the viewport-cull range stay aligned), and
      // commit the new value before placing any new tiles.
      const zCommit = zoomRef.current;
      const ratio = zCommit / committedZoomRef.current;
      rescaleWrapperChildren(ratio);
      committedZoomRef.current = zCommit;
      scaleRef.current = baseScale;
      hiresScaleRef.current = renderScale;
      viewportHeightRef.current = unscaledVp.height;
      viewportTransformRef.current = unscaledVp.transform;
      pageCssHRef.current = cssH;

      const grid = computeTileGrid(unscaledVp.width, unscaledVp.height, renderScale);
      tileGridRef.current = grid;
      // Tile keys include renderScale — old/new tiles don't collide in the map.

      // Keep main canvas visible as blurry backdrop while tiles load on top
      // (tiles have z-index: 1, main canvas has no z-index — tiles cover it)

      // Size highlight canvas for tiled mode. Cap to the probed max canvas
      // dim so Safari can actually back the highlight overlay — at extreme
      // zoom on oversize pages the requested hlScale would otherwise blow
      // past Safari's silent canvas limit.
      const highlight = highlightRef.current;
      if (highlight) {
        // Sanity clamp: when the tier cap is lifted (maxTier===Infinity),
        // renderScale is bounded only by zoom, so cap the full-page-sized
        // highlight canvas by √cacheMaxPixels as well as maxCanvasDim. Tiles
        // themselves stay TILE_SIZE-bounded and viewport-culled. The normal
        // capped path is unaffected.
        const hlMaxDim = maxTier === Infinity
          ? Math.min(qcfgRef.current.maxCanvasDim, Math.floor(Math.sqrt(qcfgRef.current.cacheMaxPixels)))
          : qcfgRef.current.maxCanvasDim;
        const hlScale = clampFullPageScale(unscaledVp.width, unscaledVp.height, renderScale, hlMaxDim);
        hlSizeRef.current = { w: Math.ceil(unscaledVp.width * hlScale), h: Math.ceil(unscaledVp.height * hlScale) };
        highlight.style.width = `${cssW * zCommit}px`;
        highlight.style.height = `${cssH * zCommit}px`;
        // Tiles use renderScale for coords; highlight may be at lower
        // (clamped) scale on Safari. Store for drawHighlights to use.
        hiresScaleRef.current = hlScale;
      }

      const pxPerCss = renderScale / baseScale;
      const cssTileW = TILE_SIZE / pxPerCss;
      const cssTileH = TILE_SIZE / pxPerCss;

      // Tile selection strategy:
      //   - Small grids (≤ TILE_RENDER_ALL_THRESHOLD tiles): render the whole
      //     page eagerly. Behavior matches the previous "render all tiles"
      //     decision — fast-pan stays smooth because every tile is already
      //     in DOM. This covers typical 100-400% zoom on Letter-size PDFs.
      //   - Large grids (> threshold): viewport-cull with 2-tile padding.
      //     Avoids the 1.5GB blow-up on 1000% zoom of oversize schematics
      //     and lifts the previous tile-path scale clamp, so Safari users
      //     get full Retina sharpness on huge pages.
      const totalTiles = grid.cols * grid.rows;
      const TILE_RENDER_ALL_THRESHOLD = 30;
      const tiles: { col: number; row: number }[] = [];
      if (totalTiles <= TILE_RENDER_ALL_THRESHOLD) {
        for (let row = 0; row < grid.rows; row++) {
          for (let col = 0; col < grid.cols; col++) {
            tiles.push({ col, row });
          }
        }
      } else {
        const containerH = container.clientHeight;
        const zoomNow = zoomRef.current;
        const panNow = panRef.current;
        const visLeftCss = -panNow.x / zoomNow;
        const visTopCss = -panNow.y / zoomNow;
        const visRightCss = visLeftCss + containerWidth / zoomNow;
        const visBottomCss = visTopCss + containerH / zoomNow;
        // 2-tile padding (in each direction) gives breathing room for fast
        // pan bursts before the debounced re-render catches up.
        const PAD = 2;
        const colMin = Math.max(0, Math.floor(visLeftCss / cssTileW) - PAD);
        const colMax = Math.min(grid.cols - 1, Math.ceil(visRightCss / cssTileW) + PAD);
        const rowMin = Math.max(0, Math.floor(visTopCss / cssTileH) - PAD);
        const rowMax = Math.min(grid.rows - 1, Math.ceil(visBottomCss / cssTileH) + PAD);
        for (let row = rowMin; row <= rowMax; row++) {
          for (let col = colMin; col <= colMax; col++) {
            tiles.push({ col, row });
          }
        }
      }

      const visibleKeys = new Set<string>();
      const toRender: { col: number; row: number }[] = [];

      for (const t of tiles) {
        const key = `${currentPage}:${t.col}:${t.row}:${renderScale}`;
        visibleKeys.add(key);

        let tileCanvas = tileContainerRef.current.get(key);
        const cached = getTileCached(pdfFileName, currentPage, t.col, t.row, renderScale);

        // Per-tile CSS size — edge tiles may be smaller than TILE_SIZE
        const req = tileRenderRequest(t.col, t.row, grid);
        const tileCssW = req.pixelW / pxPerCss;
        const tileCssH = req.pixelH / pxPerCss;

        if (cached) {
          if (!tileCanvas) {
            tileCanvas = document.createElement('canvas');
            tileCanvas.className = 'pdf-tile';
            wrapper.appendChild(tileCanvas);
            tileContainerRef.current.set(key, tileCanvas);
          }
          // A tile canvas already showing this very bitmap is only moved:
          // assigning `width` clears a canvas even to the same value, and in
          // Safari the cleared-then-redrawn tile can reach the screen as a
          // blank frame — the old-scale tiles or the blurry main canvas
          // beneath show through. Identity, not size, because an invalidated
          // cache hands back a new bitmap for the same key. A tile that was
          // hidden is redrawn regardless: WebKit may have dropped the pixels
          // of a canvas that was not on screen (so may any engine after the
          // page sat in the background — see the visibilitychange reset).
          if (tileBitmapRef.current.get(tileCanvas) !== cached.bitmap || tileCanvas.style.display === 'none') {
            tileCanvas.width = cached.bitmap.width;
            tileCanvas.height = cached.bitmap.height;
            const ctx = tileCanvas.getContext('2d');
            if (ctx) ctx.drawImage(cached.bitmap, 0, 0);
            tileBitmapRef.current.set(tileCanvas, cached.bitmap);
          }
          tileCanvas.style.width = `${tileCssW * zCommit}px`;
          tileCanvas.style.height = `${tileCssH * zCommit}px`;
          tileCanvas.style.left = `${t.col * cssTileW * zCommit}px`;
          tileCanvas.style.top = `${t.row * cssTileH * zCommit}px`;
          tileCanvas.style.display = '';
        } else {
          if (tileCanvas) {
            tileCanvas.style.width = `${tileCssW * zCommit}px`;
            tileCanvas.style.height = `${tileCssH * zCommit}px`;
            tileCanvas.style.left = `${t.col * cssTileW * zCommit}px`;
            tileCanvas.style.top = `${t.row * cssTileH * zCommit}px`;
            tileCanvas.style.display = '';
          }
          toRender.push(t);
        }
      }

      // Now that all currently-cached tiles + highlight are at zCommit-scaled
      // CSS, reset the wrapper's transient scale so Safari rasterizes the
      // GPU layer at the (new larger) intrinsic CSS size = displayed size.
      if (wrapperRef.current) {
        applyTransform(wrapperRef.current, panRef.current.x, panRef.current.y, zoomRef.current / zCommit, mirrorWidth());
      }

      // Don't hide old tiles here — they stay visible as backdrop.
      // Out-of-viewport tiles are clipped by overflow:hidden on the container.
      // Cleanup happens in the batch display rAF after new tiles are shown.

      // Phase 2: render missing tiles. `page.render()` itself MUST stay
      // sequential per pdf.js — concurrent calls on the same page produce
      // flipped/mirrored tiles. But createImageBitmap runs on the main thread
      // (not the pdf.js worker) so it can overlap with the next render. We
      // hold each iteration's bitmap promise as `pending` and collect it at
      // the top of the next iteration — meaning tile N+1's `page.render()`
      // is in flight while tile N's pixels are being pumped into an
      // ImageBitmap. Cuts ~30–50% off the all-fresh-tiles settle path versus
      // awaiting both sequentially.
      const t0 = performance.now();
      type RenderedTile = { key: string; bitmap: ImageBitmap; col: number; row: number; pixelW: number; pixelH: number };
      const rendered: RenderedTile[] = [];
      let pending: Promise<RenderedTile | null> | null = null;
      const drainPending = async () => {
        if (!pending) return;
        try { const r = await pending; if (r) rendered.push(r); } catch { /* ignore */ }
        pending = null;
      };

      // Watermark filter forwarded through the patched `watermarkFilter`
      // render option — the worker drops matching showText ops at parse time.
      const wmOptions = wmFilterOptions(getActiveWatermarkFilter(renderSettingsStore.globalSettings));

      for (const t of toRender) {
        if (tileRenderIdRef.current !== tileRenderId) { await drainPending(); return; }

        const req = tileRenderRequest(t.col, t.row, grid);
        const offscreen = acquireCanvas(req.pixelW, req.pixelH);
        const offCtx = offscreen.getContext('2d', { alpha: false });
        if (!offCtx) { releaseCanvas(offscreen); continue; }

        const tileViewport = page.getViewport({
          scale: renderScale,
          rotation: rot,
          offsetX: -req.srcX * renderScale,
          offsetY: -req.srcY * renderScale,
        });
        const task = page.render({
          canvas: offscreen, canvasContext: offCtx,
          viewport: tileViewport, intent: 'display',
          ...wmOptions,
        });
        renderTaskRef.current = { cancel: () => task.cancel() };

        try {
          await task.promise;
        } catch {
          offscreen.width = 1; offscreen.height = 1;
          continue;
        }

        if (tileRenderIdRef.current !== tileRenderId) {
          offscreen.width = 1; offscreen.height = 1;
          await drainPending();
          return;
        }

        // Clean-mode runs synchronously inside the iteration: we have to
        // finish the contrast copy before the next iter reuses the pool.
        let srcCanvas = offscreen;
        if (cleanMode) {
          const tmp = acquireCanvas(req.pixelW, req.pixelH);
          const tmpCtx = tmp.getContext('2d', { alpha: false });
          if (tmpCtx) {
            tmpCtx.filter = `contrast(${cleanContrastRef.current})`;
            tmpCtx.drawImage(offscreen, 0, 0);
            offscreen.width = 1; offscreen.height = 1;
            srcCanvas = tmp;
          }
        }

        // Collect the previous tile's bitmap (the one we kicked off last iter
        // and that was running in the background while this iter's render
        // executed in the pdf.js worker).
        await drainPending();

        // Kick off THIS tile's bitmap creation in the background. The next
        // iteration's page.render() can start immediately while these pixels
        // pump into an ImageBitmap. `srcCanvas` is captured by the closure;
        // we abandon it via width=1/height=1 once the bitmap has the pixels.
        const tileCol = t.col;
        const tileRow = t.row;
        const tilePixelW = req.pixelW;
        const tilePixelH = req.pixelH;
        const tileKey = `${currentPage}:${tileCol}:${tileRow}:${renderScale}`;
        const tilePageNum = currentPage;
        const bitmapCanvas = srcCanvas;
        pending = createImageBitmap(bitmapCanvas)
          .then((bitmap): RenderedTile => {
            bitmapCanvas.width = 1; bitmapCanvas.height = 1;
            putTileCached(pdfFileName, tilePageNum, { bitmap, col: tileCol, row: tileRow, scale: renderScale });
            return { key: tileKey, bitmap, col: tileCol, row: tileRow, pixelW: tilePixelW, pixelH: tilePixelH };
          })
          .catch((): RenderedTile | null => {
            bitmapCanvas.width = 1; bitmapCanvas.height = 1;
            return null;
          });
      }
      // Drain the last in-flight bitmap before batch-display rAF.
      await drainPending();

      // Batch display: blit all rendered tiles to DOM in one frame
      if (tileRenderIdRef.current === tileRenderId && rendered.length > 0) {
        const renderedForPage = currentPage; // capture which page these tiles are for
        requestAnimationFrame(() => {
          // Re-check render ID inside rAF — a newer render may have started
          if (tileRenderIdRef.current !== tileRenderId) return;
          // Check if page changed since we started rendering
          const nowPage = pdfStore.getDocCurrentPage(pdfFileName);
          if (nowPage !== renderedForPage) {
            log.pdf.log(`tile-rAF BLOCKED: rendered for page ${renderedForPage} but now on page ${nowPage}`);
            return; // don't display tiles for wrong page
          }
          for (const r of rendered) {
            let tileCanvas = tileContainerRef.current.get(r.key);
            if (!tileCanvas) {
              tileCanvas = document.createElement('canvas');
              tileCanvas.className = 'pdf-tile';
              wrapper.appendChild(tileCanvas);
              tileContainerRef.current.set(r.key, tileCanvas);
            }
            tileCanvas.width = r.pixelW;
            tileCanvas.height = r.pixelH;
            // Use zCommit captured at function entry — if zoom changed since,
            // syncTransform's transient scale handles the visual delta until
            // the next render commits with the newer zoom.
            tileCanvas.style.width = `${(r.pixelW / pxPerCss) * zCommit}px`;
            tileCanvas.style.height = `${(r.pixelH / pxPerCss) * zCommit}px`;
            tileCanvas.style.left = `${r.col * cssTileW * zCommit}px`;
            tileCanvas.style.top = `${r.row * cssTileH * zCommit}px`;
            const ctx = tileCanvas.getContext('2d');
            if (ctx) ctx.drawImage(r.bitmap, 0, 0);
            tileBitmapRef.current.set(tileCanvas, r.bitmap);
            tileCanvas.style.display = '';
          }
          // Cap total tile DOM elements — only evict when excessive.
          // Don't eagerly remove old-scale tiles (they serve as backdrop during
          // zoom changes and page transitions, preventing blank flashes).
          const MAX_TILE_DOM = 80;
          if (tileContainerRef.current.size > MAX_TILE_DOM) {
            // Remove tiles not at current scale first (oldest insertion order)
            const currentScaleSuffix = `:${renderScale}`;
            for (const [key, canvas] of tileContainerRef.current) {
              if (tileContainerRef.current.size <= MAX_TILE_DOM / 2) break;
              if (!key.endsWith(currentScaleSuffix)) {
                detachCanvas(canvas);
                tileContainerRef.current.delete(key);
              }
            }
          }
          pdfStore.markFirstPaint(pdfFileName);
          // Main canvas visibility is controlled by React via tiledMode state
          // Clean up transition backdrop canvases (adjacent canvases kept during page switch)
          wrapper.querySelectorAll('[data-transition-backdrop]').forEach(c => c.remove());
        });
      }

      drawHighlightsRef.current();
      setRenderEpoch(e => e + 1);

      const totalMs = performance.now() - t0;
      if (toRender.length > 0) {
        log.perf.log(`tiled-render page=${currentPage} tiles=${rendered.length}/${tiles.length} ${Math.round(totalMs)}ms scale=${renderScale.toFixed(1)}`);
        const prev = renderTimeEmaRef.current;
        renderTimeEmaRef.current = prev > 0 ? prev * 0.7 + totalMs * 0.3 : totalMs;
      }
    } catch (err) {
      if (err instanceof Error && err.message?.includes('cancel')) return;
      if (/width or height of 0|InvalidStateError/.test(String(err))) { setTimeout(() => window.dispatchEvent(new Event('resize')), 250); return; }
      log.pdf.error('renderTiledPage failed:', err);
      setError(String(err));
    }
  }, [pdfFileName, isLoaded, currentPage, cleanMode, rescaleWrapperChildren, mirrorWidth]);

  /** Route to tiled or full-page render based on the active mode + zoom level.
   *  Mode is read via shouldUseTilesRef so a runtime mode switch (Settings ▸
   *  PDF ▸ Render mode) re-routes the next render without a deps refresh.
   *  Never clear tiles during a page boundary crossing — tiles may temporarily
   *  show at the wrong zoom (effect chain fires renderActive with stale zoom).
   *  Tiles are only cleared when the predicate flips off (zoom drops below
   *  threshold in 'auto' mode, or user switches to 'standard'). */
  const renderActive = useCallback(() => {
    if (shouldUseTilesRef.current()) {
      setTiledMode(true);
      clearDetail();
      renderTiledPage();
    } else {
      setTiledMode(false);
      renderPage();
      if (tileContainerRef.current.size > 0) {
        requestAnimationFrame(() => {
          if (!shouldUseTilesRef.current()) clearTileDom();
        });
      }
    }
  }, [renderPage, renderTiledPage, clearTileDom, clearDetail]);

  const drawHighlights = useCallback(() => {
    if (!highlightRef.current || !isLoaded) return;
    const highlight = highlightRef.current;

    const pageIndex = currentPage - 1;
    const pageMatches = pdfStore.getDocMatchesForPage(pdfFileName, pageIndex);

    // Hide highlight canvas entirely when no matches — avoids compositing an empty layer
    if (pageMatches.length === 0 && matches.length === 0) {
      highlight.style.display = 'none';
      if (highlight.width > 1) { highlight.width = 1; highlight.height = 1; }
      lastHighlightZoomRef.current = '';
      return;
    }
    if (highlight.style.display === 'none') highlight.style.display = '';
    const want = hlSizeRef.current;
    if (want.w > 0 && (highlight.width !== want.w || highlight.height !== want.h)) {
      highlight.width = want.w;
      highlight.height = want.h;
    }

    const scale = hiresScaleRef.current;

    const hCtx = highlight.getContext('2d')!;
    hCtx.clearRect(0, 0, highlight.width, highlight.height);
    const vpT = viewportTransformRef.current;
    const blinkHide = blinkPhaseRef.current % 2 === 1;

    const activeIndices = pdfStore.getDocActiveMatchIndices(pdfFileName);
    const activeMatchSet = new Set<object>();
    for (const idx of activeIndices) {
      if (matches[idx]) activeMatchSet.add(matches[idx]);
    }

    if (isMultiTerm && activeMatchSet.size > 0) {
      const activeGroup = pdfStore.getDocMatchGroups(pdfFileName)[pdfStore.getDocActiveGroupIndex(pdfFileName)];
      if (activeGroup) {
        const anchorMatch = matches[activeGroup[0]];
        if (anchorMatch && anchorMatch.pageIndex === pageIndex) {
          const aRect = textItemRect(anchorMatch.item.transform, anchorMatch.item.width, vpT, scale);
          const aFontSize = pdfFontSize(anchorMatch.item.transform);

          const xTolPx = aFontSize * multiTermXGap * scale;
          const zoneX = aRect.x - xTolPx;
          const zoneW = xTolPx * 2 + aRect.w;

          const yGapPx = aFontSize * multiTermYGap * scale;
          const zoneY = aRect.y;
          const zoneH = yGapPx * (activeGroup.length);

          hCtx.strokeStyle = 'rgba(100, 200, 255, 0.4)';
          hCtx.lineWidth = 1;
          hCtx.setLineDash([4, 4]);
          hCtx.strokeRect(zoneX, zoneY, zoneW, zoneH);
          hCtx.fillStyle = 'rgba(100, 200, 255, 0.25)';
          hCtx.fillRect(zoneX, zoneY, zoneW, zoneH);
          hCtx.setLineDash([]);
        }
      }
    }

    for (let mi = 0; mi < pageMatches.length; mi++) {
      const match = pageMatches[mi];
      const { x, y, w, h } = textItemRect(match.item.transform, match.item.width, vpT, scale);

      const isActive = activeMatchSet.has(match);
      // 2R 25/10/2026 (Roger: «sem rosa piscando… tipo marca-texto»; 00h06: «verde nas outras e no selecionado o amarelo»)
      void blinkHide;
      if (isActive) {
        hCtx.fillStyle = 'rgba(214, 255, 0, 0.55)';
      } else {
        hCtx.fillStyle = 'rgba(57, 255, 20, 0.32)';
      }
      hCtx.fillRect(x, y, w, h);
    }

    // activeMatchIndex / activeGroupIndex are read imperatively from pdfStore
    // (getDocActiveMatchIndices / getDocActiveGroupIndex), so they're not real
    // deps of this callback. The "blink to active match" effect at L2176
    // already drives drawHighlightsRef.current() on those changes; stepping
    // groups also flips activeMatchIndex (_stepMatchInDoc), so that effect
    // covers group navigation too.
  }, [pdfFileName, isLoaded, currentPage, matches, isMultiTerm, multiTermYGap, multiTermXGap]);

  const renderPageRef = useRef(renderActive);
  renderPageRef.current = renderActive;

  renderDetailRef.current = async () => {
    const d = detailRef.current;
    const container = containerRef.current, main = canvasRef.current, wrapper = wrapperRef.current;
    if (!isLoaded || !container || !main || !wrapper) return;
    if (shouldUseTilesRef.current()) { clearDetail(); return; }
    const cssW = container.clientWidth;
    const cssH = pageCssHRef.current;
    if (!cssW || !cssH || main.width <= 1) return;
    const zoom = zoomRef.current;
    const dpr = window.devicePixelRatio || 1;
    const need = zoom * dpr;                       // device px per page CSS px
    // The full-page canvas is already sharp enough here: nothing to add.
    if (main.width / cssW >= need * 0.98) { clearDetail(); return; }
    // The visible part of the page, in page CSS px at zoom 1.
    const vx = -panRef.current.x / zoom, vy = -panRef.current.y / zoom;
    const vw = container.clientWidth / zoom, vh = container.clientHeight / zoom;
    const r = d.rect;
    if (r && d.canvas && d.zoom === zoom && d.page === currentPage &&
        vx >= r.x - 0.5 && vy >= r.y - 0.5 && vx + vw <= r.x + r.w + 0.5 && vy + vh <= r.y + r.h + 0.5) return;
    // A quarter of the view each side, so a short pan needs no new render;
    // never past 8192 device px a side.
    let m = 0.25;
    while (m > 0 && Math.max(vw, vh) * (1 + 2 * m) * need > 8192) m -= 0.05;
    const x0 = Math.max(0, vx - vw * m), y0 = Math.max(0, vy - vh * m);
    const x1 = Math.min(cssW, vx + vw * (1 + m)), y1 = Math.min(cssH, vy + vh * (1 + m));
    if (x1 <= x0 || y1 <= y0) { clearDetail(); return; }   // looking past the page
    const pxW = Math.ceil((x1 - x0) * need), pxH = Math.ceil((y1 - y0) * need);
    if (pxW > 8192 || pxH > 8192) return;

    const gen = ++d.gen;
    d.task?.cancel();
    const pageNum = currentPage;
    let page;
    try { page = await pdfStore.getPageFor(pdfFileName, pageNum); } catch { return; }
    if (gen !== d.gen) return;
    const rot = page.rotate + rotationRef.current;
    const baseScale = cssW / page.getViewport({ scale: 1, rotation: rot }).width;
    const viewport = page.getViewport({ scale: baseScale * need, rotation: rot, offsetX: -x0 * need, offsetY: -y0 * need });
    const off = acquireCanvas(pxW, pxH);
    const offCtx = off.getContext('2d', { alpha: false });
    if (!offCtx) { releaseCanvas(off); return; }
    const task = page.render({
      canvas: off, canvasContext: offCtx, viewport, intent: 'display',
      ...wmFilterOptions(getActiveWatermarkFilter(renderSettingsStore.globalSettings)),
    });
    d.task = { cancel: () => task.cancel() };
    try { await task.promise; } catch { off.width = 1; off.height = 1; return; }
    if (gen !== d.gen || pdfStore.getDocCurrentPage(pdfFileName) !== pageNum) { off.width = 1; off.height = 1; return; }
    d.task = null;
    let src = off;
    if (cleanMode) {
      const tmp = acquireCanvas(pxW, pxH);
      const tctx = tmp.getContext('2d', { alpha: false });
      if (tctx) { tctx.filter = `contrast(${cleanContrastRef.current})`; tctx.drawImage(off, 0, 0); off.width = 1; off.height = 1; src = tmp; }
    }
    let c = d.canvas;
    if (!c) {
      c = document.createElement('canvas');
      c.className = 'pdf-detail';
      // After the highlight canvas in the DOM (z-index keeps the highlight on
      // top): the main canvas stays the one right before the highlight, which
      // is how tests and tools find it.
      (highlightRef.current ?? main).after(c);
      d.canvas = c;
    }
    if (c.width !== pxW || c.height !== pxH) { c.width = pxW; c.height = pxH; }
    c.getContext('2d')?.drawImage(src, 0, 0);
    src.width = 1; src.height = 1;   // a pdf.js target is never pooled
    const z = committedZoomRef.current;
    c.style.left = `${x0 * z}px`;
    c.style.top = `${y0 * z}px`;
    c.style.width = `${(x1 - x0) * z}px`;
    c.style.height = `${(y1 - y0) * z}px`;
    d.rect = { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
    d.zoom = zoom;
    d.page = pageNum;
  };
  const drawHighlightsRef = useRef(drawHighlights);
  drawHighlightsRef.current = drawHighlights;

  useEffect(() => { renderActive(); }, [renderActive]);
  useEffect(() => { drawHighlights(); }, [drawHighlights]);

  // --- Adjacent page rendering (N pages visible when panning / zoomed out) ---
  useEffect(() => {
    // Single-page layout (explicit or forced while rotated): tear down any
    // adjacent canvases and never render neighbours.
    if (singlePageMode) {
      const adjMap = adjCanvasMapRef.current;
      for (const entry of adjMap.values()) detachCanvas(entry.canvas);
      adjMap.clear();
      return;
    }
    if (!isLoaded || pageCount <= 1) return;
    const wrapper = wrapperRef.current;
    const container = containerRef.current;
    if (!wrapper || !container) return;

    const cssH = pageCssHRef.current;
    if (cssH === 0) return; // main page hasn't rendered yet

    const containerWidth = container.clientWidth;
    if (containerWidth === 0) return;

    // Adjacent pages render at main tier, capped by the preset — the full
    // neighbour tier when near the viewport, the preset's far cap otherwise
    // (neighbourTierFor). The debounce (adjDebounceRef) prevents mid-zoom cascade.

    // How many pages fit in the viewport at current zoom? Render enough to
    // cover. Once one page fills the viewport, ±1 is all a scroll or a page
    // flip can reach before the next settle re-runs this — ±2 there was two
    // more full-page renders nobody could see (review 2026-10-03, 3.1).
    const zoom = zoomRef.current;
    const containerH = container.clientHeight;
    const pageH = cssH * zoom;
    const pagesInView = Math.ceil(containerH / pageH);
    const adjCount = pageH >= containerH ? 1 : Math.max(1, Math.ceil(pagesInView / 2) + 1);

    const ac = new AbortController();
    const adjMap = adjCanvasMapRef.current;

    // Determine which page numbers should have adjacent canvases
    const wantedPages = new Set<number>();
    for (let offset = -adjCount; offset <= adjCount; offset++) {
      if (offset === 0) continue; // current page rendered by main canvas
      const pageNum = currentPage + offset;
      if (pageNum >= 1 && pageNum <= pageCount) wantedPages.add(pageNum);
    }

    // Remove canvases for pages no longer in range.
    // Backdrop canvases (data-transition-backdrop) stay in DOM temporarily —
    // renderTiledPage's batch display rAF removes them after tiles cover them.
    for (const [pageNum, entry] of adjMap) {
      if (!wantedPages.has(pageNum)) {
        if (entry.canvas.dataset.transitionBackdrop) {
          adjMap.delete(pageNum); // detach from map, keep in DOM (rAF removes it)
        } else {
          detachCanvas(entry.canvas);
          adjMap.delete(pageNum);
        }
      }
    }

    /** False when nothing was drawn (aborted, or the render failed) — the
     *  caller then forgets the tier so the next run tries again. */
    const blitAdjacentPage = async (pageNum: number, canvas: HTMLCanvasElement, yOffset: number, tier: number): Promise<boolean> => {
      const cacheKey = pageCacheKey(pdfFileName, pageNum, tier, cleanMode);
      let entry = getPageCache(cacheKey);

      if (!entry) {
        try {
          // The idle prefetch may already be rendering this one.
          const shared = _neighbourInflight.get(cacheKey);
          if (shared) {
            entry = await shared;
          } else {
            const p = renderPageToBitmap(pageNum, containerWidth, tier, cleanMode, ac.signal)
              .then(result => { putPageCache(cacheKey, result); return result; })
              .finally(() => { if (_neighbourInflight.get(cacheKey) === p) _neighbourInflight.delete(cacheKey); });
            _neighbourInflight.set(cacheKey, p);
            entry = await p;
          }
          if (ac.signal.aborted) return false;
        } catch { return false; }
      }
      if (ac.signal.aborted || !entry) return false;

      // CSS sizes use committedZoom so adjacent pages stay in lockstep with
      // the main page's wrapper-children sizing — see applyTransform docstring.
      const zCommit = committedZoomRef.current;
      // Always reset canvas dimensions to clear stale content and ensure
      // getContext returns a fresh context with correct alpha setting.
      canvas.width = entry.width;
      canvas.height = entry.height;
      canvas.style.width = `${entry.cssW * zCommit}px`;
      canvas.style.height = `${entry.cssH * zCommit}px`;
      canvas.dataset.cssW = String(entry.cssW);
      canvas.dataset.cssH = String(entry.cssH);
      canvas.style.position = 'absolute';
      canvas.style.left = '0';
      canvas.style.top = `${yOffset * zCommit}px`;
      canvas.style.pointerEvents = 'none';
      const ctx = canvas.getContext('2d');
      if (ctx) ctx.drawImage(entry.bitmap, 0, 0);

      if (!canvas.parentElement) {
        wrapper.insertBefore(canvas, wrapper.firstChild);
      }
      return true;
    };

    // Sort wanted pages by distance from current page (center-out priority)
    const sortedPages = [...wantedPages].sort((a, b) => Math.abs(a - currentPage) - Math.abs(b - currentPage));

    // Render each wanted adjacent page sequentially (center-out)
    (async () => {
      for (const pageNum of sortedPages) {
        if (ac.signal.aborted) break;
        const offset = pageNum - currentPage;
        const yOffset = offset * cssH;
        const tier = neighbourTierFor(offset);
        let existing = adjMap.get(pageNum);

        // A canvas already at this tier or sharper is kept: a neighbour that
        // drifted from near to far must not be redrawn softer.
        if (existing && existing.tier >= tier) {
          // Already rendered at the right tier — reposition it. Width and
          // height go with the offset: all three are committed-zoom-scaled, so
          // updating only `top` leaves the page at the scale it had when the
          // tier was last rendered while the main page moves on. The tier
          // changes on most zoom steps, which is why this is a hazard rather
          // than a standing bug — but a saturated tier (the `medium` preset
          // caps at 6, and a tablet defaults to `medium`) holds it still while
          // the zoom keeps going.
          // The page's CSS size rides on the canvas (set when it was drawn),
          // so a kept canvas is sized right even after its bitmap left the cache.
          const zCommit = committedZoomRef.current;
          const cw = Number(existing.canvas.dataset.cssW), ch = Number(existing.canvas.dataset.cssH);
          if (cw > 0 && ch > 0) {
            existing.canvas.style.width = `${cw * zCommit}px`;
            existing.canvas.style.height = `${ch * zCommit}px`;
          }
          existing.canvas.style.top = `${yOffset * zCommit}px`;
          continue;
        }

        // Need to render (new page or tier changed)
        if (!existing) {
          const canvas = document.createElement('canvas');
          canvas.className = 'pdf-adjacent-page';
          existing = { canvas, tier: 0 };
          adjMap.set(pageNum, existing);
        }
        existing.tier = tier;
        if (!(await blitAdjacentPage(pageNum, existing.canvas, yOffset, tier))) existing.tier = 0;
      }
    })();

    return () => { ac.abort(); };
  }, [isLoaded, currentPage, pageCount, pdfFileName, cleanMode, renderPageToBitmap, adjTrigger, singlePageMode, neighbourTierFor]);

  // Sync search input when searchQuery changes externally (e.g. pre-populated from library)
  useEffect(() => {
    if (searchInputRef.current && searchQuery !== searchInputRef.current.value) {
      searchInputRef.current.value = searchQuery;
    }
  }, [searchQuery]);

  // Auto-clear lookup hint after 4 seconds
  useEffect(() => {
    if (!lookupHint) return;
    const timer = setTimeout(() => pdfStore.clearLookupHint(pdfFileName), 4000);
    return () => clearTimeout(timer);
  }, [lookupHint, pdfFileName]);

  // Surface cross-lookup feedback ("no match", "linked PDF not open") as a toast,
  // then consume it. crossProbeHint is a one-shot message channel from the store.
  useEffect(() => {
    if (!crossProbeHint) return;
    boardStore.addToast(crossProbeHint, 'info');
    pdfStore.clearCrossProbeHint(pdfFileName);
  }, [crossProbeHint, pdfFileName]);

  const pendingMatchRef = useRef<{ index: number; id: number }>({ index: -1, id: 0 });

  const prevMatchIndexRef = useRef(-1);
  const prevMatchesRef = useRef<typeof matches | null>(null);
  const prevNavSeqRef = useRef(0);
  useEffect(() => {
    if (!isLoaded || activeMatchIndex < 0 || !matches[activeMatchIndex]) return;
    // Only snap-to-match on explicit navigation: activeMatchIndex OR matches
    // array changed (a new search produces a fresh matches reference even if
    // activeMatchIndex happens to land on the same number), OR the store's
    // navigation counter moved — Enter / ⌘F on a single hit steps to the same
    // index, and the user who panned away still expects to be taken back.
    const isNewSearch = prevMatchesRef.current !== matches;
    const isStep = matchNavSeq !== prevNavSeqRef.current;
    if (!isNewSearch && !isStep && activeMatchIndex === prevMatchIndexRef.current) return;
    // A step that lands on the index already active (one hit, stepped again)
    // is the user asking to be taken back to it: re-centre even if a corner
    // of it is still on screen.
    const isRefocus = isStep && !isNewSearch && activeMatchIndex === prevMatchIndexRef.current;
    prevMatchIndexRef.current = activeMatchIndex;
    prevMatchesRef.current = matches;
    prevNavSeqRef.current = matchNavSeq;

    const match = matches[activeMatchIndex];
    const matchPage = match.pageIndex + 1;
    if (matchPage !== currentPage) {
      skipResetRef.current = true;
    }

    const matchId = ++pendingMatchRef.current.id;
    pendingMatchRef.current.index = activeMatchIndex;

    let scaleRetries = 0;
    const applyZoomAndBlink = () => {
      if (pendingMatchRef.current.id !== matchId) return;
      if (!containerRef.current) return;

      const baseScale = scaleRef.current;
      const unscaledH = viewportHeightRef.current;
      if (baseScale === 0 || unscaledH === 0) {
        if (scaleRetries++ < 5) {
          // renderPage() hasn't completed yet — retry once it does
          setTimeout(() => {
            if (pendingMatchRef.current.id === matchId) applyZoomAndBlink();
          }, 100);
        }
        return;
      }

      // For multi-term / @ groups, zoom to fit all group members; otherwise zoom to single match
      const activeGroup = (isMultiTerm || isAtSyntax) ? pdfStore.getDocMatchGroups(pdfFileName)[pdfStore.getDocActiveGroupIndex(pdfFileName)] : null;
      const groupMatches = activeGroup
        ? activeGroup.map(i => matches[i]).filter(Boolean)
        : [match];

      const container = containerRef.current;
      const items = groupMatches.map(m => m.item);

      // If the active match is already visible in the current viewport AND we're
      // already on its page, don't snap — the user already sees it (e.g. Cmd+F
      // on a selected component that's under the cursor). Just blink it.
      const matchPageNow = match.pageIndex + 1;
      const vpT = viewportTransformRef.current;
      const z = zoomRef.current;
      const px = panRef.current.x;
      const py = panRef.current.y;
      const cw = container.clientWidth;
      const ch = container.clientHeight;
      const isItemInView = (it: { transform: number[]; width: number }): boolean => {
        const r = textItemRect(it.transform, it.width, vpT, baseScale);
        const sx = r.x * z + px;
        const sy = r.y * z + py;
        const sw = r.w * z;
        const sh = r.h * z;
        return sx + sw > 0 && sy + sh > 0 && sx < cw && sy < ch;
      };
      // Skip the zoom only if we're ALREADY zoomed in enough AND the match is
      // visible. At low zooms the whole page is "in view" which would wrongly
      // leave the user at 100% — enforce the 300% floor instead.
      const alreadyInView = !isRefocus && z >= 3.0 && matchPageNow === currentPage && items.some(isItemInView);

      // On a FRESH search only, try to relocate the active match to a
      // different visible match on the same page (handles "multiple U5
      // instances on the page, user is looking at one of them" when Cmd+F
      // runs a lookup from a selection). NOT on stepwise navigation — that
      // would bounce back and forth as the user presses Down. Skipped for
      // 'lookup' searches: lookupEntity already context-scored the best
      // occurrence, so don't second-guess it by snapping to whatever is in view.
      const isContextLookup = pdfStore.getDocSearchSource(pdfFileName) === 'lookup';
      if (isNewSearch && !isContextLookup && !alreadyInView && matchPageNow === currentPage && !activeGroup) {
        for (let i = 0; i < matches.length; i++) {
          if (i === activeMatchIndex) continue;
          if (matches[i].pageIndex !== match.pageIndex) continue;
          if (isItemInView(matches[i].item)) {
            pdfStore.setActiveMatchIndex(i);
            return; // effect will re-run with the new index
          }
        }
      }

      // 2R 25/10/2026: «cruz de referência invisível» — o resultado vai sempre para o centro (window.__r2PdfCentro=false desliga)
      if (!alreadyInView || r2w.__r2PdfCentro !== false) {
        // Match navigation: enforce a floor of max(currentZoom, 3.0) so we never
        // zoom OUT when stepping between matches — stay at ≥300% or keep higher
        // zoom if the user was already zoomed in further.
        const floor = Math.max(zoomRef.current, 3.0);
        const { zoom: newZoom, pan: newPan } = zoomToItemGroup(
          items, viewportTransformRef.current, baseScale,
          container.clientWidth, container.clientHeight, 0.2,
          floor,
        );

        // Mirrored: the centering pan was computed in un-mirrored space; reflect
        // its X so the match lands centered on the flipped display.
        if (mirrorRef.current) newPan.x = container.clientWidth * (1 - newZoom) - newPan.x;
        stopGlide();
        zoomRef.current = newZoom;
        panRef.current = newPan;
        syncTransform();
      }

      renderPageRef.current();

      if (blinkTimerRef.current) clearTimeout(blinkTimerRef.current);
      blinkPhaseRef.current = 0;
      const totalBlinks = 6;
      const blinkInterval = 250;

      const doBlink = (phase: number) => {
        if (pendingMatchRef.current.id !== matchId) return;
        blinkPhaseRef.current = phase;
        drawHighlightsRef.current();
        if (phase < totalBlinks) {
          blinkTimerRef.current = setTimeout(() => doBlink(phase + 1), blinkInterval);
        } else {
          blinkPhaseRef.current = 0;
          drawHighlightsRef.current();
          blinkTimerRef.current = null;
        }
      };
      doBlink(1);
    };

    const raf = requestAnimationFrame(applyZoomAndBlink);

    return () => {
      cancelAnimationFrame(raf);
      if (blinkTimerRef.current) {
        clearTimeout(blinkTimerRef.current);
        blinkTimerRef.current = null;
      }
      blinkPhaseRef.current = 0;
    };
  }, [isLoaded, activeMatchIndex, matchNavSeq, matches, currentPage, isMultiTerm, isAtSyntax, pdfFileName, syncTransform]);

  // Follow target: zoom + highlight location (triggered by board follow mode / click-to-lookup)
  useEffect(() => {
    const target = pdfStore.consumeFollowTarget();
    if (!target || !isLoaded) return;

    const targetPage = target.pageIndex + 1;
    if (targetPage !== currentPage) {
      skipResetRef.current = true;
    }

    let retries = 0;
    const applyFollowZoom = () => {
      const baseScale = scaleRef.current;
      if (baseScale === 0 || !containerRef.current) {
        if (retries++ < 5) setTimeout(applyFollowZoom, 100);
        return;
      }

      // Board→PDF lookup: match the match-nav behavior — floor zoom at 3.0
      // (or keep higher current zoom) and center on the target group.
      const floor = Math.max(zoomRef.current, 3.0);
      const { zoom, pan } = zoomToItemGroup(
        target.items, viewportTransformRef.current, baseScale,
        containerRef.current.clientWidth, containerRef.current.clientHeight, 0.25,
        floor,
      );
      if (mirrorRef.current) pan.x = containerRef.current.clientWidth * (1 - zoom) - pan.x;
      stopGlide();
      zoomRef.current = zoom;
      panRef.current = pan;
      syncTransform();
      renderPageRef.current();

      // Show highlight on the first item for visual feedback
      if (target.items.length > 0) {
        const r = textItemRect(target.items[0].transform, target.items[0].width, viewportTransformRef.current, baseScale);
        showClickHighlight({ x: r.x, y: r.y, w: r.w, h: r.h }, '', zoomRef.current, 3000);
      }
    };

    // Defer to ensure the page has rendered first
    const raf = requestAnimationFrame(applyFollowZoom);
    return () => cancelAnimationFrame(raf);
  }, [isLoaded, currentPage, syncTransform, showClickHighlight]);

  // Apply initial transform + re-sync after page change
  useEffect(() => { syncTransform(); }, [syncTransform, currentPage]);

  useEffect(() => {
    if (!containerRef.current) return;
    const observer = new ResizeObserver(() => {
      // Container size changed → fit-to-width baseScale changes too, so tiles
      // AND full-page bitmaps cached at the old containerWidth would blit at
      // the wrong size. The page-cache key omits containerWidth, so a stale
      // entry would be found-then-rejected (cssW mismatch) and its bitmap
      // leaked when the re-render overwrites the same key — drop the whole doc
      // from both caches here. Re-clamp pan/zoom against the new bounds so the
      // page doesn't sit off-screen until the next user input.
      invalidateTileCache(pdfFileName);
      invalidatePageCache(pdfFileName); clearDetail();
      renderPageRef.current();
      syncTransform();
    });
    observer.observe(containerRef.current);
    return () => observer.disconnect();
    // isLoaded: the panel can mount before its document (it is opened first
    // to show the load state) and the container exists only once it is loaded.
  }, [pdfFileName, syncTransform, isLoaded, clearDetail]);

  // Reload PDF with fontExtraProperties when glyph debug is first activated
  useEffect(() => {
    if (!isGlyphActive || fontDataLoaded || !isLoaded) return;
    let cancelled = false;
    (async () => {
      setGlyphLoading(true);
      try {
        await pdfStore.reloadWithFontData(pdfFileName);
        if (!cancelled) {
          setFontDataLoaded(true);
          await renderPageRef.current();
        }
      } catch (err) {
        log.pdf.error('reloadWithFontData failed:', err);
      } finally {
        if (!cancelled) setGlyphLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [isGlyphActive, fontDataLoaded, isLoaded, pdfFileName]);

  // Extract glyphs and render debug/optimization overlay
  // Skip when nightMode is active — CSS invert filter would not apply to replacement text
  // cleanMode is fine: contrast is baked into canvas pixels at render time
  const isFiltered = nightMode;
  useEffect(() => {
    if (!isOverlayActive || !isLoaded || isFiltered) {
      const gc = glyphCanvasRef.current;
      if (gc) {
        const gCtx = gc.getContext('2d');
        if (gCtx) gCtx.clearRect(0, 0, gc.width, gc.height);
      }
      pageGlyphDataRef.current = null;
      return;
    }

    // textItems mode: draw raw pdf.js text items without glyph extraction
    if (isTextItemsMode) {
      const gc = glyphCanvasRef.current;
      const pdfCanvas = canvasRef.current;
      if (!gc || !pdfCanvas) return;
      gc.width = pdfCanvas.width;
      gc.height = pdfCanvas.height;
      gc.style.width = pdfCanvas.style.width;
      gc.style.height = pdfCanvas.style.height;

      const gCtx = gc.getContext('2d')!;
      gCtx.clearRect(0, 0, gc.width, gc.height);

      const vpT = viewportTransformRef.current;
      const renderScale = scaleRef.current * renderTierRef.current;
      const pageIndex = currentPage - 1;
      const rawItems = pdfStore.getDocTextItemsForPage(pdfFileName, pageIndex);
      drawTextItems(gCtx, rawItems, vpT, renderScale);

      // Log all text items to console for investigation
      log.pdf.log(`[textItems] Page ${currentPage}: ${rawItems.length} items extracted by pdf.js`);
      for (let i = 0; i < rawItems.length; i++) {
        const it = rawItems[i];
        log.pdf.log(`  #${i} "${it.str}" font=${it.fontName} fs=${pdfFontSize(it.transform).toFixed(1)} w=${it.width.toFixed(1)} tx=[${it.transform.map(v => v.toFixed(2)).join(',')}]`);
      }
      return;
    }

    // Glyph modes: need fontData loaded
    if (!isGlyphActive || !fontDataLoaded) {
      const gc = glyphCanvasRef.current;
      if (gc) {
        const gCtx = gc.getContext('2d');
        if (gCtx) gCtx.clearRect(0, 0, gc.width, gc.height);
      }
      pageGlyphDataRef.current = null;
      return;
    }

    let cancelled = false;
    (async () => {
      setGlyphLoading(true);
      try {
        const page = await pdfStore.getPageFor(pdfFileName, currentPage);
        const doc = pdfStore.getDocProxy(pdfFileName);
        if (!doc || cancelled) return;
        const pageIndex = currentPage - 1;
        const textItems = pdfStore.getDocTextItemsForPage(pdfFileName, pageIndex);
        const pageData = await extractPageGlyphs(page, doc, textItems, pageIndex);
        if (cancelled) return;
        pageGlyphDataRef.current = pageData;

        const gc = glyphCanvasRef.current;
        const pdfCanvas = canvasRef.current;
        if (!gc || !pdfCanvas) return;
        gc.width = pdfCanvas.width;
        gc.height = pdfCanvas.height;
        gc.style.width = pdfCanvas.style.width;
        gc.style.height = pdfCanvas.style.height;

        const gCtx = gc.getContext('2d')!;
        gCtx.clearRect(0, 0, gc.width, gc.height);

        // For simplify/replace: blit PDF canvas onto overlay, then modify in-place
        if (isGlyphComposite) {
          // Wait for PDF canvas to have content (renderPage may still be in flight)
          if (pdfCanvas.width === 0 || pdfCanvas.height === 0) {
            await new Promise<void>(resolve => {
              const check = () => {
                if (cancelled) { resolve(); return; }
                if (pdfCanvas.width > 0 && pdfCanvas.height > 0) { resolve(); return; }
                requestAnimationFrame(check);
              };
              requestAnimationFrame(check);
            });
            if (cancelled) return;
          }
          gCtx.drawImage(pdfCanvas, 0, 0);
        }

        const vpT = viewportTransformRef.current;
        const renderScale = scaleRef.current * renderTierRef.current;

        if (glyphDebug.overlayMode === 'boxes') {
          drawGlyphBoxes(gCtx, pageData, vpT, renderScale);
        } else if (glyphDebug.overlayMode === 'outlines') {
          drawGlyphOutlines(gCtx, pageData, vpT, renderScale);
        }

        if (glyphDebug.simplifyEnabled) {
          simplifyStatsRef.current = drawSimplifiedGlyphs(gCtx, pageData, vpT, renderScale, glyphDebug.simplifyTolerance);
        } else {
          simplifyStatsRef.current = null;
        }
        if (glyphDebug.replaceEnabled) {
          drawMonospaceReplacement(gCtx, pageData, vpT, renderScale, glyphDebug.replaceFont);
        }
      } catch (err) {
        log.pdf.error('glyph overlay failed:', err);
      } finally {
        if (!cancelled) setGlyphLoading(false);
      }
    })();

    return () => { cancelled = true; };

  }, [isOverlayActive, isTextItemsMode, isGlyphActive, isGlyphComposite, fontDataLoaded, isLoaded, isFiltered, pdfFileName, currentPage,
      glyphDebug.overlayMode, glyphDebug.simplifyEnabled, glyphDebug.simplifyTolerance,
      glyphDebug.replaceEnabled, glyphDebug.replaceFont, renderEpoch]);

  // Clean up font cache + adjacent canvases on unmount
  useEffect(() => {
    // Capture the Map reference at effect time. useRef(new Map()) never
    // reassigns .current, so this identity stays valid through unmount.
    const adjCanvasMap = adjCanvasMapRef.current;
    return () => {
      const doc = pdfStore.getDocProxy(pdfFileName);
      clearFontCache(doc?.fingerprints[0] ?? undefined);
      pageGlyphDataRef.current = null;
      for (const entry of adjCanvasMap.values()) detachCanvas(entry.canvas);
      adjCanvasMap.clear();
      if (adjDebounceRef.current) clearTimeout(adjDebounceRef.current);
      if (scrubberFlashTimerRef.current) clearTimeout(scrubberFlashTimerRef.current);
    };
  }, [pdfFileName]);

  // Accumulated scroll for page-switch mode — debounce discrete page flips
  const switchAccRef = useRef(0);
  const switchTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const handleWheel = (e: WheelEvent) => {
      e.preventDefault();
      pdfStore.switchTo(pdfFileName);

      // Single-page layout (explicit mode or forced while rotated): never flip
      // to a neighbouring page on scroll/zoom — pan stays clamped to the current
      // page. Page changes happen only via nav controls, scrubber, or shortcuts.
      const noFlip = pdfStore.isDocSinglePage(pdfFileName);

      // Trackpad pinch-to-zoom generates wheel events with ctrlKey=true.
      // Always treat those as zoom — pinch is a fundamental gesture that should
      // never be remapped by scroll binding settings.
      const isTrackpadPinch = e.ctrlKey && !e.metaKey && !e.shiftKey;
      // 2R 20/10/2026 (Roger): pinça de dois dedos no trackpad volta a dar zoom no PDF
      const R2F = trackpadDirect() && pointerMode() === 'flexbv';
      if (isTrackpadPinch) log.ui.log('pdf wheel pinch (ctrlKey)', { deltaY: e.deltaY });
      // 2R 20/10/2026 (Roger): arrastar com dois dedos não pode virar zoom; só a pinça (ctrl) e a rodinha do mouse.
      // 22/10/2026: no Windows com escala da tela a roda chega com deltaY quebrado — roda = wheelDeltaY múltiplo de 120
      const R2T = (() => {
        const w = (e as any).wheelDeltaY as number | undefined;
        const tp = e.deltaX !== 0 || (w !== undefined && w !== 0 ? w % 120 !== 0 && (e.deltaY % 1 !== 0 || w === -3 * e.deltaY) : e.deltaY % 1 !== 0);
        const ag = performance.now();
        if (tp) r2w.__r2tpT = ag;
        return tp || ag - (r2w.__r2tpT || 0) < 400;
      })();
      const R2N = !R2T && (e.deltaMode === 1 || ((e as any).wheelDeltaY !== undefined && (e as any).wheelDeltaY !== 0 && (e as any).wheelDeltaY % 120 === 0)
        || (Math.abs(e.deltaY) >= 50 && e.deltaY % 1 === 0));

      // Resolve effective action: trackpad pinch → always zoom, otherwise use bindings.
      // No `wheelDetection` safety net here — on PDF, classic mouse-wheel scrolling
      // is the natural way to walk through pages, so pan stays as pan even if the
      // input looks wheel-shaped. (Safety net remains active on the board view,
      // where there's no "next page" affordance.)
      const bindings = scrollBindingsRef.current;
      const effectiveAction: ScrollAction = isTrackpadPinch || (!e.metaKey && !e.shiftKey && !e.ctrlKey && e.deltaX === 0 && R2N)
        ? 'zoom'
        : R2F && !e.metaKey && !e.shiftKey ? 'pan'
        : (e.metaKey || e.ctrlKey) ? bindings.meta
        : e.shiftKey ? bindings.shift
        : bindings.bare;

      if (effectiveAction === 'zoom') {
        const rect = container.getBoundingClientRect();
        const mouseX = e.clientX - rect.left;
        const mouseY = e.clientY - rect.top;

        // Min zoom floor: in blocking mode (Pan Boundaries) lock at fit-width
        // (100%) so the page can't shrink into the scroll-flip bounce zone
        // (the boundary-bounce glitch a876c74/e5ef926 masked); free mode keeps
        // the 0.5 floor that restored the zoom-out-to-see-adjacent-pages flow.
        const cssH = pageCssHRef.current;
        const minZoom = renderSettingsStore.settings.pdfEnableBoundaries ? 1 : 0.5;

        // Trackpad pinch has small deltaY values — use higher sensitivity.
        //
        // `isTrackpadPinch` is really "ctrlKey", and a mouse wheel held with
        // Ctrl is the browser's standard zoom gesture, so it lands here too —
        // with a deltaY two orders of magnitude larger than a pinch step.
        // Measured: one notch took the page from 100% to 739%. Capping the
        // step bounds that without having to guess the device: every real
        // pinch event is far below the cap, and a mouse notch now zooms by
        // about the same ~2.4x the board gives for Ctrl+wheel, which is the
        // deliberate "Ctrl = coarse zoom" behaviour documented there.
        const speed = isTrackpadPinch ? TRACKPAD_PINCH_SPEED
          : R2F || R2N ? 0.0018 * (e.deltaMode === 1 || (Math.abs(e.deltaY) >= 50 && e.deltaY % 1 === 0)
            ? mouseZoomSpeed() : parseFloat(localStorage.getItem('2r-flex-tp-zoom') || '8') || 8)
          : MOUSE_WHEEL_SPEED;
        const step = isTrackpadPinch
          ? Math.max(-PINCH_STEP_CAP, Math.min(PINCH_STEP_CAP, e.deltaY))
          : e.deltaY * (r2w.__r2RodaK ? r2w.__r2RodaK(e) : 1);
        const zoomFactor = Math.exp(-step * speed);
        const oldZoom = zoomRef.current;
        const newZoom = Math.max(minZoom, Math.min(oldZoom * zoomFactor, 10));
        const ratio = newZoom / oldZoom;
        const oldPan = panRef.current;
        const newPanY = mouseY - ratio * (mouseY - oldPan.y);
        panRef.current = {
          x: mouseX - ratio * (mouseX - oldPan.x),
          y: newPanY,
        };
        zoomRef.current = newZoom;

        // Page boundary detection during zoom: when zoomed in and the viewport
        // center has moved over an adjacent page, switch to it so it renders crisp.
        if (cssH > 0 && !noFlip) {
          const pageH = cssH * newZoom;
          const containerH = container.clientHeight;
          const curPage = pdfStore.getDocCurrentPage(pdfFileName);
          const total = pdfStore.getDocPageCount(pdfFileName);

          if (newPanY + pageH < containerH / 2 && curPage < total) {
            skipResetRef.current = true;
            ++tileRenderIdRef.current;
            // Cancel stale timers — they have closures over old currentPage
            if (tierDebounceRef.current) { clearTimeout(tierDebounceRef.current); tierDebounceRef.current = null; }
            if (crispTimerRef.current) { clearTimeout(crispTimerRef.current); crispTimerRef.current = null; }
            for (const c of tileContainerRef.current.values()) c.style.display = 'none';
            pdfStore.goToPage(curPage + 1);
            panRef.current = { x: panRef.current.x, y: newPanY + pageH };
            flashScrubber();
            syncTransform();
            return;
          } else if (newPanY > containerH / 2 && curPage > 1) {
            skipResetRef.current = true;
            ++tileRenderIdRef.current;
            if (tierDebounceRef.current) { clearTimeout(tierDebounceRef.current); tierDebounceRef.current = null; }
            if (crispTimerRef.current) { clearTimeout(crispTimerRef.current); crispTimerRef.current = null; }
            for (const c of tileContainerRef.current.values()) c.style.display = 'none';
            pdfStore.goToPage(curPage - 1);
            panRef.current = { x: panRef.current.x, y: newPanY - pageH };
            flashScrubber();
            syncTransform();
            return;
          }
        }

        syncTransform();
        markGestureActive();
        scheduleTierRender();
        return;
      }

      if (effectiveAction === 'pan') {
        // Omnidirectional multi-page scrolling. Two-finger scroll moves freely
        // in X and Y. syncTransform → clampPan handles all boundary clamping.
        // Bail on an unmeasured page: flipPagesForPan needs a real page height
        // to know where a boundary is, and clampPan needs one to bound Y.
        if (pageCssHRef.current === 0) return;

        const oldPan = panRef.current;
        const newX = oldPan.x - e.deltaX;
        let newY = oldPan.y - e.deltaY;

        // One implementation of the flip, shared with the touch-drag path —
        // see flipPagesForPan. `noFlip` is single-page layout, which the
        // helper reads for itself.
        if (!noFlip) newY = flipPagesForPan(newY);

        panRef.current = { x: newX, y: newY };
        syncTransform();
        return;
      }

      // action === 'switch': discrete page change, page stays centered
      const delta = e.deltaY;
      switchAccRef.current += delta;
      if (switchTimerRef.current) clearTimeout(switchTimerRef.current);
      switchTimerRef.current = setTimeout(() => { switchAccRef.current = 0; }, 200);

      const threshold = 50; // pixels of scroll accumulation needed
      if (Math.abs(switchAccRef.current) >= threshold) {
        const dir = switchAccRef.current > 0 ? 1 : -1;
        switchAccRef.current = 0;
        const doc = pdfStore.getDocCurrentPage(pdfFileName);
        const total = pdfStore.getDocPageCount(pdfFileName);
        const target = doc + dir;
        if (target >= 1 && target <= total) {
          // Reset zoom/pan to center the new page (don't skip reset)
          zoomRef.current = 1;
          panRef.current = { x: 0, y: 0 };
          pdfStore.goToPage(target);
          syncTransform();
          flashScrubber();
        }
      }
    };

    container.addEventListener('wheel', handleWheel, { passive: false });
    return () => container.removeEventListener('wheel', handleWheel);

  }, [pdfFileName, isLoaded, syncTransform, scheduleTierRender, flashScrubber, markGestureActive, flipPagesForPan]);

  // --- Touch pinch-to-zoom state ---
  const activeTouchesRef = useRef<Map<number, { x: number; y: number }>>(new Map());
  const pinchStartDistRef = useRef(0);
  const pinchStartZoomRef = useRef(1);
  const pinchMidRef = useRef({ x: 0, y: 0 });
  /** One "pan clamped" line per gesture, not per move. */
  const clampLoggedRef = useRef(false);

  /** Who is driving zoom and pan right now.
   *
   *  iPadOS delivers one two-finger pinch as **two** streams — pointer events
   *  and WebKit's `gesture*` events — and which of them is complete varies:
   *  when the engine claims the gesture for its own recogniser it may never
   *  dispatch the second finger's `pointerdown` at all. Exactly one stream may
   *  own a gesture, and the hand-off has to be explicit in **both** directions.
   *
   *  It used to be one-directional: the gesture path stood down whenever a
   *  finger was registered, but nothing ever told the pointer path that a
   *  gesture had started. With one finger registered and the other claimed by
   *  the engine, `activeTouchesRef.size` stayed 1 — so the gesture path zoomed
   *  about the two-finger midpoint while the single-finger drag path panned
   *  along finger one, from the same gesture, on interleaved events. That is
   *  both "zooms sometimes properly, sometimes around the edge" (the visible
   *  anchor is a mixture of the two) and a scroll that fights itself. */
  const gestureOwnerRef = useRef<'none' | 'pointer' | 'gesture'>('none');
  /** WebKit has no `gesturecancel`, so a claimed gesture that simply stops
   *  arriving would own the viewer for ever. */
  const gestureReleaseTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  /** `seedPinch` is declared below the gesture effect; the effect only calls it
   *  when an event fires, so a ref is enough to bridge the order. */
  const seedPinchRef = useRef<() => void>(() => {});

  // --- Safari trackpad pinch via gesture* events ---
  // Mac Safari emits gesture* events for trackpad pinch. The global handler in
  // browser-zoom-block.ts preventDefaults gesture events at window level to
  // block browser page-zoom; that means the PDF never receives a zoom signal
  // via the wheel+ctrlKey path either, since Safari's pinch path is gesture-only.
  // Bubble-phase panel handlers fire before the window block and consume the
  // event with stopPropagation, so the global net stays a fallback for
  // gestures outside the panel (toolbar, sidebar).
  //
  // iPadOS Safari, however, fires gesture* for a two-finger TOUCH pinch as
  // well — on top of the full pointer-event stream the touch pinch below
  // already runs on. Two zoom integrators, each anchored to its own start
  // snapshot, then write zoomRef/panRef on alternating events and the page
  // lurches. So: any finger on the glass ⇒ this path stands down. A Mac
  // trackpad has no touch pointers, which is exactly the case this is for.
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    let startZoom = 1;
    // Tracked, not frozen: on iPadOS `GestureEvent.clientX/Y` is the midpoint
    // between two moving fingers and travels with them, so a midpoint fixed at
    // gesturestart is stale from the second event on — the same bug the
    // pointer pinch had, and the reason this path anchored in the wrong place
    // whenever it was the one driving.
    let lastMid = { x: 0, y: 0 };

    /** Release the claim, and hand a still-pressed finger back to the drag
     *  path so a pinch can be followed by a scroll without lifting off. */
    const releaseGesture = () => {
      if (gestureReleaseTimerRef.current) {
        clearTimeout(gestureReleaseTimerRef.current);
        gestureReleaseTimerRef.current = null;
      }
      if (gestureOwnerRef.current !== 'gesture') return;
      gestureOwnerRef.current = 'none';
      const pts = [...activeTouchesRef.current.values()];
      if (pts.length >= 2) {
        seedPinchRef.current();
      } else if (pts.length === 1) {
        isDraggingRef.current = true;
        wasDragRef.current = false;
        velocityRef.current = { x: 0, y: 0 };
        lastDragTimeRef.current = performance.now();
        dragStartRef.current = { x: pts[0].x, y: pts[0].y };
        lastMouseRef.current = { x: pts[0].x, y: pts[0].y };
      }
    };
    /** WebKit fires no gesturecancel; a claim that stops arriving must lapse. */
    const armRelease = () => {
      if (gestureReleaseTimerRef.current) clearTimeout(gestureReleaseTimerRef.current);
      gestureReleaseTimerRef.current = setTimeout(releaseGesture, 400);
    };

    const onGestureStart = (e: GestureEvent) => {
      // A complete pointer pair is the better stream — it carries both finger
      // positions, so it can anchor on the real midpoint and keep both fingers
      // on their content. Only claim the gesture when the pointer path has not.
      if (activeTouchesRef.current.size >= 2) {
        log.pdf.log('gesturestart ignored — the pointer pinch owns this gesture',
          { fingers: activeTouchesRef.current.size });
        return;
      }
      gestureOwnerRef.current = 'gesture';
      // The engine has just told us this is a two-finger gesture. Whatever the
      // one registered finger had started is not a scroll.
      isDraggingRef.current = false;
      wasDragRef.current = false;
      cancelAnimationFrame(inertiaRafRef.current);
      velocityRef.current = { x: 0, y: 0 };

      pdfStore.switchTo(pdfFileName);
      startZoom = zoomRef.current;
      const rect = container.getBoundingClientRect();
      lastMid = { x: e.clientX - rect.left, y: e.clientY - rect.top };
      log.pdf.log('gesture pinch claimed', { scale: e.scale, fingers: activeTouchesRef.current.size });
      armRelease();
      e.preventDefault();
      e.stopPropagation();
    };

    const onGestureChange = (e: GestureEvent) => {
      if (gestureOwnerRef.current !== 'gesture') return;
      armRelease();
      const minZoom = renderSettingsStore.settings.pdfEnableBoundaries ? 1 : 0.5;
      const newZoom = Math.max(minZoom, Math.min(startZoom * e.scale, 10));
      const ratio = newZoom / zoomRef.current;
      const rect = container.getBoundingClientRect();
      const mid = { x: e.clientX - rect.left, y: e.clientY - rect.top };
      // Scale about the previous midpoint, then translate by the new one's
      // travel — pan₁ = mid₀ - ratio·(mid₀ - pan₀) + (mid₁ - mid₀). Same rule
      // as the pointer pinch; anchoring on the new midpoint double-counts its
      // travel by (1 - ratio) per event.
      panRef.current = {
        x: lastMid.x - ratio * (lastMid.x - panRef.current.x) + (mid.x - lastMid.x),
        y: lastMid.y - ratio * (lastMid.y - panRef.current.y) + (mid.y - lastMid.y),
      };
      lastMid = mid;
      zoomRef.current = newZoom;
      syncTransform();
      e.preventDefault();
      e.stopPropagation();
    };

    const onGestureEnd = (e: GestureEvent) => {
      if (gestureOwnerRef.current !== 'gesture') return;
      releaseGesture();
      scheduleTierRender();
      e.preventDefault();
      e.stopPropagation();
    };

    container.addEventListener('gesturestart', onGestureStart as EventListener, { passive: false });
    container.addEventListener('gesturechange', onGestureChange as EventListener, { passive: false });
    container.addEventListener('gestureend', onGestureEnd as EventListener, { passive: false });
    return () => {
      container.removeEventListener('gesturestart', onGestureStart as EventListener);
      container.removeEventListener('gesturechange', onGestureChange as EventListener);
      container.removeEventListener('gestureend', onGestureEnd as EventListener);
      if (gestureReleaseTimerRef.current) clearTimeout(gestureReleaseTimerRef.current);
      gestureOwnerRef.current = 'none';
    };
    // isLoaded: see the ResizeObserver effect — without it a panel opened
    // before its document never attached the gesture listeners.
  }, [pdfFileName, syncTransform, scheduleTierRender, isLoaded]);


  /** Re-seed the pinch baseline from whichever two pointers are tracked now.
   *
   *  The baseline has to follow the *pair*, not just the count. A third finger,
   *  or one of two being cancelled and replaced, changes which two pointers
   *  `values()` yields while the recorded start distance and start zoom still
   *  describe the old pair — the next move then computes a ratio between two
   *  unrelated distances and the page leaps. Seeding on every membership
   *  change costs one call per pointerdown/up and removes the whole class. */
  const seedPinch = useCallback(() => {
    const container = containerRef.current;
    if (!container) return;
    const pts = [...activeTouchesRef.current.values()];
    if (pts.length < 2) { pinchStartDistRef.current = 0; return; }
    const dx = pts[1].x - pts[0].x;
    const dy = pts[1].y - pts[0].y;
    pinchStartDistRef.current = Math.hypot(dx, dy) || 0;
    pinchStartZoomRef.current = zoomRef.current;
    const rect = container.getBoundingClientRect();
    pinchMidRef.current = {
      x: (pts[0].x + pts[1].x) / 2 - rect.left,
      y: (pts[0].y + pts[1].y) / 2 - rect.top,
    };
  }, []);
  seedPinchRef.current = seedPinch;

  const handlePointerDown = useCallback((e: React.PointerEvent) => {
    const container = containerRef.current;
    if (!container) return;
    // `isPrimary` marks the first finger of a touch sequence, so it is also
    // where an id left behind by a capture loss or a cancel we never saw can
    // be dropped. Without this self-heal one missing pointerup leaves the map
    // at two entries for good: every later move takes the pinch branch, the
    // drag branch is never reached, and panning is simply dead.
    clampLoggedRef.current = false;
    if (e.pointerType === 'touch' && e.isPrimary) activeTouchesRef.current.clear();
    // setPointerCapture throws NotFoundError when the pointer is no longer
    // active — which happens for real: iOS cancels a touch between the event
    // being queued and this handler running. Uncaught, the throw aborted the
    // rest of this function, so the finger was never registered while its
    // eventual pointerup still ran the delete. With two fingers down and only
    // one registered the viewer takes the drag branch and pans off one finger
    // in the middle of a pinch. Capture is an optimisation here; the
    // bookkeeping below is not, and must happen either way.
    try { (touchSurfaceRef.current ?? container).setPointerCapture(e.pointerId); } catch { /* pointer already gone */ }
    activeTouchesRef.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    pdfStore.switchTo(pdfFileName);

    if (activeTouchesRef.current.size === 1 && (e.pointerType === 'mouse' ? e.button === 0 : true)) {
      cancelAnimationFrame(inertiaRafRef.current);
      velocityRef.current = { x: 0, y: 0 };
      lastDragTimeRef.current = performance.now();
      isDraggingRef.current = true;
      wasDragRef.current = false;
      dragStartRef.current = { x: e.clientX, y: e.clientY };
      lastMouseRef.current = { x: e.clientX, y: e.clientY };
    }

    if (activeTouchesRef.current.size >= 2) {
      // A pinch begins, or its pair changed. Either way the single-finger drag
      // is over and the baseline is stale. A complete pointer pair also takes
      // the gesture back from WebKit's own stream: it knows both finger
      // positions, so it can anchor on the real midpoint.
      gestureOwnerRef.current = 'pointer';
      isDraggingRef.current = false;
      wasDragRef.current = false;
      seedPinch();
    }
  }, [pdfFileName, seedPinch]);

  const handlePointerMove = useCallback((e: React.PointerEvent) => {
    const prev = activeTouchesRef.current.get(e.pointerId);
    if (!prev) return;
    // Keep the position current either way — releaseGesture hands the drag
    // back from wherever the finger actually is.
    activeTouchesRef.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    // WebKit's gesture recogniser owns this one. Neither branch below may run:
    // with one finger registered and the other claimed by the engine, the drag
    // branch would pan along that finger while the gesture path zoomed.
    if (gestureOwnerRef.current === 'gesture') return;

    // Pinch zoom. `>= 2` deliberately: with `=== 2`, resting a third finger on
    // the screen — easy to do while holding a tablet — matched neither branch
    // and the page stopped responding until every finger was lifted.
    if (activeTouchesRef.current.size >= 2) {
      const pts = [...activeTouchesRef.current.values()];
      const dx = pts[1].x - pts[0].x;
      const dy = pts[1].y - pts[0].y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (pinchStartDistRef.current > 0) {
        const rawScale = dist / pinchStartDistRef.current;
        const scale = 1 + (rawScale - 1) * TOUCH_PINCH_FACTOR;
        const oldZoom = zoomRef.current;
        const minZoom = renderSettingsStore.settings.pdfEnableBoundaries ? 1 : 0.5;
        const newZoom = Math.max(minZoom, Math.min(pinchStartZoomRef.current * scale, 10));
        const ratio = newZoom / oldZoom;

        // Track the midpoint and carry its own travel into the pan — the same
        // two steps BoardRenderer.installTouchPinch does. The midpoint used to
        // be frozen at the second pointerdown, which holds only while the two
        // fingers' movements cancel exactly: mid = (f1 + f2) / 2 is constant
        // iff Δf1 = -Δf2. Moving both fingers at once is ordinary; moving them
        // at matched speed and distance about a stationary centre is a knife
        // edge, and anything off it — one finger faster than the other, the
        // whole hand drifting, one finger resting — moves the midpoint by half
        // the difference. Measured on the extreme of that (one finger parked):
        // the page point under the stationary finger slid 140 px away from it.
        const container = containerRef.current;
        const rect = container ? container.getBoundingClientRect() : null;
        const mid = rect
          ? { x: (pts[0].x + pts[1].x) / 2 - rect.left, y: (pts[0].y + pts[1].y) / 2 - rect.top }
          : pinchMidRef.current;
        const last = pinchMidRef.current;

        // The scale is anchored on the PREVIOUS midpoint and the new one's
        // travel is then added as a plain translation. Anchoring on the new
        // midpoint instead looks equivalent and is not: it double-counts the
        // travel by a factor of (1 - ratio), which compounds over a gesture's
        // worth of events. Both fingers stay over the content they started on
        // exactly when pan₁ = mid₀ - ratio·(mid₀ - pan₀) + (mid₁ - mid₀),
        // which is what this is.
        panRef.current = {
          x: last.x - ratio * (last.x - panRef.current.x) + (mid.x - last.x),
          y: last.y - ratio * (last.y - panRef.current.y) + (mid.y - last.y),
        };
        pinchMidRef.current = mid;
        zoomRef.current = newZoom;
        syncTransform();
        // Skip expensive PDF re-render during active pinch — CSS transform is enough.
        // The crisp render fires on pinch end (handlePointerUp).
      }
      return;
    }

    // Single-finger drag
    if (!isDraggingRef.current) return;
    const dxm = e.clientX - lastMouseRef.current.x;
    const dym = e.clientY - lastMouseRef.current.y;
    lastMouseRef.current = { x: e.clientX, y: e.clientY };

    if (!wasDragRef.current) {
      const totalDx = e.clientX - dragStartRef.current.x;
      const totalDy = e.clientY - dragStartRef.current.y;
      if (Math.abs(totalDx) < DRAG_THRESHOLD && Math.abs(totalDy) < DRAG_THRESHOLD) return;
      wasDragRef.current = true;
    }

    // Track velocity for inertia
    const now = performance.now();
    const dt = now - lastDragTimeRef.current;
    if (dt > 0) {
      const decay = 0.6; // blend with previous velocity for smoothing
      velocityRef.current = {
        x: decay * velocityRef.current.x + (1 - decay) * (dxm / dt * 16),
        y: decay * velocityRef.current.y + (1 - decay) * (dym / dt * 16),
      };
    }
    lastDragTimeRef.current = now;

    // Panning with a finger crosses page boundaries exactly the way scrolling
    // does; without this it ran off the bottom of the current page into blank
    // paper and never came back.
    panRef.current = {
      x: panRef.current.x + dxm,
      y: flipPagesForPan(panRef.current.y + dym),
    };
    syncTransform();
  }, [syncTransform, flipPagesForPan]);

  /** Find the word + its page-space rect under a click. Shared by single & double click. */
  const hitTestWord = useCallback((e: React.MouseEvent): { word: string; rect: { x: number; y: number; w: number; h: number }; pageIndex: number; itemIndex: number } | null => {
    if (!isLoaded) return null;
    const container = containerRef.current;
    if (!container) return null;

    const containerRect = container.getBoundingClientRect();
    let clickX = (e.clientX - containerRect.left - panRef.current.x) / zoomRef.current;
    const clickY = (e.clientY - containerRect.top - panRef.current.y) / zoomRef.current;
    // Mirrored: the wrapper is flipped via CSS but text-item rects are in
    // un-mirrored page space, so flip the click X back to match (page width in
    // this space equals the container width at zoom 1 / fit-width).
    if (mirrorRef.current) clickX = container.clientWidth - clickX;

    const scale = scaleRef.current;
    const vpT = viewportTransformRef.current;
    const pageIndex = currentPage - 1;
    const items = pdfStore.getDocTextItemsForPage(pdfFileName, pageIndex);

    // Collect all matching items at the click point, pick the smallest font.
    // Watermark filter: skip text items matching any configured watermark term.
    const wmFilter = getActiveWatermarkFilter(renderSettingsStore.globalSettings);
    let bestHit: { word: string; rect: { x: number; y: number; w: number; h: number }; fontSize: number; itemIndex: number } | null = null;

    for (let ii = 0; ii < items.length; ii++) {
      const item = items[ii];
      if (isPdfWatermarkText(item.str, wmFilter)) continue;
      const r = textItemRect(item.transform, item.width, vpT, scale);
      if (clickX >= r.x && clickX <= r.x + r.w && clickY >= r.y && clickY <= r.y + r.h) {
        const charWidth = r.w / item.str.length;
        const charIndex = Math.floor((clickX - r.x) / charWidth);
        const word = extractWord(item.str, charIndex);
        if (word) {
          const fontSize = Math.sqrt(item.transform[2] ** 2 + item.transform[3] ** 2);
          if (!bestHit || fontSize < bestHit.fontSize) {
            const wordStart = item.str.toUpperCase().indexOf(word.toUpperCase(), Math.max(0, charIndex - word.length));
            const wx = r.x + (wordStart >= 0 ? wordStart * charWidth : 0);
            const ww = word.length * charWidth;
            const fontH = fontSize * LINE_HEIGHT_RATIO * scale;
            const h = Math.min(r.h, fontH);
            const y = r.y + (r.h - h) / 2;
            bestHit = { word, rect: { x: wx, y, w: ww, h }, fontSize, itemIndex: ii };
          }
        }
      }
    }
    return bestHit ? { word: bestHit.word, rect: bestHit.rect, pageIndex, itemIndex: bestHit.itemIndex } : null;
  }, [pdfFileName, isLoaded, currentPage]);

  const handleTextClick = useCallback((e: React.MouseEvent) => {
    const hit = hitTestWord(e);
    if (!hit) { hideClickHighlight(); return; }

    // Remember last clicked word + location for Cmd+F prefill / exact-match pick
    pdfStore.setLastClickedWord(hit.word);
    pdfStore.setLastClickedLocation({ fileName: pdfFileName, pageIndex: hit.pageIndex, itemIndex: hit.itemIndex });

    // Show highlight + tooltip overlay on any text (imperative — no re-render)
    showClickHighlight(hit.rect, hit.word, zoomRef.current);

    // Focus part/net on board AND mirror the term into the board search panel
    // (board → PDF lookup is symmetric; this closes the reverse direction).
    const board = boardStore.board;
    if (board) {
      const upper = hit.word.toUpperCase();
      const isPart = board.parts.some(p => p.name.toUpperCase() === upper);
      const isNet = !isPart && [...board.nets.keys()].some(n => n.toUpperCase() === upper);
      const nav = { cause: 'lookup' as const, from: `${pdfFileName} · p.${hit.pageIndex + 1}` };
      if (isPart) boardStore.focusPart(hit.word, nav);
      else if (isNet) boardStore.focusNet(hit.word, nav);
      if (isPart || isNet) openBoardSearch(hit.word, undefined, { activate: false });
    }

    // PDF↔PDF cross-lookup: if this PDF is linked to another, drive the
    // linked doc's search for the clicked token (crossProbe resolves whether
    // the partner is open and hints if not).
    if (pdfStore.getLinkedDoc(pdfFileName)) {
      pdfStore.crossProbe(pdfFileName, hit.word);
    }
  }, [hitTestWord, pdfFileName, showClickHighlight, hideClickHighlight]);

  const handleTextDblClick = useCallback((e: React.MouseEvent) => {
    const hit = hitTestWord(e);
    if (!hit) return;

    // Double-click always overrides search
    if (searchInputRef.current) {
      searchInputRef.current.value = hit.word;
      pdfStore.switchTo(pdfFileName);
      // Set location so searchText picks the exact clicked occurrence
      pdfStore.setLastClickedLocation({ fileName: pdfFileName, pageIndex: hit.pageIndex, itemIndex: hit.itemIndex });
      pdfStore.searchText(hit.word);
      navHintShownRef.current = false;
    }
    hideClickHighlight();

    const board = boardStore.board;
    if (board) {
      const upper = hit.word.toUpperCase();
      const nav = { cause: 'lookup' as const, from: `${pdfFileName} · p.${hit.pageIndex + 1}` };
      if (board.parts.some(p => p.name.toUpperCase() === upper)) {
        r2LadoPeca(hit.word); // 2R 26/10/2026: peça no lado escondido → vira a placa para o lado dela
        boardStore.focusPart(hit.word, nav);
      } else {
        boardStore.focusNet(hit.word, nav);
      }
      openBoardSearch(hit.word, undefined, { activate: false });
    }
  }, [hitTestWord, pdfFileName, hideClickHighlight]);

  const handleTextClickRef = useRef(handleTextClick);
  handleTextClickRef.current = handleTextClick;

  const handlePointerUp = useCallback((e: React.PointerEvent) => {
    const wasPinching = activeTouchesRef.current.size >= 2;
    activeTouchesRef.current.delete(e.pointerId);
    // Lifting one of three fingers leaves a pinch running on a different pair.
    seedPinch();
    // The pointer claim lasts exactly as long as the fingers do. A gesture
    // claim is WebKit's to end (gestureend, or the lapse timer).
    if (gestureOwnerRef.current === 'pointer' && activeTouchesRef.current.size === 0) {
      gestureOwnerRef.current = 'none';
    }
    // A finger that is still down after a pinch should go on scrolling rather
    // than wait to be lifted and re-placed.
    if (wasPinching && activeTouchesRef.current.size === 1
        && gestureOwnerRef.current !== 'gesture') {
      const rest = [...activeTouchesRef.current.values()][0];
      isDraggingRef.current = true;
      wasDragRef.current = false;
      velocityRef.current = { x: 0, y: 0 };
      lastDragTimeRef.current = performance.now();
      dragStartRef.current = { x: rest.x, y: rest.y };
      lastMouseRef.current = { x: rest.x, y: rest.y };
    }

    // Pinch ended — schedule crisp re-render at final zoom level
    if (wasPinching && activeTouchesRef.current.size < 2) {
      scheduleTierRender();
    }

    const wasDrag = wasDragRef.current;
    isDraggingRef.current = false;
    wasDragRef.current = false;

    // Inertia: continue panning with decaying velocity.
    //
    // The velocity lives in a LOCAL, not in `velocityRef`. It used to read the
    // ref inside the loop while `velocityRef.current = {x:0,y:0}` ran below —
    // synchronously, before the first `requestAnimationFrame` callback could
    // fire. So every run decayed zero, failed the < 0.2 test on its first
    // frame and returned: inertia never moved the page once, on any platform.
    // Nobody notices with a mouse, where releasing a drag is *meant* to stop
    // dead; on a touch screen a flick that goes nowhere is most of what
    // "scrolling is broken" means.
    const v = velocityRef.current;
    velocityRef.current = { x: 0, y: 0 };
    if (wasDrag && pdfInertiaRef.current && Math.hypot(v.x, v.y) > 0.5) {
      cancelAnimationFrame(inertiaRafRef.current);
      const friction = 0.93;
      let vx = v.x, vy = v.y;
      const animate = () => {
        vx *= friction;
        vy *= friction;
        if (Math.abs(vx) < 0.2 && Math.abs(vy) < 0.2) return;
        // A fling is a scroll and turns pages like one. Without this the drag
        // flips correctly and its own deceleration then glides straight past
        // the next boundary onto blank paper.
        panRef.current = {
          x: panRef.current.x + vx,
          y: flipPagesForPan(panRef.current.y + vy),
        };
        syncTransform();
        inertiaRafRef.current = requestAnimationFrame(animate);
      };
      inertiaRafRef.current = requestAnimationFrame(animate);
    }

    // A tap looks up the word under it — on a finger too. Touch was excluded
    // because a tap used to arrive at the end of gestures that were not taps;
    // `wasDrag` and the single-pointer test are what make it safe, and without
    // it the PDF's one real interaction is unreachable on a tablet.
    const wasTap = !wasDrag && !wasPinching && activeTouchesRef.current.size === 0;
    if (wasTap && (e.pointerType === 'touch' || e.button === 0)) {
      handleTextClickRef.current(e);
    }
  }, [scheduleTierRender, syncTransform, seedPinch, flipPagesForPan]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // No-op: Enter is handled by the input's onKeyDown so we can read
    // shiftKey to decide between next/prev and a fresh search.
  };

  // Show ↑↓ navigation hint once when matches first appear
  if (matches.length > 0 && !navHintShownRef.current) {
    navHintShownRef.current = true;
    if (!showNavHint) setShowNavHint(true);
    if (navHintTimerRef.current) clearTimeout(navHintTimerRef.current);
    navHintTimerRef.current = setTimeout(() => setShowNavHint(false), 5000);
  }

  const handleContextMenu = useCallback((e: React.MouseEvent) => {
    e.preventDefault();

    const container = containerRef.current;
    if (!container) return;
    const rect = container.getBoundingClientRect();
    const zoom = zoomRef.current;
    const pan = panRef.current;
    // Screen → CSS-space on the wrapper (page is sized cssW × cssH in CSS units)
    const cssX = (e.clientX - rect.left - pan.x) / zoom;
    const cssY = (e.clientY - rect.top - pan.y) / zoom;

    const baseScale = scaleRef.current;
    const vpT = viewportTransformRef.current;
    if (baseScale <= 0 || !vpT) {
      contextMenuStore.showPdf(e.clientX, e.clientY, '', pdfFileName);
      return;
    }

    const curPage = pdfStore.getDocCurrentPage(pdfFileName);
    const pageIdx = curPage - 1;
    const items = pdfStore.getDocTextItemsForPage(pdfFileName, pageIdx);

    // Walk items, pick the smallest bbox containing (cssX, cssY)
    let bestStr = '';
    let bestArea = Infinity;
    let R2S: { x: number; y: number; w: number; h: number } | null = null, R2T = '';
    for (const item of items) {
      const r = textItemRect(item.transform, item.width, vpT, baseScale);
      if (cssX >= r.x && cssX <= r.x + r.w && cssY >= r.y && cssY <= r.y + r.h) {
        const area = r.w * r.h;
        if (area < bestArea) {
          bestArea = area;
          bestStr = item.str.trim();
          R2S = r; R2T = item.str;
        }
      }
    }
    // 2R 20/10/2026 (Roger): botão direito / Control+clique numa linha, net ou endereço do PDF = procura no PDF
    if (bestStr && R2S) {
      const L = R2T.length || 1, P0 = Math.max(0, Math.min(L - 1, Math.floor(((cssX - R2S.x) / (R2S.w || 1)) * L)));
      let W = '', M: RegExpExecArray | null;
      const RX = /[A-Za-z0-9_][A-Za-z0-9_\-+./]*/g;
      while ((M = RX.exec(R2T))) {
        if (P0 >= M.index - 1 && P0 <= M.index + M[0].length) { W = M[0].replace(/[./-]+$/, ''); break; }
      }
      W = (W || bestStr).toUpperCase();
      try { if (searchInputRef.current) searchInputRef.current.value = W; } catch { /* */ }
      pdfStore.switchTo(pdfFileName);
      pdfStore.searchText(W);
      try { mirrorToBoard(W); } catch { /* */ }
      return;
    }

    contextMenuStore.showPdf(e.clientX, e.clientY, bestStr, pdfFileName);
  }, [pdfFileName]);

  // DEV-only test hook: expose helpers so Playwright can exercise the
  // hit-test without reconstructing the transform math.
  useEffect(() => {
    if (!import.meta.env.DEV) return;
    const target = window as unknown as {
      __pdfPanelTestHooks?: Record<string, unknown>;
    };
    target.__pdfPanelTestHooks = {
      ...(target.__pdfPanelTestHooks || {}),
      [pdfFileName]: {
        // Direct ref access — used by keyboard-shortcuts-game.spec.ts to read
        // pan/zoom state after dispatching pdf-pan / pdf-zoom events.
        getPan: () => ({ ...panRef.current }),
        getZoom: () => zoomRef.current,
        firstItemScreenCenter: () => {
          const container = containerRef.current;
          if (!container) return null;
          const rect = container.getBoundingClientRect();
          const zoom = zoomRef.current;
          const pan = panRef.current;
          const baseScale = scaleRef.current;
          const vpT = viewportTransformRef.current;
          if (baseScale <= 0 || !vpT) return null;
          const curPage = pdfStore.getDocCurrentPage(pdfFileName);
          const items = pdfStore.getDocTextItemsForPage(pdfFileName, curPage - 1);
          for (const item of items) {
            if (!item.str.trim()) continue;
            const r = textItemRect(item.transform, item.width, vpT, baseScale);
            const cx = rect.left + pan.x + (r.x + r.w / 2) * zoom;
            const cy = rect.top + pan.y + (r.y + r.h / 2) * zoom;
            return { clientX: cx, clientY: cy, str: item.str };
          }
          return null;
        },
      },
    };
    return () => {
      const hooks = target.__pdfPanelTestHooks as Record<string, unknown> | undefined;
      if (hooks) delete hooks[pdfFileName];
    };
  }, [pdfFileName]);

  /** Reset zoom to 1 and pan to origin — page fits container width exactly */
  const handleFitWidth = useCallback(() => {
    zoomRef.current = 1;
    panRef.current = { x: 0, y: 0 };
    syncTransform();
    scheduleTierRender();
  }, [syncTransform, scheduleTierRender]);

  // Listen for global Space key → fit-to-width dispatch, and keyboard pan/zoom events
  useEffect(() => {
    const handler = () => handleFitWidth();
    // pdf-fit-width intentionally omits the props.api.isActive gate: the
    // shortcut dispatch site already restricts firing to the PDF panel under
    // the cursor, so gating here would double-filter and miss legitimate cases.
    window.addEventListener('pdf-fit-width', handler);

    const panHandler = (ev: Event) => {
      // Active-panel gate: only the dockview-active PDF panel acts.
      if (!props.api.isActive) return;

      const detail = (ev as CustomEvent<{ direction: 'left' | 'right' | 'up' | 'down' }>).detail;
      const containerEl = containerRef.current;
      if (!containerEl || !wrapperRef.current) return;
      const cw = containerEl.clientWidth;
      const ch = containerEl.clientHeight;
      const { keyboardPanFraction } = renderSettingsStore.settings;
      const stepX = cw * keyboardPanFraction;
      const stepY = ch * keyboardPanFraction;
      let dx = 0, dy = 0;
      if (detail.direction === 'left')  dx = +stepX;
      if (detail.direction === 'right') dx = -stepX;
      if (detail.direction === 'up')    dy = +stepY;
      if (detail.direction === 'down')  dy = -stepY;
      // Keyboard panning is the same continuous scroll as the wheel and the
      // finger, so it crosses page boundaries the same way.
      panRef.current = { x: panRef.current.x + dx, y: flipPagesForPan(panRef.current.y + dy) };
      syncTransform();
    };
    window.addEventListener('pdf-pan', panHandler as EventListener);

    const zoomHandler = (ev: Event) => {
      // Active-panel gate: only the dockview-active PDF panel acts.
      if (!props.api.isActive) return;

      const detail = (ev as CustomEvent<{ direction: 'in' | 'out' }>).detail;
      const containerEl = containerRef.current;
      if (!containerEl || !wrapperRef.current) return;
      const rawDelta = renderSettingsStore.settings.keyboardZoomDelta;
      const factor = Math.pow(2, 1.3 * (rawDelta / 500));
      const effFactor = detail.direction === 'in' ? factor : 1 / factor;
      const mid = { x: containerEl.clientWidth / 2, y: containerEl.clientHeight / 2 };
      const minZoom = renderSettingsStore.settings.pdfEnableBoundaries ? 1 : 0.5;
      const oldZ = zoomRef.current;
      const newZ = Math.max(minZoom, Math.min(oldZ * effFactor, 10));
      const ratio = newZ / oldZ;
      // Pan correction: anchor the zoom on the container centre so the visible
      // mid-point stays put when the scale changes. Same formula as wheel-zoom.
      panRef.current = {
        x: mid.x - ratio * (mid.x - panRef.current.x),
        y: mid.y - ratio * (mid.y - panRef.current.y),
      };
      zoomRef.current = newZ;
      syncTransform();
      scheduleTierRender();
    };
    window.addEventListener('pdf-zoom', zoomHandler as EventListener);

    // 2R: zoom do esquemático acompanha o zoom da placa (proporcional, no centro)
    const bvZoomHandler = (ev: Event) => {
      if (!props.api.isVisible) return;
      const ratio = (ev as CustomEvent<{ ratio: number }>).detail?.ratio;
      const containerEl = containerRef.current;
      if (!ratio || !isFinite(ratio) || !containerEl || !wrapperRef.current) return;
      const mid = { x: containerEl.clientWidth / 2, y: containerEl.clientHeight / 2 };
      const minZoom = renderSettingsStore.settings.pdfEnableBoundaries ? 1 : 0.5;
      const oldZ = zoomRef.current;
      const newZ = Math.max(minZoom, Math.min(oldZ * ratio, 10));
      const r = newZ / oldZ;
      if (Math.abs(r - 1) < 1e-4) return;
      panRef.current = { x: mid.x - r * (mid.x - panRef.current.x), y: mid.y - r * (mid.y - panRef.current.y) };
      zoomRef.current = newZ;
      syncTransform();
      scheduleTierRender();
    };
    window.addEventListener('2r-bv-zoom', bvZoomHandler as EventListener);

    return () => {
      window.removeEventListener('pdf-fit-width', handler);
      window.removeEventListener('pdf-pan', panHandler as EventListener);
      window.removeEventListener('pdf-zoom', zoomHandler as EventListener);
      window.removeEventListener('2r-bv-zoom', bvZoomHandler as EventListener);
    };
  }, [handleFitWidth, props.api, syncTransform, scheduleTierRender, flipPagesForPan]);

  const handleAddBookmark = useCallback(() => {
    pdfStore.switchTo(pdfFileName);
    pdfStore.addBookmark(currentPage, zoomRef.current, panRef.current.x, panRef.current.y);
  }, [pdfFileName, currentPage]);

  /** Put the view at an exact pose — bookmarks and the navigation history share it. */
  const applyPose = useCallback((page: number, zoom: number, panX: number, panY: number) => {
    pdfStore.switchTo(pdfFileName);
    stopGlide();
    zoomRef.current = zoom;
    panRef.current = { x: panX, y: panY };
    const samePage = page === pdfStore.getDocCurrentPage(pdfFileName);
    if (!samePage) {
      // Defer zoom/pan restore — goToPage triggers re-render + renderPage via useEffect.
      // skipResetRef prevents the page-change effect from resetting zoom/pan to defaults.
      skipResetRef.current = true;
      pdfStore.goToPage(page);
    }
    syncTransform();
    // Only render immediately when staying on the same page. When changing pages,
    // the useEffect([renderPage]) fires after re-render with the correct currentPage.
    if (samePage) renderPageRef.current();
  }, [pdfFileName, syncTransform]);
  const applyPoseRef = useRef(applyPose);
  applyPoseRef.current = applyPose;

  // Navigation-history camera provider for this document (registered per
  // file name; the store hands a pose to a panel that mounts later).
  useEffect(() => {
    const provider: PdfCameraProvider = {
      get: () => ({ page: pdfStore.getDocCurrentPage(pdfFileName), zoom: zoomRef.current, panX: panRef.current.x, panY: panRef.current.y }),
      set: (cam) => applyPoseRef.current(cam.page, cam.zoom, cam.panX, cam.panY),
    };
    navHistoryStore.registerPdfCamera(pdfFileName, provider);
    return () => navHistoryStore.unregisterPdfCamera(pdfFileName, provider);
  }, [pdfFileName]);

  const handleBookmarkClick = useCallback((id: string) => {
    if (bookmarkClickTimerRef.current) {
      clearTimeout(bookmarkClickTimerRef.current);
      bookmarkClickTimerRef.current = null;
    }
    bookmarkClickTimerRef.current = setTimeout(() => {
      bookmarkClickTimerRef.current = null;
      const bm = pdfStore.getDocBookmarks(pdfFileName).find(b => b.id === id);
      if (!bm) return;
      applyPose(bm.page, bm.zoom, bm.panX, bm.panY);
    }, 250);
  }, [pdfFileName, applyPose]);

  const handleBookmarkDblClick = useCallback((id: string) => {
    if (bookmarkClickTimerRef.current) {
      clearTimeout(bookmarkClickTimerRef.current);
      bookmarkClickTimerRef.current = null;
    }
    pdfStore.switchTo(pdfFileName);
    pdfStore.updateBookmark(id, currentPage, zoomRef.current, panRef.current.x, panRef.current.y);
  }, [pdfFileName, currentPage]);

  const handleBookmarkRightClick = useCallback((e: React.MouseEvent, id: string) => {
    e.preventDefault();
    pdfStore.switchTo(pdfFileName);
    pdfStore.removeBookmark(id);
  }, [pdfFileName]);

  const handleBookmarkMiddleClick = useCallback((e: React.MouseEvent, id: string) => {
    if (e.button === 1 || (e.button === 0 && e.altKey)) {
      e.preventDefault();
      e.stopPropagation();
      pdfStore.switchTo(pdfFileName);
      const bm = pdfStore.bookmarks.find(b => b.id === id);
      if (bm) {
        setEditingBookmarkId(id);
        setEditingLabel(bm.label);
      }
    }
  }, [pdfFileName]);

  const handleLabelEditSubmit = useCallback((id: string) => {
    pdfStore.switchTo(pdfFileName);
    pdfStore.renameBookmark(id, editingLabel.trim());
    setEditingBookmarkId(null);
    setEditingLabel('');
  }, [pdfFileName, editingLabel]);

  const handleLabelEditKeyDown = useCallback((e: React.KeyboardEvent, id: string) => {
    if (e.key === 'Enter') {
      handleLabelEditSubmit(id);
    } else if (e.key === 'Escape') {
      setEditingBookmarkId(null);
      setEditingLabel('');
    }
  }, [handleLabelEditSubmit]);

  if (!isLoaded) {
    // The panel is created before the load, so this is what an open looks
    // like until the document is parsed: the file, the phase, or the failure.
    if (load?.phase === 'failed') {
      return (
        <div className="pdf-viewer pdf-empty" data-testid="pdf-load-state" data-phase="failed">
          <div className="pdf-load-state">
            <span className="pdf-load-title">Could not open <span translate="no">{pdfFileName}</span></span>
            {load.error && <span className="pdf-load-detail">{load.error}</span>}
          </div>
        </div>
      );
    }
    return (
      <div className="pdf-viewer pdf-empty" data-testid="pdf-load-state" data-phase={load?.phase ?? 'waiting'}>
        {pdfFileName ? (
          <div className="pdf-load-state">
            <span className="pdf-load-spinner" aria-hidden="true" />
            <span className="pdf-load-title" translate="no">{pdfFileName}</span>
            <span className="pdf-load-detail">{`${PDF_LOAD_PHASE_TEXT[load?.phase ?? 'reading']}…`}</span>
          </div>
        ) : <span>No PDF loaded.</span>}
      </div>
    );
  }

  if (error) {
    return (
      <div className="pdf-viewer pdf-empty">
        <span style={{ color: '#ff6666' }}>PDF error: {error}</span>
      </div>
    );
  }

  return (
    <div className="pdf-viewer" ref={viewerRootRef}>
      {placeToolbar(
      <div className="pdf-toolbar">
        {/* Board/PDF linking moved to the dockview tab (∞ on the PDF tab) —
            symmetric with the board tab. See components/PdfTab.tsx. */}
        <div className="pdf-toolbar-group">
          <button
            className="pdf-toolbar-btn"
            onClick={() => { pdfStore.switchTo(pdfFileName); pdfStore.goToPage(currentPage - 1); }}
            disabled={currentPage <= 1}
          >
            ◀
          </button>
          <input
            className="pdf-page-input"
            type="text"
            value={pageDraft ?? String(currentPage)}
            onChange={e => setPageDraft(e.target.value)}
            onKeyDown={e => {
              if (e.key === 'Enter') {
                (e.target as HTMLInputElement).blur();
              } else if (e.key === 'Escape') {
                pageDraftCancelRef.current = true;
                (e.target as HTMLInputElement).blur();
              }
            }}
            onFocus={e => e.target.select()}
            onBlur={e => {
              const cancelled = pageDraftCancelRef.current;
              pageDraftCancelRef.current = false;
              const raw = e.currentTarget.value;
              setPageDraft(null);
              if (cancelled) return;
              const n = parseInt(raw, 10);
              if (!isNaN(n)) {
                pdfStore.switchTo(pdfFileName);
                pdfStore.goToPage(Math.max(1, Math.min(n, pageCount)));
              }
            }}
          />
          <span className="pdf-page-info">/ {pageCount}</span>
          <button
            className="pdf-toolbar-btn"
            onClick={() => { pdfStore.switchTo(pdfFileName); pdfStore.goToPage(currentPage + 1); }}
            disabled={currentPage >= pageCount}
          >
            ▶
          </button>
        </div>

        {/* Orientation / layout controls — kept directly right of page switching. */}
        <div className="pdf-toolbar-group">
          {/* 2R 27/10/2026: botão de girar o PDF removido (Roger: «não faz sentido») */}
          <button
            data-testid="pdf-mirror"
            className={`pdf-toolbar-btn${mirror ? ' active' : ''}`}
            onClick={() => { pdfStore.switchTo(pdfFileName); pdfStore.toggleMirror(pdfFileName); }}
            title={mirror
              ? 'Mirrored horizontally — click to un-mirror (⌘↑)'
              : 'Mirror horizontally — flip left↔right (⌘↑)'}
          >
            <IconSwitchHorizontal size={14} />
          </button>
          {pageCount > 1 && (
            <button
              data-testid="pdf-page-mode"
              className={`pdf-toolbar-btn${singlePageMode ? ' active' : ''}`}
              onClick={() => { if (rotation !== 0) return; pdfStore.switchTo(pdfFileName); pdfStore.togglePageMode(pdfFileName); }}
              disabled={rotation !== 0}
              title={rotation !== 0
                ? 'Rotated pages are always shown one at a time'
                : (pageMode === 'single'
                    ? 'Single page — click for continuous scroll'
                    : 'Continuous scroll — click for single page')}
            >
              {singlePageMode ? <IconFile size={14} /> : <IconFileStack size={14} />}
            </button>
          )}
        </div>

        {/* 2R 23/10/2026 (Roger): botões de zoom no PDF — mesmo zoom da pinça, no centro da página */}
        <div className="pdf-toolbar-group">
          <button data-testid="pdf-zoom-out" className="pdf-toolbar-btn" title="Afastar (zoom −)"
            onClick={() => { const el = containerRef.current; if (!el) return; pdfStore.switchTo(pdfFileName); const r = el.getBoundingClientRect();
              el.dispatchEvent(new WheelEvent('wheel', { deltaY: 25, ctrlKey: true, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2, bubbles: true, cancelable: true })); }}>
            <IconZoomOut size={14} />
          </button>
          <button data-testid="pdf-zoom-in" className="pdf-toolbar-btn" title="Aproximar (zoom +)"
            onClick={() => { const el = containerRef.current; if (!el) return; pdfStore.switchTo(pdfFileName); const r = el.getBoundingClientRect();
              el.dispatchEvent(new WheelEvent('wheel', { deltaY: -25, ctrlKey: true, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2, bubbles: true, cancelable: true })); }}>
            <IconZoomIn size={14} />
          </button>
        </div>

        <div className="pdf-toolbar-group">
          <button
            className="pdf-toolbar-btn pdf-bookmark-add"
            onClick={handleAddBookmark}
            title="Bookmark current view"
          >
            <IconBookmarkPlus size={14} />
          </button>
          {bookmarks.map(bm => (
            editingBookmarkId === bm.id ? (
              <input
                key={bm.id}
                className="pdf-bookmark-edit"
                value={editingLabel}
                onChange={e => setEditingLabel(e.target.value)}
                onKeyDown={e => handleLabelEditKeyDown(e, bm.id)}
                onBlur={() => handleLabelEditSubmit(bm.id)}
                autoFocus
              />
            ) : (
              <button
                key={bm.id}
                className={`pdf-toolbar-btn pdf-bookmark-pill${bm.page === currentPage ? ' active' : ''}`}
                onClick={e => { if (!e.altKey) handleBookmarkClick(bm.id); }}
                onDoubleClick={() => handleBookmarkDblClick(bm.id)}
                onContextMenu={e => handleBookmarkRightClick(e, bm.id)}
                onMouseDown={e => handleBookmarkMiddleClick(e, bm.id)}
                title={`Page ${bm.page} @ ${Math.round(bm.zoom * 100)}%\nClick: go | Dbl-click: update | Right-click: delete | Opt/Middle-click: rename`}
              >
                {bm.label}
              </button>
            )
          ))}
        </div>

        <div className="pdf-toolbar-spacer" />

        <div className="pdf-toolbar-group">
          <PdfFilterMenu fileName={pdfFileName} />
          <PdfNightMenu />
        </div>
        <div className="pdf-viewport-group">
          <button
            className="pdf-toolbar-btn"
            onClick={invertScrollBindings}
            title={scrollSwapTooltip()}
          >
            {bareAction === 'pan' ? <IconHandMove size={14} /> : <IconZoomIn size={14} />}
          </button>
          <button
            className="pdf-toolbar-btn pdf-zoom-group"
            onClick={handleFitWidth}
            title="Fit to page width (Space)"
          >
            <IconArrowAutofitWidth size={14} />
            <span className="pdf-zoom-info" ref={zoomInfoRef} translate="no">{`${Math.round(zoomRef.current * 100)}%`}</span>
          </button>
        </div>
      </div>
      )}

      {/* 2R 27/10/2026 (Roger: «o search do PDF está encavalado, manter o mesmo padrão e localização do BDV»): a busca
          do PDF sai da barra e fica solta no canto de cima à esquerda do PDF, igual à da placa */}
      <div className="pdf-search-wrapper r2pb">
        <div className="pdf-search-bar">
          <form className="pdf-search-form" onSubmit={handleSearch}>
            <input
              ref={searchInputRef}
              type="text"
              className="pdf-search-input"
              data-pdf-file={pdfFileName}
              placeholder={IS_2R ? (searchSyncOn() ? 'Buscar no PDF (e junto na placa)…' : 'Buscar no PDF (vários termos: 10UF 25V)') : 'Search (multi-term: 10UF 25V)'}
              title="Enter / ↓ / Cmd+F — next match. Shift+Enter / ↑ / Shift+Cmd+F — previous match."
              defaultValue={searchQuery}
              // On focus the whole list shows whatever the field holds (Preview's
              // magnifier menu); typing then filters it.
              onFocus={() => { setRecentFilter(''); setRecentHi(-1); setRecentsOpen(true); }}
              onBlur={() => { setRecentsOpen(false); setRecentHi(-1); }}
              onChange={(e) => {
                setRecentFilter(e.target.value);
                setRecentHi(-1);
                setRecentsOpen(true);
                if (!e.target.value.trim()) {
                  pdfStore.switchTo(pdfFileName);
                  pdfStore.searchText('');
                }
              }}
              onKeyDown={(e) => {
                if (recentsOpen && pdfRecents.length > 0) {
                  if (e.key === 'ArrowDown') { e.preventDefault(); setRecentHi(h => (h + 1) % pdfRecents.length); return; }
                  if (e.key === 'ArrowUp') { e.preventDefault(); setRecentHi(h => (h <= 0 ? pdfRecents.length - 1 : h - 1)); return; }
                  if (e.key === 'Escape') { e.preventDefault(); setRecentsOpen(false); setRecentHi(-1); return; }
                  if (e.key === 'Enter' && recentHi >= 0) { e.preventDefault(); pickRecent(pdfRecents[recentHi]); return; }
                }
                if (e.key === 'Enter') { setRecentsOpen(false); setRecentHi(-1); }
                // PageUp/PageDown page the PDF even while the search field is
                // focused — after a search the focus stays here, and losing
                // keyboard paging mid-probe is worse than the caret quirk.
                // (Home/End stay untouched: they move the text caret.)
                if (e.key === 'PageDown' || e.key === 'PageUp') {
                  e.preventDefault();
                  pdfStore.switchTo(pdfFileName);
                  pdfStore.goToPage(currentPage + (e.key === 'PageDown' ? 1 : -1));
                  return;
                }
                if (matches.length > 0 && (e.key === 'ArrowDown' || e.key === 'ArrowUp')) {
                  e.preventDefault();
                  pdfStore.switchTo(pdfFileName);
                  if (e.key === 'ArrowDown') pdfStore.nextMatch();
                  else pdfStore.prevMatch();
                  return;
                }
                if (e.key === 'Enter') {
                  e.preventDefault();
                  const value = (e.target as HTMLInputElement).value;
                  pdfStore.switchTo(pdfFileName);
                  // Query unchanged + have matches → step next/prev (Shift = prev).
                  if (value && value === searchQuery && matches.length > 0) {
                    if (e.shiftKey) pdfStore.prevMatch();
                    else pdfStore.nextMatch();
                    return;
                  }
                  pdfStore.searchText(value);
                  mirrorToBoard(value);          // 2R: busca junto na placa
                  navHintShownRef.current = false;
                }
              }}
            />
          </form>
          {matches.length > 0 ? (
            <>
              <button className="pdf-search-nav-btn" onClick={() => { pdfStore.switchTo(pdfFileName); pdfStore.prevMatch(); }} title="Previous match">&#9650;</button>
              <span className="pdf-search-counter">
                {matchGroupCount > 0
                  ? `${activeGroupIndex + 1}/${matchGroupCount}`
                  : `${activeMatchIndex + 1}/${matches.length}`}
              </span>
              <button className="pdf-search-nav-btn" onClick={() => { pdfStore.switchTo(pdfFileName); pdfStore.nextMatch(); }} title="Next match">&#9660;</button>
            </>
          ) : searchQuery && !textExtracting ? (
            // Zero results: say so instead of showing nothing, and offer the
            // escape hatch — full-text search across all library PDFs.
            <>
              <span className="pdf-search-counter">0/0</span>
              <button
                className="pdf-search-nav-btn pdf-search-library-btn"
                title={`No matches here — search all library PDFs for "${searchQuery}"`}
                onClick={() => {
                  databankStore.requestPdfSearch(searchQuery, 'all');
                  showSidebarTab('library');
                }}
              >
                Library&nbsp;⌕
              </button>
            </>
          ) : null}
        </div>
        {recentsOpen && pdfRecents.length > 0 && (
          <div className="pdf-search-recents" data-testid="pdf-search-recents" role="listbox" aria-label="Recent searches">
            {pdfRecents.map((text, i) => (
              <div
                key={text}
                className={`pdf-search-recent${i === recentHi ? ' hi' : ''}`}
                role="option"
                aria-selected={i === recentHi}
                data-testid="pdf-search-recent"
                // pointerdown, not click: the input's blur would close the
                // list before a click could land.
                onPointerDown={(e) => { e.preventDefault(); pickRecent(text); }}
                onPointerEnter={() => setRecentHi(i)}
              >
                <IconHistory size={12} stroke={2} />
                <span>{text}</span>
              </div>
            ))}
          </div>
        )}
        {lookupHint && (
          <div className="pdf-lookup-hint">
            Double-click <b>{lookupHint}</b> to search
          </div>
        )}
        {showNavHint && !recentsOpen && (
          <div className="pdf-nav-hint">Enter / ↑↓ to navigate results</div>
        )}
        {isMultiTerm && (
          <div className="pdf-multiterm-dropdown">
            <div className="pdf-gap-row">
              <label>V</label>
              <input
                type="range" min={0.5} max={20} step={0.5}
                defaultValue={multiTermYGap}
                onPointerUp={e => { pdfStore.switchTo(pdfFileName); pdfStore.setMultiTermYGap(Number((e.target as HTMLInputElement).value)); }}
              />
              <span>{multiTermYGap}x</span>
            </div>
            <div className="pdf-gap-row">
              <label>H</label>
              <input
                type="range" min={0.5} max={20} step={0.5}
                defaultValue={multiTermXGap}
                onPointerUp={e => { pdfStore.switchTo(pdfFileName); pdfStore.setMultiTermXGap(Number((e.target as HTMLInputElement).value)); }}
              />
              <span>{multiTermXGap}x</span>
            </div>
            <span className="pdf-multiterm-hint">
              {matchGroupCount > 0 ? `${matchGroupCount} groups` : 'no matches'}
            </span>
          </div>
        )}
      </div>
      {textExtracting && (
        <div className="pdf-text-extract-bar" title={`Indexing text: ${Math.round(textExtractProgress * 100)}%`}>
          <div className="pdf-text-extract-fill" style={{ width: `${textExtractProgress * 100}%` }} />
        </div>
      )}
      {textExtracting && (
        <div className="pdf-text-extract-chip" data-testid="pdf-text-extract-chip"
             title="Search and lookups find what has been indexed so far">
          {`Indexing text ${Math.round(textExtractProgress * 100)} %`}
        </div>
      )}
      {load?.phase === 'rendering' && (
        <div className="pdf-load-overlay" data-testid="pdf-load-overlay" role="status">
          <span className="pdf-load-spinner" aria-hidden="true" />
          <span>{`${PDF_LOAD_PHASE_TEXT.rendering}…`}</span>
        </div>
      )}

      {nightFx?.svg && (
        // Night mode: contrast curve, then white paper → bg, black ink → fg.
        <svg width="0" height="0" aria-hidden="true" style={{ position: 'absolute' }}>
          <filter id={nightFilterId} colorInterpolationFilters="sRGB">
            <feComponentTransfer>
              <feFuncR type="table" tableValues={nightFx.svg.table} />
              <feFuncG type="table" tableValues={nightFx.svg.table} />
              <feFuncB type="table" tableValues={nightFx.svg.table} />
            </feComponentTransfer>
            <feComponentTransfer>
              {nightFx.svg.map.map((t, i) => {
                const F = (['feFuncR', 'feFuncG', 'feFuncB'] as const)[i];
                return <F key={F} type="linear" slope={t.slope} intercept={t.intercept} />;
              })}
            </feComponentTransfer>
          </filter>
        </svg>
      )}
      <div
        className="pdf-canvas-container"
        ref={containerRef}
        style={{ cursor: isDraggingRef.current ? 'grabbing' : 'default', filter: nightFx?.css }}
      >
      {/* Every touch lands here, and only here. Without this layer the target
          of a touch depended on what happened to be under the finger: page 1
          is the main <canvas>, page 2 is a `pointer-events: none` neighbour
          that falls through to the container itself — an `overflow: hidden`
          scroll container carrying the UI-scale `zoom` — and in tiled mode the
          main canvas is `visibility: hidden` so everything falls through. On
          iPadOS a drag or pinch that started over page 1 worked and one that
          started over page 2 did nothing, and that asymmetry was the only
          difference between them. Chromium treats both targets alike, which is
          why no fixture ever showed it. A plain, persistent, untransformed div
          with `touch-action: none` on the target itself removes the question:
          nothing under the finger is ever added, removed, hidden or moved. */}
      <div
        className="pdf-touch-surface"
        data-testid="pdf-touch-surface"
        ref={touchSurfaceRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={(e) => {
          // iPadOS cancels pointers when its own gesture recogniser claims the
          // touch, and that is invisible from any desktop engine — this line
          // is how the device tells us whether it is happening.
          log.pdf.log('pointercancel', { id: e.pointerId, type: e.pointerType,
            stillDown: activeTouchesRef.current.size - 1,
            owner: gestureOwnerRef.current });
          activeTouchesRef.current.delete(e.pointerId);
          seedPinch();
          if (gestureOwnerRef.current === 'pointer' && activeTouchesRef.current.size === 0) {
            gestureOwnerRef.current = 'none';
          }
          isDraggingRef.current = false;
          wasDragRef.current = false;
        }}
        // Capture can be lost without a pointerup — iOS takes it back when the
        // system interrupts a gesture. The id would then stay in the map and,
        // at two entries, wedge the viewer into a permanent pinch with no pan.
        onLostPointerCapture={(e) => {
          log.pdf.log('lostpointercapture', { id: e.pointerId, type: e.pointerType,
            stillDown: activeTouchesRef.current.size - 1,
            owner: gestureOwnerRef.current });
          activeTouchesRef.current.delete(e.pointerId);
          seedPinch();
          if (gestureOwnerRef.current === 'pointer' && activeTouchesRef.current.size === 0) {
            gestureOwnerRef.current = 'none';
          }
        }}
        // A mouse that leaves the panel ends its drag. A captured touch cannot
        // leave, so a touch "leave" is only ever spurious — and killing a
        // gesture on it is exactly the failure this layer exists to prevent.
        onPointerLeave={(e) => {
          if (e.pointerType === 'touch') return;
          activeTouchesRef.current.delete(e.pointerId);
          isDraggingRef.current = false;
          wasDragRef.current = false;
        }}
        onDoubleClick={handleTextDblClick}
        onContextMenu={(ev: React.MouseEvent) => {
          // 2R 24/10/2026: botão direito numa peça/net do PDF = mostra na placa (igual ao duplo clique); Shift abre o menu
          if (!ev.shiftKey && r2w.__r2DireitoMenu !== true) {
            const hit = hitTestWord(ev), board = boardStore.board;
            if (hit && board) {
              const up = hit.word.toUpperCase();
              if (board.parts.some(p => p.name.toUpperCase() === up) || [...board.nets.keys()].some(n => n.toUpperCase() === up)) {
                ev.preventDefault(); handleTextDblClick(ev); return;
              }
            }
          }
          handleContextMenu(ev);
        }}
      />
        {glyphLoading && <div className="pdf-glyph-loading">Parsing fonts...</div>}
        <div
          ref={wrapperRef}
          className="pdf-page-wrapper"
          style={{ transformOrigin: '0 0', willChange: 'transform' }}
        >
          <canvas ref={canvasRef} style={(tiledMode || (isGlyphComposite && !glyphLoading && !isFiltered)) ? { visibility: 'hidden' } : undefined} />
          <canvas ref={highlightRef} className="pdf-highlight-canvas" />
          <canvas ref={glyphCanvasRef} className="pdf-glyph-overlay-canvas" />
          {/* Imperatively positioned (see showClickHighlight). Always mounted +
              hidden so a click never re-renders this component — which at zoom > 1
              would recomposite the GPU layer and momentarily blur the page. */}
          <div ref={clickHighlightElRef} className="pdf-click-highlight" style={{ display: 'none', borderWidth: 1.5 }}>
            <span ref={clickTooltipElRef} className="pdf-click-tooltip" style={{ transform: 'translateX(-50%)' }} />
          </div>
        </div>
        {pageCount > 1 && (
          <PageScrubber
            currentPage={currentPage}
            pageCount={pageCount}
            onGoToPage={(n) => { pdfStore.switchTo(pdfFileName); pdfStore.goToPage(n); }}
            scrubberRef={scrubberElRef}
          />
        )}
      </div>
    </div>
  );
}

/** Extract a word from a string at the given character index */
function extractWord(str: string, charIndex: number): string | null {
  const idx = Math.max(0, Math.min(charIndex, str.length - 1));
  const wordChars = /[A-Za-z0-9_]/;
  // A '.' is part of the word only when it is a decimal point inside a pure
  // number ("0.001Ohm"), NOT a designator→pin reference ("R5960.3"). The
  // discriminator: the digit run left of the dot must not be the tail of an
  // alphanumeric designator (i.e. not preceded by a letter/underscore).
  const isDecimalDot = (i: number): boolean => {
    if (str[i] !== '.' || !/\d/.test(str[i - 1] ?? '') || !/\d/.test(str[i + 1] ?? '')) return false;
    let j = i - 1;
    while (j > 0 && /\d/.test(str[j - 1])) j--;
    return !/[A-Za-z_]/.test(str[j - 1] ?? '');
  };
  if (!wordChars.test(str[idx]) && !isDecimalDot(idx)) return null;

  let start = idx;
  let end = idx;
  while (start > 0 && (wordChars.test(str[start - 1]) || isDecimalDot(start - 1))) start--;
  while (end < str.length - 1 && (wordChars.test(str[end + 1]) || isDecimalDot(end + 1))) end++;

  const word = str.slice(start, end + 1);
  return word.length > 0 ? word : null;
}
