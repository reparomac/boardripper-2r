import { useEffect, useRef, useState, useCallback } from 'react';

/** Painel do microscópio: mostra a câmera USB ao lado da placa (split-screen).
 *  2R Tools. Isolado por PanelErrorBoundary — uma falha aqui não derruba o app. */
export function MicroscopePanel() {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [devices, setDevices] = useState<MediaDeviceInfo[]>([]);
  const [deviceId, setDeviceId] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [status, setStatus] = useState<string>('');

  const stop = useCallback(() => {
    const s = streamRef.current;
    if (s) { s.getTracks().forEach(t => t.stop()); streamRef.current = null; }
  }, []);

  const start = useCallback(async (id?: string) => {
    setError('');
    stop();
    try {
      const constraints: MediaStreamConstraints = {
        video: id ? { deviceId: { exact: id } } : true, audio: false,
      };
      const s = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = s;
      if (videoRef.current) {
        videoRef.current.srcObject = s;
        await videoRef.current.play().catch(() => {});
      }
      const all = await navigator.mediaDevices.enumerateDevices();
      const cams = all.filter(d => d.kind === 'videoinput');
      setDevices(cams);
      if (!id && cams[0]) setDeviceId(cams[0].deviceId);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : String(e));
    }
  }, [stop]);

  useEffect(() => { void start(); return () => stop(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const onPick = (id: string) => { setDeviceId(id); void start(id); };

  const bridge = (): any => (window as any).electronAPI; // ponte do 2R Tools (SDS)

  const flash = (msg: string) => { setStatus(msg); window.setTimeout(() => setStatus(''), 3500); };

  const resultMsg = (r: any): string => {
    if (r && r.ok) return 'Adicionado à ficha.';
    if (r && r.error === 'no-ficha') return 'Abra uma ficha na bancada primeiro.';
    return 'Não foi possível adicionar: ' + ((r && r.error) || 'sem ponte do 2R Tools');
  };

  const sendPhoto = async () => {
    const api = bridge();
    if (!api || !api.fichaPhoto) { flash('Disponível só dentro do 2R Tools.'); return; }
    const v = videoRef.current;
    if (!v || !v.videoWidth) { flash('Câmera sem imagem.'); return; }
    try {
      const c = document.createElement('canvas');
      c.width = v.videoWidth; c.height = v.videoHeight;
      const ctx = c.getContext('2d'); if (!ctx) { flash('Falha ao capturar.'); return; }
      ctx.drawImage(v, 0, 0, c.width, c.height);
      const blob: Blob | null = await new Promise(res => c.toBlob(res, 'image/jpeg', 0.92));
      if (!blob) { flash('Falha ao capturar.'); return; }
      const buf = new Uint8Array(await blob.arrayBuffer());
      flash(resultMsg(await api.fichaPhoto(buf)));
    } catch (e) { flash('Erro: ' + (e instanceof Error ? e.message : String(e))); }
  };

  const sendPrint = async () => {
    const api = bridge();
    if (!api || !api.fichaGrab) { flash('Disponível só dentro do 2R Tools.'); return; }
    try { flash(resultMsg(await api.fichaGrab())); }
    catch (e) { flash('Erro: ' + (e instanceof Error ? e.message : String(e))); }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: '#0B0D0F' }}>
      <div style={{ display: 'flex', gap: 8, alignItems: 'center', padding: '6px 8px', borderBottom: '1px solid #2a2d31' }}>
        <span style={{ fontSize: 12, color: '#c3c8ce', fontWeight: 600 }}>Microscópio</span>
        <select
          value={deviceId}
          onChange={e => onPick(e.target.value)}
          style={{ flex: 1, minWidth: 0, background: 'var(--r2-bg2, #1b1d21)', color: 'var(--r2-text, #d7dadc)', border: '1px solid var(--r2-line, #2a2d31)', borderRadius: 4, padding: '3px 6px', fontSize: 12 }}
        >
          {devices.length === 0 && <option value="">(nenhuma câmera)</option>}
          {devices.map((d, i) => <option key={d.deviceId || i} value={d.deviceId}>{d.label || `Câmera ${i + 1}`}</option>)}
        </select>
        <button
          onClick={() => void start(deviceId || undefined)}
          title="Atualizar"
          style={{ background: 'var(--r2-bg2, #1b1d21)', color: 'var(--r2-text, #d7dadc)', border: '1px solid var(--r2-line, #2a2d31)', borderRadius: 4, padding: '3px 8px', fontSize: 12, cursor: 'pointer' }}
        >↻</button>
        <button
          onClick={() => void sendPhoto()}
          title="Foto da câmera → ficha de reparo"
          style={{ background: 'var(--r2-bg2, #1b1d21)', color: 'var(--r2-text, #d7dadc)', border: '1px solid var(--r2-line, #2a2d31)', borderRadius: 4, padding: '3px 8px', fontSize: 12, cursor: 'pointer' }}
        >Foto</button>
        <button
          onClick={() => void sendPrint()}
          title="Print da tela → ficha de reparo"
          style={{ background: 'var(--r2-bg2, #1b1d21)', color: 'var(--r2-text, #d7dadc)', border: '1px solid var(--r2-line, #2a2d31)', borderRadius: 4, padding: '3px 8px', fontSize: 12, cursor: 'pointer' }}
        >Print</button>
      </div>
      {status && <div style={{ fontSize: 11, color: '#c3c8ce', padding: '3px 8px', borderBottom: '1px solid #2a2d31' }}>{status}</div>}
      {error
        ? <div style={{ color: '#E0B04A', fontSize: 12, padding: 12, lineHeight: 1.5 }}>
            Câmera indisponível: {error}. Verifique a permissão em Ajustes do Sistema › Privacidade e Segurança › Câmera e conecte o microscópio.
          </div>
        : <video ref={videoRef} autoPlay playsInline muted style={{ flex: 1, minHeight: 0, width: '100%', objectFit: 'contain', background: '#000' }} />}
    </div>
  );
}
