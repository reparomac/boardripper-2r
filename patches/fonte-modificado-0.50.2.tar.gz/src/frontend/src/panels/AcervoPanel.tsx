import { useEffect, useRef, useState } from 'react';
import { IconCloudUpload, IconFileText, IconCpu } from '@tabler/icons-react';
import { r2, type R2Row } from '../r2/env';

/**
 * 2R Tools: aba «Acervo 2R» (nuvem) no painel lateral — pedido do Roger, 10/10/2026.
 * Busca direta no acervo online (sem pastas): abre o boardview e o PDF da mesma
 * pasta. Embaixo, «Enviar arquivo novo» com as perguntas sobre o arquivo.
 */

type Known = Awaited<ReturnType<NonNullable<ReturnType<typeof r2>>['known']>>;

const ERR: Record<string, string> = {
  offline: 'Sem conexão com o servidor da 2R Tools.',
  license: 'O envio é liberado só para licença ativa.',
  limit: 'Limite de envios por hoje. Amanhã libera de novo.',
  server: 'O servidor não aceitou o arquivo agora. Tente de novo em instantes.',
  bad: 'Arquivo vazio ou maior que 300 MB.',
  bad_type: 'Esse tipo de arquivo não é boardview nem PDF.',
};

/** Estilo da lista (4 opções para o Roger escolher — 10/10/2026). */
export function acervoStyle(): string {
  try { return localStorage.getItem('2r-acv-style') || '2'; } catch { return '2'; }
}

function stem(name: string): string { return name.replace(/\.[^.]+$/, ''); }

function Results({ rows, busy, open }: { rows: R2Row[]; busy: string; open: (r: R2Row) => void }) {
  const st = acervoStyle();
  if (!rows.length) return null;
  if (st === '2') {              // cartões
    return (
      <div className="r2acv-cards">
        {rows.map(r => (
          <button key={r.id} className={`r2acv-card ${busy === r.id ? 'busy' : ''}`} onClick={() => open(r)}>
            <span className="r2acv-card-board">{stem(r.name)}</span>
            <span className="r2acv-card-model">{r.folder}</span>
            <span className="r2acv-chips">
              <span className="r2acv-chip">{r.kind === 'pdf' ? 'PDF' : r.name.split('.').pop()?.toUpperCase()}</span>
              {r.pdf && <span className="r2acv-chip">PDF</span>}
            </span>
          </button>
        ))}
      </div>
    );
  }
  if (st === '3') {              // agrupado por modelo
    const groups: Record<string, R2Row[]> = {};
    rows.forEach(r => { (groups[r.folder] ??= []).push(r); });
    return (
      <div className="r2acv-groups">
        {Object.entries(groups).map(([folder, rs]) => (
          <div key={folder} className="r2acv-group">
            <div className="r2acv-group-head">{folder}</div>
            {rs.map(r => (
              <button key={r.id} className={`r2acv-grow ${busy === r.id ? 'busy' : ''}`} onClick={() => open(r)}>
                {r.kind === 'pdf' ? <IconFileText size={14} /> : <IconCpu size={14} />}
                <span>{r.name}</span>{r.pdf && <span className="r2acv-tag">+ PDF</span>}
              </button>
            ))}
          </div>
        ))}
      </div>
    );
  }
  if (st === '4') {              // tabela
    return (
      <table className="r2acv-table">
        <thead><tr><th>Placa</th><th>Modelo</th><th>PDF</th></tr></thead>
        <tbody>
          {rows.map(r => (
            <tr key={r.id} className={busy === r.id ? 'busy' : ''} onClick={() => open(r)}>
              <td className="r2acv-td-board">{stem(r.name)}</td>
              <td className="r2acv-td-model">{r.folder.replace(/^.*?820-\d{4,5}\s*-\s*/, '') || r.folder}</td>
              <td>{r.kind === 'pdf' ? 'só PDF' : r.pdf ? '✓' : '—'}</td>
            </tr>
          ))}
        </tbody>
      </table>
    );
  }
  return (                       // lista compacta
    <div className="r2acv-list">
      {rows.map(r => (
        <button key={r.id} className={`r2acv-row ${busy === r.id ? 'busy' : ''}`} onClick={() => open(r)}
                title={r.by ? `Enviado por ${r.by}` : r.folder}>
          <span className="r2acv-ico">{r.kind === 'pdf' ? <IconFileText size={14} /> : <IconCpu size={14} />}</span>
          <span className="r2acv-main">
            <span className="r2acv-name">{r.name}{r.pdf && <span className="r2acv-tag">+ PDF</span>}</span>
            <span className="r2acv-folder">{r.folder}</span>
          </span>
        </button>
      ))}
    </div>
  );
}

function Search() {
  const api = r2();
  const [q, setQ] = useState('');
  const [rows, setRows] = useState<R2Row[]>([]);
  const [count, setCount] = useState<{ boards: number; pdfs: number } | null>(null);
  const [busy, setBusy] = useState('');
  const t = useRef<number | undefined>(undefined);
  useEffect(() => {
    if (!api) return;
    window.clearTimeout(t.current);
    t.current = window.setTimeout(async () => {
      try {
        const r = await api.list(q);
        setRows(r.rows); setCount({ boards: r.boards, pdfs: r.pdfs });
      } catch { setRows([]); }
    }, 150);
    return () => window.clearTimeout(t.current);
  }, [q, api]);
  const open = async (row: R2Row) => {
    if (!api) return;
    setBusy(row.id);
    try { await api.open(row.id); } finally { window.setTimeout(() => setBusy(''), 1200); }
  };
  return (
    <div className="r2acv-section">
      <input className="r2acv-search" autoFocus value={q} onChange={e => setQ(e.target.value)}
             placeholder="Placa (820-01700), modelo (A2141) ou ano"
             onKeyDown={e => { if (e.key === 'Enter' && rows[0]) open(rows[0]); }} />
      {count && !q.trim() && (
        <div className="r2acv-note">{count.boards} boardviews e {count.pdfs} esquemáticos no acervo. Digite para buscar.</div>
      )}
      {q.trim() !== '' && rows.length === 0 && <div className="r2acv-note">Nada encontrado no Acervo 2R.</div>}
      <Results rows={rows} busy={busy} open={open} />
    </div>
  );
}

function Upload() {
  const api = r2();
  const [open, setOpen] = useState(false);
  const [known, setKnown] = useState<Known | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [f, setF] = useState({ mac_model: '', board: '', emc: '', model_name: '', year: '', notes: '' });
  const [ok, setOk] = useState(false);
  const [msg, setMsg] = useState<{ text: string; err: boolean } | null>(null);
  const [sending, setSending] = useState(false);
  const fileRef = useRef<HTMLInputElement | null>(null);
  useEffect(() => { if (open && api && !known) api.known().then(setKnown).catch(() => {}); }, [open, api, known]);
  useEffect(() => {                       // Arquivo › Enviar arquivo novo ao acervo
    const fn = () => setOpen(true);
    window.addEventListener('2r-acervo-upload-open', fn);
    return () => window.removeEventListener('2r-acervo-upload-open', fn);
  }, []);

  const set = (k: keyof typeof f, v: string) => setF(p => ({ ...p, [k]: v }));
  const onA = (v: string) => {
    const a = v.trim().toUpperCase();
    setF(p => ({ ...p, mac_model: v, model_name: p.model_name || known?.models?.[a] || '' }));
  };
  const onBoard = (v: string) => {
    const b = known?.boards?.[v.trim().toUpperCase()];
    setF(p => ({ ...p, board: v, ...(b ? { mac_model: b.mac_model, emc: b.emc, model_name: b.model_name, year: b.year } : {}) }));
    if (b) setMsg({ text: 'Placa já conhecida no acervo: dados preenchidos.', err: false });
  };
  const send = async () => {
    if (!api) return;
    if (!file) return setMsg({ text: 'Escolha o arquivo.', err: true });
    if (!/^A\d{4}$/i.test(f.mac_model.trim())) return setMsg({ text: 'Informe o número A (ex.: A2141).', err: true });
    if (!/^820-\d{4,5}$/i.test(f.board.trim())) return setMsg({ text: 'Informe a placa (ex.: 820-01700).', err: true });
    if (!ok) return setMsg({ text: 'Marque a autorização para enviar.', err: true });
    setSending(true); setMsg({ text: 'Enviando…', err: false });
    try {
      const r = await api.upload(file, f);
      if (r.ok) {
        setMsg({ text: 'Enviado! Em alguns minutos o arquivo aparece no Acervo 2R. Obrigado pela ajuda.', err: false });
        setFile(null); setOk(false); setF({ mac_model: '', board: '', emc: '', model_name: '', year: '', notes: '' });
        if (fileRef.current) fileRef.current.value = '';
      } else {
        setMsg({ text: r.detail || ERR[r.error || 'server'] || ERR.server, err: true });
      }
    } catch { setMsg({ text: ERR.offline, err: true }); }
    setSending(false);
  };

  return (
    <div className="r2acv-section r2acv-upload">
      <button className="r2acv-head" onClick={() => setOpen(!open)}>
        <IconCloudUpload size={15} /> Enviar arquivo novo ao acervo <span className="r2acv-caret">{open ? '▾' : '▸'}</span>
      </button>
      {open && (
        <div className="r2acv-form">
          <div className="r2acv-note">O arquivo entra no acervo de todos os técnicos, com o seu nome como quem enviou. Informe o modelo EXATO da placa.</div>
          <label>Arquivo (boardview ou esquemático PDF)
            <input ref={fileRef} type="file" accept={(known?.ext ?? []).join(',')}
                   onChange={e => setFile(e.target.files?.[0] ?? null)} />
          </label>
          <label>Placa *<input value={f.board} onChange={e => onBoard(e.target.value)} placeholder="ex.: 820-01700" /></label>
          <label>Número A do Mac *<input value={f.mac_model} onChange={e => onA(e.target.value)} placeholder="ex.: A2141 (gravado embaixo do Mac)" /></label>
          <div className="r2acv-two">
            <label>EMC<input value={f.emc} onChange={e => set('emc', e.target.value)} placeholder="ex.: 3347" /></label>
            <label>Ano<input value={f.year} onChange={e => set('year', e.target.value)} placeholder="ex.: 2019" /></label>
          </div>
          <label>Modelo<input value={f.model_name} onChange={e => set('model_name', e.target.value)} placeholder="ex.: MACBOOK PRO 16 - T2" /></label>
          <label>Observação<input value={f.notes} onChange={e => set('notes', e.target.value)} placeholder="ex.: testada OK" /></label>
          <label className="r2acv-check">
            <input type="checkbox" checked={ok} onChange={e => setOk(e.target.checked)} />
            Declaro que posso compartilhar este arquivo e autorizo a 2R Tools a incluí-lo no Acervo 2R.
          </label>
          {known?.credit && <div className="r2acv-note">Crédito: {known.credit}</div>}
          {msg && <div className={`r2acv-msg ${msg.err ? 'err' : ''}`}>{msg.text}</div>}
          <button className="r2acv-send" disabled={sending} onClick={send}>{sending ? 'Enviando…' : 'Enviar'}</button>
        </div>
      )}
    </div>
  );
}

export function AcervoPanel() {
  if (!r2()) return null;
  return (
    <div className="r2acv">
      <div className="r2acv-title">Acervo 2R <span className="r2acv-sub">online</span></div>
      <Search />
      <Upload />
    </div>
  );
}
