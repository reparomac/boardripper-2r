import './polyfills';
import './r2/hand-globals';
import './r2/hand-rc';
import { boardStore } from './store/board-store';
import { installPortuguese } from './r2/translate';
import { installBridge } from './r2/bridge';
import { installMeter } from './r2/meter-store';
import { installCurves } from './r2/curves-store';
import { installGuide } from './r2/guide-store';
// Must precede any renderer creation: swaps PixiJS's `new Function` uniform
// parsers for eval-free ones. Lets the hosted lite build's CSP drop
// 'unsafe-eval' (deploy/boardripper-web.htaccess) — the only reason it was there.
import 'pixi.js/unsafe-eval';
import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import App from './App';
import { RootErrorBoundary } from './components/RootErrorBoundary';
import { installTranslateGuard } from './dom-translate-guard';
import { installBrowserZoomBlock } from './store/browser-zoom-block';
import { startMcpBridgeIfEnabled } from './store/mcp-bridge';
import { initSessionStore } from './store/session-store';
import { installStaleBuildGuard } from './store/stale-build';

// The boot gate in index.html has already written its message into #root when
// this is set; mounting would paint the app over it and then fail somewhere
// deeper. Nothing below this line runs on an unsupported browser.
if (!window.__brUnsupported) {
  // Before React mounts: the page translator must not be able to crash it (#36).
  installTranslateGuard();
  installBrowserZoomBlock();
  // 2R: ponte MCP (IA na placa) desligada por enquanto — liga com __2rBeta.mcp (Roger, 10/10/2026)
  { const w = window as unknown as { __2rAcervo?: unknown; __2rBeta?: Record<string, boolean> };
    if (!w.__2rAcervo || w.__2rBeta?.mcp) startMcpBridgeIfEnabled(); }
  initSessionStore();
  installStaleBuildGuard();

  // 2R Tools: dentro do app 2R (visual neutro, sem o aviso de atualização do BoardRipper)
  if ((window as unknown as { __2rAcervo?: unknown }).__2rAcervo) document.documentElement.classList.add('r2');
  installPortuguese();
  installBridge();
  installMeter();
  installCurves();
  installGuide();
  createRoot(document.getElementById('root')!).render(
    <StrictMode>
      <RootErrorBoundary>
        <App />
      </RootErrorBoundary>
    </StrictMode>
  );
}

// 2R 18/10/2026: Ctrl/⌘ + ←/→ gira a placa em qualquer lugar (menos em campos de texto)
window.addEventListener('keydown', (e: KeyboardEvent) => {
  if (!(e.ctrlKey || e.metaKey) || e.altKey || e.shiftKey) return;
  if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') return;
  const t = e.target as HTMLElement | null;
  if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable)) return;
  e.preventDefault(); e.stopPropagation();
  if (e.key === 'ArrowLeft') boardStore.rotateCCW(); else boardStore.rotateCW();
}, true);
