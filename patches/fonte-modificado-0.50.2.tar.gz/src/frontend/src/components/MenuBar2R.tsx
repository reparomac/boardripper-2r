import { useEffect, useRef, useState } from 'react';
import { boardStore } from '../store/board-store';
import { pdfStore } from '../store/pdf-store';
import { viewCommands } from '../store/view-commands';
import { getDockviewApi, ensureMicroscopePanel, applySplitLayout, SPLIT_LABELS, type SplitLayout } from '../store/dockview-api';
import { toggleCameraOverlay } from '../store/camera-overlay';
import { showSidebarTab, toggleSidebar, toggleStatusBar } from './Sidebar.utils';
import { fileInputRefs } from '../store/file-inputs';
import { historyBack, historyForward } from '../store/nav-history-actions';
import { isTwoWindowMode, setTwoWindowMode } from '../store/two-window-mode';
import { themeStore } from '../store/themes';
import { searchSyncOn, setSearchSync } from '../r2/search-sync';
import { beta } from '../r2/env';
import { openSettings2R } from './SettingsWindow2R';
import { openTrackpadPrefs } from './TrackpadPrefs2R';
import logo2r from '../assets/2r-logo.png';
import { stepPin } from '../r2/probe-seq';
import { NAVBAR_LAYOUT_KEY } from './NavBar2R';

type R2Telas = { set(papel: string, n: number): Promise<{ externas?: unknown[] } | null> };
// 2R 28/10/2026: BoardRipper 0.50.2 em paralelo com o 0.48.0 — a chave fica no app (QSettings «boardview/versao_nova»)
type R2Versao = { get(): Promise<{ on?: boolean; pasta?: string }>; set(on: boolean): Promise<{ on?: boolean }> };
const r2Versao = (): R2Versao | undefined => (window as unknown as { __2rVersaoNova?: R2Versao }).__2rVersaoNova;
const r2Telas = (): R2Telas | undefined => (window as unknown as { __2rTelas?: R2Telas }).__2rTelas;

/**
 * 2R Tools: menu de texto no alto, como no FlexBV (Roger, 10/10/2026:
 * «a barra superior, os menus com textos, preferências, ferramentas,
 * configurações extras… como no FlexBV»). Arquivo · Exibir · Placa ·
 * Ferramentas · Preferências · Ajuda. Embaixo dele fica a barra de ícones.
 */

/** 2R: o zoom do esquemático acompanha o da placa (padrão ligado). */
const syncZoomOn = () => { try { return localStorage.getItem('2r-sync-zoom') !== '0'; } catch { return true; } };
const onPdf = () => (getDockviewApi()?.activePanel?.id ?? '').startsWith('pdf-');
const isMac = typeof navigator !== 'undefined' && /Mac/i.test(navigator.platform || navigator.userAgent);
const K = (k: string) => (isMac ? k.replace('Ctrl+', '⌘') : k);

function flipSide() {
  const { showTop, showBottom, butterfly, board } = boardStore;
  if (butterfly) return;
  const swap = board?.primarySide === 'bottom';
  const uiTop = swap ? showBottom : showTop;
  if (uiTop) boardStore.selectBottom(); else boardStore.selectTop();
}

function focusSearch() {
  const el = document.querySelector<HTMLInputElement>('.toolbar-search');
  if (el) { el.focus(); el.select(); }
}

type Entry = { label: string; key?: string; run: () => void } | 'sep' | { head: string };

const SPLITS: SplitLayout[] = ['board', 'board-pdf', 'board-mic', 'pdf-mic', 'board-pdf-mic'];

function menus(): { name: string; items: Entry[] }[] {
  // 2R (Roger, 11/10/2026): «organizar os menus, separar por tipos, o que é padrão dos
  // softwares de mercado» — Arquivo · Editar · Exibir · Placa · Ferramentas · Preferências · Ajuda,
  // e dentro de cada um, grupos com título.
  // escolher um tema 2R limpa as cores trocadas à mão (fundo/barras), senão o fundo
  // podia continuar preto num tema claro (Roger, 11/10/2026)
  const theme = (id: string, label: string) => ({ label: `${themeStore.activeId === id ? '✓ ' : ''}${label}`, run: () => {
    themeStore.setBackground(null); themeStore.setChrome(null); themeStore.setTheme(id);
  } });
  return [
    { name: 'Arquivo', items: [
      { head: 'Abrir' },
      { label: 'Abrir boardview ou PDF…', key: K('Ctrl+O'), run: () => fileInputRefs.board?.click() },
      { label: 'Abertos recentemente', run: () => showSidebarTab('history') },
      'sep',
      { head: 'Arquivos de placa' },
      { label: 'Acervo 2R (nuvem)', run: () => showSidebarTab('acervo' as never) },
      { label: 'Biblioteca local', run: () => showSidebarTab('library') },
      { label: 'Enviar arquivo novo ao acervo…', run: () => { showSidebarTab('acervo' as never); window.dispatchEvent(new Event('2r-acervo-upload-open')); } },
    ] },
    { name: 'Editar', items: [
      { head: 'Buscar' },
      { label: 'Buscar em tudo (placa + PDF)', key: K('Ctrl+F'), run: focusSearch },
      { label: `${searchSyncOn() ? '✓ ' : ''}Buscar junto: placa ↔ PDF`, run: () => setSearchSync(!searchSyncOn()) },
      'sep',
      { head: 'Navegação' },
      { label: 'Voltar para a visão anterior', run: () => { historyBack(); } },
      { label: 'Avançar para a próxima visão', run: () => { historyForward(); } },
    ] },
    { name: 'Exibir', items: [
      { head: 'Zoom' },
      { label: 'Centralizar a placa', run: () => viewCommands.fit() },
      { label: 'Aproximar (zoom +)', key: 'Shift+W', run: () => viewCommands.zoom('in') },
      { label: 'Afastar (zoom −)', key: 'Shift+S', run: () => viewCommands.zoom('out') },
      'sep',
      { head: 'Painéis' },
      { label: 'Painel lateral (mostrar / esconder)', run: () => toggleSidebar() },
      { label: 'Legenda das cores das nets', run: () => window.dispatchEvent(new Event('2r-legend-toggle')) },
      { label: 'Barra de status', run: () => toggleStatusBar() },
      'sep',
      { head: 'Dividir tela' },
      ...SPLITS.map(l => ({ label: SPLIT_LABELS[l], run: () => { try { localStorage.setItem('2r-split-layout', l); } catch { /* */ } applySplitLayout(l); } })),
      { label: '2 janelas (PDF numa segunda janela)', run: () => setTwoWindowMode(!isTwoWindowMode()) },
      // 2R 27/10/2026 (Roger: «opção de abrir o PDF numa segunda ou terceira tela… sempre abrir a câmera térmica com a
      // tela externa») — window.__2rTelas vem do app (ui/boardview_view.py)
      { head: 'Telas' },
      { label: 'PDF na 2ª tela', run: () => { r2Telas()?.set('pdf', 1).then(r => { if (!isTwoWindowMode()) setTwoWindowMode(true); if (r && r.externas && !r.externas.length) boardStore.addToast('Só há uma tela ligada: o PDF abre numa janela nesta tela.', 'info'); }); } },
      { label: 'PDF na 3ª tela', run: () => { r2Telas()?.set('pdf', 2).then(r => { if (!isTwoWindowMode()) setTwoWindowMode(true); if (r && r.externas && r.externas.length < 2) boardStore.addToast('Não há 3ª tela ligada: o PDF vai para a 2ª.', 'info'); }); } },
      { label: 'PDF: perguntar a tela ao abrir', run: () => { r2Telas()?.set('pdf', 0).then(() => boardStore.addToast('PDF: com mais de uma tela, o app pergunta em qual abrir.', 'info')); } },
      { label: 'Câmera: perguntar a tela ao abrir', run: () => { r2Telas()?.set('termica', 0).then(() => boardStore.addToast('Câmera: com mais de uma tela, o app pergunta em qual abrir.', 'info')); } },
      { label: 'Câmera térmica na 2ª tela', run: () => { r2Telas()?.set('termica', 1).then(() => boardStore.addToast('Câmera térmica: abre na 2ª tela.', 'info')); } },
      { label: 'Câmera térmica na 3ª tela', run: () => { r2Telas()?.set('termica', 2).then(() => boardStore.addToast('Câmera térmica: abre na 3ª tela.', 'info')); } },
      'sep',
      { head: 'Tema' },
      theme('2r-ambar', 'Escuro: 2R Âmbar (padrão, estilo FlexBV)'),
      theme('2r-clean', 'Escuro: 2R Placa'),
      theme('2r-clean-antigo', 'Escuro: 2R Neutro (anterior)'),
      theme('2r-oliva', 'Médio: 2R Oliva'),
      theme('2r-marrom', 'Médio: 2R Marrom'),
      theme('2r-grafite', 'Médio: 2R Grafite'),
      theme('2r-claro-oliva', 'Claro: 2R Oliva'),
      theme('2r-claro-areia', 'Claro: 2R Areia (marrom)'),
      theme('2r-claro-gelo', 'Claro: 2R Gelo (cinza)'),
      'sep',
      { head: 'Tamanho da letra' },
      { label: 'Letra maior', run: () => themeStore.setScale(themeStore.scale + 0.05) },
      { label: 'Letra menor', run: () => themeStore.setScale(themeStore.scale - 0.05) },
      { label: 'Letra no tamanho padrão', run: () => themeStore.setScale(1.15) },
    ] },
    { name: 'Placa', items: [
      { head: 'Lado' },
      { label: 'Virar a placa (superior ↔ inferior)', key: 'Espaço', run: flipSide },
      { label: 'Borboleta (os dois lados)', run: () => boardStore.toggleButterfly() },
      'sep',
      { head: 'Girar e espelhar' },
      { label: 'Girar para a esquerda', key: K('Ctrl+←'), run: () => (onPdf() ? pdfStore.rotateActive('ccw') : boardStore.rotateCCW()) },
      { label: 'Girar para a direita', key: K('Ctrl+→'), run: () => (onPdf() ? pdfStore.rotateActive('cw') : boardStore.rotateCW()) },
      { label: 'Girar 180°', run: () => boardStore.rotate180() },
      { label: 'Espelhar', key: 'M', run: () => (onPdf() ? pdfStore.mirrorActive() : boardStore.flipHorizontal()) },
      { label: 'Espelhar na vertical', run: () => boardStore.flipVertical() },
      'sep',
      { head: 'Nets' },
      { label: 'Linhas das nets (desligado → estrela → corrente)', run: () => boardStore.cycleNetLineMode() },
    ] },
    { name: 'Ferramentas', items: [
      { head: 'Câmera' },
      { label: 'Microscópio (câmera USB)', run: () => ensureMicroscopePanel() },
      { label: 'Mesclar imagem real com a placa', run: () => toggleCameraOverlay() },
      ...(beta('medicoes') ? [
        'sep' as const,
        { head: 'Medições' },
        { label: 'Multímetro e medições (Rigol / i2C)…', run: () => showSidebarTab('meter' as never) },
        { label: 'Mapear componente (sequência dos pinos)…', run: () => showSidebarTab('meter' as never) },
        { label: 'Próximo pino da sequência', key: ']', run: () => { stepPin(1); } },
        { label: 'Pino anterior da sequência', key: '[', run: () => { stepPin(-1); } },
      ] : []),
      ...((beta('teleguiado') || beta('curvas')) ? ['sep' as const, { head: 'Diagnóstico' }] : []),
      ...(beta('teleguiado') ? [{ label: 'Ponto a ponto na placa…', run: () => showSidebarTab('guide' as never) }] : []),
      ...(beta('curvas') ? [{ label: 'Curvas (RastreCurve / Smart Curve)…', run: () => showSidebarTab('curves' as never) }] : []),
    ] },
    { name: 'Preferências', items: [
      { head: 'Aparência da placa' },
      { label: 'Contorno da placa…', run: () => openSettings2R('outline') },
      { label: 'Componentes…', run: () => openSettings2R('parts') },
      { label: 'Pinos / pads…', run: () => openSettings2R('pins') },
      { label: 'Propriedades dos componentes…', run: () => openSettings2R('partTypeOverrides') },
      { label: 'Cores dos pinos e das nets…', run: () => openSettings2R('netColors') },
      { label: 'Seleção e destaque…', run: () => openSettings2R('selection') },
      { label: 'Linhas das nets…', run: () => openSettings2R('netLines') },
      { label: 'Sobreposição na placa…', run: () => openSettings2R('boardOverlay') },
      { label: 'Tema e cores do programa…', run: () => openSettings2R(undefined, 'theme') },
      'sep',
      { head: 'Mouse, trackpad e teclado' },
      { label: 'Mouse e trackpad: aparelho, direção e velocidade…', run: () => openTrackpadPrefs() },
      { label: 'Navegação (gestos e roda)…', run: () => openSettings2R('navigation') },
      { label: `${syncZoomOn() ? '✓ ' : ''}Zoom do esquemático acompanha a placa`, run: () => { try { localStorage.setItem('2r-sync-zoom', syncZoomOn() ? '0' : '1'); } catch { /* */ } } },
      { label: 'Detalhes conforme o zoom…', run: () => openSettings2R('zoomLod') },
      { label: 'Atalhos do teclado…', run: () => openSettings2R('shortcuts') },
      'sep',
      { head: 'Sistema' },
      { label: 'Esquemático (PDF)…', run: () => openSettings2R('pdf') },
      { label: 'Biblioteca local…', run: () => openSettings2R('server') },
      { label: 'Desempenho…', run: () => openSettings2R('performance') },
      'sep',
      { head: 'Versão do BoardRipper' },
      { label: 'Usar a versão anterior (0.48.0) na próxima abertura', run: () => {
        const v = r2Versao();
        if (!v) { boardStore.addToast('Esta troca só funciona dentro do SDS.', 'info'); return; }
        void v.set(false).then(() => boardStore.addToast('Pronto: feche e abra o SDS para voltar ao BoardRipper 0.48.0. Para voltar a esta versão: Control+Option+Shift+N (Windows: Ctrl+Alt+Shift+N) no BoardRipper.', 'info'));
      } },
      { label: 'Voltar a barra de ícones ao padrão', run: () => { try { localStorage.removeItem(NAVBAR_LAYOUT_KEY); } catch { /* */ } location.reload(); } },
    ] },
    { name: 'Ajuda', items: [
      { label: 'Atalhos do teclado', key: '?', run: () => window.dispatchEvent(new KeyboardEvent('keydown', { key: '?' })) },
    ] },
  ];
}

export function MenuBar2R({ inline = false }: { inline?: boolean } = {}) {
  const [open, setOpen] = useState<number | null>(null);
  useEffect(() => {                      // [ e ] andam na sequência do componente
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null;
      if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable)) return;
      if (e.metaKey || e.ctrlKey || e.altKey || !beta('medicoes')) return;
      if (e.key === ']') { stepPin(1); e.preventDefault(); }
      else if (e.key === '[') { stepPin(-1); e.preventDefault(); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);
  const ref = useRef<HTMLDivElement | null>(null);
  const all = menus();
  useEffect(() => {
    if (open === null) return;
    const onDoc = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(null); };
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(null); };
    document.addEventListener('mousedown', onDoc);
    document.addEventListener('keydown', onKey);
    return () => { document.removeEventListener('mousedown', onDoc); document.removeEventListener('keydown', onKey); };
  }, [open]);
  return (
    <div className={`r2-menubar ${inline ? 'inline' : ''}`} ref={ref}>
      {all.map((m, i) => (
        <div key={m.name} className="r2-menu">
          <button className={`r2-menu-title ${open === i ? 'open' : ''}`}
                  onClick={() => setOpen(open === i ? null : i)}
                  onMouseEnter={() => { if (open !== null) setOpen(i); }}>
            {m.name}
          </button>
          {open === i && (
            <div className="r2-menu-pop">
              {m.items.map((it, j) => it === 'sep'
                ? <div key={j} className="r2-menu-sep" />
                : 'head' in it
                  ? <div key={j} className="r2-menu-head">{it.head}</div>
                  : (
                    <button key={j} className="r2-menu-item" onClick={() => { setOpen(null); it.run(); }}>
                      <span>{it.label}</span>{it.key && <span className="r2-menu-key">{it.key}</span>}
                    </button>
                  ))}
            </div>
          )}
        </div>
      ))}
      {!inline && <img className="r2-menubar-logo" src={logo2r} alt="2R Tools" title="2R Tools" draggable={false} />}
    </div>
  );
}
