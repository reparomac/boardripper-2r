import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { THEMES, themeStore, isLightHex } from '../store/themes';

/**
 * 2R Tools: botão de temas na barra (aprovado pelo Roger, 11/10/2026 — proposta_busca_e_temas.png).
 * Lista os temas 2R separados em escuros e claros; o escolhido fica como padrão
 * (store/themes.ts grava «2r-theme-last»).
 */
const nameOf = (label: string) => label.replace(/^2R Tools\s*[—-]\s*/, '').replace(/\s*\(.*?\)\s*$/, '');

export function ThemeButton2R() {
  const [open, setOpen] = useState(false);
  const [cur, setCur] = useState(themeStore.activeId);
  const btn = useRef<HTMLButtonElement | null>(null);
  const pop = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    return themeStore.subscribe(() => setCur(themeStore.activeId));
  }, []);
  useEffect(() => {
    if (!open) return;
    const h = (e: MouseEvent) => {
      const t = e.target as Node;
      if (pop.current?.contains(t) || btn.current?.contains(t)) return;
      setOpen(false);
    };
    const k = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    document.addEventListener('mousedown', h); document.addEventListener('keydown', k);
    return () => { document.removeEventListener('mousedown', h); document.removeEventListener('keydown', k); };
  }, [open]);
  const ids = Object.keys(THEMES).filter(id => id.startsWith('2r-'));
  const dark = ids.filter(id => !isLightHex(THEMES[id].ui.bgPrimary));
  const light = ids.filter(id => isLightHex(THEMES[id].ui.bgPrimary));
  const r = btn.current?.getBoundingClientRect();
  const row = (id: string) => {
    const t = THEMES[id];
    const ui = t.ui as unknown as Record<string, string>;
    const ac = ui.accent || ui.textPrimary || '#888';
    return (
      <button key={id} className={'r2-theme-row' + (cur === id ? ' on' : '')}
              onClick={() => { themeStore.setTheme(id); setCur(id); setOpen(false); }}>
        <span className="r2-theme-sw" style={{ background: t.ui.bgPrimary }}><i style={{ background: ac }} /></span>
        <span>{nameOf(t.label)}</span>
        {cur === id && <span className="r2-theme-ck">✓</span>}
      </button>
    );
  };
  return (
    <>
      <button ref={btn} className={'r2-theme-btn' + (open ? ' open' : '')} title="Tema da tela"
              onClick={() => setOpen(o => !o)} aria-label="Tema da tela">
        <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <circle cx="12" cy="12" r="9" /><path d="M12 3a9 9 0 0 0 0 18z" fill="currentColor" />
        </svg>
      </button>
      {open && r && createPortal(
        <div ref={pop} className="r2-theme-pop" style={{ top: r.bottom + 6, right: Math.max(8, window.innerWidth - r.right) }}>
          <div className="r2-theme-h">Tema da tela</div>
          <div className="r2-theme-g">Escuros</div>
          {dark.map(row)}
          <div className="r2-theme-g">Claros</div>
          {light.map(row)}
          <div className="r2-theme-foot">O último tema escolhido fica como padrão.</div>
        </div>, document.body)}
    </>
  );
}
