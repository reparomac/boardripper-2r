import { useEffect, useRef, useState, useCallback } from 'react';
import type { CSSProperties, MouseEvent as ReactMouseEvent } from 'react';
import { IconX, IconArrowsMove, IconFlipHorizontal, IconRefresh, IconPhoto, IconCamera } from '@tabler/icons-react';
import {
  useCameraOverlay, setCameraOverlay, toggleCameraOverlay,
  setCameraStream, useCameraStream, usePhotoUrl, setPhotoFile,
} from '../store/camera-overlay';
import type { CameraOverlayState } from '../store/camera-overlay';

/** Imagem real (câmera ao vivo ou foto) com a transformação de alinhamento. */
function RealImage({ st, opacity }: { st: CameraOverlayState; opacity: number }) {
  const stream = useCameraStream();
  const photo = usePhotoUrl();
  const videoRef = useRef<HTMLVideoElement | null>(null);
  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    if (v.srcObject !== stream) v.srcObject = stream;
    if (stream) v.play().catch(() => {});
  }, [stream, st.source]);
  const style: CSSProperties = {
    maxWidth: 'none', opacity: opacity / 100, pointerEvents: 'none', userSelect: 'none',
    transform: `translate(${st.x}px, ${st.y}px) scale(${st.scale}) rotate(${st.rotation}deg) scaleX(${st.flipX ? -1 : 1})`,
    transformOrigin: 'center center', background: 'transparent',
  };
  if (st.source === 'photo') {
    return photo ? <img src={photo} alt="" draggable={false} style={style} /> : null;
  }
  return <video ref={videoRef} autoPlay playsInline muted style={style} />;
}

/** Fundo da placa no modo "Pinos por cima" (2R Tools): fica DENTRO do painel da
 *  boardview, ATRÁS do canvas — o renderer deixa o fundo transparente e esconde
 *  corpos/contorno/cobre, sobrando pinos, nets, códigos e leituras por cima. */
export function BoardRealBackdrop() {
  const st = useCameraOverlay();
  if (!st.on || st.mode !== 'pins') return null;
  return (
    <div style={{
      position: 'absolute', inset: 0, zIndex: -1, pointerEvents: 'none', background: '#000',
      display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden',
    }}>
      <RealImage st={st} opacity={st.opacity} />
    </div>
  );
}

/** Sobreposição da imagem real (câmera do microscópio ou foto) com a placa.
 *  Dois modos: "Imagem por cima" (antigo) e "Pinos por cima" (novo — a
 *  boardview sem fundo fica sobre a imagem real). Quando "Alinhar" está
 *  desligado o mouse passa direto pra placa; ligado, arrasta a imagem. */
export function CameraOverlay() {
  const st = useCameraOverlay();
  const streamRef = useRef<MediaStream | null>(null);
  const fileRef = useRef<HTMLInputElement | null>(null);
  const [devices, setDevices] = useState<MediaDeviceInfo[]>([]);
  const [error, setError] = useState<string>('');
  const drag = useRef<{ dx: number; dy: number } | null>(null);

  const stop = useCallback(() => {
    const s = streamRef.current;
    if (s) { s.getTracks().forEach(t => t.stop()); streamRef.current = null; }
    setCameraStream(null);
  }, []);

  const start = useCallback(async (id?: string) => {
    setError('');
    stop();
    try {
      const constraints: MediaStreamConstraints = {
        video: id ? { deviceId: { exact: id } } : true, audio: false,
      };
      const s = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = s;
      setCameraStream(s);
      const all = await navigator.mediaDevices.enumerateDevices();
      setDevices(all.filter(d => d.kind === 'videoinput'));
      if (!id) {
        const first = all.find(d => d.kind === 'videoinput');
        if (first) setCameraOverlay({ deviceId: first.deviceId });
      }
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : String(e));
    }
  }, [stop]);

  // liga/desliga a câmera conforme o overlay e a origem (câmera x foto)
  const wantCamera = st.on && st.source === 'camera';
  useEffect(() => {
    if (wantCamera) void start(st.deviceId || undefined);
    else stop();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [wantCamera]);

  // troca de câmera
  useEffect(() => {
    if (wantCamera && st.deviceId && streamRef.current) void start(st.deviceId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [st.deviceId]);

  useEffect(() => () => stop(), [stop]);

  const onDown = (e: ReactMouseEvent) => {
    if (!st.align) return;
    drag.current = { dx: e.clientX - st.x, dy: e.clientY - st.y };
    e.preventDefault();
  };
  const onMove = (e: ReactMouseEvent) => {
    if (!drag.current) return;
    setCameraOverlay({ x: e.clientX - drag.current.dx, y: e.clientY - drag.current.dy });
  };
  const onUp = () => { drag.current = null; };

  if (!st.on) return null;

  const pins = st.mode === 'pins';
  const ctrlBtn: CSSProperties = {
    background: 'var(--r2-bg0, #000)', color: 'var(--r2-text, #d7dadc)', border: '1px solid var(--r2-line, #3a3e45)',
    borderRadius: 5, padding: '3px 7px', fontSize: 12, cursor: 'pointer',
    display: 'inline-flex', alignItems: 'center', gap: 4, fontWeight: 400,
  };
  // padrão 2R: ligado/aberto = branco em negrito + contorno verde
  const on: CSSProperties = { color: '#fff', fontWeight: 700, borderColor: '#3fae5a' };
  const label: CSSProperties = { fontSize: 11, color: '#9aa0a6', whiteSpace: 'nowrap' };
  const sep = <span style={{ width: 1, height: 18, background: '#3a3e45' }} />;

  return (
    <>
      {/* camada de captura (arrastar no modo Alinhar) + imagem no modo antigo */}
      <div
        onMouseDown={onDown}
        onMouseMove={onMove}
        onMouseUp={onUp}
        onMouseLeave={onUp}
        style={{
          position: 'absolute', inset: 0, zIndex: 40,
          pointerEvents: st.align ? 'auto' : 'none',
          cursor: st.align ? (drag.current ? 'grabbing' : 'grab') : 'default',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          overflow: 'hidden',
        }}
      >
        {error && st.source === 'camera'
          ? <div style={{ pointerEvents: 'auto', color: '#ff5a5a', background: 'rgba(11,13,15,0.85)', padding: 10, borderRadius: 6, fontSize: 12, maxWidth: 360, lineHeight: 1.5 }}>
              Câmera indisponível: {error}. Verifique a permissão da câmera e conecte o microscópio — ou use uma Foto.
            </div>
          : !pins && <RealImage st={st} opacity={st.opacity} />}
      </div>

      {/* barra de controle */}
      <div
        style={{
          position: 'absolute', top: 54, left: '50%', transform: 'translateX(-50%)',
          zIndex: 41, pointerEvents: 'auto',
          display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap',
          background: 'rgba(16,18,20,0.95)', border: '1px solid #3a3e45',
          borderRadius: 8, padding: '7px 10px', boxShadow: '0 6px 18px rgba(0,0,0,0.45)',
          maxWidth: 'calc(100vw - 24px)',
        }}
      >
        <span style={{ fontSize: 12, color: '#D4B26A', fontWeight: 700 }}>Mesclar</span>

        {/* modo: qual camada fica por cima */}
        <button style={{ ...ctrlBtn, ...(!pins ? on : {}) }}
          onClick={() => setCameraOverlay({ mode: 'camera', ...(pins ? { opacity: 50 } : {}) })}
          title="Imagem real por cima da boardview (modo antigo)">
          Imagem por cima
        </button>
        <button style={{ ...ctrlBtn, ...(pins ? on : {}) }}
          onClick={() => setCameraOverlay({ mode: 'pins', ...(!pins ? { opacity: 100 } : {}) })}
          title="Boardview SEM fundo por cima da imagem real: só pinos, nets, códigos e leituras">
          Pinos por cima
        </button>
        {sep}

        {/* origem: câmera ao vivo ou foto */}
        <button style={{ ...ctrlBtn, ...(st.source === 'camera' ? on : {}) }}
          onClick={() => setCameraOverlay({ source: 'camera' })} title="Usar a câmera / microscópio">
          <IconCamera size={15} />Câmera
        </button>
        <button style={{ ...ctrlBtn, ...(st.source === 'photo' ? on : {}) }}
          onClick={() => { setCameraOverlay({ source: 'photo' }); fileRef.current?.click(); }}
          title="Abrir uma foto da placa">
          <IconPhoto size={15} />Foto
        </button>
        <input ref={fileRef} type="file" accept="image/*" style={{ display: 'none' }}
          onChange={e => { const f = e.target.files?.[0]; if (f) { setPhotoFile(f); setCameraOverlay({ source: 'photo' }); } e.target.value = ''; }} />

        {st.source === 'camera' && (
          <select
            value={st.deviceId}
            onChange={e => setCameraOverlay({ deviceId: e.target.value })}
            style={{ background: 'var(--r2-bg0, #000)', color: 'var(--r2-text, #d7dadc)', border: '1px solid var(--r2-line, #3a3e45)', borderRadius: 5, padding: '3px 6px', fontSize: 12, maxWidth: 160 }}
          >
            {devices.length === 0 && <option value="">(câmera)</option>}
            {devices.map((d, i) => <option key={d.deviceId || i} value={d.deviceId}>{d.label || `Câmera ${i + 1}`}</option>)}
          </select>
        )}
        {sep}

        <span style={label}>Imagem</span>
        <input type="range" min={0} max={100} value={st.opacity}
          onChange={e => setCameraOverlay({ opacity: Number(e.target.value) })} style={{ width: 90 }} />
        <span style={{ ...label, width: 34, textAlign: 'right' }}>{st.opacity}%</span>

        {pins && <>
          <span style={label}>Pinos</span>
          <input type="range" min={10} max={100} value={st.pinsOpacity}
            onChange={e => setCameraOverlay({ pinsOpacity: Number(e.target.value) })} style={{ width: 90 }} />
          <span style={{ ...label, width: 34, textAlign: 'right' }}>{st.pinsOpacity}%</span>
        </>}

        <span style={label}>Escala</span>
        <input type="range" min={20} max={400} value={Math.round(st.scale * 100)}
          onChange={e => setCameraOverlay({ scale: Number(e.target.value) / 100 })} style={{ width: 80 }} />

        <span style={label}>Girar</span>
        <input type="range" min={-180} max={180} value={st.rotation}
          onChange={e => setCameraOverlay({ rotation: Number(e.target.value) })} style={{ width: 80 }} />

        <button style={{ ...ctrlBtn, ...(st.flipX ? on : {}) }}
          onClick={() => setCameraOverlay({ flipX: !st.flipX })} title="Espelhar horizontal">
          <IconFlipHorizontal size={15} />
        </button>

        <button style={{ ...ctrlBtn, ...(st.align ? on : {}) }}
          onClick={() => setCameraOverlay({ align: !st.align })}
          title={st.align ? 'Alinhar ligado: arraste a imagem (o mouse não chega à placa)' : 'Alinhar: arrastar a imagem real'}>
          <IconArrowsMove size={15} />{st.align ? 'Alinhando' : 'Alinhar'}
        </button>

        <button style={ctrlBtn} onClick={() => setCameraOverlay({ opacity: pins ? 100 : 50, pinsOpacity: 100, scale: 1, rotation: 0, flipX: false, x: 0, y: 0 })}
          title="Resetar posição/opacidade">
          <IconRefresh size={15} />
        </button>

        <button style={{ ...ctrlBtn, borderColor: '#c03030', color: '#ff6b6b' }} onClick={() => toggleCameraOverlay()} title="Fechar">
          <IconX size={15} />
        </button>
      </div>
    </>
  );
}
