import { useSyncExternalStore } from 'react';
import { guideStore } from '../r2/guide-store';
import { useBoardStore } from '../hooks/useBoardStore';
import { boardStore } from '../store/board-store';
import { bgaBall } from '../r2/bga';
import { jsx as r2jsx, jsxs as r2jsxs, Fragment as R2Frag } from 'react/jsx-runtime';
const R2D = { jsx: r2jsx, jsxs: r2jsxs, Fragment: R2Frag };
type GInfo = { gn: number; gk: number; gm: number; nome?: string; cor: string; novo?: boolean };
const r2h = window as unknown as {
  __r2rp?: { on: boolean };
  __r2GInfo?: (a: unknown, i: number) => GInfo | null;
  __r2Notes?: (d: unknown, note: string, cls: string, hud?: boolean) => React.ReactNode;
};

/** 2R Tools: faixa do Teleguiado em cima da placa — passo atual, net, ponto indicado e setas. */
export function GuideHud() {
  useSyncExternalStore(guideStore.subscribe, () => guideStore.rev);
  useBoardStore();
  const a = guideStore.active;
  if (!guideStore.on || !a) return null;
  const r = guideStore.current();
  if (!r) return null;
  const pt = r.points.length ? r.points[guideStore.pointIdx % r.points.length] : null;
  const tab = guideStore.tab() ?? boardStore.activeTab, sel = tab?.selection;   // 2R 29/10: a placa do estudo
  const sp = tab?.board && sel?.partIndex != null && sel.pinIndex != null && sel.pinIndex >= 0 ? tab.board.parts[sel.partIndex] : null;
  const selLabel = sp ? `${sp.name}.${sp.pins[sel!.pinIndex!].number || sp.pins[sel!.pinIndex!].name}` : '';
  const ball = pt && tab?.board ? bgaBall(tab.board.parts[pt.partIndex], pt.pinIndex) : null;
  const canFix = !!selLabel && selLabel.toUpperCase() !== (r.step.point || '').toUpperCase() && (!pt || selLabel !== pt.label);
  return (
    <div className="r2gd-hud">
      <button className="r2gd-hud-arrow" title="Passo anterior (←)" onClick={() => guideStore.prev()} disabled={guideStore.pos === 0}>‹</button>
      <div className="r2gd-hud-pos" title="Posição deste passo na sequência"><b>{guideStore.pos + 1}</b><span>de {a.steps.length}</span></div>
      <div className="r2gd-hud-body">
        {r2h.__r2rp && r2h.__r2rp.on && <div className="r2gd-hud-top">⏪ REPLAY</div>}
        {(() => {
          const GI = r2h.__r2GInfo ? r2h.__r2GInfo(a, guideStore.pos) : null;
          return GI ? (
            <div className={'r2gd-hud-grp' + (GI.novo ? ' novo' : '')} style={{ borderColor: GI.cor, color: GI.cor }}>
              {GI.novo ? <b>NOVO GRUPO · </b> : null}
              {'Grupo ' + String(GI.gn).padStart(2, '0') + (GI.nome ? ' — ' + GI.nome : '') + ' · passo ' + GI.gk + ' de ' + GI.gm}
            </div>
          ) : null;
        })()}
        <div className="r2gd-hud-net">{r.step.nets.join(' · ')}</div>
        <div className="r2gd-hud-sub">
          {pt ? <>medir em <b>{pt.fixed ? '◆ ' : ''}{pt.label}</b>{ball ? ` · bola ${ball.ball}` : ''}{r.points.length > 1 ? ` · Tab: +${r.points.length - 1}` : ''}</>
            : r.missing.length ? <span className="r2gd-miss">não está nesta placa</span> : 'sem ponto acessível'}
          {(() => {
            // 2R 27/10/2026 (Roger: «no estudo do Erick precisa add a ação em cada passo…»): AÇÃO antes do esperado e da atenção
            const q = String(r.step.note || '').split(' | ').filter(x => /^(AÇÃO|ESPERADO|ATENÇÃO):/.test(x))
              .sort((x, y) => (/^AÇÃO:/.test(y) ? 1 : 0) - (/^AÇÃO:/.test(x) ? 1 : 0)).join(' | ');
            return q && r2h.__r2Notes ? r2h.__r2Notes(R2D, q, 'r2gd-hud-note', true) : null;
          })()}
        </div>
        {(r.step.v || r.step.d || r.step.r) && <div className="r2gd-hud-vals">
          {r.step.v && <span>Tensão <b>{r.step.v}</b></span>}
          {r.step.d && <span>Diodo <b>{r.step.d}</b></span>}
          {r.step.r && <span>Resist. <b>{r.step.r}</b></span>}
          {r2h.__r2rp && r2h.__r2rp.on && (r.step.iv || r.step.id || r.step.ir) && <span>Esperado <b>{[r.step.iv, r.step.id, r.step.ir].filter(Boolean).join(' | ')}</b></span>}
          {r2h.__r2rp && r2h.__r2rp.on && r.step.valAt && <span>medido em <b>{new Date(r.step.valAt).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' })}</b>{r.step.valBy ? ' · ' + r.step.valBy : ''}</span>}
        </div>}
        {canFix && <button className="r2gd-hud-fix" title="Usar o pino selecionado como ponto deste passo" onClick={() => guideStore.pinSelectedAsPoint()}>◆ usar {selLabel}</button>}
      </div>
      <button className="r2gd-hud-arrow" title="Próximo passo (→)" onClick={() => guideStore.next()} disabled={guideStore.pos >= a.steps.length - 1}>›</button>
    </div>
  );
}
