import { useEffect, useRef, useState } from 'react';
import { IconX, IconSettings } from '@tabler/icons-react';
import { SettingsPanel } from '../panels/SettingsPanel';

/**
 * 2R Tools: Ajustes numa janela que abre pelo menu de cima (Roger, 10/10/2026:
 * «essas funções que ficam em ajustes deveriam ir para o menu lá em cima… está
 * perdido lá na lateral esquerda»). Preferências › <seção> abre aqui já na seção.
 * Arrasta pelo título; Esc ou × fecha. A placa continua visível (muda ao vivo).
 */
export function openSettings2R(section?: string, tab?: string) {
  window.dispatchEvent(new CustomEvent('2r-settings-open', { detail: { section, tab } }));
}

export function SettingsWindow2R() {
  const [open, setOpen] = useState(false);
  const [pos, setPos] = useState<{ x: number; y: number } | null>(null);
  const drag = useRef<{ dx: number; dy: number } | null>(null);
  useEffect(() => {
    const fn = (e: Event) => {
      const d = (e as CustomEvent<{ section?: string; tab?: string }>).detail || {};
      setOpen(true);
      window.setTimeout(() => {
        if (d.tab) window.dispatchEvent(new CustomEvent('settings-open-tab', { detail: d.tab }));
        if (d.section) window.dispatchEvent(new CustomEvent('settings-focus-section', { detail: d.section }));
      }, 60);
    };
    const key = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    window.addEventListener('2r-settings-open', fn);
    window.addEventListener('keydown', key);
    return () => { window.removeEventListener('2r-settings-open', fn); window.removeEventListener('keydown', key); };
  }, []);
  if (!open) return null;
  const style = pos ? { left: pos.x, top: pos.y, right: 'auto' as const } : undefined;
  return (
    <div className="r2-setwin" style={style}>
      <div className="r2-setwin-head"
           onMouseDown={e => {
             const r = (e.currentTarget.parentElement as HTMLElement).getBoundingClientRect();
             drag.current = { dx: e.clientX - r.left, dy: e.clientY - r.top };
             const mv = (ev: MouseEvent) => { if (drag.current) setPos({ x: Math.max(0, ev.clientX - drag.current.dx), y: Math.max(0, ev.clientY - drag.current.dy) }); };
             const up = () => { drag.current = null; window.removeEventListener('mousemove', mv); window.removeEventListener('mouseup', up); };
             window.addEventListener('mousemove', mv); window.addEventListener('mouseup', up);
           }}>
        <IconSettings size={15} /> <b>Ajustes</b>
        <span className="r2-setwin-sub">muda na placa na hora</span>
        <button className="r2-setwin-x" title="Fechar (Esc)" onMouseDown={e => e.stopPropagation()} onClick={() => setOpen(false)}><IconX size={15} /></button>
      </div>
      <div className="r2-setwin-body"><SettingsPanel /></div>
    </div>
  );
}
