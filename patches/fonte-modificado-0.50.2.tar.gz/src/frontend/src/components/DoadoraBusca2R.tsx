import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { boardStore } from '../store/board-store';
import { uiZoom } from '../store/ui-zoom';

/**
 * 2R Tools — busca de placa doadora (Roger, 30/10/2026: «preciso ter uma busca geral em placa doadora, procurar
 * componentes… essa busca pode ser no acervo online e acervo local… escolher e limitar 20 resultados»).
 * Código da peça (CD3217B12), posição (U8100) ou linha (PP3V3_G3H) → até 20 placas do Acervo 2R; o clique (ou Enter)
 * abre a placa com a peça marcada. Quem responde é o SDS (window.__2rAcervo.pecas → core/acervo_pecas.py).
 */
type Row = { id: string; pdf: string; board: string; model: string; name: string; pos: string[]; n: number;
             baixada: boolean; kind: string; fonte: string };
type Res = { rows: Row[]; total?: number; tipo?: string; online?: boolean; erro?: string };
type Api = { pecas?: (q: string, onde: string) => Promise<Res>; open: (id: string) => Promise<unknown>;
             aprende?: (d: unknown) => Promise<unknown> };
const api = (): Api | undefined => (window as unknown as { __2rAcervo?: Api }).__2rAcervo;

type Onde = 'online' | 'local' | 'ambos';
const ONDE_KEY = '2r-doadora-onde';
const lerOnde = (): Onde => { try { const v = localStorage.getItem(ONDE_KEY); return v === 'online' || v === 'local' ? v : 'ambos'; } catch { return 'ambos'; } };

// ── depois de abrir: marca a peça/linha assim que a placa carregar ──
let pendente: { alvos: string[]; linha: boolean; ate: number } | null = null;
function tentarMarcar(): boolean {
  if (!pendente) return true;
  if (Date.now() > pendente.ate) { pendente = null; return true; }
  const b = boardStore.board;
  if (!b) return false;
  if (pendente.linha) {
    const nome = pendente.alvos.find(n => b.nets.has(n)) ?? [...b.nets.keys()].find(n => pendente!.alvos.some(a => n.toUpperCase().startsWith(a)));
    if (!nome) return false;
    boardStore.focusNet(nome);
  } else {
    const nomes = new Set(b.parts.map(p => p.name.toUpperCase()));
    const alvo = pendente.alvos.find(a => nomes.has(a));
    if (!alvo) return false;
    const real = b.parts.find(p => p.name.toUpperCase() === alvo)!.name;
    boardStore.focusPart(real);
  }
  pendente = null;
  return true;
}

// ── toda placa aberta ensina as posições e linhas dela (busca local) ──
let ensinou = '';
function ensinar() {
  const b = boardStore.board, t = boardStore.activeTab, a = api();
  if (!b || !t || !a?.aprende) return;
  const chave = t.fileName + ':' + b.parts.length;
  if (chave === ensinou) return;
  ensinou = chave;
  void a.aprende({ name: t.fileName, parts: b.parts.map(p => p.name), nets: [...b.nets.keys()] });
}

let instalado = false;
function instalar() {
  if (instalado) return;
  instalado = true;
  boardStore.subscribe(() => {
    if (pendente) tentarMarcar();
    window.setTimeout(ensinar, 1500);
  });
}

export function DoadoraBusca2R() {
  const [q, setQ] = useState('');
  const [onde, setOnde] = useState<Onde>(lerOnde);
  const [res, setRes] = useState<Res | null>(null);
  const [busy, setBusy] = useState(false);
  const [open, setOpen] = useState(false);
  const [sel, setSel] = useState(0);
  const [abrindo, setAbrindo] = useState('');
  const wrap = useRef<HTMLDivElement | null>(null);
  const inp = useRef<HTMLInputElement | null>(null);
  const pop = useRef<HTMLDivElement | null>(null);
  const seq = useRef(0);

  useEffect(() => { instalar(); }, []);
  useEffect(() => {                                   // botão direito numa peça/linha: abre já buscando
    const ev = (e: Event) => {
      const termo = String((e as CustomEvent).detail?.q || '').trim();
      if (!termo) return;
      setQ(termo); setOpen(true);
      window.setTimeout(() => inp.current?.focus(), 50);
    };
    window.addEventListener('r2-doadora', ev);
    return () => window.removeEventListener('r2-doadora', ev);
  }, []);
  useEffect(() => { try { localStorage.setItem(ONDE_KEY, onde); } catch { /* */ } }, [onde]);

  useEffect(() => {
    const termo = q.trim();
    if (termo.length < 3 || !api()?.pecas) { setRes(null); setBusy(false); return; }
    const n = ++seq.current;
    setBusy(true);
    const t = window.setTimeout(() => {
      api()!.pecas!(termo, onde).then(r => { if (n === seq.current) { setRes(r); setSel(0); setOpen(true); } })
        .catch(() => { if (n === seq.current) setRes({ rows: [], erro: 'sem resposta do SDS' }); })
        .finally(() => { if (n === seq.current) setBusy(false); });
    }, 280);
    return () => window.clearTimeout(t);
  }, [q, onde]);

  useEffect(() => {
    if (!open) return;
    const fora = (e: MouseEvent) => {
      const t = e.target as Node;
      if (wrap.current?.contains(t) || pop.current?.contains(t)) return;
      setOpen(false);
    };
    document.addEventListener('mousedown', fora);
    return () => document.removeEventListener('mousedown', fora);
  }, [open]);

  const abrir = async (r: Row) => {
    const a = api();
    if (!a) return;
    const termo = q.trim().toUpperCase().replace(/\s+/g, '');
    const linha = res?.tipo === 'linha';
    const alvos = r.pos.length ? r.pos : [termo];
    pendente = alvos.length ? { alvos, linha, ate: Date.now() + 60000 } : null;
    setAbrindo(r.id);
    try { await a.open(r.id); } finally { window.setTimeout(() => setAbrindo(''), 1500); }
    setOpen(false);
    let tent = 0;                                     // a placa pode já estar aberta (nenhuma notificação nova)
    const loop = () => { if (!tentarMarcar() && ++tent < 120) window.setTimeout(loop, 500); };
    window.setTimeout(loop, 400);
    if (alvos.length) boardStore.addToast(linha ? `Abrindo a placa com a linha ${termo} marcada…`
      : `Abrindo a placa com ${alvos.slice(0, 3).join(' · ')} marcada${alvos.length > 1 ? 's' : ''}…`, 'info');
  };

  const rows = res?.rows ?? [];
  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') { setOpen(true); setSel(s => Math.min(rows.length - 1, s + 1)); e.preventDefault(); }
    else if (e.key === 'ArrowUp') { setSel(s => Math.max(0, s - 1)); e.preventDefault(); }
    else if (e.key === 'Enter') { if (rows[sel]) void abrir(rows[sel]); e.preventDefault(); }
    else if (e.key === 'Escape') { setOpen(false); }
    e.stopPropagation();
  };

  const rect = wrap.current?.getBoundingClientRect();
  const z = uiZoom();
  const tipoTxt = res?.tipo === 'posicao' ? 'posição' : res?.tipo === 'linha' ? 'linha' : 'código da peça';
  const ondeTxt = onde === 'online' ? 'Acervo online' : onde === 'local' ? 'Acervo local (baixadas)' : 'Acervo online + local';

  return (
    <div className="r2-doadora" ref={wrap} data-testid="doadora-busca"
         title="Placa doadora: em quais placas do Acervo 2R existe a peça — código (CD3217B12), posição (U8100) ou linha (PP3V3_G3H)">
      {/* na barra só o botão (a barra já tem os ícones e a busca); o campo fica na janelinha */}
      <button className={`r2-doadora-btn ${open ? 'on' : ''}`} data-testid="doadora-btn"
              onClick={() => { setOpen(o => !o); window.setTimeout(() => inp.current?.focus(), 30); }}>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2"
             strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" /></svg>
        PLACA DOADORA
      </button>
      {open && rect && createPortal(
        <div className="r2-doadora-pop" ref={pop} data-testid="doadora-pop"
             style={{ left: Math.max(8, Math.min(rect.left / z, window.innerWidth / z - 628)), top: rect.bottom / z + 6, width: 620 }}>
          {/* onde procurar: dentro da lista para não apertar a barra (que já tem os ícones e a busca) */}
          <div className="r2-doadora-topo">
            <input ref={inp} className="r2-doadora-in" value={q} placeholder="código da peça, posição ou linha"
                   spellCheck={false} autoCorrect="off" autoCapitalize="characters" autoFocus
                   onChange={e => setQ(e.target.value)} onKeyDown={onKey} data-testid="doadora-input" />
            <div className="r2-doadora-seg" role="group">
              {(['online', 'local', 'ambos'] as Onde[]).map(o => (
                <button key={o} className={onde === o ? 'on' : ''} onClick={() => setOnde(o)} data-testid={`doadora-${o}`}
                        title={o === 'online' ? 'Todo o Acervo 2R' : o === 'local' ? 'Só as placas já baixadas neste computador' : 'Online e local'}>
                  {o === 'online' ? 'ONLINE' : o === 'local' ? 'LOCAL' : 'OS DOIS'}
                </button>
              ))}
            </div>
            <span className="r2-doadora-max">máx. 20 placas</span>
          </div>
          {q.trim().length < 3 ? <div className="r2-doadora-vazio">Exemplos: CD3217B12 (código da peça), U8100 (posição) ou PP3V3_G3H (linha).</div> : <>
          <div className="r2-doadora-head">
            {busy ? 'Procurando…' : res?.erro ? `Não consegui buscar: ${res.erro}`
              : <>{rows.length}{(res?.total ?? 0) > rows.length ? ` de ${res!.total}` : ''} placa{rows.length === 1 ? '' : 's'} com <b>{q.trim().toUpperCase()}</b> · {tipoTxt} · {ondeTxt}</>}
          </div>
          {rows.map((r, i) => (
            <button key={r.id} className={`r2-doadora-row ${i === sel ? 'sel' : ''}`} onMouseEnter={() => setSel(i)}
                    onClick={() => void abrir(r)} data-testid="doadora-row" title={r.name}>
              <span className="r2-dr-board">{r.board || r.name}</span>
              <span className="r2-dr-model">{r.model}</span>
              <span className="r2-dr-pos">{r.pos.join(' · ')}</span>
              <span className="r2-dr-n">{abrindo === r.id ? 'abrindo…' : `${r.n} peça${r.n === 1 ? '' : 's'}`}</span>
              <span className={`r2-dr-tag ${r.baixada ? 'ok' : ''}`}>{r.baixada ? 'BAIXADA' : '☁ NUVEM'}</span>
            </button>
          ))}
          {!busy && !res?.erro && rows.length === 0 && (
            <div className="r2-doadora-vazio">
              Nenhuma placa com esse termo{onde === 'local' ? ' entre as baixadas' : ''}.
              {res && res.online === false ? ' O índice de peças do acervo online ainda não foi gerado — por enquanto a busca usa as placas já abertas neste computador (posição e linha).' : ''}
            </div>
          )}
          </>}
          <div className="r2-doadora-pe">Enter ou clique: abre a placa com a peça marcada · também busca posição (U8100) e linha (PP3V3_G3H)</div>
        </div>, document.body)}
    </div>
  );
}
