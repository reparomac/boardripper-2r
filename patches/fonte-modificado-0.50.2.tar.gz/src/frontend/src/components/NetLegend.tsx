import { useEffect, useState } from 'react';
import { useRenderSettings } from '../hooks/useRenderSettings';
import { useBoardStore } from '../hooks/useBoardStore';
import { IS_2R } from '../r2/env';
import { getSidebarActiveTab, isSidebarCollapsed, onSidebarChange } from './Sidebar.utils';

/**
 * 2R Tools: legenda das cores das nets sempre à vista (Roger, 10/10/2026:
 * «deixar sempre visível, por código das cores, pra saber o que é cada cor das nets»).
 * Lê os mesmos grupos de cor que a placa usa (Ajustes › cores das nets).
 */
const KEY = '2r-net-legend-open';

/** A aba «Start» está aberta? Aí a legenda vai para dentro do painel (Roger, 10/10/2026:
 *  «essa tabela de cores ficar dentro do card da sequência de start… deixar a placa livre»). */
function useStartTabOpen(): boolean {
  const [v, setV] = useState(() => getSidebarActiveTab() === 'guide' && !isSidebarCollapsed());
  useEffect(() => onSidebarChange(() => setV(getSidebarActiveTab() === 'guide' && !isSidebarCollapsed())), []);
  return v;
}

export function NetLegend({ embedded = false }: { embedded?: boolean }) {
  const s = useRenderSettings();
  const { tabs } = useBoardStore();
  const startOpen = useStartTabOpen();
  const [open, setOpen] = useState<boolean>(() => { try { return localStorage.getItem(KEY) !== '0'; } catch { return true; } });
  useEffect(() => {                       // Exibir › Legenda das cores das nets
    const fn = () => setOpen(v => { const n = !v; try { localStorage.setItem(KEY, n ? '1' : '0'); } catch { /* */ } return n; });
    window.addEventListener('2r-legend-toggle', fn);
    return () => window.removeEventListener('2r-legend-toggle', fn);
  }, []);
  if (!IS_2R || !tabs.length) return null;
  if (!embedded && startOpen) return null;          // (versão flutuante não é mais usada no 2R)
  const groups = (s.pinGroups || []).filter(g => !g.outlineOnly && g.rules?.length);
  if (!groups.length) return null;
  const toggle = () => { const v = !open; setOpen(v); try { localStorage.setItem(KEY, v ? '1' : '0'); } catch { /* */ } };
  return (
    <div className={`r2-legend ${open ? '' : 'closed'} ${embedded ? 'embedded' : ''}`}>
      <button className="r2-legend-head" onClick={toggle} title="Mostrar / esconder a legenda">
        <span>Cores das nets</span><span className="r2-legend-caret">{open ? '▾' : '▸'}</span>
      </button>
      {open && groups.map(g => (
        <div key={g.id} className="r2-legend-group">
          <div className="r2-legend-label">{g.label}</div>
          {g.rules.map(r => (
            <div key={r.id} className="r2-legend-row" title={r.keywords}>
              <span className="r2-legend-dot" style={{ background: r.color }} />
              <span className="r2-legend-kw">{r.keywords}</span>
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}
