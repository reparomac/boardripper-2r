import { useEffect, useState } from 'react';
import { IconX } from '@tabler/icons-react';
import { renderSettingsStore } from '../store/render-settings';
import { useRenderSettings } from '../hooks/useRenderSettings';

/**
 * 2R Tools (Roger, 11/10/2026): «uma opção de ocultar os componentes… ou deixar só por
 * grupos, IC, MOSFET, resistor, capacitor, cristal, bobinas… selecionar por categorias,
 * mas deixar em um local de fácil acesso» — para ver por onde as nets passam.
 * Usa os «tipos de componente» do próprio BoardRipper (o mesmo «ocultar» dos Ajustes).
 */
export function togglePartFilter() { window.dispatchEvent(new Event('2r-partfilter-toggle')); }

const PT: Record<string, string> = {
  ic: 'CIs (U)', transistor: 'MOSFETs / transistores (Q)', resistor: 'Resistores (R)',
  capacitor: 'Capacitores (C)', crystal: 'Cristais (Y)', inductor: 'Bobinas (L)',
  diode: 'Diodos (D)', connector: 'Conectores (J)', fuse: 'Fusíveis (F)',
  testpoint: 'Pontos de teste (TP)', shield: 'Blindagens (SH)',
};

/** pred → true = «só os pads» (sem corpo/contorno/nome); false = componente inteiro. */
function setPadsOnly(pred: (id: string) => boolean | null) {
  const g = renderSettingsStore.globalSnapshot();
  g.partTypes = g.partTypes.map(t => { const h = pred(t.id); return h == null ? t : { ...t, padsOnly: h, hidden: false }; });
  renderSettingsStore.applyGlobal(g);
}

export function PartFilter2R() {
  const s = useRenderSettings();
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const fn = () => setOpen(v => !v);
    const key = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    window.addEventListener('2r-partfilter-toggle', fn); window.addEventListener('keydown', key);
    return () => { window.removeEventListener('2r-partfilter-toggle', fn); window.removeEventListener('keydown', key); };
  }, []);
  if (!open) return null;
  const types = s.partTypes || [];
  const hiddenN = types.filter(t => t.padsOnly || t.hidden).length;
  return (
    <div className="r2-tp r2-pf">
      <div className="r2-setwin-head"><b>Componentes: inteiro ou só os pads</b>
        <span className="r2-setwin-sub">{hiddenN ? `${hiddenN} grupo(s) só com os pads` : 'todos inteiros'}</span>
        <button className="r2-setwin-x" title="Fechar (Esc)" onClick={() => setOpen(false)}><IconX size={15} /></button></div>
      <div className="r2-tp-body">
        <div className="r2-pf-list">
          {types.map(t => (
            <label key={t.id} className="r2acv-check">
              <input type="checkbox" checked={!t.padsOnly && !t.hidden} onChange={e => setPadsOnly(id => id === t.id ? !e.target.checked : null)} />
              {PT[t.id] || `${t.label} (${t.prefixes.join(', ')})`}
            </label>
          ))}
        </div>
        <div className="r2-tp-actions">
          <button className="r2meter-btn r2meter-off" onClick={() => setPadsOnly(() => false)}>Todos inteiros</button>
          <button className="r2meter-btn r2meter-off" onClick={() => setPadsOnly(() => true)}>Todos só os pads</button>
          <button className="r2meter-btn r2meter-off" onClick={() => setPadsOnly(id => id !== 'ic')}>Só os CIs inteiros</button>
        </div>
        <div className="r2acv-note">Desmarcado = fica só os pads (sem corpo, contorno e nome), para ver por onde as nets passam. Vale na hora e fica guardado.</div>
      </div>
    </div>
  );
}
