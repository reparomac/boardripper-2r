// src/frontend/src/components/overlay/slot-renderers.tsx
import { Fragment, type ReactNode } from 'react';
import { type OverlaySlotId, isSeparatorId } from '../../store/overlay-layout';
import type { SlotCtx } from './slot-ctx';
import { PdfFollowButton }  from './slots/PdfFollowButton';
import { ScrollModeButton } from './slots/ScrollModeButton';
import { FitBoardButton }   from './slots/FitBoardButton';
import { HoverInfoButton }  from './slots/HoverInfoButton';
import { NetDimButton }     from './slots/NetDimButton';
import { NetLinesButton }   from './slots/NetLinesButton';
import { GhostsButton }     from './slots/GhostsButton';
import { DiodeValuesButton } from './slots/DiodeValuesButton';
import { Separator }        from './slots/Separator';
import { PartsDropdown }    from './slots/PartsDropdown';
import { NetsDropdown }     from './slots/NetsDropdown';
import { SideSwitch }       from './slots/SideSwitch';
import { HistoryButtons }   from './slots/HistoryButtons';
import { MinimapButton, SlideModeButton } from './slots/SlideButtons';
import { ButterflyButton, RotateCcwButton, RotateCwButton, TracesButton, TransformMenuButton } from './slots/TransformButtons';
import { R2NetNamesBtn, R2PartNamesBtn } from './slots/R2VisButtons';

/**
 * Returns the rendered ReactNode for a given slot id. Any `sep${number}`
 * id renders as a <Separator/>; named slots route through the switch.
 * Used by both the live overlay walker and the Settings customizer.
 */
export function renderOverlaySlot(id: OverlaySlotId, ctx: SlotCtx): ReactNode {
  if (isSeparatorId(id)) return <Separator />;
  switch (id) {
    case 'sideSwitch':    return <SideSwitch ctx={ctx} />;
    case 'butterfly':     return <ButterflyButton ctx={ctx} />;
    case 'rotateCCW':     return <RotateCcwButton />;
    case 'rotateCW':      return <RotateCwButton />;
    case 'transformMenu': return <TransformMenuButton ctx={ctx} />;
    case 'history':       return <HistoryButtons />;
    case 'traces':        return <TracesButton ctx={ctx} />;
    case 'pdfFollow':     return <PdfFollowButton  ctx={ctx} />;
    case 'scrollMode':    return <ScrollModeButton ctx={ctx} />;
    case 'fitBoard':      return <FitBoardButton   ctx={ctx} />;
    case 'minimap':       return <MinimapButton />;
    case 'slides':        return <SlideModeButton />;
    case 'hoverInfo':     return <HoverInfoButton  ctx={ctx} />;
    case 'netDim':        return <NetDimButton     ctx={ctx} />;
    case 'netLines':      return <NetLinesButton   ctx={ctx} />;
    case 'ghosts':        return <GhostsButton     ctx={ctx} />;
    case 'diodeValues':   return <DiodeValuesButton ctx={ctx} />;
    case 'partsDropdown': return <PartsDropdown ctx={ctx} />;
    case 'netsDropdown':  return <NetsDropdown ctx={ctx} />;
    case 'netNames':      return <R2NetNamesBtn />;
    case 'partNames':     return <R2PartNamesBtn />;
  }
}

// 2R 23/10/2026: legenda curta embaixo de cada botão da faixa (PT / EN / ES)
const R2CAP: Record<string, [string, string, string]> = {
  sideSwitch: ['Lado', 'Side', 'Lado'], butterfly: ['Borboleta', 'Butterfly', 'Mariposa'],
  rotateCCW: ['Girar ◀', 'Rotate ◀', 'Girar ◀'], rotateCW: ['Girar ▶', 'Rotate ▶', 'Girar ▶'],
  transformMenu: ['Mais', 'More', 'Más'], history: ['Histórico', 'History', 'Historial'], traces: ['Trilhas', 'Traces', 'Pistas'],
  pdfFollow: ['PDF', 'PDF', 'PDF'], scrollMode: ['Rolagem', 'Scroll', 'Scroll'], fitBoard: ['Ajustar', 'Fit', 'Ajustar'],
  minimap: ['Mapa', 'Map', 'Mapa'], slides: ['Slides', 'Slides', 'Slides'], hoverInfo: ['Info', 'Info', 'Info'],
  netDim: ['Foco', 'Focus', 'Foco'], netLines: ['Linhas', 'Lines', 'Líneas'], ghosts: ['Lado B', 'Ghosts', 'Lado B'],
  diodeValues: ['Diodo', 'Diode', 'Diodo'], netNames: ['Nets', 'Nets', 'Nets'], partNames: ['Comp.', 'Parts', 'Comp.'],
};
function r2CapTxt(id: string): string | null {
  const e = R2CAP[id];
  if (!e) return null;
  const t = ((typeof window !== 'undefined' && (window as unknown as { __2rLang?: string }).__2rLang) || 'pt').slice(0, 2);
  return e[t === 'en' ? 1 : t === 'es' ? 2 : 0];
}

export function renderOverlayLayout(
  layout: ReadonlyArray<{ id: OverlaySlotId; visible: boolean }>,
  ctx: SlotCtx,
): ReactNode[] {
  // 2R 27/10/2026: «Borboleta» foi para junto de Top/Bottom; o mapa fica sempre à mostra (sem botão)
  return layout
    .filter(s => s.visible && s.id !== 'butterfly' && s.id !== 'minimap')
    .map(s => {
      const cap = r2CapTxt(s.id);
      return cap
        ? <Fragment key={s.id}><span className="r2-capw">{renderOverlaySlot(s.id, ctx)}<span className="r2-cap">{cap}</span></span></Fragment>
        : <Fragment key={s.id}>{renderOverlaySlot(s.id, ctx)}</Fragment>;
    });
}
