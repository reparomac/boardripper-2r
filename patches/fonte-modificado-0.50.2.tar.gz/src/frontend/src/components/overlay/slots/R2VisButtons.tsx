// 2R Tools — botões «NET» (nomes das nets) e «U1» (nomes dos componentes) na faixa da placa
import { renderSettingsStore, type RenderSettings } from '../../../store/render-settings';
import { useRenderSettings } from '../../../hooks/useRenderSettings';

function R2VisBtn({ k, title, txt }: { k: 'showNetNames' | 'showPartLabels'; title: string; txt: string }) {
  const e = useRenderSettings() as RenderSettings;
  const on = e[k] !== false && !!e[k];
  return (
    <button
      className={`board-netlines-toggle ${on ? 'active' : ''}`}
      onClick={() => { const r = renderSettingsStore.globalSnapshot(); renderSettingsStore.applyGlobal({ ...r, [k]: !on }); }}
      title={title}
    >
      <span style={{ fontSize: 11, fontWeight: 700, lineHeight: '16px' }}>{txt}</span>
    </button>
  );
}
export function R2NetNamesBtn() { return <R2VisBtn k="showNetNames" title="Net names" txt="NET" />; }
export function R2PartNamesBtn() { return <R2VisBtn k="showPartLabels" title="Part names" txt="U1" />; }
