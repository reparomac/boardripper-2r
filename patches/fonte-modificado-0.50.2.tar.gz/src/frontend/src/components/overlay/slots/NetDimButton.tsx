import { IconBulb, IconBulbFilled, IconBulbOff } from '@tabler/icons-react';
import { boardStore } from '../../../store/board-store';
import type { SlotCtx } from '../slot-ctx';

const MODE_INFO = {
  off:       { icon: IconBulbOff,    title: 'Foco: desligado — clique para escurecer o resto (Shift+clique: holofote)' },
  dim:       { icon: IconBulb,       title: 'Foco: ligado — clique para desligar' },
  darklight: { icon: IconBulbFilled, title: 'Holofote: ligado — clique para desligar' },
} as const;

export function NetDimButton({ ctx }: { ctx: SlotCtx }) {
  const { dimMode } = ctx.thisTab;
  const info = MODE_INFO[dimMode];
  const Icon = info.icon;
  return (
    <button
      className={`board-netlines-toggle ${dimMode !== 'off' ? 'active' : ''}`}
      onClick={(e) => {
        // 2R: clique liga/desliga; Shift+clique liga o holofote
        const w = window as unknown as { __r2DimShift?: boolean };
        w.__r2DimShift = !!(e && e.shiftKey);
        boardStore.cycleDimMode();
        w.__r2DimShift = false;
      }}
      title={info.title}
    >
      <Icon size={16} />
    </button>
  );
}
