/**
 * Side — the control a repair session touches most, so it leads the ribbon
 * and keeps its words. Click to show a side; Shift-click for both. The
 * keyboard's flip shortcut (hold to peek) is unchanged and named in the tip.
 * Moved down from the app toolbar in v0.39; behaviour identical.
 */
import { IconStackFront, IconStackBack, IconFlipHorizontal, IconGhost2, IconGhost2Filled } from '@tabler/icons-react';
import { boardStore } from '../../../store/board-store';
import { formatShortcut } from '../../../store/keyboard-shortcuts';
import type { SlotCtx } from '../slot-ctx';

export function SideSwitch({ ctx }: { ctx: SlotCtx }) {
  const t = ctx.thisTab;
  // The store tracks the file's side='top' layer; on files whose primary
  // side is the bottom the labels swap so "Top" means what the user sees.
  const bf = !!t.butterfly;
  const gm = t.ghostMode ?? 'off';
  const uiTop    = !bf && (t.primarySide === 'bottom' ? t.showBottom : t.showTop);
  const uiBottom = !bf && (t.primarySide === 'bottom' ? t.showTop    : t.showBottom);
  const tip = `${formatShortcut('flipBoard')} flips · hold it to peek · Shift-click for both sides`;
  return (
    <div className="overlay-seg" role="group" aria-label="Board side" data-testid="side-switch">
      <button
        type="button"
        className={`overlay-seg-btn${uiTop ? ' active' : ''}`}
        data-testid="side-top"
        aria-pressed={uiTop}
        title={`Top side · ${tip}`}
        onClick={(e) => { if (bf) boardStore.toggleButterfly(); boardStore.selectTop(e.shiftKey); }}
      >
        <IconStackFront size={15} stroke={1.9} /><span className="overlay-seg-lbl">Top</span>
      </button>
      <button
        type="button"
        className={`overlay-seg-btn${uiBottom ? ' active' : ''}`}
        data-testid="side-bottom"
        aria-pressed={uiBottom}
        title={`Bottom side · ${tip}`}
        onClick={(e) => { if (bf) boardStore.toggleButterfly(); boardStore.selectBottom(e.shiftKey); }}
      >
        <IconStackBack size={15} stroke={1.9} /><span className="overlay-seg-lbl">Bottom</span>
      </button>
      {/* 2R 27/10/2026 (Roger: «add butterfly junto com top e bottom») */}
      <button
        type="button"
        className={`overlay-seg-btn${bf ? ' active' : ''}`}
        data-testid="side-butterfly"
        aria-pressed={bf}
        title="Butterfly · os dois lados lado a lado"
        onClick={() => boardStore.toggleButterfly()}
      >
        <IconFlipHorizontal size={15} stroke={1.9} /><span className="overlay-seg-lbl">Butterfly</span>
      </button>
      {/* 2R 30/10/2026 (Roger: «voltar a função ghost… botão ao lado do bottom, top, butterfly»): com uma linha
          marcada, as peças do outro lado nessa linha aparecem apagadas (ghost); segundo clique: disco (as peças da
          linha piscam nos dois lados); terceiro: desliga */}
      <button
        type="button"
        className={`overlay-seg-btn${gm !== 'off' ? ' active' : ''}`}
        data-testid="side-ghost"
        aria-pressed={gm !== 'off'}
        title={gm === 'off' ? 'Ghost desligado · clique: peças do outro lado na linha marcada aparecem apagadas'
          : gm === 'ghosts' ? 'Ghost ligado · clique: disco (peças da linha piscam nos dois lados)'
          : 'Disco ligado · clique: desliga'}
        onClick={() => boardStore.cycleGhostMode()}
      >
        {gm === 'disco' ? <IconGhost2Filled size={15} stroke={1.9} /> : <IconGhost2 size={15} stroke={1.9} />}
        <span className="overlay-seg-lbl">{gm === 'disco' ? 'Disco' : 'Ghost'}</span>
      </button>
    </div>
  );
}
