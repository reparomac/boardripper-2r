import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { useBoardStore } from '../hooks/useBoardStore';
import { boardStore } from '../store/board-store';

/**
 * 2R Tools: busca do lado direito da barra com escopo (Roger, 10/10/2026):
 * «Tudo» = a busca geral do BoardRipper (componentes, nets, PDFs, biblioteca);
 * «No componente» = pinos do componente selecionado (número, nome ou net).
 */
export type Scope = 'all' | 'part';
const KEY = '2r-search-scope';

export function useScope(): [Scope, (s: Scope) => void] {
  const [s, set] = useState<Scope>(() => { try { return (localStorage.getItem(KEY) as Scope) || 'all'; } catch { return 'all'; } });
  return [s, (v: Scope) => { set(v); try { localStorage.setItem(KEY, v); } catch { /* */ } }];
}

export function ScopeSelect({ scope, setScope }: { scope: Scope; setScope: (s: Scope) => void }) {
  return (
    <select className="r2-scope" value={scope} onChange={e => setScope(e.target.value as Scope)}
            title="Onde buscar: tudo ou só nos pinos do componente selecionado">
      <option value="all">Tudo</option>
      <option value="part">No componente</option>
    </select>
  );
}

export function PinSearch({ seg }: { seg?: ReactNode } = {}) {
  const snap = useBoardStore();
  const tab = snap.tabs.find(t => t.id === snap.activeTabId) ?? null;
  const partIdx = tab?.selection?.partIndex ?? null;
  const part = partIdx !== null && tab?.board ? tab.board.parts[partIdx] : null;
  const [q, setQ] = useState('');
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    const onDoc = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false); };
    document.addEventListener('mousedown', onDoc);
    return () => document.removeEventListener('mousedown', onDoc);
  }, []);
  const hits = useMemo(() => {
    if (!part) return [];
    const w = q.trim().toLowerCase();
    return part.pins.map((p, i) => ({ p, i }))
      .filter(({ p }) => !w || [p.number, p.name, p.net].some(x => (x || '').toLowerCase().includes(w)))
      .slice(0, 200);
  }, [part, q]);
  const pick = (i: number) => { if (partIdx !== null) boardStore.selectPin(partIdx, i); setOpen(false); };
  return (
    <div className="r2-pinsearch toolbar-search-wrap r2-search" ref={ref}>
      <svg className="r2-search-ico" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="7" /><path d="M20 20l-3.5-3.5" /></svg>
      <input className="toolbar-search r2-pin-input" value={q} disabled={!part}
             placeholder={part ? `Pino, nome ou net em ${part.name}` : 'Selecione um componente na placa'}
             onFocus={() => setOpen(true)} onClick={() => setOpen(true)} onChange={e => { setQ(e.target.value); setOpen(true); }}
             onKeyDown={e => { if (e.key === 'Enter' && hits[0]) pick(hits[0].i); if (e.key === 'Escape') setOpen(false); }} />
      {open && part && (
        <div className="r2-pin-drop">
          {hits.length === 0 && <div className="r2-pin-none">Nenhum pino encontrado</div>}
          {hits.map(({ p, i }) => (
            <button key={i} className="r2-pin-row" onMouseDown={e => e.preventDefault()} onClick={() => pick(i)}>
              <span className="r2-pin-num">{p.number || p.name}</span>
              <span className="r2-pin-net">{p.net || '—'}</span>
            </button>
          ))}
        </div>
      )}
      {seg}
    </div>
  );
}
