import { useRef, useEffect, useState, useCallback, useLayoutEffect } from 'react';
import { createPortal } from 'react-dom';
import { IconBoxMultiple, IconLayoutBoardSplit, IconUpload, IconDownload, IconInfoCircle } from '@tabler/icons-react';
import { boardStore } from '../store/board-store';
import { IS_2R } from '../r2/env';
import { MenuBar2R } from './MenuBar2R';
import logo2r from '../assets/2r-logo.png';
import { NavBar2R } from './NavBar2R';
import { PinSearch } from './ScopedSearch2R';
import { ThemeButton2R } from './ThemeButton2R';
import { useBoardStore } from '../hooks/useBoardStore';
import { useUpdateStore } from '../hooks/useUpdateStore';
import { showSidebarTab } from './Sidebar.utils';
import { SidebarCycleButton } from './SidebarCycleButton';
import { getAllExtensions, getFileExtension } from '../parsers';
import { fileInputRefs } from '../store/file-inputs';
import { openLibraryFileById, openPdfFiles } from '../store/file-actions';
import { updateStore, fmtVersion } from '../store/update-store';
import { ReleaseNotes } from './ReleaseNotes';
import { pdfStore } from '../store/pdf-store';
import { databankStore, isElectron, type DatabankFile } from '../store/databank-store';
import { log } from '../store/log-store';
import { isLiteBuild, isOfflineBuild } from '../store/build-mode';

/** Touch-first device (tablet). Evaluated once — the primary pointer of a
 *  device does not change while the page is open. */
const COARSE_POINTER = typeof window !== 'undefined' && typeof window.matchMedia === 'function'
  && window.matchMedia('(pointer: coarse)').matches;
import { setLibrarySearch } from '../panels/LibraryPanel';
import { countInBoardTab, countInPdf, findInBoardTab, findInPdf } from '../store/cross-target-search';
import { searchSyncOn, setSearchSync } from '../r2/search-sync';
import { SearchScopeBadge, type SearchScope } from './SearchScopeBadge';
import { isTwoWindowMode, toggleTwoWindowMode, onTwoWindowModeChange } from '../store/two-window-mode';
import { uiZoom } from '../store/ui-zoom';

declare const __APP_VERSION__: string;

/** Display a version string with exactly one leading `v`. The backend's
 *  Version (release.sh tag, e.g. "v0.31.18") already carries the prefix, so
 *  the old `v${state.current_version}` rendered "vv0.31.18". Non-numeric
 *  builds like "dev" are shown verbatim (no spurious "vdev"). */

/** Hosted lite build only: download the single self-contained offline copy
 *  (boardripper-lite.html). Sits in the top-right slot where the self-update
 *  badge lives on the backend build. Relative href so it resolves under the
 *  /boardripper/web/ sub-path. Hidden in the offline file itself (you can't
 *  re-download it while running from file://). */
function DownloadOfflineButton() {
  return (
    <a
      className="toolbar-btn"
      href="./boardripper-lite.html"
      download="boardripper-lite.html"
      data-testid="download-offline"
      title="Download BoardRipper as a single offline HTML file — save it to your computer and open it in any browser, no internet needed."
      style={{ display: 'inline-flex', alignItems: 'center', gap: 5, textDecoration: 'none' }}
    >
      <IconDownload size={15} stroke={2} />
      Offline copy
    </a>
  );
}

/** Small (i) next to the update badge: who wrote this, what it is, and where
 *  to support it. Renders in every build (lite/offline/Electron included) —
 *  unlike the update badge, which is backend-only — because this is the one
 *  always-visible place the project introduces itself. The long version lives
 *  in Settings ▸ About; keep the two in step, and both in step with the
 *  "Support the project" section on landing/index.html. */
function InfoBadge() {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  // Close on outside click — same pattern as UpdateBadge.
  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open]);

  return (
    <div className="update-badge-wrap" ref={ref}>
      <button
        data-testid="info-badge"
        className={`toolbar-btn toolbar-info-badge${open ? ' active' : ''}`}
        onClick={() => setOpen(v => !v)}
        title="About BoardRipper"
        aria-label="About BoardRipper"
      >
        <IconInfoCircle size={15} stroke={2} />
      </button>

      {open && (
        <div className="update-dropdown info-dropdown">
          <div className="update-dropdown-header">
            <div className="update-dropdown-header-main">
              <span>BoardRipper {fmtVersion(__APP_VERSION__)}</span>
            </div>
            <button className="update-dropdown-close" onClick={() => setOpen(false)}>x</button>
          </div>
          <div className="update-dropdown-body info-dropdown-body">
            <p>
              Built as a tool for my own repair shop, then shared once it turned out
              useful. Free software under AGPL-3.0 — no accounts, no paywall, no
              telemetry; your boards stay on your machine.
            </p>
            <p className="info-dropdown-author">by Alexey Lavrov — RipperDoc, Munich</p>
            <p>
              Development runs about €100 a month in AI tokens out of my own pocket.
              If BoardRipper is useful to you, support is genuinely appreciated.
            </p>
            <div className="info-dropdown-links">
              <a href="https://buymeacoffee.com/inwerp" target="_blank" rel="noopener noreferrer"
                className="info-dropdown-donate">Buy me a coffee</a>
              <a href="https://www.ripperdoc.de/boardripper/" target="_blank" rel="noopener noreferrer">Website</a>
              <a href="https://github.com/AlexeyInwerp/BoardRipper" target="_blank" rel="noopener noreferrer">Source</a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/** Dropdown showing release notes + update/download action */
function UpdateBadge({ update }: { update: ReturnType<typeof useUpdateStore> }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const { state, updating, progress } = update;

  // Close on outside click
  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open]);

  const manifest = state.manifest;
  const isImportant = manifest?.important === true;
  // A mirror is publishing a release this build cannot verify — almost always a
  // rotated signing key, but indistinguishable from a hostile mirror, which is
  // why nothing below is rendered from the manifest itself.
  const unverified = state.signature_mismatch === true && !state.has_update;
  // Release notes for an available update, embedded in the signed manifest.
  // Empty (→ spoiler not shown) when the manifest carries no notes.
  const pendingNotes = (state.has_update && manifest?.notes) ? manifest.notes : '';
  // Notes for the version RUNNING right now. The whole point: after the update
  // lands, has_update flips false and the pending notes go away — this is what
  // keeps "what changed" readable afterwards. Null when we have never seen a
  // manifest for this version (bundle install / dev build).
  const installed = update.installed;

  return (
    <div className="update-badge-wrap" ref={ref}>
      <button
        data-testid="update-badge"
        className={`toolbar-btn toolbar-update-badge${state.has_update ? ' has-update' : ''}${isImportant ? ' is-important' : ''}${unverified ? ' is-unverified' : ''}${updating ? ' is-updating' : ''}`}
        onClick={() => {
          // Mid-update the badge becomes a shortcut to the live progress
          // view: jump straight to the Debug tab instead of opening the
          // dropdown (which would show stale "Update & Restart" actions).
          if (updating) { showSidebarTab('debug'); return; }
          if (!open) updateStore.check();
          setOpen(v => !v);
        }}
        title={updating ? 'Updating — see Debug tab' : unverified ? 'Update available — manual install required (signature not verifiable by this build)' : state.has_update ? (isImportant ? `Important update: ${fmtVersion(state.latest_version)}` : `Update available: ${fmtVersion(state.latest_version)}`) : `${fmtVersion(state.current_version)} — click to check`}
      >
        {updating
          ? 'Updating…'
          : state.has_update
            // Alternates between the version on offer and the word for what to
            // do about it. Both sit in one grid cell so the badge keeps a
            // steady width; with reduced motion the word wins, since that is
            // the actionable half and the version is in the tooltip.
            ? (
              // aria-hidden: the two halves would read as one run-together
              // string. The button's title already says it in a sentence.
              <span className="update-badge-swap" aria-hidden="true">
                <span className="swap-version">{fmtVersion(state.latest_version)}</span>
                <span className="swap-word">Update</span>
              </span>
            )
            : fmtVersion(state.current_version)}
      </button>

      {open && (
        <div className={`update-dropdown${isImportant && state.has_update ? ' update-dropdown-important' : ''}`}>
          <div className="update-dropdown-header">
            <div className="update-dropdown-header-main">
              <span>{state.has_update ? (isImportant ? 'Important update' : 'Update available') : fmtVersion(state.current_version)}</span>
              {state.has_update && <span className="update-dropdown-version-tag">{fmtVersion(manifest?.version || state.latest_version)}</span>}
            </div>
            {isImportant && manifest?.important_reason && (
              <span className="update-dropdown-important-reason">{manifest.important_reason}</span>
            )}
            <button className="update-dropdown-close" onClick={() => setOpen(false)}>x</button>
          </div>

          {pendingNotes && (
            <details className="update-dropdown-notes" data-testid="update-whats-new">
              <summary>What&apos;s new in {fmtVersion(manifest?.version || state.latest_version)}</summary>
              <div className="update-dropdown-body">
                <ReleaseNotes notes={pendingNotes} />
              </div>
            </details>
          )}

          {!state.has_update && !updating && (
            <div className="update-dropdown-body">
              <p>You are on the latest version.</p>
            </div>
          )}

          {updating && progress.length > 0 && (
            <div className="update-dropdown-progress">
              {progress.map((e, i) => (
                <div key={i} className={`update-progress-line update-progress-${e.status}`}>
                  {e.message}
                </div>
              ))}
            </div>
          )}

          {unverified && (
            <div className="update-dropdown-unverified" data-testid="update-unverified">
              <p><b>Update available &mdash; manual install required</b></p>
              <p>
                A newer release is published, but this build cannot verify its
                signature, so it will not install it automatically.
              </p>
              <p>
                This normally means the release signing key has been rotated.
                Rotating the key is a security measure, and your install only
                trusts the key it was built with &mdash; that refusal is exactly
                what stops anyone else pushing an update to it.
              </p>
              <p>To update, pull the new image yourself:</p>
              <code>docker compose pull{'\n'}docker compose up -d</code>
              <p>
                The current signing key is published at{' '}
                <a
                  href="https://www.ripperdoc.de/boardripper/"
                  target="_blank"
                  rel="noopener noreferrer"
                >ripperdoc.de/boardripper</a>, so you can confirm the release is
                the maintainer&rsquo;s before installing it.
              </p>
            </div>
          )}

          {state.has_update && (
            <div className="update-dropdown-actions">
              {state.docker_available ? (
                <button
                  className="update-dropdown-btn"
                  disabled={updating}
                  onClick={() => {
                    // Reveal the Debug tab so the operator can watch the
                    // verbose progress log scroll as the orchestrator
                    // pulls images, swaps the container, and restarts.
                    showSidebarTab('debug');
                    updateStore.apply();
                    setOpen(false);
                  }}
                >
                  {updating ? 'Updating…' : 'Update & Restart'}
                </button>
              ) : (
                <a
                  className="update-dropdown-btn"
                  href="https://www.ripperdoc.de/boardripper/"
                  target="_blank"
                  rel="noopener"
                >
                  Download from ripperdoc.de
                </a>
              )}
              <div className="update-dropdown-actions-right">
                {state.docker_available && manifest?.notes_url && (
                  <a
                    className="update-dropdown-notes-link"
                    href={manifest.notes_url}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    Release notes ↗
                  </a>
                )}
                <span className="update-dropdown-version">
                  {fmtVersion(state.current_version)} &#8594; {fmtVersion(state.latest_version)}
                </span>
              </div>
            </div>
          )}

          {/* What the version you are RUNNING brought. Sits below the actions
              and carries its own version in the summary, so it can never be
              mistaken for the pending release's notes above. */}
          {installed && !updating && (
            <details className="update-dropdown-notes" data-testid="update-installed-notes">
              <summary>
                What&apos;s new in {fmtVersion(installed.version)}
                {state.has_update && <span className="update-dropdown-yours"> · yours</span>}
              </summary>
              <div className="update-dropdown-body">
                <ReleaseNotes notes={installed.notes} />
                {installed.notes_url && (
                  <a
                    className="update-dropdown-notes-link"
                    href={installed.notes_url}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    Full release notes ↗
                  </a>
                )}
              </div>
            </details>
          )}
        </div>
      )}
    </div>
  );
}

interface SearchResult { label: string; count: number; action: () => void; group: string }

/** Library files listed under the Library row before the "more" spoiler. */
const LIBRARY_HITS_SHOWN = 5;
/** Rows the spoiler may add; past that the Library panel is the list. */
const LIBRARY_HITS_CAP = 50;

/** The Library panel's own metadata filter (file name, board number,
 *  manufacturer, model), ranked so a board-number hit or a name that starts
 *  with the query comes first. Same predicate as the count the Library row
 *  shows, so the rows and the number agree. */
function libraryHitsFor(ql: string): DatabankFile[] {
  const hits: { f: DatabankFile; rank: number }[] = [];
  for (const f of databankStore.files) {
    const name = f.filename.toLowerCase();
    const bn = f.board_number?.toLowerCase() ?? '';
    let rank: number;
    if (bn && bn === ql) rank = 0;
    else if ((bn && bn.includes(ql)) || name.startsWith(ql)) rank = 1;
    else if (name.includes(ql)) rank = 2;
    else if (f.manufacturer?.toLowerCase().includes(ql) || f.model?.toLowerCase().includes(ql)) rank = 3;
    else continue;
    hits.push({ f, rank });
  }
  hits.sort((a, b) => a.rank - b.rank || a.f.filename.localeCompare(b.f.filename));
  return hits.map(h => h.f);
}

/** Second line of a library row: the board number when the file name does
 *  not already carry it, then the folder. */
function libraryHitSubtitle(f: DatabankFile): string {
  const folder = f.path.includes('/') ? f.path.slice(0, f.path.lastIndexOf('/')) : '';
  const bn = f.board_number && !f.filename.toLowerCase().includes(f.board_number.toLowerCase())
    ? f.board_number
    : '';
  return [bn, folder].filter(Boolean).join(' · ');
}

/** Open a library file from the dropdown the way a Library row does: it
 *  becomes the selected and most recent file, then the shared open path
 *  (cache first, bound PDFs, PDF panel) takes it. */
function openLibraryHit(f: DatabankFile): void {
  databankStore.selectFile(f.id);
  databankStore.addToHistory(f);
  openLibraryFileById(f.id).catch(err => log.ui.error('Global search: failed to open library file:', err));
}

/** Global search — searches board tabs, open PDFs, and library. Shows per-tab dropdown. */
export type Mode2R = 'all' | 'board' | 'pdf' | 'pin';
const MODE_KEY = '2r-search-mode';
function useMode2R(): [Mode2R, (m: Mode2R) => void] {
  const [m, set] = useState<Mode2R>(() => { try { return (localStorage.getItem(MODE_KEY) as Mode2R) || 'all'; } catch { return 'all'; } });
  return [m, (v: Mode2R) => { set(v); try { localStorage.setItem(MODE_KEY, v); } catch { /* */ } }];
}
const LUPA = <svg className="r2-search-ico" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="7" /><path d="M20 20l-3.5-3.5" /></svg>;

/** 2R (aprovado pelo Roger, 11/10/2026): UMA busca, maior, com Tudo / Placa / PDF (e Pinos,
 *  quando há um componente selecionado). Lembra a última escolha. */
function Search2R() {
  const [mode, setMode] = useMode2R();
  const snap = useBoardStore();
  const tab = snap.tabs.find(t => t.id === snap.activeTabId) ?? null;
  const hasPart = (tab?.selection?.partIndex ?? null) !== null;
  const opts: [Mode2R, string, string][] = [
    ['all', 'Tudo', 'Placa e PDF juntos (Enter)'], ['board', 'Placa', 'Só na placa: componente ou net'],
    ['pdf', 'PDF', 'Só no esquemático (PDF)'],
  ];
  if (hasPart) opts.push(['pin', 'Pinos', 'Pinos do componente selecionado']);
  const seg = (
    <div className="r2-seg" role="tablist">
      {opts.map(([m, l, t]) => (
        <button key={m} className={mode === m ? 'on' : ''} title={t} onMouseDown={e => e.preventDefault()}
                onClick={() => { setMode(m); setTimeout(() => fileInputRefs.search?.focus(), 0); }}>{l}</button>
      ))}
    </div>
  );
  if (mode === 'pin' && hasPart) return <PinSearch seg={seg} />;
  return <GlobalSearch mode={mode === 'pin' ? 'all' : mode} seg={seg} />;
}

function GlobalSearch({ mode = 'all', seg }: { mode?: Exclude<Mode2R, 'pin'>; seg?: React.ReactNode } = {}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const [query, setQuery] = useState('');
  const [open, setOpen] = useState(false);
  const [results, setResults] = useState<SearchResult[]>([]);
  // Library files matching the query, listed under the Library row. The
  // Library row itself stays: it opens the panel with the whole list.
  const [libraryHits, setLibraryHits] = useState<DatabankFile[]>([]);
  const [libraryExpanded, setLibraryExpanded] = useState(false);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Register search input ref for Cmd+F shortcut. Capture inputRef.current in
  // a local at effect-run time so the cleanup compares against the same
  // element we registered — React 19 may clear the ref before the cleanup
  // fires, which would otherwise leave the stale registration behind.
  useEffect(() => {
    const el = inputRef.current;
    fileInputRefs.search = el;
    return () => { if (fileInputRefs.search === el) fileInputRefs.search = null; };
  }, []);

  // Close on outside click
  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open]);

  const runSearch = useCallback((q: string) => {
    const ql = q.toLowerCase().trim();
    if (!ql) { setResults([]); setLibraryHits([]); setOpen(false); return; }

    const items: SearchResult[] = [];

    // Board tabs: count matching parts + nets per tab
    for (const tab of boardStore.tabs) {
      if (!tab.board) continue;
      const count = countInBoardTab(ql, tab.id);
      const label = tab.fileName.replace(/\.[^.]+$/, '');
      items.push({
        label, count, group: 'Board',
        action: () => { findInBoardTab(q, tab.id); },
      });
    }

    // PDF tabs: count matches per open document
    for (const fileName of pdfStore.loadedFileNames) {
      const count = countInPdf(ql, fileName);
      const label = fileName.replace(/\.[^.]+$/, '');
      items.push({
        label, count, group: 'PDF',
        action: () => { findInPdf(q, fileName); },
      });
    }

    // Library: by board_number, filename, manufacturer, model (same filter as LibraryPanel)
    const hits = libraryHitsFor(ql);
    items.push({
      label: 'Library', count: hits.length, group: 'Library',
      action: () => {
        databankStore.setViewMode('metadata');
        showSidebarTab('library');
        setLibrarySearch(q);
      },
    });
    setResults(items);
    setLibraryHits(hits);
    setLibraryExpanded(false);
    setOpen(true);
  }, []);

  // 2R (Roger, 11/10/2026): Enter = procura na placa E no PDF de uma vez
  const findBoth = useCallback((q: string) => {
    const t = q.trim();
    if (!t) return;
    const tab = boardStore.activeTab ?? boardStore.tabs.find(x => x.board) ?? null;
    if (tab?.board) findInBoardTab(t, tab.id);
    const fn = pdfStore.activeFileName2R ?? pdfStore.loadedFileNames[0];
    if (fn) setTimeout(() => findInPdf(t, fn), 30);
    setOpen(false);
  }, []);
  const [sync, setSync] = useState(searchSyncOn());

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const v = e.target.value;
    setQuery(v);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => runSearch(v), 250);
  };

  const libraryRow = results.find(r => r.group === 'Library');
  const shownHits = libraryExpanded ? libraryHits.slice(0, LIBRARY_HITS_CAP) : libraryHits.slice(0, LIBRARY_HITS_SHOWN);
  // Group results by category (2R: Placa / PDF mostram só o grupo deles)
  const groups = mode === 'board' ? ['Board'] : mode === 'pdf' ? ['PDF'] : ['Board', 'PDF', 'Library'];
  const enter2R = (q: string) => {
    const t = q.trim(); if (!t) return;
    if (mode === 'board') { const tb = boardStore.activeTab ?? boardStore.tabs.find(x => x.board) ?? null; if (tb?.board) findInBoardTab(t, tb.id); setOpen(false); return; }
    if (mode === 'pdf') { const fn = pdfStore.activeFileName2R ?? pdfStore.loadedFileNames[0]; if (fn) findInPdf(t, fn); setOpen(false); return; }
    findBoth(t);
  };
  const ph = !IS_2R ? 'Search parts, nets, PDFs, library'
    : mode === 'board' ? 'Buscar componente ou net na placa…'
    : mode === 'pdf' ? 'Buscar texto no esquemático (PDF)…'
    : 'Buscar componente, net ou texto do PDF…';

  return (
    <div className={'toolbar-search-wrap' + (IS_2R ? ' r2-search' : '')} ref={wrapRef}>
      {IS_2R && LUPA}
      <input
        ref={inputRef}
        type="text"
        placeholder={ph}
        className="toolbar-search"
        value={query}
        onChange={handleChange}
        onKeyDown={e => { if (IS_2R && e.key === 'Enter') { e.preventDefault(); enter2R(query); } }}
        onFocus={() => { if (query.trim()) runSearch(query); }}
        data-testid="search-input"
      />
      {open && query.trim() && results.length > 0 && (
        <div className="toolbar-search-dropdown">
          {IS_2R && mode === 'all' && (
            <button className="toolbar-search-option" onClick={() => findBoth(query)}>
              <span>Placa + PDF juntos</span><span className="toolbar-search-count">Enter</span>
            </button>
          )}
          {IS_2R && (
            <label className="toolbar-search-option r2-sync-opt" onMouseDown={e => e.preventDefault()}>
              <input type="checkbox" checked={sync} onChange={e => { setSync(e.target.checked); setSearchSync(e.target.checked); }} />
              <span>Buscar junto: o que procurar na placa vai para o PDF, e vice-versa</span>
            </label>
          )}
          {groups.map(group => {
            const groupItems = results.filter(r => r.group === group);
            if (groupItems.length === 0) return null;
            return groupItems.map((item, i) => (
              <button
                key={`${group}-${i}`}
                className="toolbar-search-option"
                onClick={() => { setOpen(false); item.action(); }}
              >
                <span className="toolbar-search-label">
                  <SearchScopeBadge scope={group.toLowerCase() as SearchScope} />
                  {item.label}
                </span>
                <span className="toolbar-search-count">{item.count}</span>
              </button>
            ));
          })}
          {shownHits.length > 0 && (
            <div className="toolbar-search-files" data-testid="search-library-files">
              {shownHits.map(f => (
                <button
                  key={f.id}
                  className="toolbar-search-file"
                  data-testid="search-library-file"
                  title={f.path}
                  onClick={() => { setOpen(false); openLibraryHit(f); }}
                >
                  <span className={`library-file-icon ${f.file_type === 'board' ? 'library-icon-board' : 'library-icon-pdf'}`}>
                    {f.file_type === 'board' ? 'B' : 'P'}
                  </span>
                  <span className="toolbar-search-file-text">
                    <span className="toolbar-search-file-name" translate="no">{f.filename}</span>
                    {libraryHitSubtitle(f) && (
                      <span className="toolbar-search-file-sub" translate="no">{libraryHitSubtitle(f)}</span>
                    )}
                  </span>
                </button>
              ))}
              {!libraryExpanded && libraryHits.length > LIBRARY_HITS_SHOWN && (
                <button
                  className="toolbar-search-more"
                  data-testid="search-library-more"
                  onClick={() => setLibraryExpanded(true)}
                >
                  {`${libraryHits.length - LIBRARY_HITS_SHOWN} more…`}
                </button>
              )}
              {libraryExpanded && libraryHits.length > LIBRARY_HITS_CAP && libraryRow && (
                <button
                  className="toolbar-search-more"
                  data-testid="search-library-all"
                  onClick={() => { setOpen(false); libraryRow.action(); }}
                >
                  {`Show all ${libraryHits.length} in the Library`}
                </button>
              )}
            </div>
          )}
        </div>
      )}
      {seg}
    </div>
  );
}

export function Toolbar() {
  const fileInputRef = useRef<HTMLInputElement>(null);
  // pdfInputRef removed — single Open button + unified file picker now.
  const { activeTabId } = useBoardStore();
  const [twoWindow, setTwoWindow] = useState(isTwoWindowMode());
  useEffect(() => onTwoWindowModeChange(() => setTwoWindow(isTwoWindowMode())), []);

  const update = useUpdateStore();

  useEffect(() => {
    fileInputRefs.board = fileInputRef.current;
    // Both Open Board and Open PDF shortcuts now route through the unified
    // file input — picker shows boards + PDFs together and the change handler
    // splits them by extension.
    fileInputRefs.pdf = fileInputRef.current;
    return () => { fileInputRefs.board = null; fileInputRefs.pdf = null; };
  }, []);

  const handleFileOpen = () => {
    fileInputRef.current?.click();
  };

  /**
   * Single Open button — accepts both board files and PDFs in the same picker.
   * Splits selected files by extension and routes each to the right loader.
   */
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) { e.target.value = ''; return; }
    const all = Array.from(files);
    const pdfs: File[] = [];
    const boards: File[] = [];
    for (const f of all) {
      if (getFileExtension(f.name).toLowerCase() === '.pdf') {
        pdfs.push(f);
      } else {
        boards.push(f);
      }
    }
    if (boards.length > 0) {
      // Reuse the existing FileList-based loader by feeding it just the boards.
      // boardStore.loadFiles wants a FileList — synthesise one via DataTransfer.
      const dt = new DataTransfer();
      for (const f of boards) dt.items.add(f);
      await boardStore.loadFiles(dt.files);
    }
    if (pdfs.length > 0) {
      await openPdfFiles(pdfs, { activeTabId });
    }
    e.target.value = '';
  };

  // Delegated, viewport-clamped tooltip for [data-tooltip] buttons. Replaces a
  // pure-CSS ::after, which couldn't clamp and spilled off-screen for buttons
  // near the toolbar's right/left edge.
  const [tip, setTip] = useState<{ text: string; x: number; y: number } | null>(null);
  const tipRef = useRef<HTMLDivElement>(null);

  const showTip = useCallback((e: React.MouseEvent) => {
    const el = (e.target as HTMLElement).closest('[data-tooltip]') as HTMLElement | null;
    const text = el?.getAttribute('data-tooltip');
    if (!el || !text) return;
    const r = el.getBoundingClientRect();
    const z = uiZoom();
    setTip({ text, x: (r.left + r.width / 2) / z, y: r.bottom / z + 8 });
  }, []);
  const hideTip = useCallback((e: React.MouseEvent) => {
    const from = (e.target as HTMLElement).closest('[data-tooltip]');
    const to = e.relatedTarget instanceof HTMLElement ? e.relatedTarget.closest('[data-tooltip]') : null;
    if (from && from !== to) setTip(null);
  }, []);

  // After render, nudge the tooltip back inside the viewport (horizontal clamp;
  // flip above the button if it would overflow the bottom).
  useLayoutEffect(() => {
    const el = tipRef.current;
    if (!el || !tip) return;
    const pad = 8;
    el.style.left = `${tip.x}px`;
    el.style.top = `${tip.y}px`;
    el.style.transform = 'translateX(-50%)';
    const r = el.getBoundingClientRect();
    const z = uiZoom();
    let dx = 0;
    if (r.right > window.innerWidth - pad) dx = (window.innerWidth - pad) - r.right;
    else if (r.left < pad) dx = pad - r.left;
    if (dx) el.style.transform = `translateX(calc(-50% + ${Math.round(dx / z)}px))`;
    if (r.bottom > window.innerHeight - pad) el.style.top = `${tip.y - r.height / z - 16}px`;
  }, [tip]);

  return (
    <div className="toolbar" data-testid="toolbar" onMouseOver={showTip} onMouseOut={hideTip}>
      {tip && createPortal(
        <div
          ref={tipRef}
          className="toolbar-tooltip"
          style={{ position: 'fixed', left: tip.x, top: tip.y, transform: 'translateX(-50%)' }}
        >
          {tip.text}
        </div>,
        document.body,
      )}
      <input
        ref={fileInputRef}
        type="file"
        /* NO `accept` in the browser — deliberate, and load-bearing on iPad.
         *
         * Safari resolves each `accept` extension token to a UTI. `.pdf` maps
         * to com.adobe.pdf; every board extension we support (`.pcb`, `.bvr`,
         * `.fz`, `.brd`, `.tvw`, `.kicad_pcb`, …) is unregistered on iOS, so it
         * resolves to a dynamic UTI that matches nothing. The Files picker then
         * greys out every board file and offers PDFs only — which on a tablet,
         * where there is no drag-and-drop, means the app cannot open a board at
         * all. Android pickers degrade the same way for extensions with no MIME
         * mapping.
         *
         * Filtering buys nothing here anyway: `detectFormat` sniffs header
         * bytes and only falls back to the extension, and drag-and-drop has
         * never filtered. Electron keeps the list — a native dialog resolves
         * these extensions correctly and gives the user a real "All Files"
         * escape, so there the filter is help rather than a wall. */
        {...(isElectron() ? { accept: [...getAllExtensions(), '.pdf'].join(',') } : {})}
        multiple
        onChange={handleFileChange}
        style={{ display: 'none' }}
        data-testid="file-input"
      />
      {/* ── App bar (v0.39): the bar is about the app, the board's own bar is
          about the board. Sidebar cycle and Open on the left, search in the
          centre, window mode / about / version on the right. Side, rotate,
          mirror, butterfly and traces live in the board ribbon now — same
          store actions, same shortcuts, only the button's home moved. ── */}
      {/* 2R 22/10/2026: o botão do painel lateral foi para o canto direito da barra */}
      {/* 2R Tools: menus de texto na MESMA barra dos ícones (Roger, 10/10/2026: «a barra de
          ícones pode subir para a mesma barra do menu… ganha espaço de visualização») */}
      {IS_2R && <MenuBar2R inline />}
      {/* 2R: «Abrir» fica no menu Arquivo (Ctrl+O) — sobra espaço para a busca (11/10/2026) */}
      <button
        onClick={handleFileOpen}
        className="toolbar-btn toolbar-quiet"
        style={IS_2R ? { display: 'none' } : undefined}
        data-testid="open-btn"
        data-tooltip={isElectron() ? 'Open boards or PDFs' : 'Open boards or PDFs from your device'}
      >
        <IconUpload size={16} stroke={1.75} />{!IS_2R && 'Open'}
      </button>

      {/* 2R Tools: uma barra só (padrão FlexBV) — as funções 2R entram aqui mesmo */}
      {IS_2R && <NavBar2R inline />}

      {/* ── Search, centred ── (2R: à direita, com escopo «Tudo / No componente») */}
      <div className="toolbar-spacer" />
      {IS_2R ? <Search2R /> : <GlobalSearch />}
      {IS_2R && <ThemeButton2R />}
      {!IS_2R && <div className="toolbar-spacer" />}

      {/* Pop-out needs a real second window. The offline single file has no
       *  popout.html to open, and a tablet's window.open is a new tab (iPadOS)
       *  or nothing — so the control is hidden where it can only fail. Read
       *  once at render: the pointer type does not change. */}
      {/* 2R: «2 janelas» fica no menu Exibir — libera espaço p/ o logo e o tema. */}
      {!IS_2R && !isOfflineBuild() && !COARSE_POINTER && (
        <button
          onClick={() => toggleTwoWindowMode()}
          className={`toolbar-btn toolbar-quiet ${twoWindow ? 'active' : ''}`}
          data-testid="two-window-toggle"
          data-tooltip={twoWindow
            ? '2-window mode ON — click to re-dock PDF into main window'
            : '2-window mode — detach PDF viewer into its own window'}
        >
          {twoWindow
            ? <IconBoxMultiple size={16} stroke={1.75} />
            : <IconLayoutBoardSplit size={16} stroke={1.75} />}
          {!IS_2R && <span>2-Window</span>}
        </button>
      )}
      {IS_2R && <img className="r2-toolbar-logo" src={logo2r} alt="2R Tools" title="2R Tools" draggable={false} />}

      {/* "Save as BVR3" was a permanently-disabled placeholder (export path
          still has a side-inversion bug). Dead chrome trains users to ignore
          the toolbar — removed until the feature actually ships, at which
          point it belongs in an overflow menu. exportToBVR3 stays in parsers. */}

      <InfoBadge />
      {!isElectron() && !isLiteBuild() && <UpdateBadge update={update} />}
      <SidebarCycleButton />
      {isLiteBuild() && !isOfflineBuild() && <DownloadOfflineButton />}
    </div>
  );
}
