import { showSidebarTab } from './Sidebar.utils';
import { useBoardStore } from '../hooks/useBoardStore';
import { useEffect, useRef, useState } from 'react';
import {
  IconFocusCentered, IconZoomIn, IconZoomOut, IconRotate, IconRotateClockwise, IconFlipVertical,
  IconMicroscope, IconStack2, IconContrast, IconSearch, IconBooks, IconLayoutColumns, IconChevronDown,
  IconLayersSubtract, IconButterfly, IconRotate2, IconFlipHorizontal, IconHierarchy, IconFolderOpen,
  IconArrowLeft, IconArrowRight, IconAppWindow, IconPlus, IconRestore,
  IconSunOff, IconPalette, IconTag, IconRoute, IconGauge, IconTargetArrow, IconComponents,
  createReactComponent,
} from '@tabler/icons-react';
import { boardStore } from '../store/board-store';
import { pdfStore } from '../store/pdf-store';
import { viewCommands } from '../store/view-commands';
import {
  getDockviewApi, ensureMicroscopePanel, applySplitLayout, SPLIT_LABELS, type SplitLayout,
} from '../store/dockview-api';
import { useCameraOverlay, toggleCameraOverlay, setCameraOverlay } from '../store/camera-overlay';
import { toggleLibrarySidebar } from './Sidebar.utils';
import { fileInputRefs } from '../store/file-inputs';
import { historyBack, historyForward } from '../store/nav-history-actions';
import { isTwoWindowMode, setTwoWindowMode } from '../store/two-window-mode';
import { togglePartFilter } from './PartFilter2R';

/**
 * 2R Tools: barra de funções livre (Roger, 10/10/2026).
 * - arrasta um botão de um lado para o outro; ele «cola» (magnético) no vizinho;
 * - «+» adiciona funções novas; botão direito tira da barra ou volta ao padrão;
 * - a arrumação fica guardada neste computador.
 */

function onPdf(): boolean {
  return (getDockviewApi()?.activePanel?.id ?? '').startsWith('pdf-');
}

function flipSide() {
  const { showTop, showBottom, butterfly, board } = boardStore;
  if (butterfly) return;
  const swap = board?.primarySide === 'bottom';
  const uiTop = swap ? showBottom : showTop;
  if (uiTop) boardStore.selectBottom(); else boardStore.selectTop();
}

type Item = { id: string; label: string; short?: string; title: string; icon: React.ReactNode; run?: () => void };

const I = (C: typeof IconZoomIn) => <C size={16} stroke={1.75} />;
// 2R 23/10 a 27/10/2026: ícones próprios da barra (padrão FlexBV)
const IconZoomOutBig = createReactComponent('outline', '2r-zoom-out-big', 'ZoomOutBig', [['path', { d: 'M3 12a9 9 0 1 0 18 0a9 9 0 1 0 -18 0', key: 'svg-0' }], ['path', { d: 'M9 12h6', key: 'svg-1' }]]);
const IconZoomInBig = createReactComponent('outline', '2r-zoom-in-big', 'ZoomInBig', [['path', { d: 'M3 12a9 9 0 1 0 18 0a9 9 0 1 0 -18 0', key: 'svg-0' }], ['path', { d: 'M9 12h6', key: 'svg-1' }], ['path', { d: 'M12 9v6', key: 'svg-2' }]]);
const IconClearSearch = createReactComponent('outline', '2r-clear-search', 'ClearSearch', [['path', { d: 'M18 6l-12 12', key: 'svg-0' }], ['path', { d: 'M6 6l12 12', key: 'svg-1' }]]);
const IconShot = createReactComponent('outline', '2r-shot', 'Shot', [['path', { d: 'M5 7h1a2 2 0 0 0 2 -2a1 1 0 0 1 1 -1h6a1 1 0 0 1 1 1a2 2 0 0 0 2 2h1a2 2 0 0 1 2 2v9a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2v-9a2 2 0 0 1 2 -2', key: 'svg-0' }], ['path', { d: 'M9 13a3 3 0 1 0 6 0a3 3 0 1 0 -6 0', key: 'svg-1' }]]);
const IconSqT = createReactComponent('outline', 'square-letter-t', 'SquareLetterT', [['path', { d: 'M3 5a2 2 0 0 1 2 -2h14a2 2 0 0 1 2 2v14a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2v-14', key: 'svg-0' }], ['path', { d: 'M10 8h4', key: 'svg-1' }], ['path', { d: 'M12 8v8', key: 'svg-2' }]]);
const IconSqB = createReactComponent('outline', 'square-letter-b', 'SquareLetterB', [['path', { d: 'M3 5a2 2 0 0 1 2 -2h14a2 2 0 0 1 2 2v14a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2v-14', key: 'svg-0' }], ['path', { d: 'M10 16h2a2 2 0 1 0 0 -4h-2h2a2 2 0 1 0 0 -4h-2v8', key: 'svg-1' }]]);
const IconScreen2 = createReactComponent('outline', '2r-screen2', 'Screen2', [['path', { d: 'M2 6a1 1 0 0 1 1 -1h8a1 1 0 0 1 1 1v6a1 1 0 0 1 -1 1h-8a1 1 0 0 1 -1 -1z', key: 'svg-0' }], ['path', { d: 'M12 9h9a1 1 0 0 1 1 1v6a1 1 0 0 1 -1 1h-8a1 1 0 0 1 -1 -1', key: 'svg-1' }], ['path', { d: 'M5 13v3h3', key: 'svg-2' }], ['path', { d: 'M15 17v3m-2 0h4', key: 'svg-3' }]]);
const r2w = window as unknown as { __2rShot?: () => void; __2rScreen2?: () => void };

/** Todas as funções que podem ir para a barra. */
const CATALOG: Item[] = [
  { id: 'fit', label: 'Centralizar', short: 'Centralizar', title: 'Centralizar: a placa inteira na tela', icon: I(IconFocusCentered), run: () => viewCommands.fit() },
  { id: 'zoomIn', label: 'Aproximar (zoom +)', title: 'Aproximar (zoom +)', icon: I(IconZoomIn), run: () => viewCommands.zoom('in') },
  { id: 'zoomOut', label: 'Afastar (zoom −)', title: 'Afastar (zoom −)', icon: I(IconZoomOut), run: () => viewCommands.zoom('out') },
  { id: 'rotL', label: 'Girar para a esquerda', title: 'Girar para a esquerda (placa ou PDF ativo)', icon: I(IconRotate),
    run: () => (onPdf() ? pdfStore.rotateActive('ccw') : boardStore.rotateCCW()) },
  { id: 'rotR', label: 'Girar para a direita', title: 'Girar para a direita (placa ou PDF ativo)', icon: I(IconRotateClockwise),
    run: () => (onPdf() ? pdfStore.rotateActive('cw') : boardStore.rotateCW()) },
  { id: 'rot180', label: 'Girar 180°', title: 'Girar a placa 180°', icon: I(IconRotate2), run: () => boardStore.rotate180() },
  { id: 'mirror', label: 'Espelhar', short: 'Espelhar', title: 'Espelhar (mirror) — placa ou PDF ativo (tecla M)', icon: I(IconFlipVertical),
    run: () => (onPdf() ? pdfStore.mirrorActive() : boardStore.flipHorizontal()) },
  { id: 'flipV', label: 'Espelhar na vertical', title: 'Espelhar a placa na vertical', icon: I(IconFlipHorizontal), run: () => boardStore.flipVertical() },
  { id: 'side', label: 'Virar a placa', short: 'Virar', title: 'Virar a placa: lado superior ↔ inferior (Espaço)', icon: I(IconLayersSubtract), run: flipSide },
  { id: 'butterfly', label: 'Borboleta (os dois lados)', title: 'Borboleta: os dois lados lado a lado', icon: I(IconButterfly), run: () => boardStore.toggleButterfly() },
  { id: 'netLines', label: 'Linhas das nets', title: 'Linhas das nets: desligado → estrela → corrente', icon: I(IconHierarchy), run: () => boardStore.cycleNetLineMode() },
  { id: 'back', label: 'Voltar', title: 'Voltar para a visão anterior', icon: I(IconArrowLeft), run: () => { historyBack(); } },
  { id: 'forward', label: 'Avançar', title: 'Avançar para a próxima visão', icon: I(IconArrowRight), run: () => { historyForward(); } },
  { id: 'mic', label: 'Microscópio', short: 'Microscópio', title: 'Microscópio — câmera USB ao lado da placa', icon: I(IconMicroscope), run: () => ensureMicroscopePanel() },
  { id: 'merge', label: 'Mesclar', short: 'Mesclar', title: 'Mesclar a imagem real (câmera ou foto) com a placa', icon: I(IconStack2), run: () => toggleCameraOverlay() },
  { id: 'transp', label: 'Transparência', short: 'Transparência', title: 'Transparência da imagem mesclada e dos pinos', icon: I(IconContrast) },
  { id: 'search', label: 'Busca local', short: 'Busca local', title: 'Busca local: componente, net ou arquivo deste computador', icon: I(IconSearch),
    run: () => { const el = document.querySelector<HTMLInputElement>('.toolbar-search'); if (el) { el.focus(); el.select(); } } },
  { id: 'library', label: 'Biblioteca local', short: 'Biblioteca', title: 'Biblioteca local (pasta deste computador)', icon: I(IconBooks), run: () => toggleLibrarySidebar() },
  { id: 'open', label: 'Abrir arquivo', short: 'Abrir', title: 'Abrir boardview ou PDF deste computador', icon: I(IconFolderOpen), run: () => fileInputRefs.board?.click() },
  { id: 'twoWin', label: '2 janelas', title: 'PDF numa segunda janela', icon: I(IconAppWindow), run: () => setTwoWindowMode(!isTwoWindowMode()) },
  { id: 'micGroup', label: 'Microscópio (câmera, mesclar, transparência)', short: 'Microscópio', title: 'Microscópio: câmera ao lado, mesclar com a placa e transparência', icon: I(IconMicroscope) },
  // Roger (22:50): «voltar o ícone que desativa a função de deixar o resto da placa escuro,
  // ativar ou não as nets, pode pôr mais funções na barra»
  { id: 'dim', label: 'Escurecer o resto da placa', short: 'Escurecer', title: 'Escurecer o resto da placa ao selecionar: desligado → escurecer → foco', icon: I(IconSunOff), run: () => boardStore.cycleDimMode() },
  { id: 'legend', label: 'Cores das nets', short: 'Cores', title: 'Mostrar / esconder a legenda das cores das nets', icon: I(IconPalette), run: () => window.dispatchEvent(new Event('2r-legend-toggle')) },
  { id: 'parts', label: 'Componentes por grupo', short: 'Componentes', title: 'Mostrar / ocultar componentes por grupo (CI, MOSFET, resistor, capacitor…) — para ver as nets', icon: I(IconComponents), run: () => togglePartFilter() },
  { id: 'labels', label: 'Nomes na placa', short: 'Nomes', title: 'Mostrar / esconder os nomes (componentes e nets) na placa', icon: I(IconTag), run: () => boardStore.toggleLabels() },
  { id: 'seq', label: 'Sequência de start', short: 'Start', title: 'Sequência de start (setas do teclado)', icon: I(IconRoute), run: () => showSidebarTab('guide' as never) },
  { id: 'meter', label: 'Medições', short: 'Medições', title: 'Medições com multímetro (Rigol / i2C)', icon: I(IconGauge), run: () => showSidebarTab('meter' as never) },
  { id: 'focusSel', label: 'Ir para a seleção', short: 'Seleção', title: 'Levar a câmera até o componente selecionado', icon: I(IconTargetArrow), run: () => { const t = boardStore.activeTab; const pi = t?.selection.partIndex; if (t?.board && pi != null) boardStore.focusPart(t.board.parts[pi].name); } },
  { id: 'zoomOutBig', label: 'Afastar (passo grande)', title: 'Afastar (passo grande)', icon: I(IconZoomOutBig), run: () => { viewCommands.zoom('out'); viewCommands.zoom('out'); viewCommands.zoom('out'); } },
  { id: 'zoomInBig', label: 'Aproximar (passo grande)', title: 'Aproximar (passo grande)', icon: I(IconZoomInBig), run: () => { viewCommands.zoom('in'); viewCommands.zoom('in'); viewCommands.zoom('in'); } },
  { id: 'clearSearch', label: 'Limpar a busca', title: 'Limpar a busca e a seleção (Esc)', icon: I(IconClearSearch), run: () => {
    try { boardStore.setSearch(''); } catch { /* */ }
    try { boardStore.selectPart(null); } catch { /* */ }
    try { boardStore.highlightNet(null); } catch { /* */ }
    try {
      const i = document.querySelector('.toolbar-search') as HTMLInputElement | null;
      if (i) { Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')!.set!.call(i, ''); i.dispatchEvent(new Event('input', { bubbles: true })); }
    } catch { /* */ }
  } },
  { id: 'shot', label: 'Foto da tela', title: 'Foto da tela: salva a placa em PNG (Documentos › 2R Tools › Downloads › Prints da placa) e copia', icon: I(IconShot),
    run: () => { try { if (r2w.__2rShot) r2w.__2rShot(); else boardStore.addToast('A foto da tela só funciona dentro do SDS.', 'info'); } catch { /* */ } } },
  { id: 'split', label: 'Dividir tela', short: 'Dividir tela', title: 'Dividir a tela: escolha o que fica lado a lado', icon: I(IconLayoutColumns) },
  { id: 'top', label: 'Top (lado de cima)', short: 'Top', title: 'Mostrar o lado de cima (top) da placa', icon: I(IconSqT), run: () => boardStore.selectTop() },
  { id: 'bottom', label: 'Bottom (lado de baixo)', short: 'Bottom', title: 'Mostrar o lado de baixo (bottom) da placa', icon: I(IconSqB), run: () => boardStore.selectBottom() },
  { id: 'screen2', label: 'Segunda tela', short: 'Segunda tela', title: 'Segunda tela: leva o Boardview para o outro monitor em tela cheia (de novo volta para o app)', icon: I(IconScreen2),
    run: () => { try { if (r2w.__2rScreen2) r2w.__2rScreen2(); else boardStore.addToast('Segunda tela só funciona dentro do SDS', 'info'); } catch { /* */ } } },
];
const BY_ID = Object.fromEntries(CATALOG.map(c => [c.id, c]));
const SEP = 'sep';

// 2R 23/10/2026: barra no padrão FlexBV (os básicos; 24/10: os dois girar juntos)
const DEFAULT_LAYOUT = ['split', 'zoomOut', 'zoomIn', 'zoomOutBig', 'zoomInBig', 'rotL', 'rotR', 'flipV', 'mirror', 'fit', 'clearSearch', 'netLines', 'shot',
  SEP, 'side', SEP, 'dim', 'legend', 'parts', SEP, 'micGroup', SEP, 'screen2'];
export const NAVBAR_LAYOUT_KEY = '2r-navbar-layout-v6';
const KEY = NAVBAR_LAYOUT_KEY; // v6 (23/10/2026)
const R2_MIGRA_ROT_MOVED = false;   // v4: linhas das nets, escurecer e cores na barra (22:50)   // v3: microscópio agrupado   // v2: uma barra só (padrão FlexBV) — 10/10/2026

function loadLayout(): string[] {
  try {
    const v = JSON.parse(localStorage.getItem(KEY) || 'null');
    if (Array.isArray(v)) {
      const l = v.filter((x: unknown) => x === SEP || (typeof x === 'string' && BY_ID[x]));
      // 11/10/2026: botão «Componentes por grupo» entra uma vez, ao lado das Cores
      try {
        if (!localStorage.getItem('2r-navbar-parts-added') && !l.includes('parts')) {
          const i = l.indexOf('legend'); l.splice(i >= 0 ? i + 1 : l.length, 0, 'parts');
          localStorage.setItem('2r-navbar-parts-added', '1'); localStorage.setItem(KEY, JSON.stringify(l));
        }
      } catch { /* */ }
      // 2R 24/10/2026: os dois «girar» lado a lado (uma vez)
      try {
        if (!localStorage.getItem('2r-navbar-rot-juntos')) {
          const a = l.indexOf('rotL'), r = l.indexOf('rotR');
          if (a >= 0 && r >= 0 && r !== a + 1) { l.splice(r, 1); l.splice(l.indexOf('rotL') + 1, 0, 'rotR'); }
          localStorage.setItem('2r-navbar-rot-juntos', '1'); localStorage.setItem(KEY, JSON.stringify(l));
        }
      } catch { /* */ }
      // 2R 27/10/2026 (Roger: «remover os ícones T (top) B (bottom), sendo que já tem dentro do BDV» / «remover o ícone
      // borboleta do menu»): sai da barra salva uma vez; continuam disponíveis para pôr de volta
      try {
        if (!localStorage.getItem('2r-navbar-sem-lados')) {
          for (const x of ['top', 'bottom', 'butterfly']) { const k = l.indexOf(x); if (k >= 0) l.splice(k, 1); }
          for (let k = l.length - 1; k > 0; k--) if (l[k] === SEP && l[k - 1] === SEP) l.splice(k, 1);
          localStorage.setItem('2r-navbar-sem-lados', '1'); localStorage.setItem(KEY, JSON.stringify(l));
        }
      } catch { /* */ }
      // 11/10/2026: girar e espelhar tinham saído da barra — 23/10/2026 voltaram (padrão FlexBV); migração desligada
      try {
        if (R2_MIGRA_ROT_MOVED) {
          const m = l.filter(x => x !== 'rotL' && x !== 'rotR' && x !== 'mirror');
          localStorage.setItem('2r-navbar-rot-moved', '1'); localStorage.setItem(KEY, JSON.stringify(m));
          return m;
        }
      } catch { /* */ }
      return l;
    }
  } catch { /* sem armazenamento */ }
  return [...DEFAULT_LAYOUT];
}
function saveLayout(l: string[]) { try { localStorage.setItem(KEY, JSON.stringify(l)); } catch { /* */ } }

function usePopover(): [boolean, (v: boolean) => void, React.RefObject<HTMLDivElement | null>] {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    if (!open) return;
    const onDoc = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false); };
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    document.addEventListener('mousedown', onDoc);
    document.addEventListener('keydown', onKey);
    return () => { document.removeEventListener('mousedown', onDoc); document.removeEventListener('keydown', onKey); };
  }, [open]);
  return [open, setOpen, ref];
}

function Face({ it, extra }: { it: Item; extra?: React.ReactNode }) {
  return <>{it.icon}{extra}{it.short && <span className="nav2r-label">{it.short}</span>}</>;
}

function TransparencyPop({ onClose: _onClose }: { onClose: () => void }) {
  const cam = useCameraOverlay();
  return (
    <div className="nav2r-pop">
      {!cam.on && (
        <div className="nav2r-hint">
          A transparência vale com o Mesclar ligado.{' '}
          <button className="nav2r-link" onClick={() => toggleCameraOverlay()}>Ligar o Mesclar</button>
        </div>
      )}
      <label className="nav2r-row">
        <span>Imagem</span>
        <input type="range" min={0} max={100} value={cam.opacity} onChange={e => setCameraOverlay({ opacity: Number(e.target.value) })} />
        <b>{cam.opacity}%</b>
      </label>
      {cam.mode === 'pins' && (
        <label className="nav2r-row">
          <span>Pinos</span>
          <input type="range" min={0} max={100} value={cam.pinsOpacity} onChange={e => setCameraOverlay({ pinsOpacity: Number(e.target.value) })} />
          <b>{cam.pinsOpacity}%</b>
        </label>
      )}
    </div>
  );
}

function MicPop({ onClose }: { onClose: () => void }) {
  const cam = useCameraOverlay();
  return (
    <div className="nav2r-pop nav2r-menu nav2r-micpop">
      <button className="nav2r-item nav2r-item-ico" onClick={() => { ensureMicroscopePanel(); onClose(); }}>
        <IconMicroscope size={15} /><span>Câmera ao lado da placa</span>
      </button>
      <button className={`nav2r-item nav2r-item-ico ${cam.on ? 'sel' : ''}`} onClick={() => toggleCameraOverlay()}>
        <IconStack2 size={15} /><span>{cam.on ? 'Mesclar: ligado' : 'Mesclar com a placa'}</span>
      </button>
      <div className="nav2r-menu-sep" />
      <TransparencyPop onClose={onClose} />
    </div>
  );
}

const SPLITS: SplitLayout[] = ['board', 'board-pdf', 'board-mic', 'pdf-mic', 'board-pdf-mic'];
function SplitPop({ onClose }: { onClose: () => void }) {
  const [cur, setCur] = useState<string>(() => { try { return localStorage.getItem('2r-split-layout') || ''; } catch { return ''; } });
  return (
    <div className="nav2r-pop nav2r-menu">
      {SPLITS.map(l => (
        <button key={l} className={`nav2r-item ${cur === l ? 'sel' : ''}`}
                onClick={() => { setCur(l); try { localStorage.setItem('2r-split-layout', l); } catch { /* */ } onClose(); applySplitLayout(l); }}>
          {SPLIT_LABELS[l]}
        </button>
      ))}
    </div>
  );
}

/** Um botão da barra (arrastável). */
function Slot({ id, idx, drag }: { id: string; idx: number; drag: DragApi }) {
  const cam = useCameraOverlay();
  const [open, setOpen, ref] = usePopover();
  const it = BY_ID[id];
  const pop = id === 'transp' || id === 'split' || id === 'micGroup';
  const bs = useBoardStore();
  const active = (id === 'merge' && cam.on) || (pop && open)
    || (id === 'dim' && bs.dimMode !== 'off') || (id === 'netLines' && bs.netLineMode !== 'off')
    || (id === 'butterfly' && bs.butterfly);
  return (
    <div className={`nav2r-slot ${drag.markAt(idx)}`} ref={ref}
         draggable onDragStart={e => drag.start(e, idx)} onDragOver={e => drag.over(e, idx)}
         onDrop={e => drag.drop(e)} onDragEnd={drag.end}
         onContextMenu={e => drag.menu(e, idx)}>
      <button className={`nav2r-btn ${active ? 'active' : ''}`} title={it.title} tabIndex={-1}
              onClick={() => (pop ? setOpen(!open) : it.run?.())}>
        <Face it={it} extra={id === 'split' ? <IconChevronDown size={12} stroke={2} /> : undefined} />
      </button>
      {open && id === 'transp' && <TransparencyPop onClose={() => setOpen(false)} />}
      {open && id === 'split' && <SplitPop onClose={() => setOpen(false)} />}
      {open && id === 'micGroup' && <MicPop onClose={() => setOpen(false)} />}
    </div>
  );
}

interface DragApi {
  start: (e: React.DragEvent, idx: number) => void;
  over: (e: React.DragEvent, idx: number) => void;
  drop: (e: React.DragEvent) => void;
  end: () => void;
  markAt: (idx: number) => string;
  menu: (e: React.MouseEvent, idx: number) => void;
}

export function NavBar2R({ inline = false }: { inline?: boolean } = {}) {
  const [layout, setLayout] = useState<string[]>(loadLayout);
  const [from, setFromS] = useState<number | null>(null);
  const [mark, setMarkS] = useState<{ idx: number; side: 'l' | 'r' } | null>(null);
  // refs: o arrastar lê o valor na hora (o estado do React só muda no próximo desenho)
  const fromRef = useRef<number | null>(null);
  const markRef = useRef<{ idx: number; side: 'l' | 'r' } | null>(null);
  const setFrom = (v: number | null) => { fromRef.current = v; setFromS(v); };
  const setMark = (v: { idx: number; side: 'l' | 'r' } | null) => { markRef.current = v; setMarkS(v); };
  const [ctx, setCtx] = useState<{ x: number; y: number; idx: number } | null>(null);
  const [addOpen, setAddOpen, addRef] = usePopover();
  const barRef = useRef<HTMLDivElement | null>(null);

  const commit = (l: string[]) => {
    // separadores não ficam duplicados nem nas pontas
    const clean = l.filter((x, i, a) => !(x === SEP && (i === 0 || a[i - 1] === SEP))).filter((x, i, a) => !(x === SEP && i === a.length - 1));
    setLayout(clean); saveLayout(clean);
  };

  useEffect(() => {
    if (!ctx) return;
    const close = () => setCtx(null);
    document.addEventListener('mousedown', close);
    return () => document.removeEventListener('mousedown', close);
  }, [ctx]);

  const drag: DragApi = {
    start: (e, idx) => { setFrom(idx); e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', String(idx)); },
    over: (e, idx) => {
      if (fromRef.current === null) return;
      e.preventDefault();
      // «magnético»: gruda à esquerda ou à direita do vizinho, pela metade em que o mouse está
      const r = (e.currentTarget as HTMLElement).getBoundingClientRect();
      const side = e.clientX < r.left + r.width / 2 ? 'l' : 'r';
      const m = markRef.current;
      if (!m || m.idx !== idx || m.side !== side) setMark({ idx, side });
    },
    drop: (e) => {
      e.preventDefault();
      const f = fromRef.current, m = markRef.current;
      if (f === null || !m) return drag.end();
      const l = [...layout];
      const [moved] = l.splice(f, 1);
      let to = m.idx + (m.side === 'r' ? 1 : 0);
      if (f < to) to -= 1;
      l.splice(to, 0, moved);
      commit(l); drag.end();
    },
    end: () => { setFrom(null); setMark(null); },
    markAt: (idx) => [from === idx ? 'dragging' : '', mark?.idx === idx ? `snap-${mark.side}` : ''].join(' '),
    menu: (e, idx) => { e.preventDefault(); setCtx({ x: e.clientX, y: e.clientY, idx }); },
  };

  const missing = CATALOG.filter(c => !layout.includes(c.id));
  const add = (id: string) => { commit([...layout, id]); };

  return (
    <div className={`nav2r-bar${inline ? ' nav2r-inline' : ''}`} data-testid="nav2r-bar" ref={barRef}
         onDragOver={e => { if (fromRef.current !== null) e.preventDefault(); }}
         onDrop={e => { const f = fromRef.current; if (f !== null && !markRef.current) { e.preventDefault(); const l = [...layout]; const [m] = l.splice(f, 1); l.push(m); commit(l); drag.end(); } }}>
      {layout.map((id, i) => id === SEP
        ? <div key={'sep' + i} className={`nav2r-slot nav2r-sepslot ${drag.markAt(i)}`} draggable
               onDragStart={e => drag.start(e, i)} onDragOver={e => drag.over(e, i)} onDrop={drag.drop} onDragEnd={drag.end}
               onContextMenu={e => drag.menu(e, i)} title="Separador (arraste ou botão direito para tirar)"><span className="nav2r-sep" /></div>
        : <Slot key={id} id={id} idx={i} drag={drag} />)}
      <div className="nav2r-pop-wrap" ref={addRef}>
        <button className="nav2r-btn nav2r-add" title="Adicionar função à barra" onClick={() => setAddOpen(!addOpen)}>
          <IconPlus size={15} stroke={2} />
        </button>
        {addOpen && (
          <div className="nav2r-pop nav2r-menu nav2r-addmenu">
            <div className="nav2r-hint">Adicionar à barra (depois é só arrastar para o lugar):</div>
            {missing.map(c => (
              <button key={c.id} className="nav2r-item nav2r-item-ico" onClick={() => { add(c.id); }}>
                {c.icon}<span>{c.label}</span>
              </button>
            ))}
            <button className="nav2r-item" onClick={() => add(SEP)}>│ Separador</button>
            <div className="nav2r-menu-sep" />
            <button className="nav2r-item nav2r-item-ico" onClick={() => { commit([...DEFAULT_LAYOUT]); setAddOpen(false); }}>
              <IconRestore size={15} /><span>Voltar a barra ao padrão</span>
            </button>
          </div>
        )}
      </div>
      {ctx && (
        <div className="nav2r-pop nav2r-menu nav2r-ctx" style={{ position: 'fixed', left: ctx.x, top: ctx.y }}
             onMouseDown={e => e.stopPropagation()}>
          <button className="nav2r-item" onClick={() => { const l = [...layout]; l.splice(ctx.idx, 1); commit(l); setCtx(null); }}>
            Tirar da barra
          </button>
          <button className="nav2r-item" onClick={() => { const l = [...layout]; l.splice(ctx.idx + 1, 0, SEP); commit(l); setCtx(null); }}>
            Pôr um separador depois
          </button>
          <button className="nav2r-item" onClick={() => { commit([...DEFAULT_LAYOUT]); setCtx(null); }}>
            Voltar a barra ao padrão
          </button>
        </div>
      )}
    </div>
  );
}
