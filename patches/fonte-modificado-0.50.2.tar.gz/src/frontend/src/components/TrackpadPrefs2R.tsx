import { useEffect, useState } from 'react';
import { IconX } from '@tabler/icons-react';

/** 2R Tools: Preferências › Mouse e trackpad — aparelho (automático/mouse/trackpad), velocidades (ao vivo). */
export function openTrackpadPrefs() { window.dispatchEvent(new Event('2r-trackpad-open')); }

const get = (k: string, d: string) => { try { return localStorage.getItem(k) ?? d; } catch { return d; } };
const put = (k: string, v: string) => { try { localStorage.setItem(k, v); } catch { /* */ } };

export function TrackpadPrefs2R() {
  const [open, setOpen] = useState(false);
  const [pan, setPan] = useState(() => parseFloat(get('2r-trackpad-pan', '1.4')));
  const [zoom, setZoom] = useState(() => parseFloat(get('2r-trackpad-zoom', '1.4')));
  const [direct, setDirect] = useState(() => get('2r-trackpad-direto', '1') !== '0');
  // 2R 20/10/2026: FlexBV é o padrão; 27/10/2026: roda do mouse 1,6× (chave nova «2r-mouse-zoom2»), até 5×
  const [mode, setMode] = useState(() => get('2r-pointer-mode', 'flexbv'));
  const [mz, setMz] = useState(() => parseFloat(get('2r-mouse-zoom2', '1.6')));
  const [invM, setInvM] = useState(() => get('2r-mouse-invert', '0') === '1');
  const [invP, setInvP] = useState(() => get('2r-pan-invert', '0') === '1');
  const setInv = (m: boolean, p: boolean) => { setInvM(m); setInvP(p); put('2r-mouse-invert', m ? '1' : '0'); put('2r-pan-invert', p ? '1' : '0'); };
  useEffect(() => {
    const fn = () => setOpen(true);
    const key = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    window.addEventListener('2r-trackpad-open', fn); window.addEventListener('keydown', key);
    return () => { window.removeEventListener('2r-trackpad-open', fn); window.removeEventListener('keydown', key); };
  }, []);
  if (!open) return null;
  const row = (label: string, v: number, set: (n: number) => void, k: string) => (
    <label className="r2-tp-row">
      <span>{label} <b>{v.toFixed(1).replace('.', ',')}×</b></span>
      <input type="range" min={0.5} max={3} step={0.1} value={v} disabled={!direct}
             onChange={e => { const n = parseFloat(e.target.value); set(n); put(k, String(n)); }} />
    </label>
  );
  return (
    <div className="r2-tp">
      <div className="r2-setwin-head"><b>Mouse e trackpad</b><span className="r2-setwin-sub">vale na hora — teste na placa</span>
        <button className="r2-setwin-x" title="Fechar (Esc)" onClick={() => setOpen(false)}><IconX size={15} /></button></div>
      <div className="r2-tp-body">
        <label className="r2acv-check"><input type="checkbox" checked={direct}
          onChange={e => { setDirect(e.target.checked); put('2r-trackpad-direto', e.target.checked ? '1' : '0'); }} /> Trackpad direto (resposta imediata)</label>
        <div className="r2-tp-mode">
          <span>Estou usando</span>
          {([['flexbv', 'FlexBV (padrão)'], ['auto', 'Automático'], ['mouse', 'Mouse'], ['trackpad', 'Trackpad']] as const).map(([v, t]) => (
            <label key={v} className="r2acv-check"><input type="radio" name="r2pm" checked={mode === v} disabled={!direct}
              onChange={() => { setMode(v); put('2r-pointer-mode', v); }} /> {t}</label>
          ))}
        </div>
        <div className="r2acv-note">FlexBV: dois dedos para baixo aumenta e para cima diminui (roda do mouse: para cima aumenta); arrastar com o clique move a placa. Mouse: a roda amplia e reduz. Trackpad: dois dedos arrastam e a pinça amplia. Automático descobre sozinho.</div>
        <label className="r2-tp-row">
          <span>Zoom pela roda do mouse <b>{mz.toFixed(1).replace('.', ',')}×</b></span>
          <input type="range" min={0.5} max={5} step={0.1} value={mz} disabled={!direct || mode === 'trackpad'}
                 onChange={e => { const n = parseFloat(e.target.value); setMz(n); put('2r-mouse-zoom2', String(n)); }} />
        </label>
        <div className="r2-tp-mode">
          <span>Direção</span>
          <button className="r2meter-btn r2meter-off" disabled={!direct} onClick={() => setInv(false, false)}>Padrão Windows</button>
          <button className="r2meter-btn r2meter-off" disabled={!direct} onClick={() => setInv(true, true)}>Padrão Mac (rolagem natural)</button>
        </div>
        <label className="r2acv-check"><input type="checkbox" checked={invM}
          onChange={e => setInv(e.target.checked, invP)} /> Inverter a roda do mouse</label>
        <label className="r2acv-check"><input type="checkbox" checked={invP} disabled={!direct}
          onChange={e => setInv(invM, e.target.checked)} /> Inverter os dois dedos do trackpad</label>
        {row('Velocidade ao arrastar (dois dedos)', pan, setPan, '2r-trackpad-pan')}
        {row('Velocidade da pinça (zoom)', zoom, setZoom, '2r-trackpad-zoom')}
        <div className="r2-tp-actions">
          <button className="r2meter-btn r2meter-off" onClick={() => { setPan(1.4); setZoom(1.4); setMz(1.6); setMode('flexbv'); put('2r-trackpad-pan', '1.4'); put('2r-trackpad-zoom', '1.4'); put('2r-mouse-zoom2', '1.6'); put('2r-pointer-mode', 'flexbv'); setInv(false, false); }}>Voltar ao padrão</button>
        </div>
        <div className="r2acv-note">Desligando o «direto», volta o jeito original do BoardRipper.</div>
      </div>
    </div>
  );
}
